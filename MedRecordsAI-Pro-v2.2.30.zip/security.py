import functools
import hashlib
import hmac
import html
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import datetime, timezone
from flask import Flask, request, session, jsonify, redirect, url_for, make_response, g
DEFAULT_ADMIN_USER = 'admin'

def _hash_password_bcrypt(password: str) -> str:
    import bcrypt
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(12)).decode()

def _verify_password_bcrypt(password: str, stored_hash: str) -> bool:
    import bcrypt
    if stored_hash.startswith('$2b$') or stored_hash.startswith('$2a$'):
        return bcrypt.checkpw(password.encode(), stored_hash.encode())
    logger.warning('Stored hash is not bcrypt format — rejecting credentials')
    return False

class RateLimiter:

    def __init__(self):
        self._buckets = defaultdict(lambda: {'tokens': 0, 'last_refill': 0.0})

    def is_allowed(self, key: str, max_tokens: int, refill_rate: float) -> bool:
        now = time.time()
        bucket = self._buckets[key]
        elapsed = now - bucket['last_refill']
        bucket['tokens'] = min(max_tokens, bucket['tokens'] + elapsed * refill_rate)
        bucket['last_refill'] = now
        if bucket['tokens'] >= 1:
            bucket['tokens'] -= 1
            return True
        return False

    def cleanup(self, max_age_seconds: int=3600):
        now = time.time()
        stale = [k for k, v in self._buckets.items() if now - v['last_refill'] > max_age_seconds]
        for k in stale:
            del self._buckets[k]
_limiter = RateLimiter()
_last_cleanup = time.time()

def rate_limit(requests_per_minute: int=30, burst: int=None):
    burst = burst or requests_per_minute
    refill_rate = requests_per_minute / 60.0

    def decorator(f):

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            global _last_cleanup
            client_ip = request.remote_addr or 'unknown'
            key = f'{f.__name__}:{client_ip}'
            if not _limiter.is_allowed(key, burst, refill_rate):
                return (jsonify({'error': 'Rate limit exceeded. Please try again later.'}), 429)
            now = time.time()
            if now - _last_cleanup > 600:
                _limiter.cleanup()
                _last_cleanup = now
            return f(*args, **kwargs)
        return wrapper
    return decorator

def _generate_csrf_token() -> str:
    token = secrets.token_hex(32)
    session['_csrf_token'] = token
    return token

def get_csrf_token() -> str:
    if '_csrf_token' not in session:
        return _generate_csrf_token()
    return session['_csrf_token']

def _validate_csrf():
    if request.method in ('GET', 'HEAD', 'OPTIONS'):
        return
    if request.path in ('/login', '/logout'):
        return
    if request.path.startswith('/api/secure-upload/'):
        return
    if request.path == '/api/crm/demo-download':
        return
    if request.headers.get('X-API-Key'):
        return
    token = request.headers.get('X-CSRF-Token') or request.form.get('_csrf_token') or (request.get_json(silent=True) or {}).get('_csrf_token')
    expected = session.get('_csrf_token')
    if not token or not expected or (not hmac.compare_digest(token, expected)):
        return (jsonify({'error': 'CSRF validation failed'}), 403)
SESSION_IDLE_TIMEOUT = int(os.getenv('SESSION_IDLE_TIMEOUT', '1800'))

def _check_session_idle():
    if not session.get('authenticated'):
        return
    now = time.time()
    last_activity = session.get('_last_activity', 0)
    if last_activity and now - last_activity > SESSION_IDLE_TIMEOUT:
        username = session.get('username', 'unknown')
        session.clear()
        if request.path.startswith('/api/'):
            return (jsonify({'error': 'Session expired due to inactivity'}), 401)
        return redirect('/login')
    session['_last_activity'] = now

def require_auth(f):

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('authenticated'):
            g.auth_user = session.get('username', 'session_user')
            return f(*args, **kwargs)
        api_key = request.headers.get('X-API-Key')
        expected_key = os.getenv('API_KEY')
        if api_key and expected_key and hmac.compare_digest(api_key, expected_key):
            g.auth_user = 'api_key_user'
            return f(*args, **kwargs)
        if request.path.startswith('/api/'):
            return (jsonify({'error': 'Authentication required'}), 401)
        return redirect('/login')
    return wrapper

def _check_credentials(username: str, password: str) -> bool:
    expected_user = os.getenv('AUTH_USERNAME', DEFAULT_ADMIN_USER)
    expected_hash = os.getenv('AUTH_PASSWORD_HASH')
    if not hmac.compare_digest(username, expected_user):
        return False
    if not expected_hash:
        logger.error('AUTH_PASSWORD_HASH not set — authentication disabled')
        return False
    return _verify_password_bcrypt(password, expected_hash)

def _add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    is_file_view = request.path.startswith('/api/files/') and request.path.endswith('/view')
    if is_file_view:
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        frame_ancestors = "frame-ancestors 'self'; "
    else:
        response.headers['X-Frame-Options'] = 'DENY'
        frame_ancestors = "frame-ancestors 'none'; "
    csp = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; " + frame_ancestors + "base-uri 'self'; form-action 'self'"
    response.headers['Content-Security-Policy'] = csp
    if os.getenv('DISABLE_HSTS') != '1':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    if request.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
        response.headers['Pragma'] = 'no-cache'
    return response
EMAIL_RE = re.compile('^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$')
MAX_FIELD_LENGTHS = {'contact_name': 200, 'contact_email': 254, 'organization': 300, 'patient_case_ref': 100, 'record_type_needed': 100, 'notes': 2000, 'priority': 20, 'contact_type': 50}

def validate_contact_input(data: dict) -> list:
    errors = []
    if not data:
        return ['Request body is required']
    name = data.get('contact_name', '').strip()
    email = data.get('contact_email', '').strip()
    if not name:
        errors.append('contact_name is required')
    if not email:
        errors.append('contact_email is required')
    elif not EMAIL_RE.match(email):
        errors.append('contact_email is not a valid email address')
    for field, max_len in MAX_FIELD_LENGTHS.items():
        value = data.get(field, '')
        if isinstance(value, str) and len(value) > max_len:
            errors.append(f'{field} exceeds maximum length of {max_len} characters')
    valid_types = {'custodian', 'counsel', 'patient', 'provider'}
    if data.get('contact_type') and data['contact_type'] not in valid_types:
        errors.append(f"contact_type must be one of: {', '.join(valid_types)}")
    valid_priorities = {'normal', 'high', 'urgent'}
    if data.get('priority') and data['priority'] not in valid_priorities:
        errors.append(f"priority must be one of: {', '.join(valid_priorities)}")
    return errors

def sanitize_string(value: str, max_length: int=500) -> str:
    if not isinstance(value, str):
        return ''
    return html.escape(value.strip()[:max_length])

def validate_startup_config(app, config: dict, logger) -> list:
    warnings = []
    errors = []
    secret = app.secret_key
    if not secret or secret in ('dev-secret-change-me', 'change-this'):
        errors.append('CRITICAL: Flask secret key is not set or uses default value. Set FLASK_SECRET_KEY environment variable.')
    auth_hash = os.getenv('AUTH_PASSWORD_HASH', '')
    if not auth_hash:
        errors.append('CRITICAL: AUTH_PASSWORD_HASH not set. Login is disabled. Generate with: python -c "import bcrypt; print(bcrypt.hashpw(b\'your-password\', bcrypt.gensalt(12)).decode())"')
    elif not (auth_hash.startswith('$2b$') or auth_hash.startswith('$2a$')):
        errors.append('CRITICAL: AUTH_PASSWORD_HASH is not a bcrypt hash. Must start with $2b$ or $2a$.')
    api_key = os.getenv('API_KEY', '')
    if not api_key:
        warnings.append('WARNING: No API_KEY set. API key authentication is disabled.')
    smtp_host = os.getenv('SMTP_HOST', '')
    if smtp_host and smtp_host in ('smtp.example.com', ''):
        warnings.append('WARNING: SMTP_HOST is not configured. Email retrieval bot will not function.')
    bedrock_key = os.getenv('AWS_BEARER_TOKEN_BEDROCK', '')
    if not bedrock_key:
        warnings.append('WARNING: AWS_BEARER_TOKEN_BEDROCK not set. Bedrock LLM calls will fail. Add your API key via Settings > LLM Backend.')
    if os.getenv('DISABLE_SECURE_COOKIE') == '1' and os.getenv('BEHIND_REVERSE_PROXY') != '1':
        warnings.append('WARNING: Running without TLS. HIPAA requires encryption in transit. Deploy behind a TLS-terminating reverse proxy (nginx, Caddy, AWS ALB) or set BEHIND_REVERSE_PROXY=1 if TLS is handled upstream.')
    try:
        from db import check_disk_encryption
        encrypted, detail = check_disk_encryption()
        if encrypted is True:
            logger.info('Disk encryption: %s', detail)
        elif encrypted is False:
            warnings.append(f'WARNING: Disk encryption not detected ({detail}). HIPAA requires encryption of ePHI at rest. Enable BitLocker (Windows), FileVault (macOS), or LUKS (Linux).')
        else:
            warnings.append(f'WARNING: Could not verify disk encryption — {detail}')
    except Exception as e:
        warnings.append(f'WARNING: Disk encryption check failed — {e}')
    for w in warnings:
        logger.warning(w)
    for e in errors:
        logger.error(e)
    return warnings + errors

def sign_audit_entry(entry: dict) -> str:
    key = os.getenv('AUDIT_HMAC_KEY', os.getenv('FLASK_SECRET_KEY', ''))
    if not key:
        key = 'unsigned-audit-entry'
    canonical = {k: v for k, v in sorted(entry.items()) if k != 'hmac_signature'}
    import json
    payload = json.dumps(canonical, sort_keys=True, default=str)
    return hmac.new(key.encode(), payload.encode(), hashlib.sha256).hexdigest()

def verify_audit_signature(entry: dict) -> bool:
    stored_sig = entry.get('hmac_signature')
    if not stored_sig:
        return False
    expected_sig = sign_audit_entry(entry)
    return hmac.compare_digest(stored_sig, expected_sig)

def init_security(app: Flask):
    secret = os.getenv('FLASK_SECRET_KEY', '')
    if secret:
        app.secret_key = secret
    elif not app.secret_key:
        app.secret_key = secrets.token_hex(32)
        app.logger.warning("No FLASK_SECRET_KEY set. Generated ephemeral key (sessions won't survive restart). Set FLASK_SECRET_KEY in .env for production.")
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_COOKIE_SECURE'] = os.getenv('DISABLE_SECURE_COOKIE') != '1'
    app.config['PERMANENT_SESSION_LIFETIME'] = 28800

    @app.before_request
    def idle_check():
        result = _check_session_idle()
        if result:
            return result

    @app.before_request
    def csrf_check():
        result = _validate_csrf()
        if result:
            return result

    @app.context_processor
    def inject_csrf():
        return {'csrf_token': get_csrf_token}
    app.after_request(_add_security_headers)

    @app.route('/api/csrf-token')
    def csrf_token_endpoint():
        return jsonify({'csrf_token': get_csrf_token()})