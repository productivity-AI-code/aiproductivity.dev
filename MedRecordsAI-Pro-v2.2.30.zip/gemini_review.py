"""
gemini_review.py -- Gemini CLI integration for medical summary accuracy review.

Pipes summary JSON + PHI-redacted source content to Gemini CLI via stdin,
receives structured JSON review output with inaccuracies, unsupported claims,
and omitted findings.

Usage (standalone test):
    python gemini_review.py --summary path/to/summary.json --source path/to/redacted.txt
"""

import json
import logging
import shutil
import subprocess
import sys
import platform
from datetime import datetime, timezone
from pathlib import Path

from pipeline_schemas import extract_json_from_response, validate_review_output, REVIEW_SCHEMA_EXAMPLE

logger = logging.getLogger("gemini_review")

# Windows subprocess flags to hide console window
_STARTUPINFO = None
_CREATION_FLAGS = 0
if platform.system() == "Windows":
    _STARTUPINFO = subprocess.STARTUPINFO()
    _STARTUPINFO.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    _CREATION_FLAGS = subprocess.CREATE_NO_WINDOW


def _gemini_cmd():
    """Return the correct Gemini CLI command name for the platform.
    On Windows, subprocess needs 'gemini.cmd' (the npm shim), not 'gemini'."""
    if platform.system() == "Windows":
        # Try gemini.cmd first (npm global install), fall back to gemini
        if shutil.which("gemini.cmd"):
            return "gemini.cmd"
    return "gemini"


def is_gemini_available():
    """Check if Gemini CLI is installed and on PATH."""
    return shutil.which(_gemini_cmd()) is not None


def run_gemini_review(summary_json, redacted_source, config=None):
    """
    DEPRECATED: Redirects to run_bedrock_review() for HIPAA compliance.
    Gemini CLI is not BAA-covered — all review calls must go through Bedrock.
    """
    logger.warning("run_gemini_review() is deprecated — routing to run_bedrock_review()")
    return run_bedrock_review(summary_json, redacted_source, config)


# ── AWS Bedrock Review (HIPAA-compliant replacement for Gemini CLI) ──────────

def run_bedrock_review(summary_json, redacted_source, config=None):
    """
    Run AWS Bedrock Claude to review a medical summary against PHI-redacted source.
    HIPAA-compliant via AWS BAA. Drop-in replacement for run_gemini_review().

    Args:
        summary_json: dict -- the summary to review
        redacted_source: str -- PHI-redacted source content (all files concatenated)
        config: dict -- config with bedrock.review_model, bedrock.review_timeout

    Returns:
        dict -- review output conforming to REVIEW_SCHEMA_EXAMPLE, or None on failure
    """
    from dispatch import call_bedrock

    bedrock_cfg = (config or {}).get("bedrock", {})
    review_model = bedrock_cfg.get("review_model", "us.anthropic.claude-sonnet-4-5-v2:0")
    timeout = bedrock_cfg.get("review_timeout", 300)
    retries = bedrock_cfg.get("retries", 2)

    # Build the review prompt with schema example
    schema_str = json.dumps(REVIEW_SCHEMA_EXAMPLE, indent=2)
    summary_str = json.dumps(summary_json, indent=2)

    system_prompt = (
        "You are a medical-legal accuracy reviewer. Your task is to compare "
        "the SUMMARY below against the SOURCE DOCUMENT (PHI-redacted). "
        "For every factual claim in the summary, verify it is supported by the source.\n\n"
        "Identify:\n"
        "1. **Inaccuracies**: Claims that contradict the source (wrong dates, wrong "
        "providers, wrong measurements, transposed values)\n"
        "2. **Unsupported claims**: Claims with no evidence in the source\n"
        "3. **Omitted findings**: Critical findings in the source that are missing "
        "from the summary\n\n"
        "Output ONLY valid JSON matching this schema:\n"
        f"```json\n{schema_str}\n```\n\n"
        "Set accuracy_score between 0.0 (all wrong) and 1.0 (perfect). "
        "If everything checks out, return empty arrays and score ~0.98-1.0."
    )

    # Content size safeguard — truncate source if it would exceed model limits
    # Reserve ~20K tokens for summary + schema + output
    max_source_chars = 600000  # ~150K tokens, conservative
    if len(redacted_source) > max_source_chars:
        logger.warning("Review source too large (%d chars), truncating to %d",
                       len(redacted_source), max_source_chars)
        redacted_source = redacted_source[:max_source_chars]

    user_content = (
        f"## SUMMARY TO REVIEW\n```json\n{summary_str}\n```\n\n"
        f"## SOURCE DOCUMENT (PHI-REDACTED)\n{redacted_source}\n"
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    for attempt in range(1, retries + 1):
        try:
            logger.info("Bedrock review attempt %d/%d (model=%s, timeout=%ds)",
                        attempt, retries, review_model.split(".")[-1], timeout)

            raw_output = call_bedrock(
                model_id=review_model,
                messages=messages,
                config=config or {},
                timeout_override=timeout,
                max_tokens_override=16384,
            )

            if not raw_output or raw_output.startswith("__ERROR__:"):
                logger.warning("Bedrock review returned error: %s",
                               raw_output[:200] if raw_output else "(empty)")
                if attempt < retries:
                    continue
                return None

            parsed = extract_json_from_response(raw_output)
            if parsed is None:
                logger.warning("Could not extract JSON from Bedrock review (%d chars)",
                               len(raw_output))
                if attempt < retries:
                    continue
                return None

            # Validate
            errors = validate_review_output(parsed)
            critical = [e for e in errors if e.startswith("CRITICAL")]
            if critical:
                logger.warning("Bedrock review output validation failed: %s", critical)
                if attempt < retries:
                    continue
                return None

            # Ensure timestamp is set
            if not parsed.get("review_timestamp"):
                parsed["review_timestamp"] = datetime.now(timezone.utc).isoformat()
            parsed["reviewer"] = "bedrock"

            logger.info("Bedrock review complete: accuracy=%.2f, inaccuracies=%d, "
                        "unsupported=%d, omitted=%d",
                        parsed.get("accuracy_score", 0),
                        len(parsed.get("inaccuracies_found", [])),
                        len(parsed.get("unsupported_claims", [])),
                        len(parsed.get("omitted_findings", [])))
            return parsed

        except RuntimeError as e:
            err_str = str(e)
            logger.warning("Bedrock review attempt %d/%d failed: %s",
                           attempt, retries, err_str[:200])
            if attempt < retries:
                continue
            logger.warning("Bedrock review failed after %d attempts -- skipping", retries)
            return None

        except Exception as e:
            logger.warning("Bedrock review unexpected error: %s", e)
            if attempt < retries:
                continue
            return None

    return None


# ── Standalone test ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    logging.basicConfig(level=logging.INFO, format="%(levelname)-8s %(message)s")

    parser = argparse.ArgumentParser(description="Test Gemini review")
    parser.add_argument("--summary", required=True, help="Path to summary JSON")
    parser.add_argument("--source", required=True, help="Path to redacted source text")
    args = parser.parse_args()

    with open(args.summary) as f:
        summary = json.load(f)
    with open(args.source) as f:
        source = f.read()

    result = run_gemini_review(summary, source)
    if result:
        print(json.dumps(result, indent=2))
    else:
        print("Review failed or was skipped", file=sys.stderr)
        sys.exit(1)
