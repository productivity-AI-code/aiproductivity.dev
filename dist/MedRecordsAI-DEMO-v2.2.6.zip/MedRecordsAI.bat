@echo off
setlocal EnableDelayedExpansion
title MedRecords AI
color 0F

echo.
echo  ================================================================
echo    MedRecords AI - Intelligent Document Analysis Platform
echo    HIPAA-Compliant Medical Record Summarization
echo  ================================================================
echo.

:: Check if this is a demo build
if exist "%~dp0.demo_build" (
    echo  ----------------------------------------------------------------
    echo    DEMO VERSION - 14 Day Trial ^| 3 Cases ^| Core Features Only
    echo  ----------------------------------------------------------------
    echo.
)

:: Check if this is a licensed build (Core/Pro)
if exist "%~dp0.build_info" (
    if not exist "%~dp0.demo_build" (
        echo  ----------------------------------------------------------------
        echo    Licensed Build - Activation Required on First Launch
        echo  ----------------------------------------------------------------
        echo.
    )
)

:: ── Auto-Extract: detect if running from inside a ZIP ────────────────
:: When Windows runs a .bat from inside a ZIP, only the .bat itself is
:: extracted to a temp dir. Check for a required file to detect this.
if not exist "%~dp0setup_wizard.py" (
    echo  It looks like you opened this from inside the ZIP file.
    echo  MedRecords AI needs to be extracted first.
    echo.

    :: Try to find the ZIP in Downloads or next to this bat's original location
    set "INSTALL_DIR=%USERPROFILE%\MedRecordsAI"

    echo  Installing to: !INSTALL_DIR!
    echo.

    :: Look for the ZIP in common download locations
    set "ZIP_FOUND="
    for %%D in ("%USERPROFILE%\Downloads" "%USERPROFILE%\Desktop" "%~dp0..") do (
        for %%F in ("%%~D\MedRecordsAI*.zip") do (
            if exist "%%~F" (
                set "ZIP_FOUND=%%~F"
            )
        )
    )

    if not defined ZIP_FOUND (
        echo  [ERROR] Could not find the MedRecords AI ZIP file.
        echo.
        echo  Please extract the ZIP manually:
        echo    1. Right-click the ZIP file
        echo    2. Select "Extract All..."
        echo    3. Choose a folder like: %USERPROFILE%\MedRecordsAI
        echo    4. Run MedRecordsAI.bat from the extracted folder
        echo.
        pause
        exit /b 1
    )

    echo  Found: !ZIP_FOUND!
    echo  Extracting...
    echo.

    :: Use PowerShell to extract (available on all modern Windows)
    powershell -NoProfile -Command "Expand-Archive -LiteralPath '!ZIP_FOUND!' -DestinationPath '!INSTALL_DIR!' -Force" 2>nul

    if %ERRORLEVEL% NEQ 0 (
        echo  [ERROR] Extraction failed. Please extract manually:
        echo    Right-click the ZIP ^> Extract All ^> Choose a folder
        echo.
        pause
        exit /b 1
    )

    echo  [OK] Extracted successfully.
    echo.

    :: Relaunch from the extracted location
    if exist "!INSTALL_DIR!\MedRecordsAI.bat" (
        start "" "!INSTALL_DIR!\MedRecordsAI.bat"
        exit /b 0
    )

    :: Check if ZIP had a top-level folder
    for /d %%D in ("!INSTALL_DIR!\*") do (
        if exist "%%D\MedRecordsAI.bat" (
            start "" "%%D\MedRecordsAI.bat"
            exit /b 0
        )
    )

    echo  [ERROR] Could not find MedRecordsAI.bat in extracted files.
    echo  Please run it manually from: !INSTALL_DIR!
    pause
    exit /b 1
)

:: ── Reset Mode: clean slate for testing first-time flow ──────────────
if /i not "%~1"=="--reset" goto :skip_reset

echo  Resetting for fresh install test...
echo.

:: Stop any running services gracefully
if exist "%~dp0start_medical.py" (
    python "%~dp0start_medical.py" --stop >nul 2>&1
)

:: Kill any zombie process on port 8080
python -c "import subprocess,re; [subprocess.run(['taskkill','/F','/PID',p]) for l in subprocess.run(['netstat','-aon'],capture_output=True,text=True).stdout.splitlines() if ':8080' in l and 'LISTENING' in l for p in [l.split()[-1]] if p.isdigit()]" >nul 2>&1

:: Delete runtime files
del /q "%~dp0.installed" 2>nul
del /q "%~dp0.env" 2>nul
del /q "%~dp0config.yaml" 2>nul
del /q "%~dp0medical_records.db" 2>nul
del /q "%~dp0medical_records.db-shm" 2>nul
del /q "%~dp0medical_records.db-wal" 2>nul

:: Clear vault, logs, staging, pipeline status
if exist "%~dp0vault" rmdir /s /q "%~dp0vault" 2>nul
if exist "%~dp0logs" rmdir /s /q "%~dp0logs" 2>nul
if exist "%~dp0staging" rmdir /s /q "%~dp0staging" 2>nul

echo  [OK] Reset complete. Running first-time setup...
echo.

:skip_reset

:: ── First Run: Install ────────────────────────────────────────────────
if exist "%~dp0.installed" goto :launch

echo  First-time setup detected. Starting installation...
echo.

:: Check Python
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [ERROR] Python not found. Install Python 3.10+ from python.org
    echo          Make sure "Add Python to PATH" is checked during install.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python found
echo.

:: Install Flask first (needed for setup wizard)
echo  Preparing setup wizard...
python -m pip install flask -q >nul 2>&1

:: Launch browser-based setup wizard
echo  Opening setup wizard in your browser...
echo  (If it doesn't open automatically, go to http://localhost:9876)
echo.
python "%~dp0setup_wizard.py"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [INFO] Setup wizard closed. Checking if setup completed...
)

:: Verify setup completed
if not exist "%~dp0.installed" (
    echo.
    echo  [ERROR] Setup was not completed. Please run this file again.
    echo.
    pause
    exit /b 1
)

echo.
echo  [OK] Setup verified.
echo.

:: ── Launch ────────────────────────────────────────────────────────────
:launch
echo  Starting MedRecords AI...
echo.

:: Stop any previously tracked services so start_medical.py won't refuse
if exist "%~dp0logs\medical_services.json" (
    python "%~dp0start_medical.py" --stop >nul 2>&1
)

python "%~dp0start_medical.py" --auto-open

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [ERROR] Failed to start. Check the logs folder for details.
    pause
    exit /b 1
)

echo.
echo  Press any key to stop MedRecords AI...
pause >nul

echo.
echo  Stopping services...
python "%~dp0start_medical.py" --stop
echo  Done.
timeout /t 2 >nul
