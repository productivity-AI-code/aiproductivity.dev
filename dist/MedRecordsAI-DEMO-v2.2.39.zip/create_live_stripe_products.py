#!/usr/bin/env python3
"""
Create MedRecords AI products and prices in Stripe LIVE mode.

Usage:
    python create_live_stripe_products.py --key sk_live_YOUR_KEY
    python create_live_stripe_products.py  # uses STRIPE_LIVE_SECRET_KEY env var

After running, update stripe_webhook.py PRODUCTS dict with the new price IDs.
"""
import argparse
import json
import os
import sys

try:
    import stripe
except ImportError:
    print("ERROR: stripe package not installed. Run: pip install stripe")
    sys.exit(1)


PRODUCTS_TO_CREATE = [
    {
        "name": "MedRecords AI Core",
        "description": (
            "AI-powered medical records summarization for personal injury law firms. "
            "Core license includes: automated summarization pipeline, chronological "
            "organization, citation verification, billing analysis, and "
            "HIPAA-compliant processing."
        ),
        "metadata": {"tier": "core", "type": "license"},
        "prices": [
            {
                "label": "Core License (Launch Sale)",
                "unit_amount": 399700,  # $3,997
                "currency": "usd",
                "recurring": None,
                "metadata": {"tier": "core", "sale": "launch"},
            },
            {
                "label": "Core License (Full Price)",
                "unit_amount": 495000,  # $4,950
                "currency": "usd",
                "recurring": None,
                "metadata": {"tier": "core", "sale": "none"},
            },
        ],
    },
    {
        "name": "MedRecords AI Pro",
        "description": (
            "Full-featured AI medical records platform for personal injury law firms. "
            "Pro license includes everything in Core plus: injury visualization, "
            "case valuation analysis, demand letter generation, negligence detection, "
            "and task generation."
        ),
        "metadata": {"tier": "pro", "type": "license"},
        "prices": [
            {
                "label": "Pro License",
                "unit_amount": 799700,  # $7,997
                "currency": "usd",
                "recurring": None,
                "metadata": {"tier": "pro"},
            },
        ],
    },
    {
        "name": "MedRecords AI Core Priority Support",
        "description": (
            "Priority support for MedRecords AI Core license holders. "
            "Business-hours coverage with severity-based SLAs."
        ),
        "metadata": {"tier": "core_support", "type": "support"},
        "prices": [
            {
                "label": "Core Priority Support (Annual)",
                "unit_amount": 100000,  # $1,000/year
                "currency": "usd",
                "recurring": {"interval": "year"},
                "metadata": {"tier": "core_support"},
            },
        ],
    },
    {
        "name": "MedRecords AI Pro Priority Support",
        "description": (
            "Priority support for MedRecords AI Pro license holders. "
            "Extended coverage with severity-based SLAs and faster response times."
        ),
        "metadata": {"tier": "pro_support", "type": "support"},
        "prices": [
            {
                "label": "Pro Priority Support (Annual)",
                "unit_amount": 240000,  # $2,400/year
                "currency": "usd",
                "recurring": {"interval": "year"},
                "metadata": {"tier": "pro_support"},
            },
        ],
    },
]


def main():
    parser = argparse.ArgumentParser(description="Create Stripe live products")
    parser.add_argument("--key", help="Stripe live secret key (sk_live_*)")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be created")
    args = parser.parse_args()

    api_key = args.key or os.getenv("STRIPE_LIVE_SECRET_KEY") or os.getenv("STRIPE_SECRET_KEY")
    if not api_key:
        print("ERROR: No Stripe key provided. Use --key or set STRIPE_LIVE_SECRET_KEY")
        sys.exit(1)

    if "live" not in api_key:
        print(f"WARNING: Key appears to be test mode ({api_key[:7]}...). "
              f"This script is intended for live mode (sk_live_*).")
        confirm = input("Continue anyway? (y/N): ").strip().lower()
        if confirm != "y":
            sys.exit(0)

    stripe.api_key = api_key

    print("=" * 60)
    print("  MedRecords AI — Stripe Live Product Setup")
    print("=" * 60)

    results = {}

    for product_def in PRODUCTS_TO_CREATE:
        print(f"\n--- {product_def['name']} ---")

        if args.dry_run:
            print(f"  [DRY RUN] Would create product: {product_def['name']}")
            for price_def in product_def["prices"]:
                amt = price_def["unit_amount"] / 100
                recurring = price_def.get("recurring")
                interval = f"/{recurring['interval']}" if recurring else ""
                print(f"  [DRY RUN] Would create price: ${amt:,.2f}{interval}")
            continue

        # Create product
        product = stripe.Product.create(
            name=product_def["name"],
            description=product_def["description"],
            metadata=product_def["metadata"],
        )
        print(f"  Product created: {product.id}")

        # Create prices
        for price_def in product_def["prices"]:
            price_kwargs = {
                "product": product.id,
                "unit_amount": price_def["unit_amount"],
                "currency": price_def["currency"],
                "metadata": price_def.get("metadata", {}),
            }
            if price_def.get("recurring"):
                price_kwargs["recurring"] = price_def["recurring"]

            price = stripe.Price.create(**price_kwargs)
            amt = price_def["unit_amount"] / 100
            recurring = price_def.get("recurring")
            interval = f"/{recurring['interval']}" if recurring else ""
            print(f"  Price created: {price.id}  (${amt:,.2f}{interval})  [{price_def['label']}]")

            tier = price_def.get("metadata", {}).get("tier", "")
            if tier:
                results[tier] = price.id

        # Set default price (first one)
        if product_def["prices"]:
            first_price_id = results.get(
                product_def["prices"][0].get("metadata", {}).get("tier", ""),
                None
            )
            if first_price_id:
                stripe.Product.modify(product.id, default_price=first_price_id)

    if args.dry_run:
        print("\n[DRY RUN] No changes made.")
        return

    print("\n" + "=" * 60)
    print("  UPDATE stripe_webhook.py WITH THESE PRICE IDs:")
    print("=" * 60)
    print("\nPRODUCTS = {")
    for tier, price_id in results.items():
        amounts = {"core": 399700, "pro": 799700, "core_support": 100000, "pro_support": 240000}
        amt = amounts.get(tier, 0)
        print(f'    "{tier}": {{"price_id": "{price_id}", "amount": {amt}, "tier": "{tier}"}},')
    print("}")

    # Save results to file for reference
    output_file = os.path.join(os.path.dirname(__file__), "live_stripe_products.json")
    with open(output_file, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nPrice IDs saved to: {output_file}")


if __name__ == "__main__":
    main()
