import sqlite3
import json

def get_task(task_id):
    conn = sqlite3.connect('tracking.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,))
    row = cursor.fetchone()
    if row:
        print(json.dumps(dict(row), indent=2))
    else:
        print(f"Task {task_id} not found")
    conn.close()

if __name__ == "__main__":
    get_task('manual_20260303-154709_cd69e867')
