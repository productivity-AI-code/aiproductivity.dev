import sqlite3
from datetime import datetime, timezone

def recover_db():
    conn = sqlite3.connect('tracking.db')
    cursor = conn.cursor()
    
    # Threshold: 3 hours
    now = datetime.now(timezone.utc)
    
    cursor.execute("SELECT task_id, started_at FROM tasks WHERE status='running'")
    running_tasks = cursor.fetchall()
    
    recovered_count = 0
    for task_id, started_at in running_tasks:
        stuck = False
        if not started_at:
            stuck = True
        else:
            try:
                if 'T' in started_at:
                    start_time = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
                else:
                    start_time = datetime.strptime(started_at, '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
                
                if (now - start_time).total_seconds() > 10800:
                    stuck = True
            except Exception:
                stuck = True
        
        if stuck:
            cursor.execute(
                "UPDATE tasks SET status='failed', error='Recovered: Task was stuck running for >3h', completed_at=? WHERE task_id=?",
                (now.strftime('%Y-%m-%d %H:%M:%S'), task_id)
            )
            recovered_count += 1
            
    conn.commit()
    print(f"Successfully recovered {recovered_count} stuck tasks in tracking.db")
    conn.close()

if __name__ == "__main__":
    recover_db()
