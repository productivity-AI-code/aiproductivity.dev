#!/usr/bin/env python3
"""
local_pipeline.py -- Orchestrated medical records summarization pipeline.

Pipeline: Privacy -> Summarize -> Review -> Correct -> Audit -> Publish

Reads files in place (no copy to vault/incoming). All LLM calls routed
through AWS Bedrock (BAA-covered) for HIPAA compliance.

Usage:
  python local_pipeline.py --run-id <id> --case-ref <ref> -- file1.pdf file2.txt
  python local_pipeline.py --run-id <id> --case-ref <ref> --skip-review -- file.pdf
"""

import argparse
import hashlib
import json
import logging
import os
import random
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).parent
sys.path.insert(0, str(BASE_DIR))

from dispatch import call_bedrock, call_bedrock_vision
from pipeline_schemas import (
    extract_json_from_response,
    validate_privacy_output,
    validate_summary_output,
    validate_audit_output,
    validate_review_output,
    check_for_phi_leak,
    pre_scrub_phi,
    build_stage_prompt,
    PRIVACY_SCHEMA_EXAMPLE,
    SUMMARY_SCHEMA_EXAMPLE,
    AUDIT_SCHEMA_EXAMPLE,
    REVIEW_SCHEMA_EXAMPLE,
)
from summarization_watcher import (
    _read_file_content,
    _atomic_json_write,
    update_pipeline_status,
    PIPELINE_STATUS_DIR,
)
from gemini_review import run_bedrock_review as run_gemini_review  # BAA-compliant Bedrock replacement

logger = logging.getLogger("local_pipeline")


def _authenticate_cli():
    """
    Verify CLI caller is authorized to process medical records.
    Checks CLI_AUTH_TOKEN or AUTH_PASSWORD_HASH environment variables.
    Returns username string on success, raises SystemExit on failure.
    """
    import getpass

    # Option 1: Non-interactive token auth (for automation/scripts)
    cli_token = os.environ.get("CLI_AUTH_TOKEN")
    expected_token = os.environ.get("CLI_AUTH_TOKEN_HASH")
    if cli_token and expected_token:
        import bcrypt
        if bcrypt.checkpw(cli_token.encode(), expected_token.encode()):
            return "cli_token_user"
        logger.error("CLI_AUTH_TOKEN verification failed")
        sys.exit(1)

    # Option 2: Interactive password auth using AUTH_PASSWORD_HASH
    auth_hash = os.environ.get("AUTH_PASSWORD_HASH")
    if not auth_hash:
        logger.error("No authentication configured. Set AUTH_PASSWORD_HASH in .env")
        sys.exit(1)

    import bcrypt
    password = os.environ.get("CLI_PASSWORD") or getpass.getpass("Pipeline password: ")
    if bcrypt.checkpw(password.encode(), auth_hash.encode()):
        return os.environ.get("AUTH_USERNAME", "cli_user")

    logger.error("Authentication failed")
    sys.exit(1)

SUMMARIES_DIR = BASE_DIR / "vault" / "summaries"
AUDIT_DIR = BASE_DIR / "vault" / "audit"
STAGE_TMP_DIR = BASE_DIR / "vault" / "tmp"

# Regex patterns for sanitizing error messages (prevent PHI leaks in logs/status)
import re as _re
_ERROR_PHI_PATTERNS = [
    (_re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[REDACTED]"),
    (_re.compile(r"\b\d{3}[-.]\d{3}[-.]\d{4}\b"), "[REDACTED]"),
    (_re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"), "[REDACTED]"),
    (_re.compile(r"\b(DOB|Date of Birth)\s*[:#]?\s*\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b",
                 _re.IGNORECASE), "[REDACTED]"),
    (_re.compile(r"\b(Patient|Pt|Mr|Mrs|Ms|Dr)\.\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b"), "[REDACTED]"),
]


def _sanitize_error(msg):
    """Strip potential PHI patterns from error messages before writing to disk/stdout."""
    if not msg:
        return msg
    msg = msg[:500]
    for pattern, repl in _ERROR_PHI_PATTERNS:
        msg = pattern.sub(repl, msg)
    return msg


# ── Config loader ────────────────────────────────────────────────────────────

def _load_config():
    """Load config.yaml."""
    import yaml
    config_path = BASE_DIR / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    return {}


def _file_hash(path):
    """SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ── Stage persistence (crash recovery) ────────────────────────────────────────

def _save_stage_output(run_id, stage_name, data):
    """Save stage output encrypted to vault/tmp/{run_id}_stage_{stage_name}.json for crash recovery."""
    STAGE_TMP_DIR.mkdir(parents=True, exist_ok=True)
    out_path = STAGE_TMP_DIR / f"{run_id}_stage_{stage_name}.json"
    _atomic_json_write(out_path, data, encrypt=True)
    logger.info("  Saved %s output (encrypted) to %s", stage_name, out_path.name)


def _load_stage_output(run_id, stage_name):
    """Load previously saved encrypted stage output. Returns None if not found."""
    out_path = STAGE_TMP_DIR / f"{run_id}_stage_{stage_name}.json"
    if out_path.exists():
        try:
            raw = out_path.read_bytes()
            # Handle encrypted files (Fernet prefix: gAAAA)
            if raw[:5] == b"gAAAA":
                from security_vault import Vault
                decrypted = Vault.decrypt(raw)
                data = json.loads(decrypted.decode("utf-8"))
            else:
                data = json.loads(raw.decode("utf-8"))
            logger.info("  Resumed %s from %s", stage_name, out_path.name)
            return data
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("  Could not load cached %s: %s", stage_name, e)
    return None


def _list_completed_stages(run_id):
    """Return set of stage names that have saved outputs."""
    if not STAGE_TMP_DIR.exists():
        return set()
    prefix = f"{run_id}_stage_"
    return {
        f.stem.replace(prefix, "")
        for f in STAGE_TMP_DIR.glob(f"{prefix}*.json")
    }


def _cleanup_stage_outputs(run_id):
    """Remove temporary stage files after successful publish."""
    if not STAGE_TMP_DIR.exists():
        return
    for f in STAGE_TMP_DIR.glob(f"{run_id}_stage_*.json"):
        try:
            f.unlink()
            logger.debug("  Cleaned up %s", f.name)
        except OSError:
            pass


def _run_retention_cleanup(config):
    """
    Remove stale temporary files per HIPAA data retention policy.
    Called at pipeline startup to clean up old files.
    """
    retention = config.get("retention", {})
    tmp_days = retention.get("vault_tmp_days", 7)
    status_days = retention.get("pipeline_status_days", 90)
    now = time.time()
    cleaned = 0

    # Clean vault/tmp/ older than tmp_days
    if STAGE_TMP_DIR.exists():
        cutoff = now - (tmp_days * 86400)
        for f in STAGE_TMP_DIR.iterdir():
            try:
                if f.is_file() and f.stat().st_mtime < cutoff:
                    f.unlink()
                    cleaned += 1
            except OSError:
                pass

    # Clean vault/pipeline_status/ older than status_days
    if PIPELINE_STATUS_DIR.exists():
        cutoff = now - (status_days * 86400)
        for f in PIPELINE_STATUS_DIR.iterdir():
            try:
                if f.is_file() and f.stat().st_mtime < cutoff:
                    f.unlink()
                    cleaned += 1
            except OSError:
                pass

    if cleaned > 0:
        logger.info("Retention cleanup: removed %d stale files", cleaned)


# ── Retry wrapper ────────────────────────────────────────────────────────────

def _retry(stage_name, fn, max_retries=3):
    """Run fn() with exponential backoff + jitter. Returns result or raises."""
    for attempt in range(1, max_retries + 1):
        try:
            return fn()
        except Exception as e:
            err_str = str(e)
            # Non-retryable
            if any(x in err_str for x in ["api_credits_exhausted", "api_key_invalid"]):
                raise
            if attempt == max_retries:
                raise
            base_backoff = min(10 * (2 ** (attempt - 1)), 60)
            backoff = base_backoff * (0.7 + random.random() * 0.6)
            logger.warning("Stage %s attempt %d/%d failed: %s -- retrying in %.0fs",
                           stage_name, attempt, max_retries, err_str[:200], backoff)
            time.sleep(backoff)


# ── Stage 1: Privacy (Bedrock) ────────────────────────────────────────────────

def _stage_privacy(file_contents, config, run_id, force_claude=False):
    """
    De-identify all files using Bedrock Haiku (BAA-compliant).
    Processes each file individually, then merges results.
    """
    update_pipeline_status(run_id, "privacy", "running")
    bedrock_cfg = config.get("bedrock", {})
    privacy_model = bedrock_cfg.get("model", "us.anthropic.claude-haiku-4-5-v1:0")
    # Use haiku for privacy de-identification (fast, cost-effective)
    if force_claude or True:  # Always use Bedrock now
        privacy_model = config.get("medical_agents", {}).get("privacy", {}).get(
            "bedrock_model", bedrock_cfg.get("model", "us.anthropic.claude-haiku-4-5-v1:0"))
    logger.info("  Privacy: using Bedrock (%s)", privacy_model.split(".")[-1])

    all_sections = []
    total_found = 0
    total_redacted = 0
    by_type = {}

    schema_str = json.dumps(PRIVACY_SCHEMA_EXAMPLE, indent=2)

    total_prescrub = 0
    for filename, content in file_contents.items():
        logger.info("  Privacy: processing %s (%d chars)", filename, len(content))

        # Deterministic pre-scrub: regex catches SSN, phone, email, MRN, DOB
        # before content reaches the LLM (safety net for non-deterministic LLM)
        content, prescrub_count = pre_scrub_phi(content)
        if prescrub_count > 0:
            logger.info("  Privacy: pre-scrubbed %d high-confidence PHI patterns from %s",
                        prescrub_count, filename)
            total_prescrub += prescrub_count

        # Chunk large files
        chunks = _chunk_text(content, max_chars=20000)

        for chunk_idx, chunk_text in enumerate(chunks):
            chunk_label = f"{filename} chunk {chunk_idx + 1}/{len(chunks)}"
            doc_id = hashlib.sha256(chunk_text.encode()).hexdigest()[:16]

            prompt = (
                f"De-identify this medical record for HIPAA-compliant litigation review. "
                f"Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens. "
                f"Count every redaction. Output ONLY valid JSON matching this schema:\n"
                f"```json\n{schema_str}\n```\n\n"
                f"## Input Document ({chunk_label})\n"
                f"document_id: {doc_id}\n"
                f"source_file: {filename}\n\n"
                f"{chunk_text}"
            )

            messages = [
                {"role": "system", "content": "You are a HIPAA-compliant de-identification agent. Output ONLY valid JSON."},
                {"role": "user", "content": prompt},
            ]

            def do_privacy():
                raw = call_bedrock(privacy_model, messages, config, timeout_override=120)

                if isinstance(raw, str) and raw.startswith("__ERROR__"):
                    raise RuntimeError(raw)
                parsed = extract_json_from_response(raw)
                if parsed is None:
                    raise RuntimeError(f"Could not parse JSON from privacy output ({len(raw)} chars)")
                errors = validate_privacy_output(parsed)
                critical = [e for e in errors if e.startswith("CRITICAL")]
                if critical:
                    raise RuntimeError(f"Privacy validation failed: {critical}")
                return parsed

            parsed = _retry(f"privacy:{chunk_label}", do_privacy)

            # Accumulate results
            for sec in parsed.get("sections", []):
                sec["_source_file"] = filename
                sec["_chunk"] = chunk_idx + 1
                all_sections.append(sec)

            phi = parsed.get("phi_summary", {})
            total_found += phi.get("total_identifiers_found", 0)
            total_redacted += phi.get("total_redacted", 0)
            for t, count in phi.get("by_type", {}).items():
                by_type[t] = by_type.get(t, 0) + count

    merged = {
        "document_id": f"merged_{uuid.uuid4().hex[:8]}",
        "privacy_timestamp": datetime.now(timezone.utc).isoformat(),
        "sections": all_sections,
        "phi_summary": {
            "total_identifiers_found": total_found,
            "total_redacted": total_redacted,
            "by_type": by_type,
            "redaction_complete": total_redacted >= total_found,
        },
    }

    # Post-LLM PHI leak check on redacted output
    redacted_text = json.dumps(merged, default=str)
    phi_warnings = check_for_phi_leak(redacted_text)
    if phi_warnings:
        logger.warning("  Privacy output PHI leak check: %s", "; ".join(phi_warnings))
        merged["_phi_leak_warnings"] = phi_warnings

    update_pipeline_status(run_id, "privacy", "completed", details={
        "total_identifiers": total_found,
        "total_redacted": total_redacted,
        "regex_prescrub": total_prescrub,
        "files_processed": len(file_contents),
        "sections": len(all_sections),
        "phi_leak_warnings": len(phi_warnings),
    })
    logger.info("  Privacy complete: %d identifiers found, %d redacted (%d regex pre-scrubbed), %d sections",
                total_found, total_redacted, total_prescrub, len(all_sections))
    return merged


# ── Stage 2: Summarize (Bedrock Sonnet) ───────────────────────────────────────

def _stage_summarize(privacy_output, config, run_id, case_ref=None, source_files=None):
    """
    Generate litigation-ready clinical summary using Claude.
    """
    update_pipeline_status(run_id, "summarizer", "running")
    bedrock_cfg = config.get("bedrock", {})
    model = config.get("medical_agents", {}).get("summarizer", {}).get(
        "bedrock_model", bedrock_cfg.get("model", "us.anthropic.claude-sonnet-4-5-v2:0"))

    # Build the redacted source text from privacy sections
    redacted_text = _sections_to_text(privacy_output.get("sections", []))

    schema_str = json.dumps(SUMMARY_SCHEMA_EXAMPLE, indent=2)

    # Use the full summarizer prompt from PIPELINE_STAGES
    task = (
        "Produce a litigation-ready clinical summary of this de-identified medical record. "
        "This system is used by personal injury attorneys to analyze patient medical records. "
        "Every claim must cite its source section. Build a master chronology of all clinical events. "
        "Identify smoking-gun quotes, contradictions, discovery deficiencies, and timeline gaps. "
        "Include confidence scores. Additionally, extract ALL billing and cost information found "
        "in the records into a 'billing_data' object. For each provider, list dates of service, "
        "service descriptions, CPT codes if available, and dollar amounts. Calculate subtotals per "
        "provider, total past medical costs, and any future medical cost estimates with the basis "
        "for those estimates. If no billing data is found, output billing_data with an empty "
        "providers array and totals of 0.\n\n"
        "ALERTS & GAP DETECTION (REQUIRED):\n"
        "Generate between 3 and 10 alerts per case. Each alert must be one of these types:\n"
        "  - treatment_gap, missing_provider, pre_existing, inconsistency, "
        "compliance_issue, prior_injury, medication_change\n"
        "Each alert MUST have: type, severity (high|medium|low), title, description, "
        "impact_estimate, recommended_action, citation, date_range (or null).\n\n"
        "Output ONLY valid JSON matching this schema:\n"
        f"```json\n{schema_str}\n```\n\n"
        f"## De-Identified Medical Record\n"
        f"Case: {case_ref or 'Unknown'}\n"
        f"Source files: {', '.join(source_files or ['unknown'])}\n\n"
        f"{redacted_text}"
    )

    messages = [
        {"role": "system", "content": (
            "You are a medical-legal summarization expert. Produce detailed, "
            "litigation-ready clinical summaries for personal injury attorneys. "
            "Every claim must cite its source section. Output ONLY valid JSON."
        )},
        {"role": "user", "content": task},
    ]

    def do_summarize():
        raw = call_bedrock(model, messages, config, timeout_override=600)
        if isinstance(raw, str) and raw.startswith("__ERROR__"):
            raise RuntimeError(raw)
        parsed = extract_json_from_response(raw)
        if parsed is None:
            raise RuntimeError(f"Could not parse JSON from summarizer output ({len(raw)} chars)")
        errors = validate_summary_output(parsed, privacy_output)
        critical = [e for e in errors if e.startswith("CRITICAL")]
        if critical:
            raise RuntimeError(f"Summary validation failed: {critical}")
        return parsed

    result = _retry("summarizer", do_summarize)

    # Post-LLM PHI leak check on summary output
    summary_text = json.dumps(result, default=str)
    phi_warnings = check_for_phi_leak(summary_text)
    if phi_warnings:
        logger.warning("  Summary output PHI leak check: %s", "; ".join(phi_warnings))
        result["_phi_leak_warnings"] = phi_warnings

    update_pipeline_status(run_id, "summarizer", "completed", details={
        "claims": result.get("verification", {}).get("total_claims", 0),
        "confidence": result.get("summary", result).get("overall_confidence", 0),
        "phi_leak_warnings": len(phi_warnings),
    })
    logger.info("  Summarization complete")
    return result


# ── Stage 3: Review (Gemini CLI) ─────────────────────────────────────────────

def _stage_review(summary_output, privacy_output, config, run_id):
    """
    Gemini CLI side-by-side review: summary vs PHI-redacted source.
    Returns review findings dict or None if skipped.
    """
    update_pipeline_status(run_id, "review", "running")

    redacted_source = _sections_to_text(privacy_output.get("sections", []))

    # Truncate source if extremely large (Gemini has limits)
    max_source = 200000
    if len(redacted_source) > max_source:
        redacted_source = redacted_source[:max_source] + "\n\n[... truncated for review ...]"

    review = run_gemini_review(summary_output, redacted_source, config)

    if review is None:
        update_pipeline_status(run_id, "review", "completed", details={"skipped": True})
        logger.info("  Review skipped (Gemini unavailable or failed)")
        return None

    update_pipeline_status(run_id, "review", "completed", details={
        "accuracy_score": review.get("accuracy_score"),
        "inaccuracies": len(review.get("inaccuracies_found", [])),
        "unsupported": len(review.get("unsupported_claims", [])),
        "omitted": len(review.get("omitted_findings", [])),
    })
    return review


# ── Stage 4: Correct (Bedrock Sonnet) ─────────────────────────────────────────

def _stage_correct(summary_output, review_output, config, run_id):
    """
    Apply review corrections using Bedrock.
    Skips if review found no issues or accuracy is high enough.
    """
    if review_output is None:
        logger.info("  Correction skipped (no review data)")
        return summary_output

    lp_cfg = config.get("local_pipeline", {})
    threshold = lp_cfg.get("review_accuracy_threshold", 0.98)
    accuracy = review_output.get("accuracy_score", 1.0)
    inaccuracies = review_output.get("inaccuracies_found", [])
    unsupported = review_output.get("unsupported_claims", [])
    omitted = review_output.get("omitted_findings", [])

    total_issues = len(inaccuracies) + len(unsupported) + len(omitted)

    if accuracy >= threshold and total_issues == 0:
        logger.info("  Correction skipped (accuracy=%.2f >= %.2f, 0 issues)", accuracy, threshold)
        return summary_output

    update_pipeline_status(run_id, "correction", "running")
    bedrock_cfg = config.get("bedrock", {})
    model = bedrock_cfg.get("model", "us.anthropic.claude-sonnet-4-5-v2:0")

    review_findings = json.dumps({
        "accuracy_score": accuracy,
        "inaccuracies_found": inaccuracies,
        "unsupported_claims": unsupported,
        "omitted_findings": omitted,
    }, indent=2)

    summary_str = json.dumps(summary_output, indent=2)

    prompt = (
        "You are a medical-legal summary editor. A review has identified inaccuracies "
        "in the following clinical summary. Apply ONLY the corrections listed below. "
        "Do NOT re-write the entire summary. Preserve all accurate content, structure, "
        "and citations.\n\n"
        f"## ORIGINAL SUMMARY\n```json\n{summary_str}\n```\n\n"
        f"## REVIEW FINDINGS (corrections needed)\n```json\n{review_findings}\n```\n\n"
        "## INSTRUCTIONS\n"
        "1. For each inaccuracy, update the specific claim text and citation\n"
        "2. For unsupported claims, mark with confidence: 0.0 and add a needs_verification note\n"
        "3. For omitted findings, add them to key_findings or master_chronology as appropriate\n"
        "4. Update the verification object (total_claims, citation_coverage, etc.)\n"
        "5. Output the COMPLETE corrected summary as valid JSON\n\n"
        "Output ONLY valid JSON matching the original schema. No markdown, no explanation."
    )

    messages = [
        {"role": "system", "content": "You are a precise medical-legal summary editor. Output ONLY valid JSON."},
        {"role": "user", "content": prompt},
    ]

    def do_correct():
        raw = call_bedrock(model, messages, config, timeout_override=600)
        if isinstance(raw, str) and raw.startswith("__ERROR__"):
            raise RuntimeError(raw)
        parsed = extract_json_from_response(raw)
        if parsed is None:
            raise RuntimeError(f"Could not parse JSON from correction output ({len(raw)} chars)")
        errors = validate_summary_output(parsed)
        critical = [e for e in errors if e.startswith("CRITICAL")]
        if critical:
            raise RuntimeError(f"Correction validation failed: {critical}")
        return parsed

    result = _retry("correction", do_correct)

    update_pipeline_status(run_id, "correction", "completed", details={
        "issues_corrected": total_issues,
    })
    logger.info("  Correction complete: %d issues addressed", total_issues)
    return result


# ── Stage 5: Audit (Bedrock Haiku) ────────────────────────────────────────────

def _stage_audit(privacy_output, final_summary, config, run_id, file_hashes):
    """
    Generate HIPAA compliance audit entry using Ollama.
    References files ONLY by hash — no PHI.
    """
    update_pipeline_status(run_id, "auditor", "running")
    bedrock_cfg = config.get("bedrock", {})
    audit_model = config.get("medical_agents", {}).get("auditor", {}).get(
        "bedrock_model", bedrock_cfg.get("model", "us.anthropic.claude-haiku-4-5-v1:0"))

    phi = privacy_output.get("phi_summary", {})
    verification = final_summary.get("verification", {})
    schema_str = json.dumps(AUDIT_SCHEMA_EXAMPLE, indent=2)

    prompt = (
        "Create a HIPAA compliance audit entry for this pipeline run. "
        "Reference files ONLY by SHA-256 hash. Include NO PHI. "
        "Determine compliance status. Output ONLY valid JSON matching this schema:\n"
        f"```json\n{schema_str}\n```\n\n"
        f"## Pipeline Run Info\n"
        f"pipeline_run_id: {run_id}\n"
        f"source_file_hashes: {json.dumps(file_hashes)}\n"
        f"stages_completed: [\"privacy\", \"summarizer\", \"review\", \"correction\", \"auditor\"]\n\n"
        f"## Privacy Results\n"
        f"PHI identifiers found: {phi.get('total_identifiers_found', 0)}\n"
        f"PHI identifiers redacted: {phi.get('total_redacted', 0)}\n"
        f"Redaction complete: {phi.get('redaction_complete', False)}\n"
        f"PHI by type: {json.dumps(phi.get('by_type', {}))}\n\n"
        f"## Summary Verification\n"
        f"Total claims: {verification.get('total_claims', 0)}\n"
        f"Claims with citations: {verification.get('claims_with_citations', 0)}\n"
        f"Citation coverage: {verification.get('citation_coverage', 0)}\n"
        f"Overall confidence: {final_summary.get('summary', final_summary).get('overall_confidence', 0)}\n"
    )

    messages = [
        {"role": "system", "content": "You are a HIPAA compliance auditor. Output ONLY valid JSON. Include NO PHI."},
        {"role": "user", "content": prompt},
    ]

    def do_audit():
        raw = call_bedrock(audit_model, messages, config, timeout_override=120)

        if isinstance(raw, str) and raw.startswith("__ERROR__"):
            raise RuntimeError(raw)
        parsed = extract_json_from_response(raw)
        if parsed is None:
            raise RuntimeError(f"Could not parse JSON from audit output ({len(raw)} chars)")
        errors = validate_audit_output(parsed)
        critical = [e for e in errors if e.startswith("CRITICAL")]
        if critical:
            raise RuntimeError(f"Audit validation failed: {critical}")
        return parsed

    result = _retry("auditor", do_audit)

    update_pipeline_status(run_id, "auditor", "completed")
    logger.info("  Audit complete: status=%s", result.get("compliance_status"))
    return result


# ── Stage 6: Publish ──────────────────────────────────────────────────────────

def _stage_publish(run_id, case_ref, file_paths, file_hashes,
                   privacy_output, final_summary, audit_output, review_output, mode,
                   cross_model_result=None):
    """
    Write final summary JSON to vault/summaries/ in UI-compatible format.
    """
    update_pipeline_status(run_id, "publish", "running")
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f"{run_id}_summary.json"

    # Build the top-level summary document matching existing UI format
    source_label = (
        file_paths[0].name if len(file_paths) == 1
        else f"CASE: {case_ref} ({len(file_paths)} files)"
    )

    combined_hash = (
        list(file_hashes.values())[0] if len(file_hashes) == 1
        else hashlib.sha256("".join(sorted(file_hashes.values())).encode()).hexdigest()
    )

    summary_data = {
        "run_id": run_id,
        "source_file": source_label,
        "source_files": [fp.name for fp in file_paths],
        "case_ref": case_ref,
        "source_file_hash": combined_hash,
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "mode": f"local-{mode}",
        "pipeline_type": "local",
        "document_id": combined_hash[:16],
        "summary_timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # Merge in the summary fields (summary, bluf, alerts, billing_data, verification, etc.)
    for key, value in final_summary.items():
        if key not in summary_data:
            summary_data[key] = value

    # Add privacy metadata (not the full sections — those contain redacted content)
    summary_data["privacy_metadata"] = {
        "phi_summary": privacy_output.get("phi_summary", {}),
        "sections_count": len(privacy_output.get("sections", [])),
    }

    # Add audit
    if audit_output:
        summary_data["audit"] = audit_output

    # Add review results
    if review_output:
        summary_data["review"] = review_output
        summary_data["review_accuracy_score"] = review_output.get("accuracy_score")

    # Add cross-model verification results
    if cross_model_result:
        summary_data["cross_model_verification"] = cross_model_result
        summary_data["cross_model_accuracy_score"] = cross_model_result.get("accuracy_score")

    _atomic_json_write(summary_file, summary_data, encrypt=True)

    # Save audit separately (encrypted)
    if audit_output:
        AUDIT_DIR.mkdir(parents=True, exist_ok=True)
        _atomic_json_write(AUDIT_DIR / f"{run_id}_audit.json", audit_output, encrypt=True)

    # Update pipeline status to completed
    status_file = PIPELINE_STATUS_DIR / f"{run_id}.json"
    if status_file.exists():
        import json as _json
        status_data = _json.loads(status_file.read_text())
    else:
        status_data = {"run_id": run_id}
    status_data["status"] = "completed"
    status_data["completed_at"] = datetime.now(timezone.utc).isoformat()
    _atomic_json_write(status_file, status_data)

    logger.info("  Published: %s", summary_file)
    return summary_data


# ── Helpers ───────────────────────────────────────────────────────────────────

def _chunk_text(text, max_chars=20000):
    """Split text into chunks at page boundaries or by character limit."""
    if len(text) <= max_chars:
        return [text]

    chunks = []
    # Try splitting on page markers first
    pages = text.split("--- Page ")
    if len(pages) > 1:
        current = ""
        for page in pages:
            candidate = ("--- Page " + page) if page != pages[0] else page
            if len(current) + len(candidate) > max_chars and current:
                chunks.append(current.strip())
                current = candidate
            else:
                current += candidate
        if current.strip():
            chunks.append(current.strip())
        return chunks if chunks else [text]

    # Fallback: split by character limit at paragraph boundaries
    while text:
        if len(text) <= max_chars:
            chunks.append(text)
            break
        split_at = text.rfind("\n\n", 0, max_chars)
        if split_at < max_chars // 2:
            split_at = text.rfind("\n", 0, max_chars)
        if split_at < max_chars // 2:
            split_at = max_chars
        chunks.append(text[:split_at].strip())
        text = text[split_at:].strip()

    return chunks


def _sections_to_text(sections):
    """Convert privacy output sections to readable text for summarization/review."""
    parts = []
    for sec in sections:
        heading = sec.get("heading", sec.get("section_type", "Section"))
        source = sec.get("_source_file", "")
        content = sec.get("content", "")
        sid = sec.get("section_id", "")

        header = f"### {heading}"
        if source:
            header += f" (from: {source})"
        if sid:
            header += f" [{sid}]"
        parts.append(f"{header}\n{content}")

    return "\n\n".join(parts)


# ── Main orchestrator ─────────────────────────────────────────────────────────

def run_local_pipeline(file_paths, config, run_id, case_ref,
                       mode="fast", skip_review=False, fast_privacy=False,
                       resume=False, auth_user="unknown"):
    """
    Main orchestrator. Reads files in place, runs 6-stage pipeline.
    Saves each stage's output to vault/tmp/ for crash recovery.
    With --resume, skips stages that already have saved outputs.
    Returns summary_data dict on success, raises on failure.
    """
    started = time.time()

    # HIPAA: Run retention cleanup on stale temp files
    try:
        _run_retention_cleanup(config)
    except Exception as e:
        logger.warning("Retention cleanup failed: %s", e)

    # HIPAA: Log pipeline access
    try:
        from db import log_access
        log_access(
            username=auth_user,
            action="pipeline_start",
            resource_type="pipeline",
            resource_id=run_id,
            details=f"files={len(file_paths)}, mode={mode}, case_ref={case_ref}",
        )
    except Exception as e:
        logger.warning("Could not log pipeline access: %s", e)
    lp_cfg = config.get("local_pipeline", {})
    max_duration = lp_cfg.get("max_duration", 7200)

    # Auto-detect fast-privacy: >5 files or >50K total chars
    total_chars = 0
    for fp in file_paths:
        fp = Path(fp)
        if fp.exists():
            try:
                total_chars += fp.stat().st_size
            except OSError:
                pass
    if not fast_privacy and (len(file_paths) > 5 or total_chars > 50000):
        logger.info("  Auto-enabling fast-privacy: %d files, ~%dK chars",
                    len(file_paths), total_chars // 1000)
        fast_privacy = True

    # Check for resumable stages
    completed_stages = set()
    if resume:
        completed_stages = _list_completed_stages(run_id)
        if completed_stages:
            logger.info("  Resuming: found saved stages: %s", ", ".join(sorted(completed_stages)))

    logger.info("Local pipeline %s starting for %d file(s) (case=%s, mode=%s%s)",
                run_id, len(file_paths), case_ref, mode,
                ", resume" if resume else "")

    # Initialize pipeline status
    update_pipeline_status(run_id, "pipeline", "running", source_file=(
        file_paths[0].name if len(file_paths) == 1
        else f"CASE: {case_ref} ({len(file_paths)} files)"
    ), case_ref=case_ref)

    # Read files in place
    file_contents = {}
    file_hashes = {}
    for fp in file_paths:
        fp = Path(fp)
        if not fp.exists():
            raise FileNotFoundError(f"File not found: {fp}")
        content, page_map = _read_file_content(fp)
        if not content or not content.strip():
            logger.warning("  Skipping empty file: %s", fp.name)
            continue
        file_contents[fp.name] = content
        file_hashes[fp.name] = _file_hash(fp)

    if not file_contents:
        raise RuntimeError("No readable content found in provided files")

    logger.info("  Read %d file(s), total %d chars",
                len(file_contents), sum(len(v) for v in file_contents.values()))

    # ── Stage 1: Privacy ──
    if resume and "privacy" in completed_stages:
        logger.info("[1/6] Privacy -- resumed from cache")
        privacy_output = _load_stage_output(run_id, "privacy")
    else:
        logger.info("[1/6] Privacy (de-identification)...")
        privacy_output = _stage_privacy(file_contents, config, run_id, force_claude=fast_privacy)
        _save_stage_output(run_id, "privacy", privacy_output)

    _check_timeout(started, max_duration, "after privacy")

    # ── Stage 2: Summarize ──
    if resume and "summary" in completed_stages:
        logger.info("[2/6] Summarize -- resumed from cache")
        summary_output = _load_stage_output(run_id, "summary")
    else:
        logger.info("[2/6] Summarize (Claude)...")
        summary_output = _stage_summarize(
            privacy_output, config, run_id,
            case_ref=case_ref,
            source_files=list(file_contents.keys()),
        )
        _save_stage_output(run_id, "summary", summary_output)

    _check_timeout(started, max_duration, "after summarize")

    # ── Stage 3: Review ──
    review_output = None
    if not skip_review:
        if resume and "review" in completed_stages:
            logger.info("[3/6] Review -- resumed from cache")
            review_output = _load_stage_output(run_id, "review")
        else:
            logger.info("[3/6] Review (Gemini)...")
            review_output = _stage_review(summary_output, privacy_output, config, run_id)
            if review_output is not None:
                _save_stage_output(run_id, "review", review_output)
    else:
        logger.info("[3/6] Review -- skipped (--skip-review)")

    _check_timeout(started, max_duration, "after review")

    # ── Stage 3b: Cross-Model Verification ──
    cross_model_result = None
    cross_model_cfg = config.get("bedrock", {}).get("cross_model_review", {})
    if cross_model_cfg.get("enabled", False) and not skip_review:
        if resume and "cross_model_verification" in completed_stages:
            logger.info("[3b/6] Cross-Model Verification -- resumed from cache")
            cross_model_result = _load_stage_output(run_id, "cross_model_verification")
        else:
            logger.info("[3b/6] Cross-Model Verification (Amazon Nova)...")
            try:
                from gemini_review import run_cross_model_review
                update_pipeline_status(run_id, "cross_model_verification", "running")
                redacted_source = _sections_to_text(privacy_output.get("sections", []))
                cross_model_result = run_cross_model_review(
                    summary_output, redacted_source, config)
                if cross_model_result:
                    _save_stage_output(run_id, "cross_model_verification", cross_model_result)
                    update_pipeline_status(run_id, "cross_model_verification", "completed", details={
                        "accuracy_score": cross_model_result.get("accuracy_score"),
                        "model": cross_model_result.get("model_used"),
                        "model_family": cross_model_result.get("model_family"),
                        "inaccuracies": len(cross_model_result.get("inaccuracies_found", [])),
                    })
                    logger.info("  Cross-model verification: accuracy=%.2f, model=%s",
                                cross_model_result.get("accuracy_score", 0),
                                cross_model_result.get("model_used", "unknown"))
                else:
                    update_pipeline_status(run_id, "cross_model_verification", "completed",
                                           details={"skipped": True})
                    logger.info("  Cross-model verification skipped (returned None)")
            except Exception as e:
                if cross_model_cfg.get("required", False):
                    raise
                logger.warning("  Cross-model verification failed (non-blocking): %s", e)
                update_pipeline_status(run_id, "cross_model_verification", "completed",
                                       details={"skipped": True, "reason": str(e)[:200]})

    _check_timeout(started, max_duration, "after cross-model verification")

    # ── Stage 4: Correct ──
    if resume and "correction" in completed_stages:
        logger.info("[4/6] Correct -- resumed from cache")
        final_summary = _load_stage_output(run_id, "correction")
    else:
        logger.info("[4/6] Correct (Claude)...")
        final_summary = _stage_correct(summary_output, review_output, config, run_id)
        if final_summary is not summary_output:
            _save_stage_output(run_id, "correction", final_summary)

    _check_timeout(started, max_duration, "after correction")

    # ── Stage 5: Audit ──
    if resume and "audit" in completed_stages:
        logger.info("[5/6] Audit -- resumed from cache")
        audit_output = _load_stage_output(run_id, "audit")
    else:
        logger.info("[5/6] Audit (HIPAA compliance)...")
        audit_output = _stage_audit(privacy_output, final_summary, config, run_id, file_hashes)
        _save_stage_output(run_id, "audit", audit_output)

    # ── Stage 6: Publish ──
    logger.info("[6/6] Publish...")
    summary_data = _stage_publish(
        run_id, case_ref, [Path(fp) for fp in file_paths], file_hashes,
        privacy_output, final_summary, audit_output, review_output, mode,
        cross_model_result=cross_model_result,
    )

    # Clean up temporary stage files after successful publish
    _cleanup_stage_outputs(run_id)

    elapsed = time.time() - started
    logger.info("Pipeline %s completed in %.0fs", run_id, elapsed)

    # HIPAA: Log pipeline completion
    try:
        from db import log_access
        log_access(
            username=auth_user,
            action="pipeline_complete",
            resource_type="pipeline",
            resource_id=run_id,
            details=f"elapsed={elapsed:.0f}s, files={len(file_paths)}",
        )
    except Exception as e:
        logger.warning("Could not log pipeline completion: %s", e)

    return summary_data


def _check_timeout(started, max_duration, label):
    """Raise if pipeline has exceeded max duration."""
    elapsed = time.time() - started
    if elapsed > max_duration:
        raise RuntimeError(f"Pipeline timeout ({elapsed:.0f}s > {max_duration}s) {label}")


# ── CLI entry point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Local medical records pipeline")
    parser.add_argument("--run-id", required=True, help="Pipeline run ID")
    parser.add_argument("--case-ref", default="uncategorized", help="Case reference")
    parser.add_argument("--mode", choices=["fast", "thorough"], default="fast")
    parser.add_argument("--skip-review", action="store_true", help="Skip Gemini review")
    parser.add_argument("--fast-privacy", action="store_true", help="Use Claude-haiku for privacy instead of Ollama")
    parser.add_argument("--resume", action="store_true", help="Resume from last completed stage")
    parser.add_argument("--dry-run", action="store_true", help="Show plan without executing")
    parser.add_argument("files", nargs="+", help="Files to process")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    # Load .env for credentials
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE_DIR / ".env")
    except ImportError:
        pass

    # HIPAA: Authenticate CLI user before processing medical records
    auth_user = _authenticate_cli()
    logger.info("Authenticated as: %s", auth_user)

    config = _load_config()
    file_paths = [Path(f) for f in args.files]

    if args.dry_run:
        print(json.dumps({
            "ok": True,
            "dry_run": True,
            "run_id": args.run_id,
            "case_ref": args.case_ref,
            "mode": args.mode,
            "skip_review": args.skip_review,
            "files": [str(fp) for fp in file_paths],
            "stages": ["privacy (Bedrock pre-scrub+LLM)", "summarize (Bedrock)",
                        "review (Bedrock)", "correct (Bedrock)",
                        "audit (Bedrock)", "publish (encrypted)"],
        }, indent=2))
        return

    try:
        result = run_local_pipeline(
            file_paths, config, args.run_id, args.case_ref,
            mode=args.mode, skip_review=args.skip_review,
            fast_privacy=args.fast_privacy, resume=args.resume,
            auth_user=auth_user,
        )
        print(json.dumps({"ok": True, "data": {"run_id": args.run_id, "status": "completed"}}, indent=2))
    except Exception as e:
        logger.exception("Pipeline failed: %s", e)
        # Sanitize error message to prevent PHI leaks
        safe_msg = _sanitize_error(str(e))
        # Update status to failed
        try:
            status_file = PIPELINE_STATUS_DIR / f"{args.run_id}.json"
            if status_file.exists():
                status_data = json.loads(status_file.read_text())
            else:
                status_data = {"run_id": args.run_id}
            status_data["status"] = "failed"
            status_data["error_message"] = safe_msg
            status_data["failed_at"] = datetime.now(timezone.utc).isoformat()
            _atomic_json_write(status_file, status_data)
        except Exception:
            pass
        # HIPAA: Log pipeline failure
        try:
            from db import log_access
            log_access(
                username=auth_user,
                action="pipeline_failed",
                resource_type="pipeline",
                resource_id=args.run_id,
                details=safe_msg,
            )
        except Exception:
            pass
        print(json.dumps({"ok": False, "error": {"code": "pipeline_failed", "message": safe_msg}}))
        sys.exit(1)


if __name__ == "__main__":
    main()
