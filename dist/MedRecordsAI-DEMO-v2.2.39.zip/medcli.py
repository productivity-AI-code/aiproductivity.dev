#!/usr/bin/env python3
"""
medcli -- Agent-first CLI for MedRecords AI.

Designed for AI agents and power users. JSON output by default.
All commands gated to 'dev' tier; edit COMMAND_TIERS in medcli_lib/__init__.py
to unlock for Core/Pro/Demo.

Usage:
  python medcli.py <command> [options]
  python medcli.py --help
"""

import argparse
import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from medcli_lib import output, error, check_tier, progress


def _run(command_key, handler, args, fmt):
    """Run a command with tier check and error handling."""
    blocked = check_tier(command_key)
    if blocked:
        output(blocked, fmt=fmt)
        sys.exit(1)
    try:
        result = handler(args)
        output(result, fmt=fmt)
        sys.exit(0 if result.get("ok") else 1)
    except KeyboardInterrupt:
        output(error("interrupted", "Operation cancelled"), fmt=fmt)
        sys.exit(130)
    except Exception as e:
        output(error("internal_error", str(e)), fmt=fmt)
        sys.exit(1)


def build_parser():
    p = argparse.ArgumentParser(
        prog="medcli",
        description="MedRecords AI -- Agent-first CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--format", "-f", choices=["json", "table"], default="json",
                   help="Output format (default: json)")
    sub = p.add_subparsers(dest="command", help="Available commands")

    # ── Email ────────────────────────────────────────────────────────────
    email = sub.add_parser("email", help="Email communication")
    email_sub = email.add_subparsers(dest="email_cmd")

    es = email_sub.add_parser("send", help="Send an email")
    es.add_argument("--to", required=True, help="Recipient email")
    es.add_argument("--subject", required=True)
    es.add_argument("--body", required=True)
    es.add_argument("--template", help="Template name to use instead of --body")
    es.add_argument("--contact-id", type=int, help="Link to contact record")

    esr = email_sub.add_parser("send-request", help="Send records request to contact")
    esr.add_argument("--contact-id", type=int, required=True)
    esr.add_argument("--dry-run", action="store_true")

    ef = email_sub.add_parser("follow-up", help="Send follow-up emails")
    ef.add_argument("--contact-id", type=int, help="Specific contact")
    ef.add_argument("--all-pending", action="store_true", help="All contacts awaiting response")
    ef.add_argument("--tier", choices=["polite", "firm", "urgent", "final"])
    ef.add_argument("--dry-run", action="store_true")

    email_sub.add_parser("check-inbox", help="Poll IMAP for replies")

    el = email_sub.add_parser("log", help="View email audit trail")
    el.add_argument("--contact-id", type=int)
    el.add_argument("--direction", choices=["inbound", "outbound"])
    el.add_argument("--last", type=int, default=25)

    email_sub.add_parser("templates", help="List available email templates")
    email_sub.add_parser("test-config", help="Test SMTP/IMAP connectivity")

    # ── Contact ──────────────────────────────────────────────────────────
    contact = sub.add_parser("contact", help="Contact management")
    contact_sub = contact.add_subparsers(dest="contact_cmd")

    cl = contact_sub.add_parser("list", help="List contacts")
    cl.add_argument("--status", choices=["new", "contacted", "awaiting", "received", "failed", "cancelled"])
    cl.add_argument("--type", choices=["custodian", "counsel", "patient", "provider"])
    cl.add_argument("--case-ref")
    cl.add_argument("--limit", type=int, default=50)

    cg = contact_sub.add_parser("get", help="Get contact details + email history")
    cg.add_argument("id", type=int)

    ca = contact_sub.add_parser("add", help="Add new contact")
    ca.add_argument("--name", required=True)
    ca.add_argument("--email", required=True)
    ca.add_argument("--type", required=True, choices=["custodian", "counsel", "patient", "provider"])
    ca.add_argument("--organization")
    ca.add_argument("--case-ref")
    ca.add_argument("--priority", choices=["normal", "high", "urgent"], default="normal")
    ca.add_argument("--record-type", help="Type of records needed")
    ca.add_argument("--notes")

    ci = contact_sub.add_parser("import", help="Bulk import from Excel")
    ci.add_argument("--file", required=True)

    ce = contact_sub.add_parser("export", help="Export contacts")
    ce.add_argument("--format", choices=["csv", "json", "excel"], default="json", dest="export_format")

    cb = contact_sub.add_parser("bulk-email", help="Batch email by filter")
    cb.add_argument("--filter", required=True, help='Filter like "status=awaiting,priority=urgent"')
    cb.add_argument("--template", required=True, help="Email template name")
    cb.add_argument("--dry-run", action="store_true")

    # ── Notify ───────────────────────────────────────────────────────────
    notify = sub.add_parser("notify", help="Send notifications")
    notify_sub = notify.add_subparsers(dest="notify_cmd")

    ns = notify_sub.add_parser("slack", help="Send Slack message")
    ns.add_argument("--message", required=True)
    ns.add_argument("--channel", help="Channel ID (defaults to config)")

    # ── Pipeline ─────────────────────────────────────────────────────────
    pipeline = sub.add_parser("pipeline", help="Document processing pipeline")
    pipe_sub = pipeline.add_subparsers(dest="pipeline_cmd")

    pr = pipe_sub.add_parser("run", help="Run pipeline on file(s)")
    pr.add_argument("path", help="File or directory path")
    pr.add_argument("--mode", choices=["fast", "thorough", "auto"], default="auto")
    pr.add_argument("--case-ref")
    pr.add_argument("--wait", action="store_true", help="Block until complete")

    ps = pipe_sub.add_parser("status", help="Check pipeline run status")
    ps.add_argument("run_id")

    pl = pipe_sub.add_parser("list", help="List pipeline runs")
    pl.add_argument("--status", choices=["running", "completed", "failed"])
    pl.add_argument("--limit", type=int, default=20)

    prt = pipe_sub.add_parser("retry", help="Retry failed pipeline")
    prt.add_argument("run_id")

    pw = pipe_sub.add_parser("wait", help="Block until pipeline completes")
    pw.add_argument("run_id")
    pw.add_argument("--timeout", type=int, default=3600)

    prl = pipe_sub.add_parser("run-local", help="Local pipeline (Ollama+Claude+Gemini)")
    prl.add_argument("path", help="File or directory path")
    prl.add_argument("--mode", choices=["fast", "thorough"], default="fast")
    prl.add_argument("--case-ref", help="Case reference for grouping")
    prl.add_argument("--wait", action="store_true", help="Block until complete")
    prl.add_argument("--skip-review", action="store_true", help="Skip Gemini review step")
    prl.add_argument("--fast-privacy", action="store_true", help="Use Claude-haiku for privacy (faster)")
    prl.add_argument("--resume", action="store_true", help="Resume from last completed stage")
    prl.add_argument("--dry-run", action="store_true", help="Show plan without executing")

    # ── File ─────────────────────────────────────────────────────────────
    file_p = sub.add_parser("file", help="Document management")
    file_sub = file_p.add_subparsers(dest="file_cmd")

    fu = file_sub.add_parser("upload", help="Upload file to vault")
    fu.add_argument("path", help="File path to upload")
    fu.add_argument("--case-ref")
    fu.add_argument("--category", default="uncategorized")

    fl = file_sub.add_parser("list", help="List documents")
    fl.add_argument("--case-ref")
    fl.add_argument("--status", choices=["pending", "processing", "completed", "failed"])
    fl.add_argument("--limit", type=int, default=50)

    fd = file_sub.add_parser("download", help="Download file")
    fd.add_argument("doc_id", type=int)
    fd.add_argument("--output", help="Output file path")

    file_sub.add_parser("sync", help="Reconcile vault with database")

    # ── Summary ──────────────────────────────────────────────────────────
    summary = sub.add_parser("summary", help="View summaries")
    summary_sub = summary.add_subparsers(dest="summary_cmd")

    sg = summary_sub.add_parser("get", help="Get summary")
    sg.add_argument("run_id")
    sg.add_argument("--section", choices=["ingestion", "privacy", "summary", "audit"])

    sl = summary_sub.add_parser("list", help="List summaries")
    sl.add_argument("--case-ref")

    # ── Demand ───────────────────────────────────────────────────────────
    demand = sub.add_parser("demand", help="Demand package generation")
    demand_sub = demand.add_subparsers(dest="demand_cmd")

    dg = demand_sub.add_parser("generate", help="Generate demand package")
    dg.add_argument("run_id")
    dg.add_argument("--case-type", required=True)
    dg.add_argument("--plaintiff")
    dg.add_argument("--jurisdiction")

    # ── Valuation ────────────────────────────────────────────────────────
    valuation = sub.add_parser("valuation", help="Case valuation")
    val_sub = valuation.add_subparsers(dest="valuation_cmd")

    ve = val_sub.add_parser("estimate", help="Estimate case value")
    ve.add_argument("run_id")

    # ── Negligence ───────────────────────────────────────────────────────
    negligence = sub.add_parser("negligence", help="Negligence detection")
    neg_sub = negligence.add_subparsers(dest="negligence_cmd")

    na = neg_sub.add_parser("analyze", help="Analyze for negligence")
    na.add_argument("run_id")

    # ── CRM ──────────────────────────────────────────────────────────────
    crm = sub.add_parser("crm", help="Sales CRM")
    crm_sub = crm.add_subparsers(dest="crm_cmd")

    crl = crm_sub.add_parser("leads", help="List leads")
    crl.add_argument("--stage")
    crl.add_argument("--source")
    crl.add_argument("--limit", type=int, default=50)

    cra = crm_sub.add_parser("add-lead", help="Create a lead")
    cra.add_argument("--email", required=True)
    cra.add_argument("--name", required=True)
    cra.add_argument("--company")
    cra.add_argument("--phone")
    cra.add_argument("--stage", default="prospect")
    cra.add_argument("--source", default="manual")
    cra.add_argument("--notes")

    cru = crm_sub.add_parser("update-lead", help="Update a lead")
    cru.add_argument("id", type=int)
    cru.add_argument("--stage")
    cru.add_argument("--notes")
    cru.add_argument("--follow-up-date")
    cru.add_argument("--assigned-to")

    crm_sub.add_parser("sync-sheets", help="Sync leads from Google Sheets")

    crx = crm_sub.add_parser("export", help="Export leads")
    crx.add_argument("--format", choices=["csv", "json", "excel"], default="json", dest="export_format")

    crm_sub.add_parser("stats", help="CRM pipeline and revenue stats")

    # ── Campaign ─────────────────────────────────────────────────────
    campaign = sub.add_parser("campaign", help="Email campaigns")
    camp_sub = campaign.add_subparsers(dest="campaign_cmd")

    cpl = camp_sub.add_parser("list", help="List campaigns")
    cpl.add_argument("--status", choices=["draft", "generating", "review", "approved", "sending", "sent", "paused", "failed"])
    cpl.add_argument("--type", choices=["sales_outreach", "demo_followup", "nurture", "announcement"])
    cpl.add_argument("--limit", type=int, default=50)

    cpc = camp_sub.add_parser("create", help="Create a draft campaign")
    cpc.add_argument("--name", required=True)
    cpc.add_argument("--type", required=True, dest="campaign_type",
                     choices=["sales_outreach", "demo_followup", "nurture", "announcement"])
    cpc.add_argument("--prompt", required=True, help="Brief/instructions for Claude")
    cpc.add_argument("--subject-template", default="Quick question for {contact_name}")
    cpc.add_argument("--smtp-profile-id", type=int)
    cpc.add_argument("--stages", nargs="*", help="Target lead stages")
    cpc.add_argument("--sources", nargs="*", help="Target lead sources")
    cpc.add_argument("--tiers", nargs="*", help="Target prospect tiers")

    cpg = camp_sub.add_parser("get", help="Get campaign details + message stats")
    cpg.add_argument("id", type=int)

    cpu = camp_sub.add_parser("update", help="Update a draft/failed campaign")
    cpu.add_argument("id", type=int)
    cpu.add_argument("--name")
    cpu.add_argument("--type", dest="campaign_type",
                     choices=["sales_outreach", "demo_followup", "nurture", "announcement"])
    cpu.add_argument("--prompt")
    cpu.add_argument("--subject-template")
    cpu.add_argument("--smtp-profile-id", type=int)

    cpd = camp_sub.add_parser("delete", help="Delete a draft/failed campaign")
    cpd.add_argument("id", type=int)

    cpgen = camp_sub.add_parser("generate", help="Generate Claude email drafts")
    cpgen.add_argument("id", type=int)

    cpm = camp_sub.add_parser("messages", help="List campaign messages")
    cpm.add_argument("id", type=int)
    cpm.add_argument("--status", choices=["draft", "approved", "sent", "failed"])
    cpm.add_argument("--limit", type=int, default=50)
    cpm.add_argument("--offset", type=int, default=0)

    cpem = camp_sub.add_parser("edit-message", help="Edit a message subject/body")
    cpem.add_argument("msg_id", type=int)
    cpem.add_argument("--subject")
    cpem.add_argument("--body")

    cpa = camp_sub.add_parser("approve", help="Approve all draft messages")
    cpa.add_argument("id", type=int)

    cps = camp_sub.add_parser("send", help="Send approved campaign")
    cps.add_argument("id", type=int)

    cppa = camp_sub.add_parser("pause", help="Pause a sending campaign")
    cppa.add_argument("id", type=int)

    camp_sub.add_parser("stats", help="Campaign analytics")
    camp_sub.add_parser("smtp-profiles", help="List SMTP profiles")

    cpst = camp_sub.add_parser("smtp-test", help="Test SMTP connection")
    cpst.add_argument("id", type=int)

    # ── System ───────────────────────────────────────────────────────────
    sub.add_parser("health", help="System health check")
    sub.add_parser("status", help="Dashboard statistics")

    audit_p = sub.add_parser("audit", help="HIPAA audit log")
    audit_p.add_argument("--last", type=int, default=50)
    audit_p.add_argument("--username")

    config_p = sub.add_parser("config", help="Configuration")
    config_sub = config_p.add_subparsers(dest="config_cmd")
    config_sub.add_parser("show", help="Show current config (secrets redacted)")

    # ── Agent ────────────────────────────────────────────────────────────
    agent = sub.add_parser("agent", help="Agent dispatch and management")
    agent_sub = agent.add_subparsers(dest="agent_cmd")

    ad = agent_sub.add_parser("dispatch", help="Dispatch task to agent")
    ad.add_argument("--agent", required=True)
    ad.add_argument("--task", required=True)
    ad.add_argument("--context")
    ad.add_argument("--wait", action="store_true")

    ast = agent_sub.add_parser("status", help="Check task status")
    ast.add_argument("--task-id")

    agent_sub.add_parser("list", help="List available agents")

    ae = agent_sub.add_parser("errors", help="View error report")
    ae.add_argument("--agent")
    ae.add_argument("--last", type=int, default=20)

    al = agent_sub.add_parser("lessons", help="View learned lessons")
    al.add_argument("--agent")

    ar = agent_sub.add_parser("run", help="Execute a workflow")
    ar.add_argument("name", help="Workflow name from config.yaml")
    ar.add_argument("--dry-run", action="store_true", help="Show planned steps without executing")

    asch = agent_sub.add_parser("schedule", help="View/set workflow schedule")
    asch.add_argument("name", help="Workflow name")
    asch.add_argument("--cron", help="Cron expression (e.g., '0 9 * * 1')")

    alog = agent_sub.add_parser("log", help="View workflow run history")
    alog.add_argument("--name", help="Filter by workflow name")
    alog.add_argument("--limit", type=int, default=20)

    # ── Service / Customer Success ────────────────────────────────────────
    svc = sub.add_parser("service", help="Service / Customer Success")
    svc_sub = svc.add_subparsers(dest="service_cmd")

    sl = svc_sub.add_parser("list", help="List customers")
    sl.add_argument("--health-status", choices=["healthy", "at_risk", "churned"])
    sl.add_argument("--tier", choices=["core", "pro"])
    sl.add_argument("--limit", type=int, default=50)

    sg = svc_sub.add_parser("get", help="Get customer detail")
    sg.add_argument("id", type=int)

    sa = svc_sub.add_parser("add", help="Add a customer")
    sa.add_argument("--name", required=True)
    sa.add_argument("--email", required=True)
    sa.add_argument("--company")
    sa.add_argument("--phone")
    sa.add_argument("--tier", choices=["core", "pro"])
    sa.add_argument("--license-key")

    su = svc_sub.add_parser("update", help="Update a customer")
    su.add_argument("id", type=int)
    su.add_argument("--health-score", type=int)
    su.add_argument("--health-status", choices=["healthy", "at_risk", "churned"])
    su.add_argument("--onboarding-status", choices=["not_started", "in_progress", "completed"])
    su.add_argument("--notes")
    su.add_argument("--csm-assigned")
    su.add_argument("--nps-score", type=int)
    su.add_argument("--renewal-date")

    sd = svc_sub.add_parser("delete", help="Delete a customer")
    sd.add_argument("id", type=int)

    sss = svc_sub.add_parser("sync-sheets", help="Sync customers from Google Sheet")
    sss.add_argument("--sheet-id", help="Google Sheet ID (or from config.yaml)")

    svc_sub.add_parser("sync-stripe", help="Sync customers from Stripe")
    svc_sub.add_parser("stats", help="Dashboard stats")

    shc = svc_sub.add_parser("health-check", help="At-risk customers and renewals due")
    shc.add_argument("--days", type=int, default=30)

    sev = svc_sub.add_parser("events", help="List customer events")
    sev.add_argument("--customer-id", type=int)
    sev.add_argument("--type")
    sev.add_argument("--limit", type=int, default=50)

    sae = svc_sub.add_parser("add-event", help="Create a customer event")
    sae.add_argument("--customer-id", type=int, required=True)
    sae.add_argument("--type", required=True)
    sae.add_argument("--description", default="")

    sex = svc_sub.add_parser("export", help="Export customers")
    sex.add_argument("--format", choices=["json", "csv"], default="json")

    # ── Top-level convenience ────────────────────────────────────────────
    wait_p = sub.add_parser("wait", help="Block until task completes")
    wait_p.add_argument("task_id")
    wait_p.add_argument("--timeout", type=int, default=3600)

    chat_p = sub.add_parser("chat", help="Chat with summary (RAG)")
    chat_p.add_argument("run_id")
    chat_p.add_argument("--message", "-m", required=True)
    chat_p.add_argument("--model", choices=["claude", "ollama"], default="claude")

    return p


def dispatch(args):
    """Route parsed args to the correct command handler."""
    fmt = args.format
    cmd = args.command

    if not cmd:
        build_parser().print_help()
        sys.exit(2)

    # ── Email ────────────────────────────────────────────────────────
    if cmd == "email":
        from medcli_lib.email_cmds import handle_email
        ecmd = args.email_cmd
        if not ecmd:
            build_parser().parse_args(["email", "--help"])
            sys.exit(2)
        key = f"email.{ecmd}"
        _run(key, lambda a: handle_email(ecmd, a), args, fmt)

    # ── Contact ──────────────────────────────────────────────────────
    elif cmd == "contact":
        from medcli_lib.contact_cmds import handle_contact
        ccmd = args.contact_cmd
        if not ccmd:
            build_parser().parse_args(["contact", "--help"])
            sys.exit(2)
        key = f"contact.{ccmd}"
        _run(key, lambda a: handle_contact(ccmd, a), args, fmt)

    # ── Notify ───────────────────────────────────────────────────────
    elif cmd == "notify":
        from medcli_lib.notify_cmds import handle_notify
        ncmd = args.notify_cmd
        if not ncmd:
            build_parser().parse_args(["notify", "--help"])
            sys.exit(2)
        key = f"notify.{ncmd}"
        _run(key, lambda a: handle_notify(ncmd, a), args, fmt)

    # ── Pipeline ─────────────────────────────────────────────────────
    elif cmd == "pipeline":
        from medcli_lib.pipeline_cmds import handle_pipeline
        pcmd = args.pipeline_cmd
        if not pcmd:
            build_parser().parse_args(["pipeline", "--help"])
            sys.exit(2)
        key = f"pipeline.{pcmd}"
        _run(key, lambda a: handle_pipeline(pcmd, a), args, fmt)

    # ── File ─────────────────────────────────────────────────────────
    elif cmd == "file":
        from medcli_lib.file_cmds import handle_file
        fcmd = args.file_cmd
        if not fcmd:
            build_parser().parse_args(["file", "--help"])
            sys.exit(2)
        key = f"file.{fcmd}"
        _run(key, lambda a: handle_file(fcmd, a), args, fmt)

    # ── Summary ──────────────────────────────────────────────────────
    elif cmd == "summary":
        from medcli_lib.analysis_cmds import handle_summary
        scmd = args.summary_cmd
        if not scmd:
            build_parser().parse_args(["summary", "--help"])
            sys.exit(2)
        key = f"summary.{scmd}"
        _run(key, lambda a: handle_summary(scmd, a), args, fmt)

    # ── Demand ───────────────────────────────────────────────────────
    elif cmd == "demand":
        from medcli_lib.analysis_cmds import handle_demand
        dcmd = args.demand_cmd
        if not dcmd:
            build_parser().parse_args(["demand", "--help"])
            sys.exit(2)
        _run("demand.generate", lambda a: handle_demand(dcmd, a), args, fmt)

    # ── Valuation ────────────────────────────────────────────────────
    elif cmd == "valuation":
        from medcli_lib.analysis_cmds import handle_valuation
        vcmd = args.valuation_cmd
        if not vcmd:
            build_parser().parse_args(["valuation", "--help"])
            sys.exit(2)
        _run("valuation.estimate", lambda a: handle_valuation(vcmd, a), args, fmt)

    # ── Negligence ───────────────────────────────────────────────────
    elif cmd == "negligence":
        from medcli_lib.analysis_cmds import handle_negligence
        ncmd = args.negligence_cmd
        if not ncmd:
            build_parser().parse_args(["negligence", "--help"])
            sys.exit(2)
        _run("negligence.analyze", lambda a: handle_negligence(ncmd, a), args, fmt)

    # ── CRM ──────────────────────────────────────────────────────────
    elif cmd == "crm":
        from medcli_lib.crm_cmds import handle_crm
        ccmd = args.crm_cmd
        if not ccmd:
            build_parser().parse_args(["crm", "--help"])
            sys.exit(2)
        key = f"crm.{ccmd}"
        _run(key, lambda a: handle_crm(ccmd, a), args, fmt)

    # ── Campaign ──────────────────────────────────────────────────────
    elif cmd == "campaign":
        from medcli_lib.campaign_cmds import handle_campaign
        ccmd = args.campaign_cmd
        if not ccmd:
            build_parser().parse_args(["campaign", "--help"])
            sys.exit(2)
        key = f"campaign.{ccmd}"
        _run(key, lambda a: handle_campaign(ccmd, a), args, fmt)

    # ── System: health, status, audit, config ────────────────────────
    elif cmd == "health":
        from medcli_lib.system_cmds import cmd_health
        _run("health", cmd_health, args, fmt)

    elif cmd == "status":
        from medcli_lib.system_cmds import cmd_status
        _run("status", cmd_status, args, fmt)

    elif cmd == "audit":
        from medcli_lib.system_cmds import cmd_audit
        _run("audit", cmd_audit, args, fmt)

    elif cmd == "config":
        from medcli_lib.system_cmds import cmd_config
        if not args.config_cmd:
            build_parser().parse_args(["config", "--help"])
            sys.exit(2)
        _run("config.show", cmd_config, args, fmt)

    # ── Agent ────────────────────────────────────────────────────────
    elif cmd == "agent":
        from medcli_lib.agent_cmds import handle_agent
        acmd = args.agent_cmd
        if not acmd:
            build_parser().parse_args(["agent", "--help"])
            sys.exit(2)
        key = f"agent.{acmd}"
        _run(key, lambda a: handle_agent(acmd, a), args, fmt)

    # ── Service / Customer Success ────────────────────────────────────
    elif cmd == "service":
        from medcli_lib.service_cmds import handle_service
        scmd = args.service_cmd
        if not scmd:
            build_parser().parse_args(["service", "--help"])
            sys.exit(2)
        key = f"service.{scmd}"
        _run(key, lambda a: handle_service(scmd, a), args, fmt)

    # ── Top-level: wait, chat ────────────────────────────────────────
    elif cmd == "wait":
        from medcli_lib.pipeline_cmds import cmd_wait
        _run("wait", cmd_wait, args, fmt)

    elif cmd == "chat":
        from medcli_lib.analysis_cmds import cmd_chat
        _run("chat", cmd_chat, args, fmt)

    else:
        output(error("unknown_command", f"Unknown command: {cmd}"), fmt=fmt)
        sys.exit(2)


def main():
    parser = build_parser()
    args = parser.parse_args()
    dispatch(args)


if __name__ == "__main__":
    main()
