"""
gemini_review.py -- Gemini CLI integration for medical summary accuracy review.

Pipes summary JSON + PHI-redacted source content to Gemini CLI via stdin,
receives structured JSON review output with inaccuracies, unsupported claims,
and omitted findings.

Usage (standalone test):
    python gemini_review.py --summary path/to/summary.json --source path/to/redacted.txt
"""

import json
import logging
import shutil
import subprocess
import sys
import platform
from datetime import datetime, timezone
from pathlib import Path

from pipeline_schemas import extract_json_from_response, validate_review_output, REVIEW_SCHEMA_EXAMPLE

logger = logging.getLogger("gemini_review")

# Windows subprocess flags to hide console window
_STARTUPINFO = None
_CREATION_FLAGS = 0
if platform.system() == "Windows":
    _STARTUPINFO = subprocess.STARTUPINFO()
    _STARTUPINFO.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    _CREATION_FLAGS = subprocess.CREATE_NO_WINDOW


def _gemini_cmd():
    """Return the correct Gemini CLI command name for the platform.
    On Windows, subprocess needs 'gemini.cmd' (the npm shim), not 'gemini'."""
    if platform.system() == "Windows":
        # Try gemini.cmd first (npm global install), fall back to gemini
        if shutil.which("gemini.cmd"):
            return "gemini.cmd"
    return "gemini"


def is_gemini_available():
    """Check if Gemini CLI is installed and on PATH."""
    return shutil.which(_gemini_cmd()) is not None


def run_gemini_review(summary_json, redacted_source, config=None):
    """
    DEPRECATED: Redirects to run_bedrock_review() for HIPAA compliance.
    Gemini CLI is not BAA-covered — all review calls must go through Bedrock.
    """
    logger.warning("run_gemini_review() is deprecated — routing to run_bedrock_review()")
    return run_bedrock_review(summary_json, redacted_source, config)


# ── AWS Bedrock Review (HIPAA-compliant replacement for Gemini CLI) ──────────

def run_bedrock_review(summary_json, redacted_source, config=None):
    """
    Run AWS Bedrock Claude to review a medical summary against PHI-redacted source.
    HIPAA-compliant via AWS BAA. Drop-in replacement for run_gemini_review().

    Args:
        summary_json: dict -- the summary to review
        redacted_source: str -- PHI-redacted source content (all files concatenated)
        config: dict -- config with bedrock.review_model, bedrock.review_timeout

    Returns:
        dict -- review output conforming to REVIEW_SCHEMA_EXAMPLE, or None on failure
    """
    from dispatch import call_bedrock

    bedrock_cfg = (config or {}).get("bedrock", {})
    review_model = bedrock_cfg.get("review_model", "us.anthropic.claude-sonnet-4-5-v2:0")
    timeout = bedrock_cfg.get("review_timeout", 300)
    retries = bedrock_cfg.get("retries", 2)

    # Build the review prompt with schema example
    schema_str = json.dumps(REVIEW_SCHEMA_EXAMPLE, indent=2)
    summary_str = json.dumps(summary_json, indent=2)

    system_prompt = (
        "You are a medical-legal accuracy reviewer. Your task is to compare "
        "the SUMMARY below against the SOURCE DOCUMENT (PHI-redacted). "
        "For every factual claim in the summary, verify it is supported by the source.\n\n"
        "Identify:\n"
        "1. **Inaccuracies**: Claims that contradict the source (wrong dates, wrong "
        "providers, wrong measurements, transposed values)\n"
        "2. **Unsupported claims**: Claims with no evidence in the source\n"
        "3. **Omitted findings**: Critical findings in the source that are missing "
        "from the summary\n\n"
        "CRITICAL — HIPAA PHI DETECTION:\n"
        "4. **Unredacted PHI**: Scan the summary for ANY unredacted Protected Health "
        "Information. This includes patient names, dates of birth, SSN, MRN, specific "
        "treatment dates (YYYY-MM-DD format — dates more specific than year are PHI), "
        "phone numbers, email addresses, street addresses, insurance/policy numbers. "
        "Add each instance to a 'phi_detected' array with: phi_text, location, "
        "phi_type (name/date/mrn/ssn/phone/address/etc.), severity (high/medium/low). "
        "If no PHI found, return empty array: \"phi_detected\": []\n\n"
        "Output ONLY valid JSON matching this schema:\n"
        f"```json\n{schema_str}\n```\n\n"
        "Set accuracy_score between 0.0 (all wrong) and 1.0 (perfect). "
        "If everything checks out, return empty arrays and score ~0.98-1.0."
    )

    # Content size safeguard — truncate source if it would exceed model limits
    # Reserve ~20K tokens for summary + schema + output
    max_source_chars = 600000  # ~150K tokens, conservative
    if len(redacted_source) > max_source_chars:
        logger.warning("Review source too large (%d chars), truncating to %d",
                       len(redacted_source), max_source_chars)
        redacted_source = redacted_source[:max_source_chars]

    user_content = (
        f"## SUMMARY TO REVIEW\n```json\n{summary_str}\n```\n\n"
        f"## SOURCE DOCUMENT (PHI-REDACTED)\n{redacted_source}\n"
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    for attempt in range(1, retries + 1):
        try:
            logger.info("Bedrock review attempt %d/%d (model=%s, timeout=%ds)",
                        attempt, retries, review_model.split(".")[-1], timeout)

            raw_output = call_bedrock(
                model_id=review_model,
                messages=messages,
                config=config or {},
                timeout_override=timeout,
                max_tokens_override=16384,
            )

            if not raw_output or raw_output.startswith("__ERROR__:"):
                logger.warning("Bedrock review returned error: %s",
                               raw_output[:200] if raw_output else "(empty)")
                if attempt < retries:
                    continue
                return None

            parsed = extract_json_from_response(raw_output)
            if parsed is None:
                logger.warning("Could not extract JSON from Bedrock review (%d chars)",
                               len(raw_output))
                if attempt < retries:
                    continue
                return None

            # Validate
            errors = validate_review_output(parsed)
            critical = [e for e in errors if e.startswith("CRITICAL")]
            if critical:
                logger.warning("Bedrock review output validation failed: %s", critical)
                if attempt < retries:
                    continue
                return None

            # Ensure timestamp is set
            if not parsed.get("review_timestamp"):
                parsed["review_timestamp"] = datetime.now(timezone.utc).isoformat()
            parsed["reviewer"] = "bedrock"

            logger.info("Bedrock review complete: accuracy=%.2f, inaccuracies=%d, "
                        "unsupported=%d, omitted=%d",
                        parsed.get("accuracy_score", 0),
                        len(parsed.get("inaccuracies_found", [])),
                        len(parsed.get("unsupported_claims", [])),
                        len(parsed.get("omitted_findings", [])))
            return parsed

        except RuntimeError as e:
            err_str = str(e)
            logger.warning("Bedrock review attempt %d/%d failed: %s",
                           attempt, retries, err_str[:200])
            if attempt < retries:
                continue
            logger.warning("Bedrock review failed after %d attempts -- skipping", retries)
            return None

        except Exception as e:
            logger.warning("Bedrock review unexpected error: %s", e)
            if attempt < retries:
                continue
            return None

    return None


# ── Cross-Model Verification (model-agnostic Converse API) ───────────────────

def _detect_model_family(model_id):
    """Identify the model family from a Bedrock model ID."""
    mid = model_id.lower()
    if "anthropic" in mid or "claude" in mid:
        return "anthropic_claude"
    if "amazon" in mid or "nova" in mid:
        return "amazon_nova"
    if "meta" in mid or "llama" in mid:
        return "meta_llama"
    if "mistral" in mid:
        return "mistral"
    if "cohere" in mid:
        return "cohere"
    return "unknown"


def run_cross_model_review(summary_json, redacted_source, config=None):
    """
    Cross-model verification: uses a NON-Claude model via Bedrock Converse API
    to independently verify a Claude-generated summary against source materials.

    Provides a genuine second-opinion by using a different model architecture.
    HIPAA-compliant via AWS BAA. Returns review dict conforming to
    REVIEW_SCHEMA_EXAMPLE + cross_model metadata, or None on failure.

    Args:
        summary_json: dict -- the summary to verify
        redacted_source: str -- PHI-redacted source content
        config: dict -- config with bedrock.cross_model_review settings

    Returns:
        dict -- review output with cross-model metadata, or None on failure
    """
    from dispatch import call_bedrock_converse

    if not summary_json or not isinstance(summary_json, dict):
        logger.warning("Cross-model review skipped: invalid summary_json (type=%s)",
                       type(summary_json).__name__)
        return None

    bedrock_cfg = (config or {}).get("bedrock", {})
    cross_cfg = bedrock_cfg.get("cross_model_review", {})

    if not cross_cfg.get("enabled", False):
        logger.info("Cross-model verification disabled in config")
        return None

    review_model = cross_cfg.get("model", "us.amazon.nova-pro-v1:0")
    fallback_model = cross_cfg.get("fallback_model", "us.amazon.nova-lite-v1:0")
    timeout = cross_cfg.get("timeout", 300)
    retries = cross_cfg.get("retries", 2)
    required = cross_cfg.get("required", False)
    max_source_chars = cross_cfg.get("max_source_chars", 300000)

    # Build the review prompt
    schema_str = json.dumps(REVIEW_SCHEMA_EXAMPLE, indent=2)
    summary_str = json.dumps(summary_json, indent=2)

    system_prompt = (
        "You are an independent medical-legal accuracy reviewer. Your role is to provide "
        "a SECOND OPINION on a clinical summary that was generated by a DIFFERENT AI system. "
        "You must independently verify every factual claim against the source document. "
        "Do not assume the original summary is correct — verify each claim from scratch.\n\n"
        "For every factual claim in the summary, check it against the source document and identify:\n"
        "1. **Inaccuracies**: Claims that contradict the source (wrong dates, wrong "
        "providers, wrong measurements, transposed values)\n"
        "2. **Unsupported claims**: Claims with no evidence in the source\n"
        "3. **Omitted findings**: Critical findings in the source that are missing "
        "from the summary\n\n"
        "CRITICAL — HIPAA PHI DETECTION:\n"
        "4. **Unredacted PHI**: Scan the summary for ANY unredacted Protected Health "
        "Information that should have been removed during de-identification. This includes:\n"
        "   - Patient names, dates of birth, Social Security numbers\n"
        "   - Medical record numbers (MRN), account numbers\n"
        "   - Specific treatment dates (e.g., 2024-08-27) that were NOT replaced with "
        "[REDACTED_DATE] tokens — dates more specific than year are PHI under HIPAA Safe Harbor\n"
        "   - Phone numbers, email addresses, street addresses\n"
        "   - Insurance/policy numbers, provider NPI numbers\n"
        "   - Any other HIPAA Safe Harbor identifiers\n"
        "If you find unredacted PHI, add each instance to the 'phi_detected' array. "
        "For each instance, provide: the PHI text found, the field/location in the summary "
        "where it appears, and the type of PHI (name, date, mrn, ssn, phone, address, etc.).\n\n"
        "Output ONLY valid JSON matching this schema:\n"
        f"```json\n{schema_str}\n```\n\n"
        "IMPORTANT: Also include a 'phi_detected' array in your output:\n"
        "```json\n"
        "\"phi_detected\": [\n"
        "  {\"phi_text\": \"2024-08-27\", \"location\": \"master_chronology[0].date\", "
        "\"phi_type\": \"treatment_date\", \"severity\": \"high\"}\n"
        "]\n"
        "```\n"
        "If no PHI is found, return an empty array: \"phi_detected\": []\n\n"
        "Set accuracy_score between 0.0 (all wrong) and 1.0 (perfect). "
        "If everything checks out, return empty arrays and score ~0.98-1.0."
    )

    # Truncate source if needed for model context window
    if len(redacted_source) > max_source_chars:
        logger.warning("Cross-model review source too large (%d chars), truncating to %d",
                       len(redacted_source), max_source_chars)
        redacted_source = redacted_source[:max_source_chars]

    user_content = (
        f"## SUMMARY TO VERIFY (generated by a different AI)\n```json\n{summary_str}\n```\n\n"
        f"## SOURCE DOCUMENT (PHI-REDACTED)\n{redacted_source}\n"
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    # Try primary model, then fallback
    models_to_try = [review_model]
    if fallback_model and fallback_model != review_model:
        models_to_try.append(fallback_model)

    for model_idx, current_model in enumerate(models_to_try):
        model_label = current_model.split(".")[-1] if "." in current_model else current_model
        is_fallback = model_idx > 0

        for attempt in range(1, retries + 1):
            try:
                logger.info("Cross-model review attempt %d/%d (model=%s%s, timeout=%ds)",
                            attempt, retries, model_label,
                            " [fallback]" if is_fallback else "", timeout)

                raw_output = call_bedrock_converse(
                    model_id=current_model,
                    messages=messages,
                    config=config or {},
                    timeout_override=timeout,
                    max_tokens_override=5120,
                )

                if not raw_output or raw_output.startswith("__ERROR__:"):
                    logger.warning("Cross-model review returned error: %s",
                                   raw_output[:200] if raw_output else "(empty)")
                    if attempt < retries:
                        continue
                    break  # Try fallback model

                parsed = extract_json_from_response(raw_output)
                if parsed is None:
                    logger.warning("Could not extract JSON from cross-model review (%d chars)",
                                   len(raw_output))
                    if attempt < retries:
                        continue
                    break

                # Validate
                errors = validate_review_output(parsed)
                critical = [e for e in errors if e.startswith("CRITICAL")]
                if critical:
                    logger.warning("Cross-model review validation failed: %s", critical)
                    if attempt < retries:
                        continue
                    break

                # Tag with cross-model metadata
                if not parsed.get("review_timestamp"):
                    parsed["review_timestamp"] = datetime.now(timezone.utc).isoformat()
                parsed["reviewer"] = "cross_model"
                parsed["model_used"] = current_model
                parsed["model_family"] = _detect_model_family(current_model)

                logger.info("Cross-model review complete (model=%s): accuracy=%.2f, "
                            "inaccuracies=%d, unsupported=%d, omitted=%d",
                            model_label,
                            parsed.get("accuracy_score", 0),
                            len(parsed.get("inaccuracies_found", [])),
                            len(parsed.get("unsupported_claims", [])),
                            len(parsed.get("omitted_findings", [])))
                return parsed

            except RuntimeError as e:
                err_str = str(e)
                logger.warning("Cross-model review attempt %d/%d failed: %s",
                               attempt, retries, err_str[:200])
                if attempt < retries:
                    continue
                break  # Try fallback model

            except Exception as e:
                logger.warning("Cross-model review unexpected error: %s", e)
                if attempt < retries:
                    continue
                break

        if is_fallback:
            logger.warning("Cross-model review failed on both primary and fallback models")

    # All attempts exhausted
    if required:
        raise RuntimeError("Cross-model verification failed and is configured as required")

    logger.warning("Cross-model review failed — skipping (required=false)")
    return None


# ── Standalone test ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    logging.basicConfig(level=logging.INFO, format="%(levelname)-8s %(message)s")

    parser = argparse.ArgumentParser(description="Test Gemini review")
    parser.add_argument("--summary", required=True, help="Path to summary JSON")
    parser.add_argument("--source", required=True, help="Path to redacted source text")
    args = parser.parse_args()

    with open(args.summary) as f:
        summary = json.load(f)
    with open(args.source) as f:
        source = f.read()

    result = run_gemini_review(summary, source)
    if result:
        print(json.dumps(result, indent=2))
    else:
        print("Review failed or was skipped", file=sys.stderr)
        sys.exit(1)
