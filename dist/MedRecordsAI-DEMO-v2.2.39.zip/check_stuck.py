import sqlite3
import json
from datetime import datetime, timezone

def check_stuck_tasks():
    conn = sqlite3.connect('tracking.db')
    cursor = conn.cursor()
    cursor.execute("SELECT task_id, agent, started_at, task FROM tasks WHERE status='running'")
    running_tasks = cursor.fetchall()
    
    now = datetime.now(timezone.utc)
    stuck_ids = []
    active_tasks = []
    
    for task_id, agent, started_at, task_content in running_tasks:
        if not started_at:
            stuck_ids.append(task_id)
            continue
        
        try:
            if 'T' in started_at:
                start_time = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
            else:
                start_time = datetime.strptime(started_at, '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
            
            diff = now - start_time
            if diff.total_seconds() > 10800: # 3 hours
                stuck_ids.append(task_id)
            else:
                active_tasks.append((task_id, agent, started_at, diff.total_seconds()))
        except Exception:
            stuck_ids.append(task_id)
            
    print(f"Total running: {len(running_tasks)}")
    print(f"Stuck (>3h): {len(stuck_ids)}")
    print(f"Active (<3h): {len(active_tasks)}")
    
    for task_id, agent, started_at, diff in active_tasks:
        print(f"ID: {task_id}")
        print(f"  Agent: {agent}")
        print(f"  Started: {started_at} (Duration: {int(diff)}s)")
    
    conn.close()

if __name__ == "__main__":
    check_stuck_tasks()
