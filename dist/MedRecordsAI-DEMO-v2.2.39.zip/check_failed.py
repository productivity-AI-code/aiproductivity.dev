import sqlite3
import json

def check_failed_tasks():
    conn = sqlite3.connect('tracking.db')
    cursor = conn.cursor()
    cursor.execute("SELECT task_id, agent, status, error, task FROM tasks WHERE status='failed' LIMIT 5")
    failed_tasks = cursor.fetchall()
    
    for task in failed_tasks:
        print(f"ID: {task[0]}")
        print(f"  Agent: {task[1]}")
        print(f"  Status: {task[2]}")
        print(f"  Error: {task[3]}")
        print(f"  Task Prefix: {task[4][:200]}...")
        print("-" * 20)
    
    conn.close()

if __name__ == "__main__":
    check_failed_tasks()
