
import hashlib
import json
import logging
import os
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath

import requests

logger = logging.getLogger("updater")

MANIFEST_URL = "https://aiproductivity.dev/dist/manifest.json"
BASE_DIR = Path(__file__).parent


class Updater:
    def __init__(self, current_version):
        self.current_version = current_version

    def check_for_updates(self):
        """Check if a newer version is available."""
        try:
            resp = requests.get(MANIFEST_URL, timeout=10, verify=True)
            resp.raise_for_status()
            manifest = resp.json()
            latest_version = manifest.get("version")

            if self._is_newer(latest_version, self.current_version):
                return {
                    "update_available": True,
                    "latest_version": latest_version,
                    "download_url": manifest.get("download_url"),
                    "changelog": manifest.get("changelog", "No changelog provided."),
                    "sha256": manifest.get("sha256"),  # May be None for old manifests
                }
        except Exception as e:
            logger.error("Update check failed: %s", e)

        return {"update_available": False}

    def _is_newer(self, latest, current):
        """Simple version comparison (e.g. 2.2.6 > 2.2.5)"""
        try:
            l_parts = [int(p) for p in latest.split(".")]
            c_parts = [int(p) for p in current.split(".")]
            return l_parts > c_parts
        except Exception:
            return latest != current

    @staticmethod
    def _validate_zip_entries(zip_ref):
        """Reject ZIP files containing path traversal or absolute path entries."""
        for entry in zip_ref.namelist():
            # Reject absolute paths
            if PurePosixPath(entry).is_absolute() or (len(entry) > 1 and entry[1] == ":"):
                raise ValueError(f"ZIP contains absolute path: {entry}")
            # Reject directory traversal
            if ".." in entry.split("/") or ".." in entry.split("\\"):
                raise ValueError(f"ZIP contains path traversal: {entry}")
            # Reject entries that resolve outside extraction root
            try:
                Path(entry).resolve()
            except Exception:
                raise ValueError(f"ZIP contains invalid path: {entry}")

    def apply_update(self, download_url, expected_sha256=None):
        """Download and apply update ZIP with integrity verification."""
        update_tmp = BASE_DIR / "vault" / "tmp" / "update.zip"
        update_tmp.parent.mkdir(parents=True, exist_ok=True)

        try:
            logger.info("Downloading update from %s ...", download_url)
            resp = requests.get(download_url, stream=True, timeout=60, verify=True)
            resp.raise_for_status()

            # Stream download and compute SHA256 simultaneously
            sha256 = hashlib.sha256()
            with open(update_tmp, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        sha256.update(chunk)

            computed_hash = sha256.hexdigest()

            # Verify integrity if hash was provided
            if expected_sha256:
                if computed_hash != expected_sha256.lower():
                    logger.error(
                        "Update integrity check FAILED: expected %s, got %s",
                        expected_sha256, computed_hash,
                    )
                    update_tmp.unlink(missing_ok=True)
                    return False
                logger.info("Update integrity verified (SHA256: %s)", computed_hash[:16])
            else:
                logger.warning(
                    "No SHA256 hash provided in manifest — update integrity unverified. "
                    "This is acceptable for legacy manifests but should be fixed."
                )

            logger.info("Extracting update...")
            with zipfile.ZipFile(update_tmp, "r") as zip_ref:
                # Validate ZIP entries for path traversal attacks
                self._validate_zip_entries(zip_ref)

                # Extract to a temporary folder to avoid overwriting running code
                extract_path = BASE_DIR / "vault" / "tmp" / "extracted_update"
                if extract_path.exists():
                    shutil.rmtree(extract_path)
                zip_ref.extractall(extract_path)

                # In a real on-premise app, we'd trigger a .bat script to
                # kill the process, move files, and restart.
                # For this implementation, we'll mark it as 'pending_restart'
                return True
        except ValueError as e:
            logger.error("Update rejected — ZIP validation failed: %s", e)
            update_tmp.unlink(missing_ok=True)
            return False
        except Exception as e:
            logger.error("Update failed: %s", e)
            update_tmp.unlink(missing_ok=True)
            return False
