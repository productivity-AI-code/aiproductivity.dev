import sqlite3
import json
from datetime import datetime

def check_running_tasks():
    conn = sqlite3.connect('tracking.db')
    cursor = conn.cursor()
    # Handle None values by using COALESCE or checking in Python
    cursor.execute("SELECT task_id, agent, started_at, task FROM tasks WHERE status='running' ORDER BY started_at ASC")
    running_tasks = cursor.fetchall()
    
    now = datetime.utcnow()
    
    print(f"Current UTC time: {now}")
    print(f"Running tasks: {len(running_tasks)}")
    print("-" * 20)
    
    for task in running_tasks[:10]:
        started_at = task[2]
        if started_at:
            try:
                # Try common formats
                if 'T' in started_at:
                    start_time = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
                else:
                    start_time = datetime.strptime(started_at, '%Y-%m-%d %H:%M:%S')
                duration = now - start_time.replace(tzinfo=None)
            except Exception as e:
                duration = f"Error parsing: {started_at} ({e})"
        else:
            duration = "Unknown (None)"
            
        print(f"ID: {task[0]}")
        print(f"  Agent: {task[1]}")
        print(f"  Started: {started_at} (Duration: {duration})")
        print(f"  Task Prefix: {task[3][:100]}...")
        print("-" * 20)
    
    conn.close()

if __name__ == "__main__":
    check_running_tasks()
