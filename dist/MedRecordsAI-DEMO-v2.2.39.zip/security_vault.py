"""
security_vault.py — HIPAA-compliant encryption layer using Fernet (AES-128-CBC + HMAC-SHA256).

Key storage priority:
  1. OS credential store (Windows Credential Manager / macOS Keychain) via keyring
  2. VAULT_KEY environment variable (for Docker/CI)
  3. Migration from legacy vault/.vault_key file → moves key to OS store, deletes file

The encryption key is NEVER stored alongside the encrypted data on disk.
"""

import os
import base64
import logging
from pathlib import Path
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.fernet import Fernet

logger = logging.getLogger("security_vault")

# Legacy key file path (for migration only — new installs use OS keyring)
_LEGACY_KEY_FILE = Path(__file__).parent / "vault" / ".vault_key"

# Keyring service/account identifiers
_KEYRING_SERVICE = "medrecords-vault"
_KEYRING_ACCOUNT = "master-key"


def _get_key_from_keyring():
    """Try to load the Fernet key from the OS credential store."""
    try:
        import keyring
        stored = keyring.get_password(_KEYRING_SERVICE, _KEYRING_ACCOUNT)
        if stored:
            return stored.encode("ascii")
    except Exception as e:
        logger.debug("Keyring read failed: %s", e)
    return None


def _store_key_in_keyring(key_bytes):
    """Store a Fernet key in the OS credential store."""
    try:
        import keyring
        keyring.set_password(_KEYRING_SERVICE, _KEYRING_ACCOUNT, key_bytes.decode("ascii"))
        logger.info("Vault key stored in OS credential store (%s)",
                     keyring.get_keyring().__class__.__name__)
        return True
    except Exception as e:
        logger.warning("Could not store key in OS keyring: %s", e)
        return False


def _migrate_legacy_key():
    """Migrate key from legacy vault/.vault_key file to OS keyring, then delete the file."""
    if not _LEGACY_KEY_FILE.exists():
        return None

    try:
        with open(_LEGACY_KEY_FILE, "rb") as f:
            data = f.read()
        _salt, key = data.split(b"||")
        # Validate it's a working Fernet key
        Fernet(key)

        # Store in OS keyring
        if _store_key_in_keyring(key):
            # Delete the file so key is no longer co-located with data
            try:
                _LEGACY_KEY_FILE.unlink()
                logger.info("Migrated vault key to OS credential store and deleted legacy file")
            except OSError as e:
                logger.warning("Could not delete legacy key file: %s (delete manually: %s)", e, _LEGACY_KEY_FILE)
        return key
    except Exception as e:
        logger.warning("Legacy key migration failed: %s", e)
        return None


def _generate_new_key():
    """Generate a new Fernet key using PBKDF2 with random seed."""
    import socket
    import uuid
    seed = os.urandom(32) + socket.gethostname().encode() + str(uuid.getnode()).encode()

    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(seed))
    return key


class Vault:
    _fernet = None

    @classmethod
    def _get_fernet(cls):
        if cls._fernet:
            return cls._fernet

        key = None

        # Priority 1: OS credential store (keyring)
        key = _get_key_from_keyring()
        if key:
            logger.debug("Vault key loaded from OS credential store")

        # Priority 2: Environment variable (for Docker/CI)
        if not key:
            env_key = os.getenv("VAULT_KEY")
            if env_key:
                key = env_key.encode("ascii")
                logger.debug("Vault key loaded from VAULT_KEY env var")

        # Priority 3: Migrate from legacy file
        if not key:
            key = _migrate_legacy_key()

        # Priority 4: Generate new key and store in OS keyring
        if not key:
            logger.info("Generating new vault master key...")
            key = _generate_new_key()
            if not _store_key_in_keyring(key):
                # Last resort: write to file if keyring is unavailable
                logger.warning("OS keyring unavailable — storing key in file (NOT recommended for production)")
                _LEGACY_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
                salt = os.urandom(16)
                with open(_LEGACY_KEY_FILE, "wb") as f:
                    f.write(salt + b"||" + key)

        cls._fernet = Fernet(key)
        return cls._fernet

    @classmethod
    def encrypt(cls, data):
        """Encrypt bytes or string data."""
        if isinstance(data, str):
            data = data.encode("utf-8")
        f = cls._get_fernet()
        return f.encrypt(data)

    @classmethod
    def decrypt(cls, token):
        """Decrypt data back to bytes. Raises on failure — never returns plaintext."""
        f = cls._get_fernet()
        try:
            return f.decrypt(token)
        except Exception as e:
            logger.error("Decryption failed — data may be corrupted or key mismatch: %s", type(e).__name__)
            raise

    @classmethod
    def encrypt_file(cls, source_path, dest_path=None):
        """Encrypt a file on disk."""
        source_path = Path(source_path)
        if not dest_path:
            dest_path = source_path

        with open(source_path, "rb") as f:
            raw_data = f.read()

        encrypted_data = cls.encrypt(raw_data)

        with open(dest_path, "wb") as f:
            f.write(encrypted_data)

        logger.debug("Encrypted file: %s", source_path.name)

    @classmethod
    def decrypt_file(cls, source_path):
        """Decrypt an encrypted file from disk and return bytes."""
        with open(source_path, "rb") as f:
            encrypted_data = f.read()
        return cls.decrypt(encrypted_data)

    @classmethod
    def is_encrypted(cls, path):
        """Check if a file is a Fernet token (base64 encoded, starts with gAAAA)."""
        try:
            with open(path, "rb") as f:
                header = f.read(5)
                return header == b'gAAAA'
        except (OSError, IOError):
            return False

    @classmethod
    def encrypt_field(cls, value):
        """Encrypt a string field for database storage. Returns base64 ASCII string."""
        if not value:
            return None
        encrypted = cls.encrypt(value)
        return encrypted.decode("ascii") if isinstance(encrypted, bytes) else encrypted

    @classmethod
    def decrypt_field(cls, encrypted_value):
        """Decrypt a database field back to string. Returns None if input is None."""
        if not encrypted_value:
            return None
        try:
            token = encrypted_value.encode("ascii") if isinstance(encrypted_value, str) else encrypted_value
            return cls.decrypt(token).decode("utf-8")
        except Exception:
            logger.warning("Could not decrypt field — may be plaintext legacy data")
            return encrypted_value
