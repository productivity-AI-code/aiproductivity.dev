import os
import shutil
from pathlib import Path

def reclaim_vault():
    base_dir = Path(r"C:\Users\dandi\projects\ai-team")
    processing_dir = base_dir / "vault" / "processing"
    incoming_dir = base_dir / "vault" / "incoming"
    
    if not processing_dir.exists():
        print("Processing directory does not exist.")
        return

    # Files to move back (excluding subdirectories like checkpoints/failed)
    files_reclaimed = 0
    for item in processing_dir.iterdir():
        if item.is_file():
            # Remove run_id prefix if it was added by the watcher (e.g. case_2026..._filename.txt)
            # The watcher uses run_id + "_" + original_name
            # We move it back to incoming so it can be re-detected
            dest = incoming_dir / item.name
            try:
                shutil.move(str(item), str(dest))
                files_reclaimed += 1
            except Exception as e:
                print(f"Failed to move {item.name}: {e}")
                
    print(f"Successfully reclaimed {files_reclaimed} files from processing to incoming.")

if __name__ == "__main__":
    reclaim_vault()
