"""
medical_app.py -- Flask backend for Medical Records Retrieval & Summarization UI.

Production-hardened with:
- Session-based authentication + API key support
- CSRF protection on all state-changing endpoints
- Rate limiting on upload/auth endpoints
- Security headers (CSP, X-Frame-Options, etc.)
- Input validation with field length limits
- Pagination on list endpoints
- Structured JSON logging with rotation
- Health check endpoint with dependency verification
- HIPAA access logging
- Startup configuration validation
- Batch contact import from Excel
- HMAC-signed audit trail entries

Usage:
  python medical_app.py                   # Run on configured port
  python medical_app.py --port 8080       # Custom port
"""

import argparse
import hashlib
import io
import json
import logging
import logging.handlers
import os
import re
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import yaml
from dotenv import load_dotenv
from flask import (
    Flask, request, jsonify, send_from_directory, send_file, abort, session, redirect,
    make_response,
)
from werkzeug.utils import secure_filename

from security_vault import Vault

load_dotenv()

BASE_DIR = Path(__file__).parent
VAULT_INCOMING = BASE_DIR / "vault" / "incoming"
VAULT_SUMMARIES = BASE_DIR / "vault" / "summaries"
VAULT_AUDIT = BASE_DIR / "vault" / "audit"
PIPELINE_STATUS_DIR = BASE_DIR / "vault" / "pipeline_status"
UI_DIR = BASE_DIR / "ui"

app = Flask(__name__, static_folder=str(UI_DIR), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100MB

ALLOWED_EXTENSIONS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif",
    ".dcm", ".dicom", ".doc", ".docx", ".txt",
    ".csv", ".json", ".xml", ".log",
    ".xlsx", ".xls", ".html", ".htm",
}

# Maximum concurrent pipeline threads
_active_pipelines = threading.Semaphore(3)


# ── Logging Setup ─────────────────────────────────────────────────────────────

def _setup_logging():
    """Configure structured logging with file rotation."""
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(exist_ok=True)

    formatter = logging.Formatter(
        '{"time":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s",'
        '"message":"%(message)s","module":"%(module)s","line":%(lineno)d}'
    )

    # File handler with rotation (10MB per file, keep 5 backups)
    file_handler = logging.handlers.RotatingFileHandler(
        str(log_dir / "medical_app.log"),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    # Error-only file for quick triage
    error_handler = logging.handlers.RotatingFileHandler(
        str(log_dir / "medical_app_errors.log"),
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    error_handler.setFormatter(formatter)
    error_handler.setLevel(logging.ERROR)

    # Console handler (human-readable)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    ))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(error_handler)
    root_logger.addHandler(console_handler)

    return logging.getLogger("medical_app")


logger = _setup_logging()


# ── Config ────────────────────────────────────────────────────────────────────

def load_config():
    config_path = BASE_DIR / "config.yaml"
    if not config_path.exists():
        # Try to copy from example
        example_path = BASE_DIR / "config.yaml.example"
        if example_path.exists():
            import shutil
            shutil.copy2(example_path, config_path)
            logger.info("Created config.yaml from config.yaml.example")
        else:
            logger.warning("config.yaml not found at %s — using defaults", config_path)
            return {}
    try:
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        logger.error("Failed to load config.yaml: %s", e)
        return {}


# ── Database (uses unified db module) ─────────────────────────────────────────

from db import get_db, init_db, transaction, log_access  # noqa: E402


def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


def safe_write_json(file_path, data, encrypt=True):
    """Write JSON to disk, optionally encrypting."""
    file_path = Path(file_path)
    json_str = json.dumps(data, indent=2)
    
    if encrypt:
        try:
            write_data = Vault.encrypt(json_str)
            mode = "wb"
        except Exception as e:
            logger.error("Failed to encrypt JSON for %s: %s", file_path.name, e)
            write_data = json_str.encode("utf-8")
            mode = "wb"
    else:
        write_data = json_str
        mode = "w"

    with open(file_path, mode, encoding="utf-8" if mode == "w" else None) as f:
        f.write(write_data)


def safe_load_json(file_path):
    """Read JSON from disk, transparently decrypting if needed."""
    file_path = Path(file_path)
    if not file_path.exists():
        return None
    try:
        if Vault.is_encrypted(file_path):
            raw = Vault.decrypt_file(file_path).decode("utf-8")
        else:
            raw = file_path.read_text(encoding="utf-8")
        return json.loads(raw)
    except Exception as e:
        logger.error("Failed to load JSON from %s: %s", file_path.name, e)
        return None


def _normalize_summary_response(data):
    """Normalize summary data so the frontend receives a consistent structure.

    The LLM summarizer may output fields with varying names and nesting
    levels.  This function ensures:
      - data.summary.summary.overall_confidence  exists
      - data.summary.verification               exists (computed if missing)
      - data.summary.billing_data.total_combined exists
      - Common clinical fields are mapped to expected names inside
        data.summary.summary (active_diagnoses, medications, etc.)
    """
    if not data or not isinstance(data.get("summary"), dict):
        return data

    s = data["summary"]

    # ── 1. Ensure inner 'summary' object exists ─────────────────────────
    # Frontend: const summary = data.summary?.summary || {}
    inner = s.get("summary") if isinstance(s.get("summary"), dict) else {}
    needs_inner = not inner

    if needs_inner:
        inner = {}

        # overall_confidence — try multiple field names
        for key in ("overall_confidence", "confidence_overall", "confidence"):
            val = s.get(key)
            if isinstance(val, (int, float)):
                inner["overall_confidence"] = float(val)
                break

        # master_chronology
        if "master_chronology" in s and isinstance(s["master_chronology"], list):
            inner["master_chronology"] = s["master_chronology"]

        # active_diagnoses — from clinical_findings.diagnoses or diagnosis_summary
        clinical = s.get("clinical_findings", {})
        if isinstance(clinical, dict):
            if "diagnoses" in clinical:
                inner["active_diagnoses"] = clinical["diagnoses"]
            if "cross_file_contradictions" in clinical:
                inner["contradictions_flagged"] = clinical["cross_file_contradictions"]
        if "diagnosis_summary" in s and isinstance(s["diagnosis_summary"], list):
            inner.setdefault("active_diagnoses", s["diagnosis_summary"])
        if "cross_file_contradictions" in s and isinstance(s["cross_file_contradictions"], list):
            inner.setdefault("contradictions_flagged", s["cross_file_contradictions"])

        # medications
        meds = s.get("medications_timeline") or s.get("medications")
        if isinstance(meds, dict):
            meds = list(meds.values())
        if isinstance(meds, list) and meds:
            inner["medications"] = meds

        # discovery_deficiencies
        for src in ("discovery_deficiencies", "priority_records_to_obtain"):
            vals = s.get(src)
            if not vals:
                strat = s.get("strategic_summary_for_counsel", {})
                if isinstance(strat, dict):
                    vals = strat.get(src)
            if isinstance(vals, list) and vals:
                inner["discovery_deficiencies"] = vals
                break

        # Direct copy fields
        for key in ("timeline_gaps", "key_findings", "smoking_gun_quotes",
                     "chief_complaint", "alerts"):
            if key in s:
                inner[key] = s[key]

        # chief_complaint fallback from patient_summary
        if "chief_complaint" not in inner:
            ps = s.get("patient_summary") or s.get("patient_profile")
            if isinstance(ps, dict):
                incident = ps.get("incident") or ps.get("incident_summary")
                if isinstance(incident, dict):
                    inner["chief_complaint"] = {
                        "text": incident.get("description", ""),
                        "citation": incident.get("citation", ""),
                    }

        s["summary"] = inner
    else:
        # inner exists — still ensure overall_confidence is populated
        if "overall_confidence" not in inner:
            for key in ("confidence_overall", "confidence"):
                val = s.get(key)
                if isinstance(val, (int, float)):
                    inner["overall_confidence"] = float(val)
                    break

    # ── 2. Compute verification stats if missing ─────────────────────────
    if not isinstance(s.get("verification"), dict) or not s["verification"]:
        inner = s.get("summary", {})
        claim_items = []
        for key in ("active_diagnoses", "medications", "key_findings",
                     "master_chronology"):
            arr = inner.get(key, [])
            if isinstance(arr, list):
                claim_items.extend(arr)

        total = len(claim_items)
        cited = 0
        low_conf = 0
        needs_verify = 0
        for item in claim_items:
            if not isinstance(item, dict):
                continue
            if any(item.get(k) for k in ("citation", "citations", "source",
                                          "source_ref", "cite")):
                cited += 1
            conf = item.get("confidence")
            if isinstance(conf, (int, float)) and conf < 0.7:
                low_conf += 1
            if item.get("needs_verification") or item.get("unverified"):
                needs_verify += 1

        contras = inner.get("contradictions_flagged", [])
        contra_n = len(contras) if isinstance(contras, list) else 0
        gaps = inner.get("discovery_deficiencies", [])
        gaps_n = len(gaps) if isinstance(gaps, list) else 0
        coverage = (cited / total) if total > 0 else 0.0

        s["verification"] = {
            "total_claims": total,
            "claims_with_citations": cited,
            "citation_coverage": round(coverage, 2),
            "low_confidence_claims": low_conf,
            "needs_verification": needs_verify,
            "contradictions_found": contra_n,
            "discovery_gaps": gaps_n,
        }

    # ── 3. Normalize billing total ────────────────────────────────────────
    billing = s.get("billing_data")
    if isinstance(billing, dict) and "total_combined" not in billing:
        for key in ("total_past_documented_charges",
                     "documented_past_medical_costs_total",
                     "total_charges", "total"):
            val = billing.get(key)
            if isinstance(val, (int, float)):
                billing["total_combined"] = val
                break

    return data


# ── Security Middleware ───────────────────────────────────────────────────────

from security import (  # noqa: E402
    init_security, require_auth, rate_limit,
    validate_contact_input, sanitize_string, get_csrf_token,
    validate_startup_config, sign_audit_entry,
)

init_security(app)

try:
    from stripe_webhook import stripe_bp  # noqa: E402
    app.register_blueprint(stripe_bp)
except Exception as e:
    logger.warning("Stripe webhook disabled: %s", e)

# Product guard: tier-based enforcement (demo/core/pro)
try:
    from product_guard import init_product_guard  # noqa: E402
    init_product_guard(app)
except Exception as e:
    logger.warning("Product guard init failed: %s", e)
    # Fallback: try legacy demo guard directly
    try:
        from demo_guard import init_demo_guard  # noqa: E402
        init_demo_guard(app)
    except Exception as e2:
        logger.warning("Demo guard init also failed: %s", e2)

# Dev-only route gate: block Sales/CRM and Service routes in non-dev builds
_DEV_ONLY_PREFIXES = ("/api/crm/", "/api/service/")
try:
    from product_guard import get_build_type as _get_bt
    if _get_bt() != "dev":
        @app.before_request
        def _block_dev_only_routes():
            if any(request.path.startswith(p) for p in _DEV_ONLY_PREFIXES):
                return jsonify({
                    "error": "Feature not available",
                    "message": "Sales and Service features are not available in this build.",
                }), 403
except Exception:
    pass  # dev environment or product_guard not available — allow all

# File integrity checker (verifies no code tampering since packaging)
try:
    from integrity import verify_integrity, start_background_checker, is_critically_tampered  # noqa: E402
    _tampered = verify_integrity()
    if _tampered:
        logger.warning("Integrity check: %d file(s) modified: %s", len(_tampered), ", ".join(_tampered))
    start_background_checker()
except Exception as e:
    logger.warning("Integrity checker disabled: %s", e)


# ── Graceful Shutdown Handler ────────────────────────────────────────────────

_shutting_down = False


def is_shutting_down():
    """Check if the server is in the process of shutting down.
    Used by summarization_watcher to save pipeline checkpoints."""
    return _shutting_down


SHUTDOWN_FLAG_FILE = BASE_DIR / "vault" / ".shutting_down"


def _shutdown_handler(signum, frame):
    """Handle SIGTERM from PM2 — set flag so pipelines can save state."""
    global _shutting_down
    _shutting_down = True
    # Write file-based flag so summarization_watcher (in background threads) can detect shutdown
    try:
        SHUTDOWN_FLAG_FILE.parent.mkdir(parents=True, exist_ok=True)
        SHUTDOWN_FLAG_FILE.write_text(str(time.time()), encoding="utf-8")
    except Exception:
        pass
    logger.info("Graceful shutdown initiated (signal %d) — active pipelines will save checkpoints", signum)


import signal
import atexit
# Register signal handlers for graceful shutdown
# SIGTERM: PM2 sends this before SIGKILL
# SIGINT: Ctrl+C in terminal
# SIGBREAK: Ctrl+Break on Windows
# Only works in main thread — guarded for when module is imported from a background thread
try:
    signal.signal(signal.SIGTERM, _shutdown_handler)
    signal.signal(signal.SIGINT, _shutdown_handler)
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _shutdown_handler)
except ValueError:
    pass  # Not main thread — signal handler already registered by the main process


def _atexit_shutdown():
    """Write shutdown flag on normal exit so pipeline threads can detect it."""
    if not _shutting_down:
        # Signal handler didn't fire — write flag now for any running pipeline threads
        try:
            SHUTDOWN_FLAG_FILE.parent.mkdir(parents=True, exist_ok=True)
            SHUTDOWN_FLAG_FILE.write_text(str(time.time()), encoding="utf-8")
        except Exception:
            pass

atexit.register(_atexit_shutdown)


# ── Stale Pipeline Cleanup ───────────────────────────────────────────────────

CHECKPOINT_DIR = BASE_DIR / "vault" / "processing" / "checkpoints"


def _cleanup_stale_pipelines():
    """Handle pipelines left in 'running' state after a server restart.
    Pipelines with checkpoint files are marked 'interrupted' for auto-resume.
    Pipelines without checkpoints are marked 'failed'."""
    if not PIPELINE_STATUS_DIR.exists():
        return
    cleaned = 0
    interrupted = 0
    for f in PIPELINE_STATUS_DIR.glob("*.json"):
        try:
            data = safe_load_json(f)
            if not data:
                continue
            if data.get("status") in ("running", "interrupted"):
                run_id = f.stem
                checkpoint_file = CHECKPOINT_DIR / f"{run_id}.json"
                has_checkpoint = checkpoint_file.exists()

                if has_checkpoint:
                    # Has checkpoint — mark as interrupted for auto-resume
                    data["status"] = "interrupted"
                    data["error"] = "Pipeline interrupted by server restart — will auto-resume"
                    safe_write_json(f, data, encrypt=False)
                    interrupted += 1
                else:
                    # No checkpoint — mark as failed
                    data["status"] = "failed"
                    data["error"] = "Pipeline interrupted by server restart"
                    data["completed_at"] = datetime.now(timezone.utc).isoformat()
                    safe_write_json(f, data, encrypt=False)
                    cleaned += 1
        except Exception:
            continue
    if cleaned:
        logger.info("Marked %d stale pipelines as failed on startup", cleaned)
    if interrupted:
        logger.info("Found %d interrupted pipelines with checkpoints — will auto-resume", interrupted)

    # Also sync document statuses: any doc marked 'processing' whose pipeline
    # is actually failed/completed should be updated
    try:
        from db import transaction as db_transaction
        now = datetime.now(timezone.utc).isoformat()
        with db_transaction() as conn:
            stuck = conn.execute(
                "SELECT id, run_id FROM documents WHERE status = 'processing'"
            ).fetchall()
            fixed = 0
            for row in stuck:
                run_id = row["run_id"] if isinstance(row, dict) else row[1]
                doc_id = row["id"] if isinstance(row, dict) else row[0]
                if not run_id:
                    continue
                sf = PIPELINE_STATUS_DIR / f"{run_id}.json"
                ps = safe_load_json(sf)
                if ps:
                    pipeline_status = ps.get("status", "unknown")
                    if pipeline_status in ("failed", "completed"):
                        new_status = "failed" if pipeline_status == "failed" else "completed"
                        conn.execute(
                            "UPDATE documents SET status = ?, vault_zone = ?, updated_at = ? WHERE id = ?",
                            (new_status, new_status, now, doc_id),
                        )
                        fixed += 1
            if fixed:
                logger.info("Synced %d stuck document statuses with pipeline results", fixed)
    except Exception as e:
        logger.debug("Document status sync on startup skipped: %s", e)

# Clean up stale shutdown flag from previous process
try:
    if SHUTDOWN_FLAG_FILE.exists():
        SHUTDOWN_FLAG_FILE.unlink()
except Exception:
    pass

_cleanup_stale_pipelines()


def _auto_resume_pipelines():
    """Auto-resume interrupted pipelines that have checkpoints.
    Runs in a background thread after a delay to let the server stabilize."""
    import yaml as _yaml

    try:
        cfg_path = BASE_DIR / "config.yaml"
        with open(cfg_path, encoding="utf-8") as f:
            config = _yaml.safe_load(f) or {}
    except Exception:
        config = {}

    pipeline_cfg = config.get("pipeline", {})
    if not pipeline_cfg.get("auto_resume", True):
        logger.info("Auto-resume disabled in config")
        return

    delay = pipeline_cfg.get("auto_resume_delay_seconds", 15)
    max_attempts = pipeline_cfg.get("max_auto_resume_attempts", 3)

    logger.info("Auto-resume: waiting %ds for server to stabilize...", delay)
    time.sleep(delay)

    if not PIPELINE_STATUS_DIR.exists():
        return

    resumed = 0
    for f in PIPELINE_STATUS_DIR.glob("*.json"):
        try:
            data = safe_load_json(f)
            if not data or data.get("status") != "interrupted":
                continue

            run_id = f.stem
            # Check retry count
            resume_count = data.get("auto_resume_count", 0)
            if resume_count >= max_attempts:
                logger.warning("Auto-resume: %s exceeded max attempts (%d), marking as failed",
                              run_id, max_attempts)
                data["status"] = "failed"
                data["error"] = f"Auto-resume failed after {max_attempts} attempts"
                data["completed_at"] = datetime.now(timezone.utc).isoformat()
                safe_write_json(f, data, encrypt=False)
                continue

            # Find source files — first check checkpoint for saved paths
            resolved_paths = []
            try:
                checkpoint_file = CHECKPOINT_DIR / f"{run_id}.json"
                if checkpoint_file.exists():
                    checkpoint_data = safe_load_json(checkpoint_file)
                    saved_paths = (checkpoint_data or {}).get("_source_paths", [])
                    for sp in saved_paths:
                        p = Path(sp)
                        if p.exists():
                            resolved_paths.append(p)
                    if resolved_paths:
                        logger.info("Auto-resume: found %d source files from checkpoint for %s",
                                   len(resolved_paths), run_id)
            except Exception:
                pass

            # Fallback: search vault directories by run_id pattern
            if not resolved_paths:
                vault_root = BASE_DIR / "vault"
                for zone in ["incoming", "processing", "processing/failed", "processed"]:
                    zone_dir = vault_root / zone
                    if not zone_dir.exists():
                        continue
                    for p in zone_dir.rglob("*"):
                        if p.is_file() and run_id in p.name:
                            resolved_paths.append(p)

            if not resolved_paths:
                try:
                    conn = get_db()
                    try:
                        rows = conn.execute(
                            "SELECT original_path, current_path FROM documents WHERE run_id = ?",
                            (run_id,)
                        ).fetchall()
                        for row in rows:
                            for path_col in ("original_path", "current_path"):
                                p = Path(row[path_col]) if row[path_col] else None
                                if p and p.exists() and p.suffix.lower() != ".json":
                                    resolved_paths.append(p)
                    finally:
                        conn.close()
                except Exception:
                    pass

            if not resolved_paths:
                logger.warning("Auto-resume: no source files found for %s, skipping", run_id)
                continue

            # Concurrency check
            if not _active_pipelines.acquire(blocking=False):
                logger.warning("Auto-resume: too many active pipelines, deferring %s", run_id)
                continue

            # Update resume count and status
            data["status"] = "running"
            data["auto_resume_count"] = resume_count + 1
            data["auto_resumed_at"] = datetime.now(timezone.utc).isoformat()
            safe_write_json(f, data, encrypt=False)

            # Determine pipeline type from status data
            mode = data.get("mode", "fast")
            case_ref = data.get("case_ref")
            str_paths = [str(p) for p in resolved_paths]

            if mode == "thorough":
                t = threading.Thread(
                    target=_run_thorough_pipeline_background,
                    args=(str_paths, run_id, case_ref, "thorough"),
                    daemon=False,
                )
            elif len(resolved_paths) > 1:
                t = threading.Thread(
                    target=_run_combined_pipeline_background,
                    args=(str_paths, run_id, case_ref),
                    daemon=False,
                )
            else:
                t = threading.Thread(
                    target=_run_pipeline_background,
                    args=(str_paths[0], run_id),
                    daemon=False,
                )
            t.start()
            resumed += 1
            logger.info("Auto-resumed pipeline %s (attempt %d/%d, mode=%s, files=%d)",
                       run_id, resume_count + 1, max_attempts, mode, len(resolved_paths))

        except Exception as e:
            logger.error("Auto-resume error for %s: %s", f.stem, e)

    if resumed:
        logger.info("Auto-resumed %d interrupted pipeline(s)", resumed)


# Start auto-resume in background thread
threading.Thread(target=_auto_resume_pipelines, daemon=True, name="auto-resume").start()


# ── Pipeline Watchdog ────────────────────────────────────────────────────────

def _pipeline_watchdog():
    """Background thread that detects and fails hung pipelines.
    Runs every 60 seconds, checks for stages stuck in 'running' state
    longer than configured max durations."""
    import yaml

    while True:
        time.sleep(60)
        try:
            if not PIPELINE_STATUS_DIR.exists():
                continue

            # Load max durations from config
            try:
                cfg_path = BASE_DIR / "config.yaml"
                with open(cfg_path, encoding="utf-8") as f:
                    cfg = yaml.safe_load(f) or {}
                pipeline_cfg = cfg.get("pipeline", {})
            except Exception:
                pipeline_cfg = {}

            max_fast = pipeline_cfg.get("max_duration_fast", 1800)      # 30 min
            max_thorough = pipeline_cfg.get("max_duration_thorough", 5400)  # 90 min
            now = datetime.now(timezone.utc)

            for sf in PIPELINE_STATUS_DIR.glob("*.json"):
                try:
                    data = safe_load_json(sf)
                    if not data or data.get("status") != "running":
                        continue

                    # Determine max duration based on run mode
                    run_id = data.get("run_id", sf.stem)
                    is_thorough = "thorough" in run_id or data.get("mode") == "thorough"
                    max_dur = max_thorough if is_thorough else max_fast

                    # Check pipeline start time
                    started_str = data.get("started_at")
                    if not started_str:
                        continue

                    try:
                        started_at = datetime.fromisoformat(started_str.replace("Z", "+00:00"))
                    except (ValueError, AttributeError):
                        continue

                    elapsed = (now - started_at).total_seconds()

                    if elapsed > max_dur:
                        logger.warning(
                            "Watchdog: Pipeline %s stuck for %.0fs (max=%ds) — marking failed",
                            run_id, elapsed, max_dur,
                        )
                        data["status"] = "failed"
                        data["error_message"] = f"Pipeline timed out (subprocess timeout on large combined case)"
                        data["retryable"] = True
                        data["user_action"] = "Try processing fewer files at once, or increase timeout in config.yaml"
                        data["failed_at"] = now.isoformat()

                        # Also mark any running stages as failed
                        for stage_name, stage_data in data.get("stages", {}).items():
                            if isinstance(stage_data, dict) and stage_data.get("status") == "running":
                                stage_data["status"] = "failed"
                                stage_data["details"] = {
                                    "error_type": "TIMEOUT",
                                    "error_msg": "Stage timed out",
                                    "retryable": True,
                                }

                        safe_write_json(sf, data, encrypt=False)

                except Exception as e:
                    logger.debug("Watchdog error on %s: %s", sf.name, e)

        except Exception as e:
            logger.debug("Watchdog cycle error: %s", e)


def _start_pipeline_watchdog():
    """Start the pipeline watchdog as a daemon thread."""
    t = threading.Thread(target=_pipeline_watchdog, daemon=True, name="pipeline-watchdog")
    t.start()
    logger.info("Pipeline watchdog started (checks every 60s)")

_start_pipeline_watchdog()


def _background_worker():
    """Internal worker thread that processes enqueued tasks."""
    from db import pop_task, remove_from_queue, release_task
    from dispatch import run_task, load_config
    
    worker_id = f"app-worker-{uuid.uuid4().hex[:6]}"
    config = load_config()
    logger.info("Background worker %s started", worker_id)
    
    while True:
        try:
            task_id = pop_task(worker_id)
            if task_id:
                logger.info("Worker processing task: %s", task_id)
                success = run_task(task_id, config)
                if success:
                    remove_from_queue(task_id)
                    logger.info("Task %s completed", task_id)
                else:
                    # Logic for retries or manual failure
                    release_task(task_id)
                    logger.warning("Task %s failed or released", task_id)
            else:
                time.sleep(10)
        except Exception as e:
            logger.error("Background worker error: %s", e)
            time.sleep(30)


def _start_background_worker():
    """Start the internal background worker thread."""
    t = threading.Thread(target=_background_worker, daemon=True, name="background-worker")
    t.start()
    logger.info("Resilient task worker started")

# _start_background_worker()


# ── JSON Error Handlers ──────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(e):
    return jsonify({"error": str(e.description) if hasattr(e, 'description') else "Bad request"}), 400

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(e):
    logger.error("Internal server error: %s", type(e).__name__)
    return jsonify({"error": "Internal server error"}), 500


# ── Static UI & Auth Routes ──────────────────────────────────────────────────

@app.route("/")
@require_auth
def index():
    return send_from_directory(str(UI_DIR), "index.html")


@app.route("/landing")
def landing_page():
    return send_from_directory(str(UI_DIR), "landing.html")


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(str(UI_DIR), filename)


@app.route("/login", methods=["GET", "POST"])
@rate_limit(requests_per_minute=10, burst=5)
def login():
    if request.method == "GET":
        return send_from_directory(str(UI_DIR), "login.html")

    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    from security import _check_credentials
    if _check_credentials(username, password):
        session["authenticated"] = True
        session["username"] = username
        session.permanent = True
        log_access(username, "login", "session", ip_address=request.remote_addr)
        logger.info("User logged in: %s from %s", username, request.remote_addr)
        return jsonify({"success": True, "redirect": "/"})

    logger.warning("Failed login attempt from ip=%s", request.remote_addr)
    log_access(username or "unknown", "login_failed", "session",
               ip_address=request.remote_addr)
    return jsonify({"error": "Invalid credentials"}), 401


@app.route("/logout", methods=["POST"])
def logout():
    username = session.get("username", "unknown")
    session.clear()
    log_access(username, "logout", "session", ip_address=request.remote_addr)
    return jsonify({"success": True, "redirect": "/login"})


# ── Health Check (unauthenticated for load balancer probes) ──────────────────

@app.route("/health")
def health_check():
    """Health check endpoint for monitoring. Returns minimal info for unauthenticated
    requests (load balancers), detailed checks for authenticated users."""
    # Minimal response for unauthenticated callers (load balancers)
    if not session.get("authenticated"):
        try:
            conn = get_db()
            conn.execute("SELECT 1").fetchone()
            conn.close()
            return jsonify({"status": "healthy"}), 200
        except Exception:
            return jsonify({"status": "unhealthy"}), 503

    # Detailed checks for authenticated users
    checks = {}
    healthy = True

    # Database check
    try:
        conn = get_db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = f"error: {type(e).__name__}"
        healthy = False

    # Vault directories check
    for name, path in [
        ("vault_incoming", VAULT_INCOMING),
        ("vault_summaries", VAULT_SUMMARIES),
        ("vault_audit", VAULT_AUDIT),
    ]:
        if path.exists() and os.access(str(path), os.W_OK):
            checks[name] = "ok"
        else:
            checks[name] = "missing or not writable"
            healthy = False

    # AWS Bedrock credentials check
    checks["bedrock"] = "ok" if os.getenv("AWS_ACCESS_KEY_ID") else "not configured"

    status_code = 200 if healthy else 503
    return jsonify({
        "status": "healthy" if healthy else "unhealthy",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }), status_code


# ── Contacts API ─────────────────────────────────────────────────────────────

@app.route("/api/contacts")
@require_auth
@rate_limit(requests_per_minute=60)
def list_contacts():
    """List contacts with pagination. Query params: page, per_page, status, q."""
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 100)
    status_filter = request.args.get("status", "")
    search_q = request.args.get("q", "").strip()

    offset = (page - 1) * per_page

    conn = get_db()
    try:
        query = """SELECT id, contact_name, contact_email, contact_type, organization,
                          patient_case_ref, record_type_needed, date_added, status,
                          last_contact_date, priority, follow_up_count, source
                   FROM contacts"""
        params = []
        conditions = []

        if status_filter:
            conditions.append("status = ?")
            params.append(status_filter)
        if search_q:
            conditions.append(
                "(contact_name LIKE ? OR contact_email LIKE ? OR organization LIKE ? OR patient_case_ref LIKE ?)"
            )
            like = f"%{search_q}%"
            params.extend([like, like, like, like])

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # Get total count
        count_query = query.replace(
            "SELECT id, contact_name, contact_email, contact_type, organization,"
            "\n                          patient_case_ref, record_type_needed, date_added, status,"
            "\n                          last_contact_date, priority, follow_up_count, source",
            "SELECT COUNT(*) as total"
        )
        total = conn.execute(count_query, params).fetchone()["total"]

        query += " ORDER BY date_added DESC LIMIT ? OFFSET ?"
        params.extend([per_page, offset])

        rows = conn.execute(query, params).fetchall()
    finally:
        conn.close()

    log_access(
        session.get("username", "api"), "list", "contacts",
        ip_address=request.remote_addr,
        details=f"page={page} per_page={per_page} total={total}",
    )

    return jsonify({
        "contacts": [dict(r) for r in rows],
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


@app.route("/api/contacts/<int:contact_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_contact(contact_id):
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
        if not row:
            abort(404)

        emails = conn.execute(
            "SELECT * FROM email_log WHERE contact_id = ? ORDER BY timestamp DESC",
            (contact_id,),
        ).fetchall()
    finally:
        conn.close()

    log_access(
        session.get("username", "api"), "view", "contact",
        resource_id=str(contact_id), ip_address=request.remote_addr,
    )

    result = dict(row)
    result["emails"] = [dict(e) for e in emails]
    return jsonify(result)


# ── Create Contact ───────────────────────────────────────────────────────────

@app.route("/api/contacts", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def create_contact():
    """Add a new contact from the UI and trigger retrieval automation."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # Input validation
    errors = validate_contact_input(data)
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 400

    name = sanitize_string(data["contact_name"], 200)
    email = data["contact_email"].strip().lower()
    contact_type = data.get("contact_type", "custodian")
    organization = sanitize_string(data.get("organization", ""), 300)
    case_ref = sanitize_string(data.get("patient_case_ref", ""), 100)
    record_type = data.get("record_type_needed", "")
    priority = data.get("priority", "normal")
    notes = sanitize_string(data.get("notes", ""), 2000)

    upload_token = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    try:
        with transaction() as conn:
            cursor = conn.execute(
                """INSERT INTO contacts
                   (contact_name, contact_email, contact_type, organization,
                    patient_case_ref, record_type_needed, date_added, status,
                    priority, notes, upload_token, follow_up_count, source, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, 0, 'ui', ?, ?)""",
                (name, email, contact_type, organization, case_ref, record_type,
                 now, priority, notes, upload_token, now, now),
            )
            contact_id = cursor.lastrowid
    except sqlite3.IntegrityError as e:
        logger.warning("Duplicate contact: %s", e)
        return jsonify({"error": "A contact with this upload token already exists"}), 409

    _audit_log("contact_added_ui", contact_id, f"Contact added via UI (id={contact_id})")
    log_access(
        session.get("username", "api"), "create", "contact",
        resource_id=str(contact_id), ip_address=request.remote_addr,
    )
    logger.info("Contact created via UI: id=%d", contact_id)

    config = load_config()
    port = config.get("web_ui", {}).get("port", 8080)
    base_url = os.getenv("UPLOAD_BASE_URL", f"http://localhost:{port}")
    return jsonify({
        "id": contact_id,
        "contact_name": name,
        "contact_email": email,
        "status": "new",
        "upload_token": upload_token,
        "upload_link": f"{base_url}/api/secure-upload/{upload_token}",
        "message": "Contact created. The retrieval bot will send the initial request email on its next cycle.",
    }), 201


# ── Batch Contact Import (Excel) ────────────────────────────────────────────

@app.route("/api/contacts/batch", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def batch_import_contacts():
    """
    Import contacts from an uploaded Excel file.
    Expected columns: Contact Name | Email | Type | Organization | Case Ref | Record Type | Priority | Notes
    """
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    suffix = Path(file.filename).suffix.lower()
    if suffix not in (".xlsx", ".xls"):
        return jsonify({"error": "Only Excel files (.xlsx, .xls) are accepted"}), 400

    try:
        import openpyxl
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    try:
        wb = openpyxl.load_workbook(io.BytesIO(file.read()), read_only=True, data_only=True)
        ws = wb.active
        if ws is None:
            return jsonify({"error": "Excel file has no active worksheet"}), 400
    except Exception as e:
        return jsonify({"error": f"Cannot read Excel file: {e}"}), 400

    # Parse header row to find column mapping
    headers = []
    for cell in next(ws.iter_rows(min_row=1, max_row=1, values_only=False)):
        val = str(cell.value or "").strip().lower()
        headers.append(val)

    # Map columns by header name (flexible matching)
    col_map = {}
    header_aliases = {
        "contact_name": ["contact name", "name", "contact_name"],
        "contact_email": ["email", "contact email", "contact_email", "email address"],
        "contact_type": ["type", "contact type", "contact_type"],
        "organization": ["organization", "org", "company", "facility"],
        "patient_case_ref": ["case ref", "case reference", "patient_case_ref", "case #", "case"],
        "record_type_needed": ["record type", "record_type_needed", "records needed", "record type needed"],
        "priority": ["priority"],
        "notes": ["notes", "note", "comments"],
    }
    for field, aliases in header_aliases.items():
        for i, h in enumerate(headers):
            if h in aliases:
                col_map[field] = i
                break

    if "contact_name" not in col_map or "contact_email" not in col_map:
        return jsonify({
            "error": "Excel file must have 'Contact Name' and 'Email' columns",
            "found_headers": headers,
        }), 400

    # Process rows
    results = {"imported": 0, "skipped": 0, "errors": []}
    now = datetime.now(timezone.utc).isoformat()
    config = load_config()
    port = config.get("web_ui", {}).get("port", 8080)
    base_url = os.getenv("UPLOAD_BASE_URL", f"http://localhost:{port}")

    row_num = 1  # Start at 1 because row 0 is header
    try:
        with transaction() as conn:
            for row in ws.iter_rows(min_row=2, values_only=True):
                row_num += 1
                if not row or all(v is None for v in row):
                    continue

                # Extract fields
                def cell(field, default=""):
                    idx = col_map.get(field)
                    if idx is not None and idx < len(row) and row[idx] is not None:
                        return str(row[idx]).strip()
                    return default

                name = cell("contact_name")
                email = cell("contact_email")

                if not name or not email:
                    results["skipped"] += 1
                    continue

                # Validate email format
                if not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email):
                    results["errors"].append(f"Row {row_num}: Invalid email '{email}'")
                    results["skipped"] += 1
                    continue

                # Check for duplicate (same email + case ref)
                case_ref = cell("patient_case_ref")
                existing = conn.execute(
                    "SELECT id FROM contacts WHERE contact_email = ? AND patient_case_ref = ?",
                    (email.lower(), case_ref),
                ).fetchone()

                if existing:
                    results["skipped"] += 1
                    continue

                upload_token = str(uuid.uuid4())
                contact_type = cell("contact_type", "custodian").lower()
                if contact_type not in ("custodian", "counsel", "patient", "provider"):
                    contact_type = "custodian"

                priority = cell("priority", "normal").lower()
                if priority not in ("normal", "high", "urgent"):
                    priority = "normal"

                conn.execute(
                    """INSERT INTO contacts
                       (contact_name, contact_email, contact_type, organization,
                        patient_case_ref, record_type_needed, date_added, status,
                        priority, notes, upload_token, follow_up_count, source,
                        created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, 0, 'excel', ?, ?)""",
                    (sanitize_string(name, 200), email.lower(), contact_type,
                     sanitize_string(cell("organization"), 300), sanitize_string(case_ref, 100),
                     cell("record_type_needed"), now, priority,
                     sanitize_string(cell("notes"), 2000), upload_token, now, now),
                )
                results["imported"] += 1

    except Exception as e:
        logger.error("Batch import error at row %d: %s", row_num, e)
        return jsonify({
            "error": f"Import failed at row {row_num}: {e}",
            "partial_results": results,
        }), 500
    finally:
        wb.close()

    _audit_log(
        "contacts_batch_import", None,
        f"Batch import: {results['imported']} imported, {results['skipped']} skipped, "
        f"{len(results['errors'])} errors",
    )
    log_access(
        session.get("username", "api"), "batch_import", "contacts",
        ip_address=request.remote_addr,
        details=f"imported={results['imported']} skipped={results['skipped']}",
    )
    logger.info("Batch import: %d imported, %d skipped", results["imported"], results["skipped"])

    return jsonify({
        "message": f"Successfully imported {results['imported']} contacts.",
        "results": results,
    })


# ── Contact Import Template Download ────────────────────────────────────────

@app.route("/api/contacts/template")
@require_auth
def download_contact_template():
    """Generate and serve an Excel template for batch contact import."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Contacts Import"

    # Column definitions
    columns = [
        ("Contact Name", 25, "Dr. John Smith"),
        ("Email", 30, "records@hospital.com"),
        ("Type", 18, "medical_provider"),
        ("Organization", 25, "Memorial Hospital"),
        ("Case Ref", 20, "CASE-2024-001"),
        ("Record Type", 22, "medical_records"),
        ("Priority", 12, "high"),
        ("Notes", 35, "Request all records from 2024"),
    ]

    # Header styling
    header_fill = PatternFill(start_color="4F46E5", end_color="4F46E5", fill_type="solid")
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    # Write headers
    for col_idx, (name, width, _) in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width

    # Example row
    example_font = Font(name="Calibri", color="999999", italic=True, size=10)
    for col_idx, (_, _, example) in enumerate(columns, 1):
        cell = ws.cell(row=2, column=col_idx, value=example)
        cell.font = example_font
        cell.border = thin_border

    # Instructions sheet
    instructions = wb.create_sheet("Instructions")
    instructions.column_dimensions["A"].width = 20
    instructions.column_dimensions["B"].width = 60
    instructions_data = [
        ("Column", "Description"),
        ("Contact Name", "Required. Full name of the contact person or department."),
        ("Email", "Required. Email address for correspondence."),
        ("Type", "Contact type: medical_provider, legal, insurance, hospital, pharmacy, imaging_center, employer, client, other"),
        ("Organization", "Optional. Name of the organization or facility."),
        ("Case Ref", "Optional. Patient case reference number (e.g., CASE-2024-001)."),
        ("Record Type", "Optional. Type of records needed: medical_records, billing_records, imaging, lab_results, pharmacy_records, employment_records, insurance_records, other"),
        ("Priority", "Optional. Priority level: low, normal, high, urgent (default: normal)."),
        ("Notes", "Optional. Any special instructions or notes."),
    ]
    for row_idx, (col_a, col_b) in enumerate(instructions_data, 1):
        cell_a = instructions.cell(row=row_idx, column=1, value=col_a)
        cell_b = instructions.cell(row=row_idx, column=2, value=col_b)
        if row_idx == 1:
            cell_a.font = Font(bold=True)
            cell_b.font = Font(bold=True)

    # Serve file
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="contacts_import_template.xlsx",
    )


# ── Manual Upload ────────────────────────────────────────────────────────────

@app.route("/api/upload", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=240, burst=120)
def manual_upload():
    """Upload a medical document from the UI for manual summarization."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": f"File type not allowed. Supported: {', '.join(sorted(ALLOWED_EXTENSIONS))}"}), 400

    original_filename = file.filename
    sanitized = secure_filename(original_filename)
    if not sanitized:
        return jsonify({"error": "Invalid filename"}), 400

    # Optional case reference for grouping multi-file uploads
    case_ref = request.form.get("case_ref", "").strip() or None

    # HIPAA-compliant file naming: hash-based, no patient names on disk
    file_bytes = file.read()
    file_hash = hashlib.sha256(file_bytes).hexdigest()
    ext = Path(sanitized).suffix.lower()
    safe_name = f"{file_hash[:16]}{ext}"

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    upload_dir = VAULT_INCOMING / f"manual_{timestamp}"
    upload_dir.mkdir(parents=True, exist_ok=True)

    save_path = upload_dir / safe_name
    # Encrypt file at rest for HIPAA compliance
    from security_vault import Vault
    save_path.write_bytes(Vault.encrypt(file_bytes))

    # Encrypt original filename for DB storage (recoverable but not on disk)
    encrypted_original = None
    try:
        encrypted_original = Vault.encrypt(original_filename).decode("ascii")
    except Exception:
        pass

    # Register in documents table
    doc_id = None
    try:
        with transaction() as conn:
            cur = conn.execute(
                """INSERT INTO documents
                   (filename, original_path, current_path, file_hash, file_size,
                    extension, vault_zone, status, uploaded_by, upload_source, case_ref,
                    original_filename_encrypted)
                   VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', ?, 'manual', ?, ?)""",
                (safe_name, str(save_path), str(save_path), file_hash,
                 len(file_bytes), ext,
                 session.get("username", "api"), case_ref, encrypted_original),
            )
            doc_id = cur.lastrowid
    except Exception as e:
        logger.error("Failed to register document: %s", e)

    # Auto-detect case_ref if none provided
    suggestion = None
    if not case_ref and doc_id:
        try:
            from case_detector import suggest_case_ref as _suggest
            conn2 = get_db()
            try:
                rows = conn2.execute(
                    "SELECT DISTINCT case_ref FROM documents WHERE case_ref IS NOT NULL AND case_ref != ''"
                ).fetchall()
            finally:
                conn2.close()
            existing = [r["case_ref"] for r in rows]
            result = _suggest(original_filename, existing)
            if result and result["confidence"] in ("high", "medium"):
                case_ref = result["suggestion"]
                suggestion = result
                try:
                    with transaction() as conn3:
                        conn3.execute(
                            "UPDATE documents SET case_ref = ? WHERE id = ?",
                            (case_ref, doc_id),
                        )
                except Exception as e:
                    logger.error("Auto-assign case_ref error: %s", e)
        except Exception as e:
            logger.debug("Case detection skipped: %s", e)

    # Audit log uses hash-based ID, never original filename (HIPAA)
    _audit_log("file_uploaded_manual", None, f"Manual upload: {file_hash[:12]}{ext}{' case=' + case_ref if case_ref else ''}")
    log_access(
        session.get("username", "api"), "upload", "document",
        resource_id=file_hash[:12], ip_address=request.remote_addr,
        details=f"hash={file_hash[:12]}" + (f", case_ref={case_ref}" if case_ref else ""),
    )
    logger.info("Manual upload: %s (doc_id=%s, case_ref=%s)", file_hash[:12], doc_id, case_ref)

    resp = {
        "file_id": f"manual_{timestamp}_{safe_name}",
        "doc_id": doc_id,
        "file_path": str(save_path),
        "file_hash": file_hash,
        "case_ref": case_ref,
        "message": "File uploaded. Use /api/summarize to trigger processing.",
    }
    if suggestion:
        resp["case_suggestion"] = suggestion
    return jsonify(resp)


# ── Demo Case Loader ──────────────────────────────────────────────────────────

@app.route("/api/demo-case/load", methods=["POST"])
@require_auth
def load_demo_case():
    """Load the included demo case files for first-time demonstration."""
    demo_dir = BASE_DIR / "demo_case"
    if not demo_dir.exists():
        return jsonify({"error": "Demo case not found"}), 404

    demo_files = sorted(
        f for f in demo_dir.iterdir()
        if f.is_file() and f.name != "README.txt" and f.suffix.lower() in ALLOWED_EXTENSIONS
    )
    if not demo_files:
        return jsonify({"error": "No demo files found"}), 404

    case_ref = "DEMO-Martinez-MVA-2024"
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    uploaded = []

    import shutil
    upload_dir = VAULT_INCOMING / f"demo_{timestamp}"
    upload_dir.mkdir(parents=True, exist_ok=True)
    file_paths = []

    for df in demo_files:
        dest = upload_dir / df.name
        shutil.copy2(str(df), str(dest))
        file_hash = hashlib.sha256(dest.read_bytes()).hexdigest()
        file_paths.append(str(dest))

        try:
            with transaction() as conn:
                cur = conn.execute(
                    """INSERT INTO documents
                       (filename, original_path, current_path, file_hash, file_size,
                        extension, vault_zone, status, uploaded_by, upload_source, case_ref)
                       VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', ?, 'manual', ?)""",
                    (df.name, str(dest), str(dest), file_hash,
                     dest.stat().st_size, dest.suffix.lower(),
                     session.get("username", "api"), case_ref),
                )
                uploaded.append({"filename": df.name, "doc_id": cur.lastrowid})
        except Exception as e:
            logger.error("Failed to register demo file %s: %s", df.name, e)

    _audit_log("demo_case_loaded", None, f"Demo case loaded: {len(uploaded)} files")
    return jsonify({
        "message": f"Demo case loaded: {len(uploaded)} files",
        "case_ref": case_ref,
        "files": uploaded,
        "file_paths": file_paths,
    })


# ── Secure Upload (Token-Based, no auth required) ───────────────────────────

@app.route("/api/secure-upload/<token>", methods=["GET", "POST"])
@rate_limit(requests_per_minute=10, burst=5)
def secure_upload(token):
    """Token-authenticated upload endpoint for external contacts."""
    # Validate token format (UUID)
    try:
        uuid.UUID(token)
    except ValueError:
        abort(404)

    conn = get_db()
    try:
        contact = conn.execute(
            "SELECT id, contact_name, patient_case_ref FROM contacts WHERE upload_token = ?",
            (token,),
        ).fetchone()
    finally:
        conn.close()

    if not contact:
        _audit_log("upload_token_invalid", None, f"Invalid token attempt: {token[:8]}...")
        logger.warning("Invalid upload token from %s: %s...", request.remote_addr, token[:8])
        abort(403)

    if request.method == "GET":
        import html as html_mod
        case_ref = html_mod.escape(contact["patient_case_ref"] or "N/A")
        return f"""<!DOCTYPE html>
<html><head><title>Secure Document Upload</title>
<style>body{{font-family:Inter,sans-serif;max-width:600px;margin:40px auto;padding:20px}}
h1{{color:#1f2937}}form{{border:2px dashed #d1d5db;padding:40px;text-align:center;border-radius:8px}}
input[type=file]{{margin:20px 0}}button{{background:#4f46e5;color:#fff;padding:12px 24px;border:none;border-radius:6px;cursor:pointer;font-size:16px}}
button:hover{{background:#4338ca}}</style></head>
<body><h1>Secure Document Upload</h1>
<p>Case: {case_ref}</p>
<form method="POST" enctype="multipart/form-data">
<p>Select your medical records to upload:</p>
<input type="file" name="file" accept=".pdf,.png,.jpg,.jpeg,.tiff,.tif,.dcm,.dicom,.doc,.docx,.txt,.csv,.json,.xml,.log,.xlsx,.xls,.html,.htm" required>
<br><button type="submit">Upload Securely</button>
</form></body></html>"""

    # POST: handle upload
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    original_filename = file.filename or ""
    if not original_filename or not allowed_file(original_filename):
        return jsonify({"error": "Invalid file type"}), 400

    sanitized = secure_filename(original_filename)
    if not sanitized:
        return jsonify({"error": "Invalid filename"}), 400

    # HIPAA-compliant: hash-based filename, no patient names on disk
    file_bytes = file.read()
    file_hash = hashlib.sha256(file_bytes).hexdigest()
    ext = Path(sanitized).suffix.lower()
    safe_name = f"{file_hash[:16]}{ext}"

    contact_dir = VAULT_INCOMING / str(contact["id"])
    contact_dir.mkdir(parents=True, exist_ok=True)
    save_path = contact_dir / safe_name
    # Encrypt file at rest for HIPAA compliance
    from security_vault import Vault
    save_path.write_bytes(Vault.encrypt(file_bytes))

    # Encrypt original filename for retrieval (HIPAA: no PHI in DB plaintext)
    encrypted_original = Vault.encrypt(original_filename).decode("ascii")

    # Update contact status and register document transactionally
    try:
        with transaction() as conn:
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "UPDATE contacts SET status = 'received', last_contact_date = ?, updated_at = ? WHERE id = ?",
                (now, now, contact["id"]),
            )
            conn.execute(
                """INSERT INTO documents
                   (filename, original_path, current_path, file_hash, file_size,
                    extension, vault_zone, status, uploaded_by, upload_source,
                    contact_id, case_ref, original_filename_encrypted)
                   VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', 'external', 'secure_upload', ?, ?, ?)""",
                (safe_name, str(save_path), str(save_path), file_hash,
                 len(file_bytes), ext,
                 contact["id"], contact["patient_case_ref"], encrypted_original),
            )
    except Exception as e:
        logger.error("Failed to update contact/document after upload: %s", e)

    _audit_log("file_uploaded_secure", contact["id"], f"Secure upload: hash={file_hash[:12]}")
    log_access(
        "external", "secure_upload", "document",
        resource_id=str(contact["id"]), ip_address=request.remote_addr,
        details=f"file_hash={file_hash[:12]}",
    )

    return """<!DOCTYPE html>
<html><head><title>Upload Successful</title>
<style>body{font-family:Inter,sans-serif;max-width:600px;margin:40px auto;padding:20px;text-align:center}
.success{color:#059669;font-size:24px}</style></head>
<body><p class="success">File uploaded successfully!</p>
<p>Your records have been securely received. You may close this window.</p></body></html>"""


# ── On-Demand Summarization ──────────────────────────────────────────────────

@app.route("/api/summarize", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def trigger_summarize():
    """Trigger on-demand summarization for uploaded file(s).

    Accepts either:
      - {"file_path": "..."} — single file
      - {"file_paths": [...], "case_ref": "..."} — combined multi-file case
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # ── Demo expiration enforcement ──────────────────────────────────
    from licensing import is_demo_build, is_demo_expired
    if is_demo_build() and is_demo_expired():
        return jsonify({
            "error": "Your 14-day trial has expired. Purchase a license to continue processing cases.",
            "upgrade_url": "https://aiproductivity.dev/#pricing",
        }), 403

    case_ref = data.get("case_ref", "").strip() or None
    mode = data.get("mode", "auto").strip().lower()
    if mode not in ("auto", "fast", "thorough"):
        mode = "auto"

    # Collect file paths: support both single and multi-file
    raw_paths = data.get("file_paths") or []
    if not raw_paths and "file_path" in data:
        raw_paths = [data["file_path"]]

    if not raw_paths:
        return jsonify({"error": "file_path or file_paths required"}), 400

    # Validate all paths
    resolved_paths = []
    for raw in raw_paths:
        fp = Path(raw)
        try:
            resolved = fp.resolve(strict=False)
            resolved.relative_to(VAULT_INCOMING.resolve())
        except (ValueError, OSError):
            logger.warning("Path traversal attempt: %s from %s", raw, request.remote_addr)
            return jsonify({"error": f"Invalid file path: {Path(raw).name}"}), 400
        if not resolved.exists():
            return jsonify({"error": f"File not found: {Path(raw).name}"}), 404
        if resolved.is_symlink():
            return jsonify({"error": "Symbolic links are not allowed"}), 400
        resolved_paths.append(resolved)

    run_id = f"manual_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"

    # Record the task in SQLite
    from dispatch import create_task, load_config
    from db import enqueue_task
    config = load_config()
    
    # Map-Reduce / Thorough routing check
    total_pages = 0
    for p in resolved_paths:
        if p.suffix.lower() == ".pdf" and p.exists():
            try:
                import fitz
                with fitz.open(str(p)) as doc:
                    total_pages += len(doc)
            except:
                pass
    
    total_size = sum(p.stat().st_size for p in resolved_paths if p.exists())
    is_thorough = mode == "thorough" or (mode == "auto" and (len(resolved_paths) > 10 or total_size > 5_000_000 or total_pages > 50))
    
    # Store task metadata
    create_task(
        task_id=run_id,
        agent="pipeline",
        model=config.get("claude", {}).get("model", "claude-sonnet-4-6"),
        role=f"Mode: {mode} ({'Thorough' if is_thorough else 'Fast'})",
        task=f"Summarize {len(resolved_paths)} files",
        context=json.dumps({
            "file_paths": [str(p) for p in resolved_paths],
            "case_ref": case_ref,
            "mode": mode,
            "is_thorough": is_thorough
        }),
        status="queued"
    )
    
    # Add to the worker queue (for tracking)
    enqueue_task(run_id, priority=10 if mode == "fast" else 5)

    # Concurrency check
    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Too many pipelines running. Please try again later."}), 429

    # Launch pipeline in a background thread
    try:
        if is_thorough:
            t = threading.Thread(
                target=_run_thorough_pipeline_background,
                args=([str(p) for p in resolved_paths], run_id, case_ref, "thorough"),
                daemon=False,
            )
        elif len(resolved_paths) > 1:
            t = threading.Thread(
                target=_run_combined_pipeline_background,
                args=([str(p) for p in resolved_paths], run_id, case_ref),
                daemon=False,
            )
        else:
            t = threading.Thread(
                target=_run_pipeline_background,
                args=(str(resolved_paths[0]), run_id),
                daemon=False,
            )
        t.start()
    except Exception as e:
        _active_pipelines.release()
        logger.error("Failed to start pipeline thread for %s: %s", run_id, e)
        _write_pipeline_failure(run_id, e, mode=mode)
        return jsonify({"error": "Failed to start pipeline"}), 500
    logger.info("Pipeline %s started (%s, %d files)", run_id, mode, len(resolved_paths))

    log_access(
        session.get("username", "api"), "trigger_summarize", "pipeline",
        resource_id=run_id, ip_address=request.remote_addr,
        details=f"files={len(resolved_paths)}, mode={mode}" + (f", case_ref={case_ref}" if case_ref else ""),
    )

    return jsonify({
        "run_id": run_id,
        "status": "running",
        "mode": mode,
        "file_count": len(resolved_paths),
        "case_ref": case_ref,
        "message": "Pipeline started. Poll /api/pipeline/<run_id> for status.",
    })


def _classify_pipeline_error(error_str):
    """Classify a pipeline error for user-friendly reporting."""
    e = error_str.lower()
    if "__error__:" in e:
        parts = error_str.split(":", 2)
        error_type = parts[1] if len(parts) > 1 else "unknown"
        return error_type, parts[2] if len(parts) > 2 else error_str
    if any(kw in e for kw in ("credit balance", "insufficient", "billing", "overloaded",
                                "credit limit", "exceeded your", "funds", "payment required")):
        return "api_credits_exhausted", "Your Anthropic API credit balance is too low. Add credits at console.anthropic.com."
    if "invalid" in e and ("api key" in e or "x-api-key" in e or "authentication" in e):
        return "api_key_invalid", "Your Anthropic API key is invalid."
    if "timeout" in e or "timed out" in e:
        return "api_timeout", "The AI request timed out."
    if "rate limit" in e or "429" in e:
        return "api_rate_limited", "Too many API requests. Wait a minute."
    return "unknown", error_str


def _sanitize_pipeline_error(msg):
    """Strip potential PHI patterns from pipeline error messages."""
    import re
    if not msg:
        return msg
    msg = str(msg)[:500]
    # Strip SSN, phone, email, DOB, patient names from error messages
    msg = re.sub(r"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED]", msg)
    msg = re.sub(r"\b\d{3}[-.]\d{3}[-.]\d{4}\b", "[REDACTED]", msg)
    msg = re.sub(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", "[REDACTED]", msg)
    msg = re.sub(r"\b(Patient|Pt|Mr|Mrs|Ms|Dr)\.\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b", "[REDACTED]", msg)
    return msg


def _write_pipeline_failure(run_id, error, mode=None):
    """Write a structured failure status for a pipeline run."""
    error_type, error_msg = _classify_pipeline_error(str(error))
    from summarization_watcher import _get_user_action
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f"{run_id}.json"
    data = safe_load_json(status_file) or {}

    # Sanitize error messages before writing to disk (HIPAA: no PHI in status files)
    safe_error = _sanitize_pipeline_error(str(error))
    safe_error_msg = _sanitize_pipeline_error(error_msg)

    data.update({
        "run_id": run_id,
        "status": "failed",
        "error": safe_error,
        "error_type": error_type,
        "error_message": safe_error_msg,
        "user_action": _get_user_action(error_type),
        "retryable": error_type not in ("api_key_invalid", "api_credits_exhausted"),
        "failed_at": datetime.now(timezone.utc).isoformat(),
    })
    if mode:
        data["mode"] = mode
    
    try:
        safe_write_json(status_file, data, encrypt=False)
    except Exception as write_err:
        logger.error("Failed to write pipeline status file: %s", write_err)


def _run_pipeline_background(file_path, run_id):
    """Run the summarization pipeline in a background thread with error handling."""
    try:
        from summarization_watcher import run_pipeline, load_config as load_watcher_config
        config = load_watcher_config()
        run_pipeline(Path(file_path), config, run_id=run_id)
    except Exception as e:
        logger.error("Background pipeline error for %s: %s", run_id, type(e).__name__)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


def _run_combined_pipeline_background(file_paths, run_id, case_ref):
    """Run the summarization pipeline on multiple files combined into one case.
    Automatically routes to thorough pipeline for large cases."""
    try:
        from summarization_watcher import (
            run_pipeline_combined, run_pipeline_thorough,
            load_config as load_watcher_config,
        )
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]

        # Route large cases to thorough pipeline (chunked processing)
        # Check total pages across all files if available (approximate from PDF structure)
        total_pages = 0
        for p in paths:
            if p.suffix.lower() == ".pdf" and p.exists():
                try:
                    # Quick page count without full OCR
                    import fitz
                    with fitz.open(str(p)) as doc:
                        total_pages += len(doc)
                except:
                    pass

        total_size = sum(p.stat().st_size for p in paths if p.exists())
        if len(paths) > 10 or total_size > 10_000_000 or total_pages > 50:
            logger.info("Large case detected (%d files, %d pages, %.1fMB) — routing to thorough pipeline",
                        len(paths), total_pages, total_size / 1_000_000)
            run_pipeline_thorough(paths, config, run_id=run_id, case_ref=case_ref, mode="thorough")
        else:
            run_pipeline_combined(paths, config, run_id=run_id, case_ref=case_ref)
    except Exception as e:
        logger.error("Combined pipeline error for %s: %s", run_id, type(e).__name__)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


def _run_thorough_pipeline_background(file_paths, run_id, case_ref, mode="thorough"):
    """Run the thorough pipeline for large/complex cases."""
    try:
        from summarization_watcher import run_pipeline_thorough, load_config as load_watcher_config
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]
        run_pipeline_thorough(paths, config, run_id=run_id, case_ref=case_ref, mode=mode)
    except Exception as e:
        logger.error("Thorough pipeline error for %s: %s", run_id, type(e).__name__)
        _write_pipeline_failure(run_id, e, mode="thorough")
    finally:
        _active_pipelines.release()


def _run_auto_pipeline_background(file_paths, run_id, case_ref):
    """Auto-detect mode: run preprocessing, decide fast vs thorough, then execute."""
    try:
        from summarization_watcher import (
            run_pipeline, run_pipeline_combined, run_pipeline_thorough,
            load_config as load_watcher_config,
        )
        from document_preprocessor import preprocess_case, determine_processing_mode
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]

        # Quick preprocessing to determine mode (no transcription yet)
        preprocess_result = preprocess_case(paths, config, mode="auto", transcribe=False)
        recommended = determine_processing_mode(preprocess_result, "auto")

        logger.info("Auto-detect for %s: %d pages, %d clinical, %d handwritten -> %s",
                     run_id, preprocess_result.total_pages, preprocess_result.clinical_pages,
                     preprocess_result.handwritten_pages, recommended)

        # Force thorough for large cases even if auto-detect didn't trigger
        total_size = sum(p.stat().st_size for p in paths if p.exists())
        if recommended != "thorough" and (len(paths) > 10 or total_size > 10_000_000):
            logger.info("Large case override (%d files, %.1fMB) — forcing thorough pipeline",
                        len(paths), total_size / 1_000_000)
            recommended = "thorough"

        if recommended == "thorough":
            run_pipeline_thorough(paths, config, run_id=run_id, case_ref=case_ref, mode="thorough")
        elif len(paths) > 1:
            run_pipeline_combined(paths, config, run_id=run_id, case_ref=case_ref)
        else:
            run_pipeline(paths[0], config, run_id=run_id)
    except Exception as e:
        logger.error("Auto pipeline error for %s: %s", run_id, type(e).__name__)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


# ── Preprocessing API ────────────────────────────────────────────────────────

@app.route("/api/preprocess", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def preprocess_files():
    """Run preprocessing only — returns dedup stats and recommended mode.

    Useful for UI preview before committing to full pipeline.
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    raw_paths = data.get("file_paths") or []
    if not raw_paths and "file_path" in data:
        raw_paths = [data["file_path"]]

    if not raw_paths:
        return jsonify({"error": "file_path or file_paths required"}), 400

    resolved_paths = []
    for raw in raw_paths:
        fp = Path(raw)
        try:
            resolved = fp.resolve(strict=False)
            resolved.relative_to(VAULT_INCOMING.resolve())
        except (ValueError, OSError):
            return jsonify({"error": f"Invalid file path: {Path(raw).name}"}), 400
        if not resolved.exists():
            return jsonify({"error": f"File not found: {Path(raw).name}"}), 404
        resolved_paths.append(resolved)

    try:
        from document_preprocessor import preprocess_case
        config = load_config()
        result = preprocess_case(resolved_paths, config, mode="auto", transcribe=False)

        return jsonify({
            "total_pages": result.total_pages,
            "unique_pages": result.unique_pages,
            "duplicate_pages": result.duplicate_pages,
            "blank_pages": result.blank_pages,
            "noise_pages": result.noise_pages,
            "handwritten_pages": result.handwritten_pages,
            "clinical_pages": result.clinical_pages,
            "chunks": len(result.chunks),
            "recommended_mode": result.recommended_mode,
            "dedup_stats": result.dedup_stats,
        })
    except Exception as e:
        logger.error("Preprocessing error: %s", type(e).__name__)
        return jsonify({"error": "Preprocessing failed"}), 500


# ── Summaries API ────────────────────────────────────────────────────────────

@app.route("/api/summaries")
@require_auth
@rate_limit(requests_per_minute=60)
def list_summaries():
    """List completed summaries with pagination."""
    if not VAULT_SUMMARIES.exists():
        return jsonify({"summaries": [], "pagination": {"page": 1, "total": 0}})

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 25, type=int), 50)

    all_files = sorted(VAULT_SUMMARIES.glob("*_summary.json"), reverse=True)
    total = len(all_files)
    offset = (page - 1) * per_page
    page_files = all_files[offset:offset + per_page]

    summaries = []
    for f in page_files:
        try:
            data = safe_load_json(f)
            if not data:
                continue
            summaries.append({
                "run_id": data.get("run_id", f.stem),
                "source_file": data.get("source_file", ""),
                "processed_at": data.get("processed_at", ""),
                "has_summary": "summary" in data and data["summary"] is not None,
                "compliance_status": (data.get("audit", {}) or {}).get("compliance_status", "unknown"),
            })
        except (json.JSONDecodeError, KeyError):
            continue

    log_access(
        session.get("username", "api"), "list", "summaries",
        ip_address=request.remote_addr,
    )

    return jsonify({
        "summaries": summaries,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


@app.route("/api/summaries/<run_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_summary(run_id):
    """Get a specific summary with full details. Decrypts if encrypted."""
    # Sanitize run_id to prevent path traversal
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        # Fallback for older naming
        summary_file = VAULT_SUMMARIES / f"{safe_id}.json"
        if not summary_file.exists():
            abort(404)

    data = safe_load_json(summary_file)
    if not data:
        logger.error("Failed to load summary %s (safe_load_json returned None)", safe_id)
        abort(500)

    # Normalize varying LLM output structures for frontend compatibility
    data = _normalize_summary_response(data)

    # ── Demo watermark injection ─────────────────────────────────────
    from licensing import is_demo_build, get_watermark_text
    if is_demo_build():
        watermark = get_watermark_text()
        if watermark:
            data["_trial_watermark"] = watermark

    _audit_log("summary_viewed", None, f"Summary viewed: {safe_id}")
    log_access(
        session.get("username", "api"), "view", "summary",
        resource_id=safe_id, ip_address=request.remote_addr,
    )
    return jsonify(data)


@app.route("/api/summaries/<run_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10)
def delete_summary(run_id):
    """Delete a specific summary and its associated pipeline status."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        abort(404)

    # Delete summary file
    summary_file.unlink()

    # Also delete pipeline status if it exists
    pipeline_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if pipeline_file.exists():
        pipeline_file.unlink()

    # Clear run_id from documents table
    try:
        with transaction() as db:
            db.execute("UPDATE documents SET run_id = NULL, summary_file = NULL WHERE run_id = ?", (safe_id,))
    except Exception:
        pass

    _audit_log("summary_deleted", None, f"Summary deleted: {safe_id}")
    log_access(
        session.get("username", "api"), "delete", "summary",
        resource_id=safe_id, ip_address=request.remote_addr,
    )
    return jsonify({"ok": True, "deleted": safe_id})


# ── Demand Package API ───────────────────────────────────────────────────────

@app.route("/api/demand/generate", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def generate_demand():
    """Generate a demand package from a completed summary."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    run_id = data.get("run_id", "").strip()
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Check for pre-generated (cached) demand package first — serves regardless of license
    demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
    cached_narrative = demand_dir / "narrative.json"
    if demand_dir.exists() and cached_narrative.exists() and (demand_dir / "demand_package.docx").exists():
        cached = safe_load_json(cached_narrative)
        if cached:
            logger.info("Serving cached demand package for %s", safe_id)
            return jsonify({
                "ok": True,
                "run_id": safe_id,
                "demand_amount": cached.get("demand_amount"),
                "billing_total": cached.get("billing_total"),
                "files": [
                    {"filename": "demand_package.docx", "label": "Demand Letter (DOCX)"},
                    {"filename": "billing_summary.xlsx", "label": "Billing Summary (XLSX)"},
                    {"filename": "exhibit_list.docx", "label": "Exhibit List (DOCX)"},
                ],
                "narrative": cached.get("narrative"),
            })

    # License check only needed for live generation
    from licensing import is_feature_allowed
    if not is_feature_allowed("demand_package"):
        return jsonify({"error": "Demand Package requires a Pro license. Upgrade at https://aiproductivity.dev/#pricing"}), 403

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    summary_data = safe_load_json(summary_file)
    if not summary_data:
        return jsonify({"error": "Failed to read summary (access denied or corrupted)"}), 500

    # Build options — frontend sends {run_id, options: {...}}
    opts = data.get("options", data)
    options = {
        "case_type": opts.get("case_type", "mva"),
        "state": opts.get("state", "default"),
        "plaintiff_name": opts.get("plaintiff_name", "[PLAINTIFF]"),
        "incident_date": opts.get("incident_date", "[DATE OF INCIDENT]"),
        "multiplier": float(opts.get("multiplier", 3.0)),
        "response_deadline_days": int(opts.get("response_deadline_days", opts.get("response_days", 30))),
    }

    demand_amount = opts.get("demand_amount")
    if demand_amount:
        try:
            options["demand_amount"] = float(demand_amount)
        except (ValueError, TypeError):
            pass

    # Generate
    try:
        with open(BASE_DIR / "config.yaml") as cf:
            config = yaml.safe_load(cf)

        from demand_generator import generate_demand_package
        result = generate_demand_package(summary_data, config, options)

        # Save demand files to vault
        demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
        demand_dir.mkdir(parents=True, exist_ok=True)

        (demand_dir / "demand_package.docx").write_bytes(result["demand_docx"])
        (demand_dir / "billing_summary.xlsx").write_bytes(result["billing_xlsx"])
        (demand_dir / "exhibit_list.docx").write_bytes(result["exhibit_docx"])

        # Save narrative JSON for reference
        with open(demand_dir / "narrative.json", "w", encoding="utf-8") as nf:
            json.dump(result["narrative"], nf, indent=2)

        log_access(
            session.get("username", "api"), "generate_demand", "demand_package",
            resource_id=safe_id, ip_address=request.remote_addr,
            details=f"case_type={options['case_type']}, demand=${result['demand_amount']:,.2f}" if result.get("demand_amount") else "",
        )

        return jsonify({
            "ok": True,
            "run_id": safe_id,
            "demand_amount": result.get("demand_amount"),
            "billing_total": result.get("billing_total"),
            "files": [
                {"filename": "demand_package.docx", "label": "Demand Letter (DOCX)"},
                {"filename": "billing_summary.xlsx", "label": "Billing Summary (XLSX)"},
                {"filename": "exhibit_list.docx", "label": "Exhibit List (DOCX)"},
            ],
            "narrative": result.get("narrative"),
        })

    except Exception as e:
        logger.error("Demand generation failed for %s: %s", safe_id, type(e).__name__)
        return jsonify({"error": "Demand generation failed"}), 500


@app.route("/api/demand/<run_id>/download/<filename>")
@require_auth
def download_demand_file(run_id, filename):
    """Download a demand package file."""
    safe_id = secure_filename(run_id)
    safe_filename = secure_filename(filename)
    if not safe_id or not safe_filename:
        abort(400)

    demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
    file_path = demand_dir / safe_filename
    if not file_path.exists():
        abort(404)

    # Determine MIME type
    mime_types = {
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pdf": "application/pdf",
    }
    ext = Path(safe_filename).suffix.lower()
    mime = mime_types.get(ext, "application/octet-stream")

    return send_file(
        str(file_path),
        mimetype=mime,
        as_attachment=True,
        download_name=safe_filename,
    )


@app.route("/api/demand/case-types")
@require_auth
def get_case_types():
    """Return available case types for demand package generation."""
    from demand_generator import get_case_types as _get_types, get_states as _get_states
    return jsonify({
        "case_types": _get_types(),
        "states": _get_states(),
    })


# ── Case Valuation API ───────────────────────────────────────────────────────

@app.route("/api/valuation/estimate", methods=["POST"])
@require_auth
def estimate_valuation():
    """Estimate settlement value range for a processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("case_valuation"):
        return jsonify({"error": "Case Valuation requires a Pro license. Upgrade at https://aiproductivity.dev/#pricing"}), 403

    from case_valuation import estimate_case_value

    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load the summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    summary_data = safe_load_json(summary_path)
    if not summary_data:
        return jsonify({"error": "Failed to read summary (access denied or corrupted)"}), 500

    options = data.get("options", {})
    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = estimate_case_value(summary_data, config, options)
        return jsonify(result)
    except Exception as e:
        logger.exception("Valuation estimation failed")
        return jsonify({"error": str(e)}), 500


# ── Licensing API ─────────────────────────────────────────────────────────────

@app.route("/api/license/status")
@require_auth
def license_status():
    """Return current license state."""
    from licensing import get_license_state, get_trial_remaining, validate_license_key
    state = get_license_state()
    state["trial_remaining"] = get_trial_remaining()
    # Add 'valid' field for API consumers
    if state.get("license_key"):
        validation = validate_license_key(state["license_key"])
        state["valid"] = validation.get("valid", False)
    else:
        state["valid"] = state.get("tier") == "trial"
    # Add build info and demo expiration if applicable
    try:
        from product_guard import get_build_type, get_build_info
        bt = get_build_type()
        if bt != "dev":
            state["build_type"] = bt
            bi = get_build_info()
            if bi:
                state["product_version"] = bi.get("version")
        if bt == "demo":
            from licensing import check_demo_expiration
            demo_status = check_demo_expiration()
            state["is_demo"] = True
            state["demo_days_remaining"] = demo_status["days_remaining"]
            state["demo_expired"] = demo_status["expired"]
    except ImportError:
        # Legacy fallback
        try:
            from demo_guard import is_demo
            if is_demo():
                from licensing import check_demo_expiration
                demo_status = check_demo_expiration()
                state["is_demo"] = True
                state["demo_days_remaining"] = demo_status["days_remaining"]
                state["demo_expired"] = demo_status["expired"]
        except ImportError:
            pass
    return jsonify(state)

@app.route("/api/license/activate", methods=["POST"])
def activate_license_route():
    """Activate a license key. No auth required — users need this to unlock the app."""
    from licensing import activate_license as _activate
    key = request.json.get("key", "").strip()
    result = _activate(key)
    if result.get("valid"):
        return jsonify({"success": True, "tier": result["tier"]})
    return jsonify({"success": False, "error": "Invalid license key"}), 400


# ── Negligence Detection API ─────────────────────────────────────────────────

@app.route("/api/negligence/analyze", methods=["POST"])
@require_auth
def analyze_negligence():
    """Analyze a processed case for standard-of-care deviations."""
    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Check for pre-generated (cached) negligence scan first — serves regardless of license
    cached_path = VAULT_SUMMARIES / f"{safe_id}_negligence.json"
    if cached_path.exists():
        cached = safe_load_json(cached_path)
        if cached:
            logger.info("Serving cached negligence scan for %s", safe_id)
            return jsonify(cached)

    # License check only needed for live generation
    from licensing import is_feature_allowed
    if not is_feature_allowed("negligence_detection"):
        return jsonify({"error": "Negligence Detection requires a Pro license. Upgrade at https://aiproductivity.dev/#pricing"}), 403
    from negligence_detector import detect_negligence

    # Load summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    summary_data = safe_load_json(summary_path)
    if not summary_data:
        return jsonify({"error": "Failed to read summary (access denied or corrupted)"}), 500

    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = detect_negligence(summary_data, config)
        return jsonify(result)
    except Exception as e:
        logger.exception("Negligence analysis failed")
        return jsonify({"error": str(e)}), 500


# ── Auto-Task Generation API ─────────────────────────────────────────────────

@app.route("/api/tasks/generate", methods=["POST"])
@require_auth
def generate_case_tasks():
    """Generate actionable task list from processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("task_generation"):
        return jsonify({"error": "Auto-Task Generation requires a Pro license. Upgrade at https://aiproductivity.dev/#pricing"}), 403
    from task_generator import generate_tasks

    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    summary_data = safe_load_json(summary_path)
    if not summary_data:
        return jsonify({"error": "Failed to read summary (access denied or corrupted)"}), 500

    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = generate_tasks(summary_data, config)
        return jsonify(result)
    except Exception as e:
        logger.exception("Task generation failed")
        return jsonify({"error": str(e)}), 500


# ── Injury Visualization API ─────────────────────────────────────────────────

@app.route("/api/injury-diagram/<run_id>")
@require_auth
def get_injury_diagram(run_id):
    """Generate injury body diagram SVG for a processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("injury_visualization"):
        return jsonify({"error": "Injury Visualization requires a Pro license. Upgrade at https://aiproductivity.dev/#pricing"}), 403
    from injury_visualizer import generate_injury_svg

    run_id = secure_filename(run_id)
    if not run_id:
        return jsonify({"error": "Invalid run_id"}), 400

    summary_path = VAULT_SUMMARIES / f"{run_id}_summary.json"
    if not summary_path.exists():
        # Fallback: try without _summary suffix
        summary_path = VAULT_SUMMARIES / f"{run_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found"}), 404

    summary_data = safe_load_json(summary_path)
    if not summary_data:
        return jsonify({"error": "Failed to read summary (access denied or corrupted)"}), 500

    result = generate_injury_svg(summary_data)

    # Save SVG to summaries folder alongside the summary JSON
    if result.get("svg"):
        svg_path = VAULT_SUMMARIES / f"{run_id}_injury_diagram.svg"
        try:
            svg_path.write_text(result["svg"], encoding="utf-8")
            result["saved_path"] = str(svg_path)
        except Exception as e:
            logger.warning("Failed to save injury SVG: %s", e)

    if request.args.get("format") == "svg":
        return result["svg"], 200, {"Content-Type": "image/svg+xml"}

    return jsonify(result)


# ── Pipeline Status API ──────────────────────────────────────────────────────

@app.route("/api/pipeline")
@require_auth
@rate_limit(requests_per_minute=30)
def list_pipelines():
    """List all pipeline runs with status, most recent first."""
    if not PIPELINE_STATUS_DIR.exists():
        return jsonify({"runs": []})

    runs = []
    for f in sorted(PIPELINE_STATUS_DIR.glob("*.json"), reverse=True):
        try:
            data = safe_load_json(f)
            if not data:
                continue

            # Auto-fail stale "running" pipelines (no update in 30 min)
            if data.get("status") == "running" and data.get("started_at"):
                try:
                    started = datetime.fromisoformat(data["started_at"])
                    # Find most recent timestamp from ANY source:
                    # stages (fast pipeline), chunks/preprocessing (thorough), auto_resumed_at
                    latest_ts = started
                    for sv in data.get("stages", {}).values():
                        if isinstance(sv, dict) and sv.get("timestamp"):
                            ts = datetime.fromisoformat(sv["timestamp"])
                            if ts > latest_ts:
                                latest_ts = ts
                    # Check thorough pipeline timestamps (chunks, preprocessing)
                    for key in ("chunks", "preprocessing"):
                        phase = data.get(key)
                        if isinstance(phase, dict) and phase.get("timestamp"):
                            ts = datetime.fromisoformat(phase["timestamp"])
                            if ts > latest_ts:
                                latest_ts = ts
                    # Check auto-resume timestamp
                    if data.get("auto_resumed_at"):
                        ts = datetime.fromisoformat(data["auto_resumed_at"])
                        if ts > latest_ts:
                            latest_ts = ts
                    if (datetime.now(timezone.utc) - latest_ts).total_seconds() > 1800:
                        data["status"] = "failed"
                        data["error"] = "Pipeline timed out (no progress for 30 minutes)"
                        data["completed_at"] = datetime.now(timezone.utc).isoformat()
                        with open(f, "w", encoding="utf-8") as fw:
                            json.dump(data, fw, indent=2)
                except (ValueError, TypeError):
                    pass

            run_data = {
                "run_id": data.get("run_id", f.stem),
                "status": data.get("status", "unknown"),
                "mode": data.get("mode", "fast"),
                "started_at": data.get("started_at"),
                "completed_at": data.get("completed_at"),
                "error": data.get("error"),
                "error_message": data.get("error_message"),
                "user_action": data.get("user_action"),
                "retryable": data.get("retryable"),
                "cancelled": data.get("cancelled", False),
                "source_file": data.get("source_file"),
                "case_ref": data.get("case_ref"),
                "stages": {k: {"status": v.get("status"), "timestamp": v.get("timestamp"), "started_at": v.get("started_at"), "duration_seconds": v.get("duration_seconds")} for k, v in data.get("stages", {}).items()},
            }
            # Include thorough-mode data if present
            for key in ("preprocessing", "chunks", "merge"):
                if key in data:
                    run_data[key] = data[key]
            runs.append(run_data)
        except Exception:
            continue

    return jsonify({"runs": runs[:50]})  # Limit to 50 most recent


@app.route("/api/pipeline-stats")
@require_auth
@rate_limit(requests_per_minute=30)
def pipeline_timing_stats():
    """Return aggregated pipeline timing stats for frontend ETA estimation."""
    stats_file = BASE_DIR / "vault" / "pipeline_stats.json"
    records = []

    if stats_file.exists():
        try:
            loaded = json.loads(stats_file.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                records = loaded
        except (json.JSONDecodeError, OSError):
            pass

    # Fallback: if stats file is missing or has < 3 records, compute from status files
    if len(records) < 3:
        status_dir = BASE_DIR / "vault" / "pipeline_status"
        if status_dir.is_dir():
            stage_order = ["ingestion", "privacy", "summarizer", "auditor"]
            for sf in sorted(status_dir.glob("*.json"))[-50:]:
                try:
                    sd = json.loads(sf.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    continue
                if sd.get("status") != "completed":
                    continue
                # Skip if already in records
                if any(r.get("run_id") == sd.get("run_id") for r in records):
                    continue
                # Compute durations from sequential timestamps
                stage_durations = {}
                stages = sd.get("stages", {})
                prev_ts = sd.get("started_at")
                for sn in stage_order:
                    si = stages.get(sn)
                    if not isinstance(si, dict):
                        continue
                    if "duration_seconds" in si:
                        stage_durations[sn] = si["duration_seconds"]
                        prev_ts = si.get("timestamp", prev_ts)
                        continue
                    ts = si.get("timestamp")
                    if ts and prev_ts:
                        try:
                            from datetime import datetime as _dt
                            t0 = _dt.fromisoformat(prev_ts)
                            t1 = _dt.fromisoformat(ts)
                            dur = round((t1 - t0).total_seconds(), 1)
                            if dur > 0:
                                stage_durations[sn] = dur
                        except (ValueError, TypeError):
                            pass
                    prev_ts = ts or prev_ts
                if stage_durations:
                    records.append({
                        "run_id": sd.get("run_id"),
                        "mode": sd.get("mode", "fast"),
                        "input_chars": sd.get("input_chars", 0),
                        "file_size_bytes": sd.get("file_size_bytes", 0),
                        "stage_durations": stage_durations,
                    })

    if not records:
        return jsonify({"stage_averages": {}, "records": 0})

    stage_totals = {}     # {stage: [duration, ...]}
    size_buckets = {}     # {"small": {stage: [dur, ...]}, ...}
    chunk_times = []      # per-chunk averages for thorough mode

    for r in records:
        input_chars = r.get("input_chars", 0)
        bucket = "small" if input_chars < 50000 else ("medium" if input_chars < 200000 else "large")

        for stage, dur in r.get("stage_durations", {}).items():
            stage_totals.setdefault(stage, []).append(dur)
            size_buckets.setdefault(bucket, {}).setdefault(stage, []).append(dur)

        if r.get("mode") == "thorough" and r.get("chunks_total_seconds") and r.get("chunk_count"):
            chunk_times.append(r["chunks_total_seconds"] / r["chunk_count"])

    def avg(lst):
        return round(sum(lst) / len(lst), 1) if lst else None

    return jsonify({
        "records": len(records),
        "stage_averages": {s: avg(durs) for s, durs in stage_totals.items()},
        "size_buckets": {
            bucket: {s: avg(durs) for s, durs in stages.items()}
            for bucket, stages in size_buckets.items()
        },
        "thorough_chunk_avg_seconds": avg(chunk_times),
    })


@app.route("/api/pipeline/<run_id>")
@require_auth
@rate_limit(requests_per_minute=120)  # Polled frequently
def pipeline_status(run_id):
    """Get the status of a pipeline run (for UI polling)."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"run_id": safe_id, "status": "not_found"}), 404

    try:
        if Vault.is_encrypted(status_file):
            decrypted_bytes = Vault.decrypt_file(status_file)
            data = json.loads(decrypted_bytes.decode("utf-8"))
        else:
            with open(status_file, encoding="utf-8") as f:
                data = json.load(f)
        return jsonify(data)
    except Exception as e:
        logger.error("Failed to read pipeline status %s: %s", safe_id, e)
        return jsonify({"error": "Failed to read status"}), 500


@app.route("/api/pipeline/<run_id>/retry", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=3)
def pipeline_retry(run_id):
    """Retry a failed pipeline run. Resumes from checkpoint if available."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"error": "Pipeline run not found"}), 404

    status_data = safe_load_json(status_file)
    if not status_data:
        return jsonify({"error": "Could not read pipeline status"}), 500

    if status_data.get("status") not in ("failed",):
        return jsonify({"error": f"Cannot retry pipeline with status '{status_data.get('status')}'. Only failed pipelines can be retried."}), 400

    # Check if the error is retryable (e.g., API credits exhausted is NOT retryable)
    if status_data.get("retryable") is False:
        error_type = status_data.get("error_type", "unknown")
        user_action = status_data.get("user_action", "Check your configuration and try again.")
        return jsonify({
            "error": f"This pipeline failure is not retryable ({error_type}).",
            "error_type": error_type,
            "user_action": user_action,
            "retryable": False,
        }), 400

    # Demo expiration check
    from licensing import is_demo_build, is_demo_expired
    if is_demo_build() and is_demo_expired():
        return jsonify({"error": "Your 14-day trial has expired. Purchase a license.", "upgrade_url": "https://aiproductivity.dev/#pricing"}), 403

    # Determine pipeline type and source files from status data
    source_file = status_data.get("source_file", "")
    case_ref = status_data.get("case_ref")
    mode = status_data.get("mode", "fast")

    # Find source files: check processing/failed/ or original incoming paths
    resolved_paths = []
    vault_root = BASE_DIR / "vault"
    for zone in ["incoming", "processing", "processing/failed", "processed"]:
        zone_dir = vault_root / zone
        if not zone_dir.exists():
            continue
        for p in zone_dir.rglob("*"):
            if p.is_file() and safe_id in p.name:
                resolved_paths.append(p)

    # Also check documents table for original paths
    if not resolved_paths:
        try:
            conn = get_db()
            try:
                rows = conn.execute(
                    "SELECT original_path, current_path FROM documents WHERE run_id = ?",
                    (safe_id,)
                ).fetchall()
                for row in rows:
                    for path_col in ("original_path", "current_path"):
                        p = Path(row[path_col]) if row[path_col] else None
                        if p and p.exists() and p.suffix.lower() != ".json":
                            resolved_paths.append(p)
            finally:
                conn.close()
        except Exception:
            pass

    if not resolved_paths:
        return jsonify({"error": "Source files not found for retry. Please re-upload the documents."}), 404

    # Concurrency check — acquired AFTER all pre-flight checks to prevent leaks
    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Too many pipelines running. Please try again later."}), 429

    # Reset status to running
    status_data["status"] = "running"
    status_data["retried_at"] = datetime.now(timezone.utc).isoformat()
    status_data.pop("error_type", None)
    status_data.pop("error_message", None)
    status_data.pop("user_action", None)
    status_data.pop("failed_at", None)
    status_data.pop("cancelled", None)
    safe_write_json(status_file, status_data, encrypt=False)

    # Remove cancel flag file if it exists from a previous cancel
    cancel_flag = PIPELINE_STATUS_DIR / f"{safe_id}.cancel"
    try:
        if cancel_flag.exists():
            cancel_flag.unlink()
    except Exception:
        pass

    # Re-launch pipeline (will resume from checkpoint)
    try:
        if mode == "thorough":
            t = threading.Thread(
                target=_run_thorough_pipeline_background,
                args=([str(p) for p in resolved_paths], safe_id, case_ref, "thorough"),
                daemon=False,
            )
        elif len(resolved_paths) > 1:
            t = threading.Thread(
                target=_run_combined_pipeline_background,
                args=([str(p) for p in resolved_paths], safe_id, case_ref),
                daemon=False,
            )
        else:
            t = threading.Thread(
                target=_run_pipeline_background,
                args=(str(resolved_paths[0]), safe_id),
                daemon=False,
            )
        t.start()
    except Exception as e:
        _active_pipelines.release()
        logger.error("Failed to start retry pipeline thread for %s: %s", safe_id, e)
        _write_pipeline_failure(safe_id, e, mode=mode)
        return jsonify({"error": "Failed to start pipeline retry"}), 500

    logger.info("Pipeline %s retried with %d files", safe_id, len(resolved_paths))

    return jsonify({
        "run_id": safe_id,
        "status": "retrying",
        "file_count": len(resolved_paths),
        "message": "Pipeline retry started. Resuming from last checkpoint.",
    })


@app.route("/api/pipeline/<run_id>/cancel", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def pipeline_cancel(run_id):
    """Cancel a running pipeline. Marks status as failed with cancelled flag."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"error": "Pipeline run not found"}), 404

    status_data = safe_load_json(status_file)
    if not status_data:
        return jsonify({"error": "Could not read pipeline status"}), 500

    if status_data.get("status") != "running":
        return jsonify({"error": f"Cannot cancel pipeline with status '{status_data.get('status')}'. Only running pipelines can be cancelled."}), 400

    now = datetime.now(timezone.utc).isoformat()
    status_data["status"] = "failed"
    status_data["cancelled"] = True
    status_data["error"] = "Cancelled by user"
    status_data["error_message"] = "Pipeline was cancelled by user"
    status_data["error_type"] = "cancelled"
    status_data["user_action"] = "Click Retry to restart this pipeline."
    status_data["retryable"] = True
    status_data["failed_at"] = now
    status_data["completed_at"] = now

    # Mark any running stages as failed
    for stage_name, stage_data in status_data.get("stages", {}).items():
        if isinstance(stage_data, dict) and stage_data.get("status") == "running":
            stage_data["status"] = "failed"
            stage_data["details"] = {"error_type": "cancelled", "error_msg": "Cancelled by user"}
            stage_data["timestamp"] = now

    # Also mark thorough-mode phases as cancelled if running
    for phase in ("preprocessing", "chunks", "merge"):
        if phase in status_data and isinstance(status_data[phase], dict):
            if status_data[phase].get("status") == "running":
                status_data[phase]["status"] = "failed"
                status_data[phase]["timestamp"] = now

    # Write cancel flag file for background thread detection
    cancel_flag = PIPELINE_STATUS_DIR / f"{safe_id}.cancel"
    try:
        cancel_flag.write_text(now, encoding="utf-8")
    except Exception as e:
        logger.warning("Could not write cancel flag for %s: %s", safe_id, e)

    safe_write_json(status_file, status_data, encrypt=False)

    try:
        with transaction() as db:
            db.execute(
                "UPDATE tasks SET status = ?, error = ? WHERE task_id = ?",
                ("failed", "Cancelled by user", safe_id),
            )
    except Exception:
        pass

    _audit_log("pipeline_cancelled", None, f"Pipeline cancelled: {safe_id}")
    log_access(
        session.get("username", "api"), "cancel", "pipeline",
        resource_id=safe_id, ip_address=request.remote_addr,
    )

    logger.info("Pipeline %s cancelled by user", safe_id)
    return jsonify({
        "run_id": safe_id,
        "status": "cancelled",
        "message": "Pipeline cancelled. You can retry it later.",
    })


@app.route("/api/pipeline/<run_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def pipeline_delete(run_id):
    """Delete a pipeline run's status file and associated artifacts."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"error": "Pipeline run not found"}), 404

    status_data = safe_load_json(status_file)
    if status_data and status_data.get("status") == "running":
        return jsonify({"error": "Cannot delete a running pipeline. Cancel it first."}), 400

    try:
        status_file.unlink()
    except Exception as e:
        logger.error("Failed to delete pipeline status %s: %s", safe_id, e)
        return jsonify({"error": "Failed to delete pipeline status file"}), 500

    # Clean up cancel flag and checkpoint if present
    for suffix in (".cancel", ):
        flag = PIPELINE_STATUS_DIR / f"{safe_id}{suffix}"
        try:
            if flag.exists():
                flag.unlink()
        except Exception:
            pass

    checkpoint_file = BASE_DIR / "vault" / "processing" / "checkpoints" / f"{safe_id}.json"
    try:
        if checkpoint_file.exists():
            checkpoint_file.unlink()
    except Exception:
        pass

    try:
        with transaction() as db:
            db.execute("DELETE FROM tasks WHERE task_id = ?", (safe_id,))
    except Exception:
        pass

    _audit_log("pipeline_deleted", None, f"Pipeline run deleted: {safe_id}")
    log_access(
        session.get("username", "api"), "delete", "pipeline",
        resource_id=safe_id, ip_address=request.remote_addr,
    )

    logger.info("Pipeline run %s deleted by user", safe_id)
    return jsonify({"ok": True, "deleted": safe_id})


def _delete_pipeline_artifacts(safe_id):
    """Delete all artifacts for a pipeline run. Returns True on success."""
    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    try:
        status_file.unlink()
    except Exception as e:
        logger.error("Failed to delete pipeline status %s: %s", safe_id, e)
        return False

    for suffix in (".cancel",):
        flag = PIPELINE_STATUS_DIR / f"{safe_id}{suffix}"
        try:
            if flag.exists():
                flag.unlink()
        except Exception:
            pass

    checkpoint_file = BASE_DIR / "vault" / "processing" / "checkpoints" / f"{safe_id}.json"
    try:
        if checkpoint_file.exists():
            checkpoint_file.unlink()
    except Exception:
        pass

    try:
        with transaction() as db:
            db.execute("DELETE FROM tasks WHERE task_id = ?", (safe_id,))
    except Exception:
        pass

    return True


@app.route("/api/pipeline/bulk-delete", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def pipeline_bulk_delete():
    """Delete multiple pipeline runs at once."""
    data = request.get_json()
    run_ids = data.get("run_ids") if data else None

    if not run_ids or not isinstance(run_ids, list):
        return jsonify({"error": "run_ids must be a non-empty list"}), 400
    if len(run_ids) > 500:
        return jsonify({"error": "Maximum 500 pipelines per request"}), 400

    deleted = []
    skipped = []

    for run_id in run_ids:
        safe_id = secure_filename(str(run_id))
        if not safe_id:
            continue

        status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
        if not status_file.exists():
            continue

        status_data = safe_load_json(status_file)
        if status_data and status_data.get("status") == "running":
            skipped.append(safe_id)
            continue

        if _delete_pipeline_artifacts(safe_id):
            deleted.append(safe_id)

    if deleted:
        _audit_log("pipeline_bulk_deleted", None, f"Bulk deleted {len(deleted)} pipeline runs")
        log_access(
            session.get("username", "api"), "bulk_delete", "pipeline",
            details=f"Deleted {len(deleted)} runs", ip_address=request.remote_addr,
        )
        logger.info("Bulk deleted %d pipeline runs", len(deleted))

    return jsonify({"ok": True, "deleted": len(deleted), "skipped": skipped})


@app.route("/api/pipeline/clear-all", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=2)
def pipeline_clear_all():
    """Delete ALL non-running pipeline runs."""
    deleted = 0
    skipped_running = 0

    try:
        for status_file in PIPELINE_STATUS_DIR.glob("*.json"):
            safe_id = status_file.stem
            status_data = safe_load_json(status_file)
            if status_data and status_data.get("status") == "running":
                skipped_running += 1
                continue

            if _delete_pipeline_artifacts(safe_id):
                deleted += 1
    except Exception as e:
        logger.error("Error during pipeline clear-all: %s", e)
        return jsonify({"error": f"Partial clear: deleted {deleted}, error: {e}"}), 500

    if deleted:
        _audit_log("pipeline_clear_all", None, f"Cleared all pipelines: {deleted} deleted, {skipped_running} running skipped")
        log_access(
            session.get("username", "api"), "clear_all", "pipeline",
            details=f"Cleared {deleted} runs, {skipped_running} running skipped",
            ip_address=request.remote_addr,
        )
        logger.info("Pipeline clear-all: deleted %d, skipped %d running", deleted, skipped_running)

    return jsonify({"ok": True, "deleted": deleted, "skipped_running": skipped_running})


# ── Health Check ──────────────────────────────────────────────────────────────

_app_start_time = time.time()


@app.route("/api/health")
def api_health_check():
    """Health check endpoint for PM2/monitoring. No auth required."""
    import os as _os

    db_ok = False
    try:
        conn = get_db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        db_ok = True
    except Exception:
        pass

    api_key_configured = bool(_os.getenv("ANTHROPIC_API_KEY", ""))

    # Count active pipelines (3 - available = active)
    # Semaphore doesn't expose count directly, so try to acquire then release
    active = 0
    acquired = []
    for _ in range(3):
        if _active_pipelines.acquire(blocking=False):
            acquired.append(True)
        else:
            break
    active = 3 - len(acquired)
    for _ in acquired:
        _active_pipelines.release()

    status = "healthy" if db_ok and api_key_configured else "degraded"
    http_code = 200 if status == "healthy" else 503

    return jsonify({
        "status": status,
        "uptime_seconds": int(time.time() - _app_start_time),
        "active_pipelines": active,
        "db_ok": db_ok,
        "api_key_configured": api_key_configured,
    }), http_code


# ── Audit Trail API ──────────────────────────────────────────────────────────

@app.route("/api/audit")
@require_auth
@rate_limit(requests_per_minute=30)
def list_audit():
    """List audit trail entries from DB access_log + vault files, merged by timestamp."""
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 100)
    source = request.args.get("source", "all")  # all, db, files

    entries = []

    # 1. Pull from access_log DB table (real activity tracking)
    if source in ("all", "db"):
        conn = get_db()
        try:
            rows = conn.execute(
                "SELECT * FROM access_log ORDER BY timestamp DESC LIMIT 500"
            ).fetchall()
            for r in rows:
                entries.append({
                    "timestamp": r["timestamp"],
                    "action": r["action"],
                    "details": f"{r['resource_type']}"
                              + (f" #{r['resource_id']}" if r["resource_id"] else "")
                              + (f" — {r['details']}" if r["details"] else ""),
                    "user": r["username"],
                    "ip_address": r["ip_address"],
                    "source": "db",
                })
        finally:
            conn.close()

    # 2. Pull from vault audit files (HMAC-signed file entries)
    if source in ("all", "files") and VAULT_AUDIT.exists():
        for f in sorted(VAULT_AUDIT.glob("*.json"), reverse=True)[:200]:
            try:
                data = safe_load_json(f)
                if data:
                    data["source"] = "file"
                    entries.append(data)
            except (json.JSONDecodeError, KeyError):
                continue

    # Sort merged entries by timestamp descending
    entries.sort(key=lambda e: e.get("timestamp") or "", reverse=True)

    total = len(entries)
    offset = (page - 1) * per_page
    page_entries = entries[offset:offset + per_page]

    log_access(
        session.get("username", "api"), "list", "audit_trail",
        ip_address=request.remote_addr,
    )

    return jsonify({
        "entries": page_entries,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": max(1, (total + per_page - 1) // per_page),
        },
    })


# ── System Status API ────────────────────────────────────────────────────────

@app.route("/api/status")
@app.route("/api/dashboard/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def system_status():
    """Overall system status: counts, health checks."""
    summary_count = len(list(VAULT_SUMMARIES.glob("*_summary.json"))) if VAULT_SUMMARIES.exists() else 0
    incoming_count = sum(1 for _ in VAULT_INCOMING.rglob("*") if _.is_file()) if VAULT_INCOMING.exists() else 0
    processing_count = sum(1 for _ in (BASE_DIR / "vault" / "processing").rglob("*") if _.is_file()) if (BASE_DIR / "vault" / "processing").exists() else 0

    contact_counts = {"total": 0, "new": 0, "contacted": 0, "awaiting": 0, "received": 0, "failed": 0}
    try:
        conn = get_db()
        for row in conn.execute("SELECT status, COUNT(*) as cnt FROM contacts GROUP BY status").fetchall():
            status_key = row["status"]
            if status_key in contact_counts:
                contact_counts[status_key] = row["cnt"]
            contact_counts["total"] += row["cnt"]
        conn.close()
    except Exception:
        pass

    # Include build type so UI can show/hide dev-only features
    try:
        from product_guard import get_build_type
        build_type = get_build_type()
    except ImportError:
        build_type = "dev"

    return jsonify({
        "summaries_completed": summary_count,
        "files_incoming": incoming_count,
        "files_processing": processing_count,
        "contacts": contact_counts,
        "system": "operational",
        "build_type": build_type,
    })


# ── Incoming Files API ────────────────────────────────────────────────────────

@app.route("/api/incoming")
@require_auth
@rate_limit(requests_per_minute=60)
def list_incoming():
    """List files in vault/incoming/ for the dashboard drill-down."""
    if not VAULT_INCOMING.exists():
        return jsonify({"files": [], "total": 0})

    files = []
    for p in sorted(VAULT_INCOMING.rglob("*"), key=lambda x: x.stat().st_mtime, reverse=True):
        if not p.is_file():
            continue
        files.append({
            "name": p.name,
            "path": str(p.relative_to(VAULT_INCOMING)),
            "size": p.stat().st_size,
            "modified": datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat(),
            "extension": p.suffix.lower(),
        })

    return jsonify({"files": files[:100], "total": len(files)})


# ── Chat with Summaries API ──────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=20, burst=10)
def chat_with_summaries():
    """Chat endpoint: LLM with context retrieval (RAG) via VectorStore."""
    data = request.get_json()
    if not data or not data.get("message", "").strip():
        return jsonify({"error": "message is required"}), 400

    user_message = data["message"].strip()[:2000]
    conversation = data.get("history", [])[-10:]  # Last 10 messages
    run_id_filter = data.get("run_id") # Optional: chat about a specific case

    config = load_config()
    
    # ── Context Retrieval (RAG) ──────────────────────────────────────
    try:
        from vector_store import VectorStore
        vs = VectorStore(config)
        # Search for the top 10 most relevant chunks
        # If run_id_filter is provided, only search that case
        search_ids = [run_id_filter] if run_id_filter else None
        results = vs.search(user_message, run_ids=search_ids, top_k=10)
        
        context_parts = []
        for r in results:
            source = f"Case: {r['run_id']} (Page {r['page_number']})"
            context_parts.append(f"[{source}]\n{r['content']}")
        
        retrieved_context = "\n\n---\n\n".join(context_parts)
    except Exception as e:
        logger.warning("RAG retrieval failed, falling back to basic summary: %s", e)
        retrieved_context = _build_summary_context()
    # ─────────────────────────────────────────────────────────────────

    backend = config.get("llm_backend", "ollama")

    system_prompt = (
        "You are a medical records assistant with access to the following patient records. "
        "Answer questions accurately based on the snippets provided. "
        "Always cite which case or page your answer comes from using the bracketed headers. "
        "If the information is not in the records, say so clearly. "
        "Never fabricate medical information.\n\n"
        "=== RETRIEVED MEDICAL CONTEXT ===\n" + retrieved_context
    )

    messages = [{"role": "system", "content": system_prompt}]
    for msg in conversation:
        if msg.get("role") in ("user", "assistant"):
            messages.append({"role": msg["role"], "content": msg["content"][:2000]})
    messages.append({"role": "user", "content": user_message})

    try:
        reply, model = _chat_bedrock(messages, config)
    except Exception as e:
        logger.error("Chat error: %s", e)
        return jsonify({"error": f"LLM unavailable: {e}"}), 503

    log_access(
        session.get("username", "api"), "chat", "summaries",
        ip_address=request.remote_addr,
        details=f"q={user_message[:80]}",
    )

    return jsonify({"reply": reply, "model": model, "backend": backend})



def _chat_bedrock(messages, config):
    """Send chat messages via AWS Bedrock (HIPAA-compliant via BAA)."""
    from dispatch import call_bedrock

    bedrock_cfg = config.get("bedrock", {})
    model = bedrock_cfg.get("chat_model", bedrock_cfg.get("model", "us.anthropic.claude-sonnet-4-5-v2:0"))

    try:
        response = call_bedrock(
            model_id=model,
            messages=messages,
            config=config,
            timeout_override=bedrock_cfg.get("timeout", 120),
            max_tokens_override=8192,
        )
        return response or "No response from model.", model
    except RuntimeError as e:
        err_str = str(e)
        if err_str.startswith("__ERROR__:"):
            parts = err_str.split(":", 2)
            raise RuntimeError(parts[2] if len(parts) > 2 else err_str)
        raise


def _build_summary_context():
    """Build a concise context string from all existing summaries."""
    if not VAULT_SUMMARIES.exists():
        return "No summaries available yet."

    parts = []
    for f in sorted(VAULT_SUMMARIES.glob("*_summary.json"), reverse=True)[:20]:
        try:
            data = safe_load_json(f)
            if not data:
                continue
            summary = data.get("summary", {})
            if not summary:
                continue
            s = summary.get("summary", {})
            source = data.get("source_file", f.stem)
            run_id = data.get("run_id", "")
            chief = s.get("chief_complaint", {}).get("text", "N/A")
            diagnoses = ", ".join(d.get("diagnosis", "") for d in s.get("active_diagnoses", []))
            meds = ", ".join(f"{m.get('name','')} {m.get('dosage','')}" for m in s.get("medications", []))
            findings = ", ".join(f.get("finding", "") for f in s.get("key_findings", []))
            raw_gaps = s.get("timeline_gaps", [])
            gap_strs = []
            for g in raw_gaps:
                if isinstance(g, str):
                    gap_strs.append(g)
                elif isinstance(g, dict):
                    gap_strs.append(
                        g.get("gap_description")
                        or g.get("note")
                        or (f"{g.get('gap_start', '')} to {g.get('gap_end', '')}" if g.get("gap_start") else str(g))
                    )
            gaps = "; ".join(gap_strs)
            confidence = s.get("overall_confidence", "N/A")

            parts.append(
                f"--- Document: {source} (ID: {run_id}) ---\n"
                f"Chief Complaint: {chief}\n"
                f"Diagnoses: {diagnoses or 'None listed'}\n"
                f"Medications: {meds or 'None listed'}\n"
                f"Key Findings: {findings or 'None listed'}\n"
                f"Timeline Gaps: {gaps or 'None'}\n"
                f"Confidence: {confidence}\n"
            )
        except (json.JSONDecodeError, KeyError, TypeError, AttributeError):
            continue

    return "\n".join(parts) if parts else "No summaries available yet."


# ── Summary Feedback (RLHF) API ──────────────────────────────────────────────

@app.route("/api/summaries/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_feedback(run_id):
    """Submit quality feedback on a summary for RLHF."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    rating = data.get("rating", "")
    if rating not in ("poor", "good", "excellent"):
        return jsonify({"error": "rating must be poor, good, or excellent"}), 400

    feedback_text = (data.get("feedback_text") or "")[:2000]
    username = session.get("username", "api")

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO summary_feedback (run_id, rating, feedback_text, username)
                   VALUES (?, ?, ?, ?)""",
                (safe_id, rating, feedback_text, username),
            )
    except Exception as e:
        logger.error("Feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("summary_feedback", None, f"Feedback on {safe_id}: {rating}")
    logger.info("Feedback for %s: %s by %s", safe_id, rating, username)

    return jsonify({"success": True, "message": f"Thank you for your {rating} rating."})


@app.route("/api/summaries/<run_id>/feedback")
@require_auth
@rate_limit(requests_per_minute=60)
def get_feedback(run_id):
    """Get all feedback for a summary."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM summary_feedback WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()

    return jsonify({"feedback": [dict(r) for r in rows]})


@app.route("/api/feedback/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def feedback_stats():
    """Aggregate feedback statistics for RLHF insights."""
    conn = get_db()
    try:
        totals = conn.execute(
            "SELECT rating, COUNT(*) as cnt FROM summary_feedback GROUP BY rating"
        ).fetchall()
        recent = conn.execute(
            """SELECT sf.run_id, sf.rating, sf.feedback_text, sf.created_at, sf.username
               FROM summary_feedback sf ORDER BY sf.created_at DESC LIMIT 20"""
        ).fetchall()
    finally:
        conn.close()

    stats = {"poor": 0, "good": 0, "excellent": 0}
    for row in totals:
        stats[row["rating"]] = row["cnt"]

    return jsonify({
        "stats": stats,
        "total": sum(stats.values()),
        "recent": [dict(r) for r in recent],
    })


# ── Case Valuation Outcome Tracking (RL) ─────────────────────────────────────

@app.route("/api/valuations/<run_id>/outcome", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_valuation_outcome(run_id):
    """Submit actual settlement/verdict outcome for valuation calibration."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    accuracy = data.get("attorney_accuracy_rating", "")
    if accuracy and accuracy not in ("too_low", "accurate", "too_high"):
        return jsonify({"error": "attorney_accuracy_rating must be too_low, accurate, or too_high"}), 400

    outcome_type = data.get("outcome_type", "")
    if outcome_type and outcome_type not in ("settled", "verdict", "dismissed", "pending"):
        return jsonify({"error": "outcome_type must be settled, verdict, dismissed, or pending"}), 400

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO valuation_outcomes
                   (run_id, predicted_low, predicted_mid, predicted_high, predicted_severity,
                    actual_settlement, actual_verdict, outcome_type, attorney_accuracy_rating,
                    attorney_notes, jurisdiction, case_type)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (safe_id,
                 data.get("predicted_low"), data.get("predicted_mid"), data.get("predicted_high"),
                 data.get("predicted_severity"),
                 data.get("actual_settlement"), data.get("actual_verdict"),
                 outcome_type or None, accuracy or None,
                 (data.get("attorney_notes") or "")[:2000] or None,
                 data.get("jurisdiction"), data.get("case_type")),
            )
    except Exception as e:
        logger.error("Valuation outcome save error: %s", e)
        return jsonify({"error": "Failed to save outcome"}), 500

    _audit_log("valuation_outcome", None, f"Outcome for {safe_id}: {accuracy or outcome_type}")
    return jsonify({"success": True, "message": "Valuation outcome recorded."})


@app.route("/api/valuations/<run_id>/outcome")
@require_auth
@rate_limit(requests_per_minute=60)
def get_valuation_outcome(run_id):
    """Get outcome data for a valuation."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM valuation_outcomes WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()
    return jsonify({"outcomes": [dict(r) for r in rows]})


# ── Demand Package Feedback (RL) ─────────────────────────────────────────────

@app.route("/api/demand/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_demand_feedback(run_id):
    """Submit quality feedback on a demand package."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    rating = data.get("rating", "")
    if rating and rating not in ("poor", "good", "excellent"):
        return jsonify({"error": "rating must be poor, good, or excellent"}), 400

    tone = data.get("tone_feedback", "")
    if tone and tone not in ("too_aggressive", "appropriate", "too_conservative"):
        return jsonify({"error": "tone_feedback must be too_aggressive, appropriate, or too_conservative"}), 400

    edit_sev = data.get("edit_severity", "")
    if edit_sev and edit_sev not in ("minor_tweaks", "significant_rewrites", "unusable"):
        return jsonify({"error": "edit_severity must be minor_tweaks, significant_rewrites, or unusable"}), 400

    legal_acc = data.get("legal_accuracy")
    if legal_acc is not None:
        try:
            legal_acc = int(legal_acc)
            if not (1 <= legal_acc <= 5):
                return jsonify({"error": "legal_accuracy must be 1-5"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "legal_accuracy must be an integer 1-5"}), 400

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO demand_feedback
                   (run_id, rating, sections_edited, edit_severity, tone_feedback,
                    legal_accuracy, feedback_text)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (safe_id, rating or None,
                 data.get("sections_edited"),
                 edit_sev or None, tone or None,
                 legal_acc,
                 (data.get("feedback_text") or "")[:2000] or None),
            )
    except Exception as e:
        logger.error("Demand feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("demand_feedback", None, f"Demand feedback on {safe_id}: {rating}")
    return jsonify({"success": True, "message": "Demand package feedback recorded."})


# ── Negligence Detection Feedback (RL) ───────────────────────────────────────

@app.route("/api/negligence/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_negligence_feedback(run_id):
    """Submit accept/reject feedback on individual negligence findings."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # Support batch submission of multiple findings
    findings = data.get("findings", [data]) if "findings" in data else [data]

    inserted = 0
    try:
        with transaction() as conn:
            for finding in findings:
                title = (finding.get("finding_title") or "")[:500]
                accepted = finding.get("finding_accepted")
                if accepted is not None:
                    accepted = 1 if accepted else 0

                conn.execute(
                    """INSERT INTO negligence_feedback
                       (run_id, finding_title, finding_accepted, severity_correct,
                        corrected_severity, attorney_notes)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (safe_id, title or None, accepted,
                     1 if finding.get("severity_correct") else (0 if finding.get("severity_correct") is not None else None),
                     finding.get("corrected_severity"),
                     (finding.get("attorney_notes") or "")[:2000] or None),
                )
                inserted += 1
    except Exception as e:
        logger.error("Negligence feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("negligence_feedback", None, f"Negligence feedback on {safe_id}: {inserted} findings")
    return jsonify({"success": True, "message": f"{inserted} finding(s) feedback recorded."})


@app.route("/api/negligence/<run_id>/feedback")
@require_auth
@rate_limit(requests_per_minute=60)
def get_negligence_feedback(run_id):
    """Get all negligence feedback for a run."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM negligence_feedback WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()
    return jsonify({"feedback": [dict(r) for r in rows]})


# ── RL Feedback Statistics ───────────────────────────────────────────────────

@app.route("/api/rl/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def rl_feedback_stats():
    """Aggregate RL feedback statistics across all features."""
    conn = get_db()
    try:
        # Valuation outcomes
        val_stats = conn.execute(
            """SELECT attorney_accuracy_rating as rating, COUNT(*) as cnt
               FROM valuation_outcomes WHERE attorney_accuracy_rating IS NOT NULL
               GROUP BY attorney_accuracy_rating"""
        ).fetchall()

        # Demand feedback
        dem_stats = conn.execute(
            "SELECT rating, COUNT(*) as cnt FROM demand_feedback WHERE rating IS NOT NULL GROUP BY rating"
        ).fetchall()
        dem_tone = conn.execute(
            """SELECT tone_feedback, COUNT(*) as cnt FROM demand_feedback
               WHERE tone_feedback IS NOT NULL GROUP BY tone_feedback"""
        ).fetchall()

        # Negligence feedback
        neg_stats = conn.execute(
            """SELECT
                 SUM(CASE WHEN finding_accepted = 1 THEN 1 ELSE 0 END) as accepted,
                 SUM(CASE WHEN finding_accepted = 0 THEN 1 ELSE 0 END) as rejected,
                 COUNT(*) as total
               FROM negligence_feedback WHERE finding_accepted IS NOT NULL"""
        ).fetchone()

        # Exemplar bank counts
        exemplar_counts = conn.execute(
            "SELECT feature, COUNT(*) as cnt FROM exemplar_bank GROUP BY feature"
        ).fetchall()
    finally:
        conn.close()

    return jsonify({
        "valuation": {
            "accuracy": {r["rating"]: r["cnt"] for r in val_stats},
            "total": sum(r["cnt"] for r in val_stats),
        },
        "demand": {
            "ratings": {r["rating"]: r["cnt"] for r in dem_stats},
            "tone": {r["tone_feedback"]: r["cnt"] for r in dem_tone},
            "total": sum(r["cnt"] for r in dem_stats),
        },
        "negligence": {
            "accepted": neg_stats["accepted"] or 0 if neg_stats else 0,
            "rejected": neg_stats["rejected"] or 0 if neg_stats else 0,
            "total": neg_stats["total"] or 0 if neg_stats else 0,
            "precision": round((neg_stats["accepted"] or 0) / max(1, neg_stats["total"] or 1), 3) if neg_stats else 0,
        },
        "exemplars": {r["feature"]: r["cnt"] for r in exemplar_counts},
    })


# ── Email Settings API ────────────────────────────────────────────────────────

@app.route("/api/settings/email")
@require_auth
@rate_limit(requests_per_minute=30)
def get_email_settings():
    """Get current email configuration (passwords masked)."""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM email_config WHERE id = 1").fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({
            "configured": False,
            "smtp_host": "", "smtp_port": 587, "smtp_username": "",
            "imap_host": "", "imap_port": 993, "imap_username": "",
            "sender_name": "", "sender_organization": "", "sender_phone": "",
            "enabled": False,
        })

    d = dict(row)
    # Mask passwords in response
    d["smtp_password"] = "********" if d.get("smtp_password_encrypted") else ""
    d["imap_password"] = "********" if d.get("imap_password_encrypted") else ""
    del d["smtp_password_encrypted"]
    del d["imap_password_encrypted"]
    d["configured"] = True
    return jsonify(d)


@app.route("/api/settings/email", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def save_email_settings():
    """Save email configuration."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    smtp_host = (data.get("smtp_host") or "").strip()
    smtp_port = int(data.get("smtp_port", 587))
    smtp_username = (data.get("smtp_username") or "").strip()
    smtp_password = data.get("smtp_password", "")
    imap_host = (data.get("imap_host") or "").strip()
    imap_port = int(data.get("imap_port", 993))
    imap_username = (data.get("imap_username") or "").strip()
    imap_password = data.get("imap_password", "")
    sender_name = sanitize_string(data.get("sender_name", ""), 200)
    sender_org = sanitize_string(data.get("sender_organization", ""), 300)
    sender_phone = sanitize_string(data.get("sender_phone", ""), 50)
    enabled = 1 if data.get("enabled") else 0

    username = session.get("username", "api")
    now = datetime.now(timezone.utc).isoformat()

    # Don't overwrite password if masked value sent back
    conn = get_db()
    try:
        existing = conn.execute("SELECT * FROM email_config WHERE id = 1").fetchone()
    finally:
        conn.close()

    from security_vault import Vault
    if smtp_password == "********" and existing:
        smtp_password_enc = existing["smtp_password_encrypted"]
    else:
        smtp_password_enc = Vault.encrypt_field(smtp_password) if smtp_password else ""

    if imap_password == "********" and existing:
        imap_password_enc = existing["imap_password_encrypted"]
    else:
        imap_password_enc = Vault.encrypt_field(imap_password) if imap_password else ""

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO email_config
                   (id, smtp_host, smtp_port, smtp_username, smtp_password_encrypted,
                    imap_host, imap_port, imap_username, imap_password_encrypted,
                    sender_name, sender_organization, sender_phone,
                    enabled, updated_at, updated_by)
                   VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (smtp_host, smtp_port, smtp_username, smtp_password_enc,
                 imap_host, imap_port, imap_username, imap_password_enc,
                 sender_name, sender_org, sender_phone,
                 enabled, now, username),
            )
    except Exception as e:
        logger.error("Email config save error: %s", e)
        return jsonify({"error": "Failed to save settings"}), 500

    _audit_log("email_settings_updated", None, f"Email settings updated by {username}")
    logger.info("Email settings updated by %s", username)

    return jsonify({"success": True, "message": "Email settings saved."})


@app.route("/api/settings/email/test", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def test_email_connection():
    """Test SMTP and IMAP connection."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    results = {"smtp": None, "imap": None}

    # Test SMTP
    smtp_host = (data.get("smtp_host") or "").strip()
    smtp_port = int(data.get("smtp_port", 587))
    smtp_user = (data.get("smtp_username") or "").strip()
    smtp_pass = data.get("smtp_password", "")

    from security_vault import Vault
    if smtp_pass == "********":
        conn = get_db()
        try:
            row = conn.execute("SELECT smtp_password_encrypted FROM email_config WHERE id = 1").fetchone()
            smtp_pass = Vault.decrypt_field(row["smtp_password_encrypted"]) if row else ""
        finally:
            conn.close()

    if smtp_host:
        try:
            import smtplib
            with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as s:
                s.ehlo()
                s.starttls()
                s.ehlo()
                if smtp_user and smtp_pass:
                    s.login(smtp_user, smtp_pass)
                results["smtp"] = {"status": "ok", "message": "SMTP connection successful"}
        except Exception as e:
            results["smtp"] = {"status": "error", "message": str(e)}
    else:
        results["smtp"] = {"status": "skipped", "message": "No SMTP host configured"}

    # Test IMAP
    imap_host = (data.get("imap_host") or "").strip()
    imap_port = int(data.get("imap_port", 993))
    imap_user = (data.get("imap_username") or "").strip()
    imap_pass = data.get("imap_password", "")

    if imap_pass == "********":
        conn = get_db()
        try:
            row = conn.execute("SELECT imap_password_encrypted FROM email_config WHERE id = 1").fetchone()
            imap_pass = Vault.decrypt_field(row["imap_password_encrypted"]) if row else ""
        finally:
            conn.close()

    if imap_host:
        try:
            import imaplib
            with imaplib.IMAP4_SSL(imap_host, imap_port) as m:
                if imap_user and imap_pass:
                    m.login(imap_user, imap_pass)
                results["imap"] = {"status": "ok", "message": "IMAP connection successful"}
        except Exception as e:
            results["imap"] = {"status": "error", "message": str(e)}
    else:
        results["imap"] = {"status": "skipped", "message": "No IMAP host configured"}

    return jsonify(results)


def _save_bedrock_api_key(api_key):
    """Save Bedrock API key to .env and set in current process environment.

    Bedrock API keys start with ABSK and use the AWS_BEARER_TOKEN_BEDROCK
    environment variable. boto3 picks this up automatically for auth.
    """
    env_path = BASE_DIR / ".env"
    env_lines = []
    if env_path.exists():
        env_lines = env_path.read_text(encoding="utf-8").splitlines()

    target_key = "AWS_BEARER_TOKEN_BEDROCK"
    found = False
    new_lines = []
    for line in env_lines:
        key = line.split("=", 1)[0].strip() if "=" in line else ""
        if key == target_key:
            new_lines.append(f"{target_key}={api_key}")
            found = True
        else:
            new_lines.append(line)

    if not found:
        new_lines.append(f"{target_key}={api_key}")

    env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

    # Set in current process so it takes effect immediately
    os.environ[target_key] = api_key
    logger.info("Bedrock API key updated")


# ── LLM Backend Settings API ──────────────────────────────────────────────

@app.route("/api/settings/bedrock-test", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def test_bedrock_connection():
    """Test AWS Bedrock connectivity with a Bedrock API key (ABSK...)."""
    import urllib.request
    import urllib.error
    import urllib.parse

    data = request.get_json() or {}
    api_key = data.get("api_key", "").strip()

    if not api_key:
        api_key = os.getenv("AWS_BEARER_TOKEN_BEDROCK", "")
    if not api_key:
        return jsonify({"success": False, "error": "No API key provided"}), 400

    config_data = load_config()
    region = config_data.get("bedrock", {}).get("region", "us-east-1")
    model_id = config_data.get("bedrock", {}).get("model", "us.anthropic.claude-sonnet-4-6")

    # Use boto3 with Converse API — natively supports ABSK keys via env var
    import boto3
    import botocore.exceptions

    # Temporarily set the env var so boto3 picks it up
    old_key = os.environ.get("AWS_BEARER_TOKEN_BEDROCK")
    os.environ["AWS_BEARER_TOKEN_BEDROCK"] = api_key

    try:
        client = boto3.client("bedrock-runtime", region_name=region)
        response = client.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": "Hi"}]}],
        )
        output_text = response["output"]["message"]["content"][0]["text"]
        return jsonify({"success": True, "message": f"Connected to Bedrock successfully. Model responded: {output_text[:50]}"})
    except botocore.exceptions.ClientError as e:
        code = e.response["Error"].get("Code", "")
        msg = e.response["Error"].get("Message", str(e))
        logger.warning("Bedrock test failed: %s: %s (model=%s, region=%s)", code, msg, model_id, region)
        if "AccessDenied" in code or "403" in str(e):
            return jsonify({"success": False, "error": f"Access denied: {msg} (Region: {region}, Model: {model_id})"}), 400
        if "ValidationException" in code:
            return jsonify({"success": False, "error": f"Invalid model: {msg} (Region: {region}, Model: {model_id})"}), 400
        return jsonify({"success": False, "error": f"{code}: {msg}"}), 400
    except Exception as e:
        logger.warning("Bedrock test failed: %s: %s", type(e).__name__, e)
        return jsonify({"success": False, "error": f"{type(e).__name__}: {str(e)[:200]}"}), 400
    finally:
        # Restore original env var
        if old_key is not None:
            os.environ["AWS_BEARER_TOKEN_BEDROCK"] = old_key
        elif "AWS_BEARER_TOKEN_BEDROCK" in os.environ and not old_key:
            os.environ["AWS_BEARER_TOKEN_BEDROCK"] = api_key  # keep it set


@app.route("/api/settings/llm")
@require_auth
@rate_limit(requests_per_minute=30)
def get_llm_settings():
    """Get current LLM backend configuration."""
    config = load_config()
    backend = config.get("llm_backend", "bedrock")
    ollama_cfg = config.get("ollama", {})
    bedrock_cfg = config.get("bedrock", {})

    # Check Bedrock availability (API key set)
    has_bedrock_key = bool(os.getenv("AWS_BEARER_TOKEN_BEDROCK"))

    # Bedrock per-agent models
    agents_cfg = config.get("medical_agents", {})
    bedrock_agent_models = {
        "ingestion": agents_cfg.get("ingestion", {}).get("bedrock_model", "us.anthropic.claude-haiku-4-5-v1:0"),
        "privacy": agents_cfg.get("privacy", {}).get("bedrock_model", "us.anthropic.claude-haiku-4-5-v1:0"),
        "summarizer": agents_cfg.get("summarizer", {}).get("bedrock_model", "us.anthropic.claude-sonnet-4-5-v2:0"),
        "auditor": agents_cfg.get("auditor", {}).get("bedrock_model", "us.anthropic.claude-haiku-4-5-v1:0"),
    }

    # Check Ollama availability and fetch installed models
    ollama_ok = False
    ollama_models = []
    endpoint = ollama_cfg.get("endpoint", "http://localhost:11434")
    try:
        import urllib.request
        req = urllib.request.Request(f"{endpoint}/api/tags")
        req.add_header("User-Agent", "MedRecords")
        with urllib.request.urlopen(req, timeout=3) as resp:
            if resp.status == 200:
                ollama_ok = True
                tags_data = json.loads(resp.read().decode("utf-8"))
                ollama_models = [m["name"] for m in tags_data.get("models", [])]
    except Exception:
        pass

    # Current per-agent Ollama model assignments
    current_ollama_models = {
        "ingestion": agents_cfg.get("ingestion", {}).get("model", "qwen2.5:7b"),
        "privacy": agents_cfg.get("privacy", {}).get("model", "glm4:9b"),
        "summarizer": agents_cfg.get("summarizer", {}).get("model", "qwen2.5:7b"),
        "auditor": agents_cfg.get("auditor", {}).get("model", "glm4:9b"),
        "chat": ollama_cfg.get("chat_model", "qwen2.5:7b"),
    }

    return jsonify({
        "backend": backend,
        "bedrock": {
            "model": bedrock_cfg.get("model", "us.anthropic.claude-sonnet-4-5-v2:0"),
            "region": bedrock_cfg.get("region", "us-east-1"),
            "chat_model": bedrock_cfg.get("chat_model", "us.anthropic.claude-sonnet-4-5-v2:0"),
            "available": has_bedrock_key,
            "key_hint": (os.getenv("AWS_BEARER_TOKEN_BEDROCK", "")[:8] + "****") if has_bedrock_key else "",
            "agent_models": bedrock_agent_models,
        },
        "ollama": {
            "endpoint": endpoint,
            "available": ollama_ok,
            "models": ollama_models,
            "current_models": current_ollama_models,
            "bedrock_fallback": ollama_cfg.get("bedrock_fallback", False),
        },
    })


@app.route("/api/settings/llm", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def save_llm_settings():
    """Switch LLM backend and model. Writes to config.yaml."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    new_backend = data.get("backend", "bedrock").strip()
    if new_backend not in ("bedrock", "ollama"):
        return jsonify({"error": "Invalid backend. Choose bedrock or ollama."}), 400

    config = load_config()
    config["llm_backend"] = new_backend

    # Update Bedrock settings
    bedrock_model = data.get("bedrock_model", "").strip()
    if bedrock_model:
        if "bedrock" not in config:
            config["bedrock"] = {}
        config["bedrock"]["model"] = bedrock_model

    bedrock_region = data.get("bedrock_region", "").strip()
    if bedrock_region:
        if "bedrock" not in config:
            config["bedrock"] = {}
        config["bedrock"]["region"] = bedrock_region

    # Save Bedrock API key (ABSK...)
    bedrock_api_key = data.get("bedrock_api_key", "").strip()
    if bedrock_api_key:
        _save_bedrock_api_key(bedrock_api_key)

    # Update Ollama per-agent models
    ollama_agent_models = data.get("ollama_agent_models")
    if isinstance(ollama_agent_models, dict):
        if "medical_agents" not in config:
            config["medical_agents"] = {}
        for agent_name in ("ingestion", "privacy", "summarizer", "auditor"):
            model_name = ollama_agent_models.get(agent_name, "").strip()
            if model_name:
                if agent_name not in config["medical_agents"]:
                    config["medical_agents"][agent_name] = {}
                config["medical_agents"][agent_name]["model"] = model_name

    ollama_chat = data.get("ollama_chat_model", "").strip()
    if ollama_chat:
        if "ollama" not in config:
            config["ollama"] = {}
        config["ollama"]["chat_model"] = ollama_chat

    bedrock_fallback = data.get("bedrock_fallback")
    if bedrock_fallback is not None:
        if "ollama" not in config:
            config["ollama"] = {}
        config["ollama"]["bedrock_fallback"] = bool(bedrock_fallback)

    # Write back to config.yaml
    config_path = BASE_DIR / "config.yaml"
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    except Exception as e:
        logger.error("Failed to save config.yaml: %s", e)
        return jsonify({"error": "Failed to save configuration"}), 500

    _audit_log("llm_backend_changed", None,
               f"LLM backend changed to {new_backend} by {session.get('username', 'api')}")
    logger.info("LLM backend changed to %s", new_backend)

    return jsonify({
        "success": True,
        "backend": new_backend,
        "message": f"LLM backend switched to {new_backend}. Pipeline will use this on next run.",
    })


# ── Self-Updater API ────────────────────────────────────────────────────────

@app.route("/api/admin/check-update")
@require_auth
def check_update():
    """Check if a new version of MedRecords AI is available."""
    from updater import Updater
    try:
        # Load version from VERSION file
        version_file = BASE_DIR / "VERSION"
        current_version = version_file.read_text().strip() if version_file.exists() else "unknown"
        
        upd = Updater(current_version)
        result = upd.check_for_updates()
        result["current_version"] = current_version
        return jsonify(result)
    except Exception as e:
        logger.error("Update check failed: %s", e)
        return jsonify({"update_available": False, "error": str(e)})


@app.route("/api/admin/apply-update", methods=["POST"])
@require_auth
def apply_update():
    """Download and prepare update for next restart."""
    data = request.get_json()
    download_url = data.get("download_url")
    if not download_url:
        return jsonify({"error": "download_url required"}), 400

    from updater import Updater
    version_file = BASE_DIR / "VERSION"
    current_version = version_file.read_text().strip() if version_file.exists() else "unknown"
    
    upd = Updater(current_version)
    success = upd.apply_update(download_url)
    
    if success:
        _audit_log("system_update_prepared", None, f"Update downloaded from {download_url}")
        return jsonify({"success": True, "message": "Update downloaded. Restart the application to apply."})
    else:
        return jsonify({"success": False, "error": "Update failed to download."}), 500


# ── File Management API ──────────────────────────────────────────────────────

VALID_CATEGORIES = {
    "uncategorized", "clinical_notes", "lab_results", "imaging",
    "discharge", "billing", "referral", "legal", "correspondence",
    "summary",
}


@app.route("/api/files")
@require_auth
@rate_limit(requests_per_minute=60)
def list_files():
    """List all tracked documents with filters and pagination."""
    page = max(1, request.args.get("page", 1, type=int))
    per_page = min(100, max(1, request.args.get("per_page", 25, type=int)))
    status_filter = request.args.get("status", "").strip()
    category_filter = request.args.get("category", "").strip()
    case_ref_filter = request.args.get("case_ref", "").strip()
    vault_zone_filter = request.args.get("vault_zone", "").strip()
    search_q = request.args.get("q", "").strip()[:200]
    run_id_filter = request.args.get("run_id", "").strip()[:200]

    conditions = []
    params = []

    if status_filter and status_filter in ("pending", "processing", "completed", "failed"):
        conditions.append("d.status = ?")
        params.append(status_filter)
    if category_filter and category_filter in VALID_CATEGORIES:
        conditions.append("d.category = ?")
        params.append(category_filter)
    if case_ref_filter:
        conditions.append("d.case_ref = ?")
        params.append(case_ref_filter)
    if vault_zone_filter and vault_zone_filter in ("incoming", "processing", "processed", "failed"):
        conditions.append("d.vault_zone = ?")
        params.append(vault_zone_filter)
    if run_id_filter:
        conditions.append("d.run_id = ?")
        params.append(run_id_filter)
    if search_q:
        conditions.append("(d.filename LIKE ? OR d.case_ref LIKE ? OR d.notes LIKE ?)")
        like = f"%{search_q}%"
        params.extend([like, like, like])

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    conn = get_db()
    try:
        total = conn.execute(
            f"SELECT COUNT(*) FROM documents d{where}", params
        ).fetchone()[0]

        offset = (page - 1) * per_page
        rows = conn.execute(
            f"""SELECT d.*, c.contact_name
                FROM documents d
                LEFT JOIN contacts c ON d.contact_id = c.id
                {where}
                ORDER BY d.created_at DESC
                LIMIT ? OFFSET ?""",
            params + [per_page, offset],
        ).fetchall()
    finally:
        conn.close()

    files = []
    for r in rows:
        files.append({
            "id": r["id"],
            "filename": r["filename"],
            "extension": r["extension"],
            "file_size": r["file_size"],
            "status": r["status"],
            "vault_zone": r["vault_zone"],
            "case_ref": r["case_ref"],
            "category": r["category"],
            "contact_name": r["contact_name"],
            "contact_id": r["contact_id"],
            "run_id": r["run_id"],
            "upload_source": r["upload_source"],
            "created_at": r["created_at"],
            "processed_at": r["processed_at"],
        })

    log_access(
        session.get("username", "api"), "list_files", "documents",
        ip_address=request.remote_addr, details=f"page={page}",
    )

    return jsonify({
        "files": files,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": max(1, -(-total // per_page)),
        },
    })


@app.route("/api/files/<int:doc_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_file_detail(doc_id):
    """Get full details for a specific document."""
    conn = get_db()
    try:
        row = conn.execute(
            """SELECT d.*, c.contact_name
               FROM documents d
               LEFT JOIN contacts c ON d.contact_id = c.id
               WHERE d.id = ?""",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    result = dict(row)
    # Check if file still exists on disk
    current = result.get("current_path") or result.get("original_path")
    result["file_exists"] = bool(current and Path(current).exists())
    # Check if summary exists
    if result.get("run_id"):
        summary_path = VAULT_SUMMARIES / f"{result['run_id']}_summary.json"
        result["has_summary"] = summary_path.exists()
    else:
        result["has_summary"] = False

    log_access(
        session.get("username", "api"), "view_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
    )

    return jsonify(result)


@app.route("/api/files/<int:doc_id>", methods=["PATCH"])
@require_auth
@rate_limit(requests_per_minute=30)
def update_file_metadata(doc_id):
    """Update document metadata (case_ref, category, notes)."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    conn = get_db()
    try:
        existing = conn.execute("SELECT id FROM documents WHERE id = ?", (doc_id,)).fetchone()
    finally:
        conn.close()

    if not existing:
        return jsonify({"error": "Document not found"}), 404

    updates = []
    params = []

    if "case_ref" in data:
        case_ref = (data["case_ref"] or "").strip()[:100]
        updates.append("case_ref = ?")
        params.append(case_ref if case_ref else None)
    if "category" in data:
        category = (data["category"] or "").strip()
        if category and category not in VALID_CATEGORIES:
            return jsonify({"error": f"Invalid category. Valid: {', '.join(sorted(VALID_CATEGORIES))}"}), 400
        updates.append("category = ?")
        params.append(category or "uncategorized")
    if "notes" in data:
        notes = (data["notes"] or "").strip()[:2000]
        updates.append("notes = ?")
        params.append(notes if notes else None)

    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    updates.append("updated_at = ?")
    params.append(datetime.now(timezone.utc).isoformat())
    params.append(doc_id)

    try:
        with transaction() as conn:
            conn.execute(
                f"UPDATE documents SET {', '.join(updates)} WHERE id = ?",
                params,
            )
    except Exception as e:
        logger.error("Document update error: %s", e)
        return jsonify({"error": "Failed to update document"}), 500

    _audit_log("document_updated", None, f"Document {doc_id} metadata updated")
    return jsonify({"success": True, "message": "Document updated."})


@app.route("/api/files/bulk-update", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=20)
def bulk_update_files():
    """Bulk-update case_ref for multiple documents."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    doc_ids = data.get("doc_ids")
    if not doc_ids or not isinstance(doc_ids, list):
        return jsonify({"error": "doc_ids must be a non-empty list"}), 400
    if len(doc_ids) > 500:
        return jsonify({"error": "Maximum 500 documents per request"}), 400
    if not all(isinstance(i, int) for i in doc_ids):
        return jsonify({"error": "doc_ids must be integers"}), 400

    case_ref = (data.get("case_ref") or "").strip()[:100]
    case_ref = case_ref if case_ref else None

    now = datetime.now(timezone.utc).isoformat()
    placeholders = ",".join("?" for _ in doc_ids)

    try:
        with transaction() as conn:
            cur = conn.execute(
                f"UPDATE documents SET case_ref = ?, updated_at = ? WHERE id IN ({placeholders})",
                [case_ref, now] + doc_ids,
            )
            updated = cur.rowcount
    except Exception as e:
        logger.error("Bulk update error: %s", e)
        return jsonify({"error": "Failed to update documents"}), 500

    _audit_log("bulk_update", None, f"Bulk case_ref update: {updated} docs -> {case_ref}")
    return jsonify({"success": True, "updated": updated})


@app.route("/api/files/bulk-delete", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def bulk_delete_files():
    """Bulk-delete multiple documents from disk and database."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    doc_ids = data.get("doc_ids")
    if not doc_ids or not isinstance(doc_ids, list):
        return jsonify({"error": "doc_ids must be a non-empty list"}), 400
    if len(doc_ids) > 500:
        return jsonify({"error": "Maximum 500 documents per request"}), 400
    if not all(isinstance(i, int) for i in doc_ids):
        return jsonify({"error": "doc_ids must be integers"}), 400

    placeholders = ",".join("?" for _ in doc_ids)
    vault_root = (BASE_DIR / "vault").resolve()

    conn = get_db()
    try:
        rows = conn.execute(
            f"SELECT id, filename, current_path, original_path, file_hash FROM documents WHERE id IN ({placeholders})",
            doc_ids,
        ).fetchall()
    finally:
        conn.close()

    disk_deleted = 0
    for row in rows:
        file_path = row["current_path"] or row["original_path"]
        if file_path:
            resolved = Path(file_path).resolve()
            if str(resolved).startswith(str(vault_root)) and resolved.exists() and resolved.is_file():
                try:
                    resolved.unlink()
                    disk_deleted += 1
                except Exception as e:
                    logger.error("Bulk delete file error %s: %s", resolved, e)

    try:
        with transaction() as txn:
            txn.execute(
                f"DELETE FROM documents WHERE id IN ({placeholders})", doc_ids
            )
            db_deleted = txn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk delete DB error: %s", e)
        return jsonify({"error": "Failed to delete from database"}), 500

    _audit_log("bulk_delete", None, f"Bulk delete: {db_deleted} docs removed, {disk_deleted} files from disk")
    log_access(
        session.get("username", "api"), "bulk_delete", "document",
        ip_address=request.remote_addr,
        details=f"deleted={db_deleted}, disk={disk_deleted}",
    )

    return jsonify({"success": True, "deleted": db_deleted, "deleted_from_disk": disk_deleted})


@app.route("/api/cases")
@require_auth
@rate_limit(requests_per_minute=60)
def list_cases():
    """List distinct case references with file counts."""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT case_ref, COUNT(*) as file_count "
            "FROM documents WHERE case_ref IS NOT NULL AND case_ref != '' "
            "GROUP BY case_ref ORDER BY case_ref"
        ).fetchall()
    finally:
        conn.close()

    cases = [{"name": r["case_ref"], "file_count": r["file_count"]} for r in rows]
    return jsonify({"cases": cases})


@app.route("/api/files/suggest-case", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def suggest_case():
    """Suggest a case_ref for a file based on its filename."""
    data = request.get_json()
    if not data or not data.get("filename"):
        return jsonify({"error": "filename required"}), 400

    try:
        from case_detector import suggest_case_ref as _suggest
        conn = get_db()
        try:
            rows = conn.execute(
                "SELECT DISTINCT case_ref FROM documents WHERE case_ref IS NOT NULL AND case_ref != ''"
            ).fetchall()
        finally:
            conn.close()
        existing = [r["case_ref"] for r in rows]
        result = _suggest(data["filename"], existing)
        return jsonify(result or {"suggestion": None})
    except Exception as e:
        logger.error("Case suggestion error: %s", e)
        return jsonify({"suggestion": None})


@app.route("/api/files/<int:doc_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def delete_file(doc_id):
    """Delete a document from disk and database."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, file_hash FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    file_path = row["current_path"] or row["original_path"]
    deleted_from_disk = False

    if file_path:
        resolved = Path(file_path).resolve()
        vault_root = (BASE_DIR / "vault").resolve()
        if not str(resolved).startswith(str(vault_root)):
            return jsonify({"error": "Path traversal denied"}), 403

        if resolved.exists() and resolved.is_file():
            try:
                resolved.unlink()
                deleted_from_disk = True
            except Exception as e:
                logger.error("Failed to delete file %s: %s", resolved, e)

    try:
        with transaction() as conn:
            conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    except Exception as e:
        logger.error("Document delete DB error: %s", e)
        return jsonify({"error": "Failed to delete from database"}), 500

    _audit_log("document_deleted", None,
               f"Document {doc_id} deleted: {row['filename']} (hash={row['file_hash'][:12] if row['file_hash'] else 'N/A'})")
    log_access(
        session.get("username", "api"), "delete_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    return jsonify({
        "success": True,
        "deleted_from_disk": deleted_from_disk,
        "message": "Document deleted.",
    })


@app.route("/api/files/<int:doc_id>/reprocess", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def reprocess_file(doc_id):
    """Re-trigger the summarization pipeline for a document."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, status FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    # Find the file on disk
    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = p
            break

    if not file_path:
        return jsonify({"error": "Source file not found on disk"}), 404

    # Path traversal check
    resolved = Path(file_path).resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        return jsonify({"error": "Path traversal denied"}), 403
    if resolved.is_symlink():
        return jsonify({"error": "Symbolic links not allowed"}), 400

    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Max concurrent pipelines reached. Try again later."}), 429

    run_id = f"reprocess_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"

    # Update document status
    try:
        with transaction() as conn:
            conn.execute(
                "UPDATE documents SET status = 'processing', run_id = ?, updated_at = ? WHERE id = ?",
                (run_id, datetime.now(timezone.utc).isoformat(), doc_id),
            )
    except Exception as e:
        logger.error("Failed to update document for reprocessing: %s", e)
        _active_pipelines.release()
        return jsonify({"error": "Failed to update document status"}), 500

    t = threading.Thread(
        target=_run_pipeline_background,
        args=(str(resolved), run_id),
        daemon=True,
    )
    t.start()

    _audit_log("document_reprocessed", None, f"Document {doc_id} reprocessed as {run_id}")

    return jsonify({
        "success": True,
        "run_id": run_id,
        "message": "Pipeline restarted. Poll /api/pipeline/<run_id> for status.",
    })


@app.route("/api/files/<int:doc_id>/download")
@require_auth
@rate_limit(requests_per_minute=30)
def download_file(doc_id):
    """Download a document file."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        abort(404)

    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = Path(p)
            break

    if not file_path:
        abort(404)

    # Path traversal check
    resolved = file_path.resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        abort(403)

    log_access(
        session.get("username", "api"), "download_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    if Vault.is_encrypted(resolved):
        decrypted_bytes = Vault.decrypt_file(resolved)
        return send_file(
            io.BytesIO(decrypted_bytes),
            as_attachment=True,
            download_name=row["filename"]
        )

    return send_file(str(resolved), as_attachment=True, download_name=row["filename"])


@app.route("/api/files/<int:doc_id>/view")
@require_auth
@rate_limit(requests_per_minute=30)
def view_file(doc_id):
    """Serve a document file inline for in-browser viewing (PDF viewer, etc.). Decrypts if needed."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, extension FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        abort(404)

    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = Path(p)
            break

    if not file_path:
        abort(404)

    # Path traversal check
    resolved = file_path.resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        abort(403)

    ext = (row["extension"] or file_path.suffix).lower()
    # Determine MIME type for inline display
    mime_types = {
        ".pdf": "application/pdf",
        ".html": "text/html",
        ".htm": "text/html",
        ".txt": "text/plain",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".tiff": "image/tiff",
        ".tif": "image/tiff",
    }
    mimetype = mime_types.get(ext, "application/octet-stream")

    log_access(
        session.get("username", "api"), "view_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    if Vault.is_encrypted(resolved):
        decrypted_bytes = Vault.decrypt_file(resolved)
        response = make_response(send_file(io.BytesIO(decrypted_bytes), mimetype=mimetype))
    else:
        response = make_response(send_file(str(resolved), mimetype=mimetype))
        
    response.headers["Content-Disposition"] = f"inline; filename=\"{row['filename']}\""
    return response


@app.route("/api/files/sync", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=2)
def sync_files():
    """Scan vault directories and register any untracked files into the documents table."""
    vault_root = BASE_DIR / "vault"
    zones = {
        "incoming": vault_root / "incoming",
        "processed": vault_root / "processed",
        "failed": vault_root / "processing" / "failed",
    }

    registered = 0
    conn = get_db()
    try:
        existing_paths = {
            r[0] for r in conn.execute("SELECT original_path FROM documents").fetchall()
        }
    finally:
        conn.close()

    supported = {".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif",
                 ".dcm", ".dicom", ".doc", ".docx", ".txt"}

    for zone_name, zone_dir in zones.items():
        if not zone_dir.exists():
            continue
        for p in zone_dir.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in supported:
                continue
            if str(p) in existing_paths:
                continue

            status = "pending" if zone_name == "incoming" else (
                "completed" if zone_name == "processed" else "failed"
            )

            try:
                file_hash = hashlib.sha256(p.read_bytes()).hexdigest()
                with transaction() as conn:
                    conn.execute(
                        """INSERT INTO documents
                           (filename, original_path, current_path, file_hash, file_size,
                            extension, vault_zone, status, uploaded_by, upload_source)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'system', 'api')""",
                        (p.name, str(p), str(p), file_hash,
                         p.stat().st_size, p.suffix.lower(),
                         zone_name, status),
                    )
                registered += 1
            except Exception as e:
                logger.error("Failed to register file %s: %s", p, e)

    _audit_log("files_synced", None, f"File sync: {registered} new files registered")

    return jsonify({
        "success": True,
        "registered": registered,
        "message": f"Synced {registered} new file(s) into the documents table.",
    })


# ── Audit Helper ─────────────────────────────────────────────────────────────

def _audit_log(action, contact_id, details):
    """Write an HMAC-signed audit entry to vault/audit/."""
    VAULT_AUDIT.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc)
    entry = {
        "timestamp": timestamp.isoformat(),
        "action": action,
        "source": "medical_app",
        "contact_id": contact_id,
        "details": details,
        "user": session.get("username", "system") if session else "system",
        "ip_address": request.remote_addr if request else None,
    }
    # HMAC sign for immutability verification
    entry["hmac_signature"] = sign_audit_entry(entry)

    filename = f"{timestamp.strftime('%Y%m%d-%H%M%S')}_{action}_{uuid.uuid4().hex[:6]}.json"
    try:
        with open(VAULT_AUDIT / filename, "w", encoding="utf-8") as f:
            json.dump(entry, f, indent=2)
    except Exception as e:
        logger.error("Failed to write audit log: %s", e)


# ── Deposition Summary API ────────────────────────────────────────────────────

@app.route("/api/deposition/upload", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def upload_deposition():
    """Upload and analyze a deposition transcript."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    ext = Path(file.filename).suffix.lower()
    if ext not in {".pdf", ".txt", ".doc", ".docx"}:
        return jsonify({"error": "Deposition transcripts must be PDF, TXT, DOC, or DOCX"}), 400

    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({"error": "Invalid filename"}), 400

    # Save to vault/depositions/
    depo_dir = BASE_DIR / "vault" / "depositions"
    depo_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_id = f"depo_{timestamp}"
    save_path = depo_dir / f"{run_id}_{filename}"
    file.save(str(save_path))

    # Extract text from the file
    transcript_text = ""
    try:
        if ext == ".txt":
            transcript_text = save_path.read_text(encoding="utf-8", errors="replace")
        elif ext == ".pdf":
            try:
                import fitz
                doc = fitz.open(str(save_path))
                for page in doc:
                    transcript_text += f"\nPAGE {page.number + 1}\n"
                    transcript_text += page.get_text()
                doc.close()
            except ImportError:
                return jsonify({"error": "PDF support requires PyMuPDF. Install with: pip install pymupdf"}), 500
        elif ext in (".doc", ".docx"):
            try:
                from docx import Document as DocxDoc
                doc = DocxDoc(str(save_path))
                transcript_text = "\n".join(p.text for p in doc.paragraphs)
            except ImportError:
                return jsonify({"error": "DOCX support requires python-docx. Install with: pip install python-docx"}), 500
    except Exception as e:
        return jsonify({"error": f"Failed to extract text: {str(e)}"}), 500

    if not transcript_text.strip():
        return jsonify({"error": "No text could be extracted from the file"}), 400

    # Options from form data
    options = {
        "deponent_name": request.form.get("deponent_name", "").strip(),
        "deponent_role": request.form.get("deponent_role", "witness"),
        "case_ref": request.form.get("case_ref", "").strip(),
    }
    focus = request.form.get("focus_areas", "").strip()
    if focus:
        options["focus_areas"] = [a.strip() for a in focus.split(",") if a.strip()]

    # Run analysis
    try:
        config_path = BASE_DIR / "config.yaml"
        config = {}
        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

        from deposition_summarizer import summarize_deposition, save_deposition_summary
        result = summarize_deposition(transcript_text, config, options)
        save_deposition_summary(run_id, result)

        log_access(
            session.get("username", "api"), "deposition_analysis", "deposition",
            resource_id=run_id, ip_address=request.remote_addr,
            details=f"file={filename}, deponent={options.get('deponent_name', 'Unknown')}",
        )

        return jsonify({
            "ok": True,
            "run_id": run_id,
            "result": result,
        })

    except Exception as e:
        logger.exception("Deposition analysis failed")
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500


@app.route("/api/deposition/list")
@require_auth
def list_depositions():
    """List all analyzed depositions."""
    from deposition_summarizer import list_deposition_summaries
    return jsonify({"depositions": list_deposition_summaries()})


@app.route("/api/deposition/<run_id>")
@require_auth
def get_deposition(run_id):
    """Get a specific deposition analysis."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    depo_file = BASE_DIR / "vault" / "depositions" / f"{safe_id}_deposition.json"
    if not depo_file.exists():
        abort(404)

    data = safe_load_json(depo_file)
    if not data:
        abort(404)
    return jsonify(data)


# ── Case Management Integrations API ─────────────────────────────────────────

@app.route("/api/integrations/list")
@require_auth
def list_integration_platforms():
    """List all supported integration platforms and their status."""
    from integrations import list_integrations
    return jsonify({"platforms": list_integrations()})


@app.route("/api/integrations/configure", methods=["POST"])
@require_auth
def configure_integration_endpoint():
    """Configure an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    settings = data.get("settings", {})

    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    try:
        from integrations import configure_integration
        result = configure_integration(platform_id, settings)
        log_access(
            session.get("username", "api"), "configure_integration", "integration",
            resource_id=platform_id, ip_address=request.remote_addr,
        )
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.exception("Integration configuration failed")
        return jsonify({"error": str(e)}), 500


@app.route("/api/integrations/disable", methods=["POST"])
@require_auth
def disable_integration_endpoint():
    """Disable an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    from integrations import disable_integration
    return jsonify(disable_integration(platform_id))


@app.route("/api/integrations/test", methods=["POST"])
@require_auth
def test_integration_endpoint():
    """Test connectivity to an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    from integrations import test_connection
    return jsonify(test_connection(platform_id))


@app.route("/api/integrations/push", methods=["POST"])
@require_auth
def push_to_integration_endpoint():
    """Push data to an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    run_id = data.get("run_id", "").strip()
    data_type = data.get("data_type", "summary")
    case_ref = data.get("case_ref", "").strip() or None

    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load the data based on type
    push_data = None
    if data_type == "summary":
        summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
        if not summary_file.exists():
            summary_file = VAULT_SUMMARIES / f"{safe_id}.json"
        if summary_file.exists():
            with open(summary_file, encoding="utf-8") as f:
                push_data = json.load(f)

    elif data_type == "deposition":
        depo_file = BASE_DIR / "vault" / "depositions" / f"{safe_id}_deposition.json"
        if depo_file.exists():
            with open(depo_file, encoding="utf-8") as f:
                push_data = json.load(f)

    elif data_type == "demand_package":
        demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
        narrative_file = demand_dir / "narrative.json"
        if narrative_file.exists():
            with open(narrative_file, encoding="utf-8") as f:
                push_data = json.load(f)

    if push_data is None:
        return jsonify({"error": f"No {data_type} data found for run_id: {run_id}"}), 404

    try:
        from integrations import push_to_integration
        result = push_to_integration(platform_id, push_data, data_type, case_ref)
        log_access(
            session.get("username", "api"), "push_integration", "integration",
            resource_id=f"{platform_id}:{safe_id}", ip_address=request.remote_addr,
            details=f"type={data_type}",
        )
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.exception("Integration push failed")
        return jsonify({"error": f"Push failed: {str(e)}"}), 500


@app.route("/api/integrations/history")
@require_auth
def integration_history():
    """Get integration push history."""
    from integrations import get_push_history
    limit = request.args.get("limit", 50, type=int)
    return jsonify({"history": get_push_history(limit)})


# ── Sales CRM API ────────────────────────────────────────────────────────────

VALID_LEAD_SOURCES = {"website", "referral", "demo_download", "cold_outreach", "trade_show", "stripe", "manual", "google_sheets"}
VALID_LEAD_STAGES = {"prospect", "demo_requested", "demo_active", "trial", "negotiation", "closed_won", "closed_lost"}
VALID_PROSPECT_TIERS = {"core", "pro"}
TIER_LICENSE_PRICES = {"core": 399700, "pro": 799700}   # cents (Stripe convention)
TIER_SUPPORT_PRICES = {"core": 100000, "pro": 240000}   # cents/yr

# Stage-weighted conversion probabilities (VP Sales industry-standard B2B SaaS)
STAGE_CONVERSION_PROBABILITY = {
    "prospect": 0.05,
    "demo_requested": 0.15,
    "demo_active": 0.30,
    "trial": 0.50,
    "negotiation": 0.75,
    "closed_won": 1.0,
    "closed_lost": 0.0,
}
LEAD_FIELD_LENGTHS = {
    "contact_name": 200, "contact_email": 254, "company": 300, "phone": 50,
    "notes": 2000, "lost_reason": 500, "assigned_to": 100, "state": 2, "url": 500,
}


def _validate_lead_input(data, require_name_email=True):
    """Validate lead creation/update input. Returns list of error strings."""
    errors = []
    if not data:
        return ["Request body is required"]
    if require_name_email:
        if not data.get("contact_name", "").strip():
            errors.append("contact_name is required")
        if not data.get("contact_email", "").strip():
            errors.append("contact_email is required")
        elif not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", data["contact_email"].strip()):
            errors.append("contact_email is not a valid email address")
    for field, max_len in LEAD_FIELD_LENGTHS.items():
        value = data.get(field, "")
        if isinstance(value, str) and len(value) > max_len:
            errors.append(f"{field} exceeds maximum length of {max_len} characters")
    if data.get("lead_source") and data["lead_source"] not in VALID_LEAD_SOURCES:
        errors.append(f"lead_source must be one of: {', '.join(sorted(VALID_LEAD_SOURCES))}")
    if data.get("stage") and data["stage"] not in VALID_LEAD_STAGES:
        errors.append(f"stage must be one of: {', '.join(sorted(VALID_LEAD_STAGES))}")
    return errors


@app.route("/api/crm/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def crm_stats():
    """Dashboard summary stats for the Sales CRM."""
    conn = get_db()
    try:
        # Counts by stage
        rows = conn.execute("SELECT stage, COUNT(*) as cnt FROM leads GROUP BY stage").fetchall()
        by_stage = {r["stage"]: r["cnt"] for r in rows}
        total_leads = sum(by_stage.values())

        # Active demos with days remaining
        demo_rows = conn.execute(
            "SELECT id, contact_name, company, demo_expires FROM leads WHERE stage = 'demo_active' AND demo_expires IS NOT NULL"
        ).fetchall()
        active_demos = []
        for d in demo_rows:
            try:
                expires = datetime.fromisoformat(d["demo_expires"])
                days_rem = max(0, (expires - datetime.now(timezone.utc)).days)
            except (ValueError, TypeError):
                days_rem = 0
            active_demos.append({
                "id": d["id"], "contact_name": d["contact_name"],
                "company": d["company"], "days_remaining": days_rem, "demo_expires": d["demo_expires"],
            })

        # Conversion rate
        won = by_stage.get("closed_won", 0)
        lost = by_stage.get("closed_lost", 0)
        conversion_rate = round(won / (won + lost) * 100, 1) if (won + lost) > 0 else 0

        # Closed revenue (actual amount_paid)
        rev_row = conn.execute("SELECT COALESCE(SUM(amount_paid), 0) as total FROM leads WHERE stage = 'closed_won'").fetchone()
        total_revenue = rev_row["total"]

        # Pipeline: include ALL open leads; use Core tier as default for unpriced leads
        default_deal_value = TIER_LICENSE_PRICES["core"]  # $3,997 in cents
        pipeline_rows = conn.execute("""
            SELECT stage, prospect_tier, license_quantity, wants_support
            FROM leads
            WHERE stage NOT IN ('closed_won', 'closed_lost')
        """).fetchall()

        pipeline_fy = 0
        pipeline_arr = 0
        weighted_pipeline = 0
        stage_pipeline = {}

        for r in pipeline_rows:
            s = r["stage"]
            tier = r["prospect_tier"]
            qty = r["license_quantity"] or 1
            deal_val = TIER_LICENSE_PRICES.get(tier, default_deal_value) * qty
            prob = STAGE_CONVERSION_PROBABILITY.get(s, 0)

            pipeline_fy += deal_val
            weighted_pipeline += int(deal_val * prob)
            if r["wants_support"]:
                pipeline_arr += TIER_SUPPORT_PRICES.get(tier, TIER_SUPPORT_PRICES["core"]) * qty

            if s not in stage_pipeline:
                stage_pipeline[s] = {"count": 0, "raw_value": 0, "weighted_value": 0, "probability": prob}
            stage_pipeline[s]["count"] += 1
            stage_pipeline[s]["raw_value"] += deal_val
            stage_pipeline[s]["weighted_value"] += int(deal_val * prob)

        # Converted Revenue YTD (closed_won with amount_paid in current year)
        current_year = datetime.now(timezone.utc).year
        ytd_row = conn.execute(
            "SELECT COALESCE(SUM(amount_paid), 0) as total FROM leads WHERE stage = 'closed_won' AND stage_changed_at >= ?",
            (f"{current_year}-01-01",),
        ).fetchone()
        converted_rev_ytd = ytd_row["total"]

        # Active licenses
        lic_row = conn.execute("SELECT COUNT(*) as cnt FROM leads WHERE license_key IS NOT NULL AND stage = 'closed_won'").fetchone()
        active_licenses = lic_row["cnt"]

        # Follow-ups due
        fu_row = conn.execute(
            "SELECT COUNT(*) as cnt FROM leads WHERE follow_up_date <= date('now') AND stage NOT IN ('closed_won', 'closed_lost')"
        ).fetchone()
        follow_ups_due = fu_row["cnt"]
    finally:
        conn.close()

    return jsonify({
        "total_leads": total_leads,
        "by_stage": by_stage,
        "active_demos": active_demos,
        "conversion_rate": conversion_rate,
        "pipeline_fy": pipeline_fy,
        "pipeline_arr": pipeline_arr,
        "weighted_pipeline": weighted_pipeline,
        "stage_pipeline": stage_pipeline,
        "total_revenue": total_revenue,
        "converted_rev_ytd": converted_rev_ytd,
        "active_licenses": active_licenses,
        "follow_ups_due": follow_ups_due,
        "stage_probabilities": STAGE_CONVERSION_PROBABILITY,
    })


@app.route("/api/crm/leads", methods=["GET"])
@require_auth
@rate_limit(requests_per_minute=60)
def crm_list_leads():
    """List leads with pagination, filtering, and search."""
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 200)
    stage = request.args.get("stage", "").strip()
    source = request.args.get("source", "").strip()
    q = request.args.get("q", "").strip()
    sort = request.args.get("sort", "created_at").strip()
    order = request.args.get("order", "desc").strip().lower()

    allowed_sorts = {"created_at", "updated_at", "contact_name", "company", "stage", "follow_up_date", "amount_paid", "stage_changed_at", "state"}
    if sort not in allowed_sorts:
        sort = "created_at"
    if order not in ("asc", "desc"):
        order = "desc"

    where = []
    params = []
    if stage and stage in VALID_LEAD_STAGES:
        where.append("stage = ?")
        params.append(stage)
    if source and source in VALID_LEAD_SOURCES:
        where.append("lead_source = ?")
        params.append(source)
    if q:
        where.append("(contact_name LIKE ? OR contact_email LIKE ? OR company LIKE ? OR state LIKE ?)")
        like = f"%{q}%"
        params.extend([like, like, like, like])

    where_clause = f"WHERE {' AND '.join(where)}" if where else ""

    conn = get_db()
    try:
        total = conn.execute(f"SELECT COUNT(*) as cnt FROM leads {where_clause}", params).fetchone()["cnt"]
        offset = (page - 1) * per_page
        rows = conn.execute(
            f"""SELECT *, CAST(julianday('now') - julianday(stage_changed_at) AS INTEGER) as days_in_stage
                FROM leads {where_clause} ORDER BY {sort} {order} LIMIT ? OFFSET ?""",
            params + [per_page, offset],
        ).fetchall()
    finally:
        conn.close()

    log_access(
        session.get("username", "api"), "list", "leads",
        ip_address=request.remote_addr,
        details=f"page={page} per_page={per_page} total={total}",
    )

    return jsonify({
        "leads": [dict(r) for r in rows],
        "pagination": {
            "page": page, "per_page": per_page, "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


@app.route("/api/crm/leads", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def crm_create_lead():
    """Create a new lead."""
    data = request.get_json(silent=True)
    errors = _validate_lead_input(data)
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 400

    name = sanitize_string(data["contact_name"], 200)
    email = data["contact_email"].strip().lower()
    company = sanitize_string(data.get("company", ""), 300)
    phone = sanitize_string(data.get("phone", ""), 50)
    lead_source = data.get("lead_source", "manual")
    stage = data.get("stage", "prospect")
    notes = sanitize_string(data.get("notes", ""), 2000)
    follow_up_date = data.get("follow_up_date", "")
    assigned_to = sanitize_string(data.get("assigned_to", ""), 100)
    prospect_tier = data.get("prospect_tier") or None
    if prospect_tier and prospect_tier not in VALID_PROSPECT_TIERS:
        prospect_tier = None
    license_quantity = max(1, int(data.get("license_quantity", 1) or 1))
    wants_support = 1 if data.get("wants_support") else 0
    state = sanitize_string(data.get("state", ""), 2).upper()
    url = sanitize_string(data.get("url", ""), 500)
    now = datetime.now(timezone.utc).isoformat()

    # Auto-link to existing contact by email
    contact_id = None
    conn = get_db()
    try:
        match = conn.execute("SELECT id FROM contacts WHERE contact_email = ? LIMIT 1", (email,)).fetchone()
        if match:
            contact_id = match["id"]
    finally:
        conn.close()

    try:
        with transaction() as conn:
            cursor = conn.execute(
                """INSERT INTO leads
                   (contact_name, contact_email, company, phone, lead_source, stage,
                    state, url, notes, follow_up_date, assigned_to, contact_id,
                    prospect_tier, license_quantity, wants_support,
                    stage_changed_at, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (name, email, company, phone, lead_source, stage,
                 state or None, url or None, notes, follow_up_date or None, assigned_to or None, contact_id,
                 prospect_tier, license_quantity, wants_support,
                 now, now, now),
            )
            lead_id = cursor.lastrowid
            conn.execute(
                "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, changed_at) VALUES (?, NULL, ?, ?, ?)",
                (lead_id, stage, session.get("username", "api"), now),
            )
    except Exception as e:
        logger.error("Failed to create lead: %s", e)
        return jsonify({"error": "Failed to create lead"}), 500

    log_access(
        session.get("username", "api"), "create", "lead", str(lead_id),
        ip_address=request.remote_addr, details=f"email={email}",
    )

    # Return the created lead
    conn = get_db()
    try:
        lead = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    finally:
        conn.close()

    return jsonify(dict(lead)), 201


@app.route("/api/crm/leads/<int:lead_id>", methods=["GET"])
@require_auth
@rate_limit(requests_per_minute=60)
def crm_get_lead(lead_id):
    """Get a single lead with stage history."""
    conn = get_db()
    try:
        lead = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
        if not lead:
            return jsonify({"error": "Lead not found"}), 404
        history = conn.execute(
            "SELECT * FROM lead_stage_history WHERE lead_id = ? ORDER BY changed_at DESC", (lead_id,)
        ).fetchall()
    finally:
        conn.close()

    result = dict(lead)
    result["stage_history"] = [dict(h) for h in history]
    # Computed pipeline estimates
    tier = result.get("prospect_tier")
    qty = result.get("license_quantity") or 1
    result["fy_estimate"] = TIER_LICENSE_PRICES.get(tier, 0) * qty
    result["arr_estimate"] = TIER_SUPPORT_PRICES.get(tier, 0) * qty if result.get("wants_support") else 0

    # Email history from campaigns
    conn2 = get_db()
    try:
        emails = conn2.execute("""
            SELECT cm.subject, cm.status, cm.sent_at, cm.error_message, cm.created_at,
                   c.name as campaign_name, c.campaign_type,
                   sp.name as smtp_profile_name, sp.from_email
            FROM campaign_messages cm
            JOIN campaigns c ON cm.campaign_id = c.id
            LEFT JOIN smtp_profiles sp ON c.smtp_profile_id = sp.id
            WHERE cm.lead_id = ?
            ORDER BY cm.created_at DESC
        """, (lead_id,)).fetchall()
        result["email_history"] = [dict(e) for e in emails]
    except Exception:
        result["email_history"] = []
    finally:
        conn2.close()

    log_access(
        session.get("username", "api"), "view", "lead", str(lead_id),
        ip_address=request.remote_addr,
    )
    return jsonify(result)


@app.route("/api/crm/leads/<int:lead_id>", methods=["PUT"])
@require_auth
@rate_limit(requests_per_minute=30)
def crm_update_lead(lead_id):
    """Update a lead. Partial updates supported."""
    data = request.get_json(silent=True)
    errors = _validate_lead_input(data, require_name_email=False)
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 400

    conn = get_db()
    try:
        existing = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    finally:
        conn.close()
    if not existing:
        return jsonify({"error": "Lead not found"}), 404

    updatable = [
        "contact_name", "contact_email", "company", "phone", "lead_source", "stage",
        "demo_sent_date", "demo_expires", "demo_cases_used", "license_key", "license_tier",
        "activated_at", "amount_paid", "currency", "stripe_session_id",
        "state", "url", "notes", "follow_up_date", "assigned_to", "lost_reason",
        "prospect_tier", "license_quantity", "wants_support",
    ]
    sets = []
    params = []
    for field in updatable:
        if field in data:
            val = data[field]
            if field == "prospect_tier":
                val = val if val in VALID_PROSPECT_TIERS else None
            elif field == "license_quantity":
                val = max(1, int(val or 1))
            elif field == "wants_support":
                val = 1 if val else 0
            elif isinstance(val, str) and field in LEAD_FIELD_LENGTHS:
                val = sanitize_string(val, LEAD_FIELD_LENGTHS[field])
            sets.append(f"{field} = ?")
            params.append(val)

    if not sets:
        return jsonify({"error": "No fields to update"}), 400

    now = datetime.now(timezone.utc).isoformat()
    sets.append("updated_at = ?")
    params.append(now)

    # Track stage change
    stage_changed = "stage" in data and data["stage"] != existing["stage"]
    if stage_changed:
        sets.append("stage_changed_at = ?")
        params.append(now)

    params.append(lead_id)

    try:
        with transaction() as conn:
            conn.execute(f"UPDATE leads SET {', '.join(sets)} WHERE id = ?", params)
            if stage_changed:
                conn.execute(
                    "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, notes, changed_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (lead_id, existing["stage"], data["stage"], session.get("username", "api"),
                     data.get("stage_note", ""), now),
                )
    except Exception as e:
        logger.error("Failed to update lead %d: %s", lead_id, e)
        return jsonify({"error": "Failed to update lead"}), 500

    log_access(
        session.get("username", "api"), "update", "lead", str(lead_id),
        ip_address=request.remote_addr,
        details=f"fields={','.join(f for f in updatable if f in data)}",
    )

    conn = get_db()
    try:
        lead = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    finally:
        conn.close()
    return jsonify(dict(lead))


@app.route("/api/crm/leads/<int:lead_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10)
def crm_delete_lead(lead_id):
    """Delete a lead and its stage history."""
    conn = get_db()
    try:
        existing = conn.execute("SELECT id FROM leads WHERE id = ?", (lead_id,)).fetchone()
    finally:
        conn.close()
    if not existing:
        return jsonify({"error": "Lead not found"}), 404

    try:
        with transaction() as conn:
            conn.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    except Exception as e:
        logger.error("Failed to delete lead %d: %s", lead_id, e)
        return jsonify({"error": "Failed to delete lead"}), 500

    log_access(
        session.get("username", "api"), "delete", "lead", str(lead_id),
        ip_address=request.remote_addr,
    )
    return jsonify({"message": "Lead deleted", "id": lead_id})


@app.route("/api/crm/leads/bulk-delete", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def crm_bulk_delete_leads():
    """Bulk-delete multiple leads."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    lead_ids = data.get("lead_ids")
    if not lead_ids or not isinstance(lead_ids, list):
        return jsonify({"error": "lead_ids must be a non-empty list"}), 400
    if len(lead_ids) > 500:
        return jsonify({"error": "Maximum 500 leads per request"}), 400
    if not all(isinstance(i, int) for i in lead_ids):
        return jsonify({"error": "lead_ids must be integers"}), 400

    placeholders = ",".join("?" for _ in lead_ids)
    try:
        with transaction() as txn:
            txn.execute(f"DELETE FROM leads WHERE id IN ({placeholders})", lead_ids)
            deleted = txn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk delete leads error: %s", e)
        return jsonify({"error": "Failed to delete leads"}), 500

    log_access(
        session.get("username", "api"), "bulk_delete", "lead",
        ip_address=request.remote_addr,
        details=f"deleted={deleted}",
    )
    return jsonify({"success": True, "deleted": deleted})


@app.route("/api/crm/leads/bulk-update-stage", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def crm_bulk_update_stage():
    """Bulk-update stage for multiple leads with stage history tracking."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    lead_ids = data.get("lead_ids")
    new_stage = data.get("stage")
    if not lead_ids or not isinstance(lead_ids, list):
        return jsonify({"error": "lead_ids must be a non-empty list"}), 400
    if len(lead_ids) > 500:
        return jsonify({"error": "Maximum 500 leads per request"}), 400
    if not all(isinstance(i, int) for i in lead_ids):
        return jsonify({"error": "lead_ids must be integers"}), 400
    valid_stages = {"prospect", "demo_requested", "demo_active", "trial", "negotiation", "closed_won", "closed_lost"}
    if new_stage not in valid_stages:
        return jsonify({"error": f"Invalid stage. Must be one of: {', '.join(sorted(valid_stages))}"}), 400

    now = datetime.now(timezone.utc).isoformat()
    username = session.get("username", "api")
    updated = 0

    try:
        placeholders = ",".join("?" for _ in lead_ids)
        with transaction() as conn:
            rows = conn.execute(
                f"SELECT id, stage FROM leads WHERE id IN ({placeholders})", lead_ids
            ).fetchall()
            for row in rows:
                if row["stage"] == new_stage:
                    continue
                conn.execute(
                    "UPDATE leads SET stage = ?, stage_changed_at = ?, updated_at = ? WHERE id = ?",
                    (new_stage, now, now, row["id"]),
                )
                conn.execute(
                    "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, notes, changed_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (row["id"], row["stage"], new_stage, username, "Bulk status update", now),
                )
                updated += 1
    except Exception as e:
        logger.error("Bulk update stage error: %s", e)
        return jsonify({"error": "Failed to update leads"}), 500

    log_access(
        username, "bulk_update_stage", "lead",
        ip_address=request.remote_addr,
        details=f"updated={updated}, stage={new_stage}",
    )
    return jsonify({"success": True, "updated": updated, "stage": new_stage})


@app.route("/api/crm/leads/bulk-update-tier", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def crm_bulk_update_tier():
    """Bulk-update prospect_tier for multiple leads."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    lead_ids = data.get("lead_ids")
    prospect_tier = data.get("prospect_tier")  # None to clear, "core" or "pro"
    if not lead_ids or not isinstance(lead_ids, list):
        return jsonify({"error": "lead_ids must be a non-empty list"}), 400
    if len(lead_ids) > 500:
        return jsonify({"error": "Maximum 500 leads per request"}), 400
    if not all(isinstance(i, int) for i in lead_ids):
        return jsonify({"error": "lead_ids must be integers"}), 400
    if prospect_tier is not None and prospect_tier not in VALID_PROSPECT_TIERS:
        return jsonify({"error": f"Invalid tier. Must be one of: {', '.join(VALID_PROSPECT_TIERS)}"}), 400

    now = datetime.now(timezone.utc).isoformat()
    placeholders = ",".join("?" for _ in lead_ids)
    try:
        with transaction() as conn:
            conn.execute(
                f"UPDATE leads SET prospect_tier = ?, updated_at = ? WHERE id IN ({placeholders})",
                [prospect_tier, now] + lead_ids,
            )
            updated = conn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk update tier error: %s", e)
        return jsonify({"error": "Failed to update leads"}), 500

    log_access(
        session.get("username", "api"), "bulk_update_tier", "lead",
        ip_address=request.remote_addr,
        details=f"updated={updated}, tier={prospect_tier}",
    )
    return jsonify({"success": True, "updated": updated, "prospect_tier": prospect_tier})


@app.route("/api/crm/leads/bulk-update-support", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def crm_bulk_update_support():
    """Bulk-update wants_support (priority service) for multiple leads."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    lead_ids = data.get("lead_ids")
    wants_support = data.get("wants_support")
    if not lead_ids or not isinstance(lead_ids, list):
        return jsonify({"error": "lead_ids must be a non-empty list"}), 400
    if len(lead_ids) > 500:
        return jsonify({"error": "Maximum 500 leads per request"}), 400
    if not all(isinstance(i, int) for i in lead_ids):
        return jsonify({"error": "lead_ids must be integers"}), 400
    if wants_support not in (0, 1, True, False):
        return jsonify({"error": "wants_support must be 0 or 1"}), 400

    ws_val = 1 if wants_support else 0
    now = datetime.now(timezone.utc).isoformat()
    placeholders = ",".join("?" for _ in lead_ids)
    try:
        with transaction() as conn:
            conn.execute(
                f"UPDATE leads SET wants_support = ?, updated_at = ? WHERE id IN ({placeholders})",
                [ws_val, now] + lead_ids,
            )
            updated = conn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk update support error: %s", e)
        return jsonify({"error": "Failed to update leads"}), 500

    log_access(
        session.get("username", "api"), "bulk_update_support", "lead",
        ip_address=request.remote_addr,
        details=f"updated={updated}, wants_support={ws_val}",
    )
    return jsonify({"success": True, "updated": updated, "wants_support": ws_val})


@app.route("/api/crm/leads/import-transactions", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def crm_import_transactions():
    """Import Stripe transactions as closed_won leads."""
    tx_file = BASE_DIR / "vault" / "stripe_transactions.json"
    if not tx_file.exists():
        return jsonify({"imported": 0, "skipped": 0, "total_transactions": 0, "message": "No transactions file found"})

    try:
        transactions = json.loads(tx_file.read_text())
    except Exception as e:
        logger.error("Failed to read transactions: %s", e)
        return jsonify({"error": "Failed to read transactions file"}), 500

    imported = 0
    skipped = 0
    now = datetime.now(timezone.utc).isoformat()

    for tx in transactions:
        tier = tx.get("tier", "")
        if tier not in ("core", "pro", "core_support", "pro_support"):
            skipped += 1
            continue

        sid = tx.get("stripe_session_id", "")
        if not sid:
            skipped += 1
            continue

        # Check for existing lead with this stripe session
        conn = get_db()
        try:
            exists = conn.execute("SELECT id FROM leads WHERE stripe_session_id = ?", (sid,)).fetchone()
        finally:
            conn.close()
        if exists:
            skipped += 1
            continue

        email = tx.get("email", "unknown@unknown.com")
        # Auto-link to contacts table
        contact_id = None
        conn = get_db()
        try:
            match = conn.execute("SELECT id FROM contacts WHERE contact_email = ? LIMIT 1", (email,)).fetchone()
            if match:
                contact_id = match["id"]
        finally:
            conn.close()

        # Support tiers map to the base tier for license_tier display
        is_support = tier.endswith("_support")
        display_tier = tier  # e.g. "core_support" stays as-is for clarity
        license_key = tx.get("license_key", "") if not is_support else ""

        try:
            with transaction() as conn:
                cursor = conn.execute(
                    """INSERT INTO leads
                       (contact_name, contact_email, company, lead_source, stage,
                        license_key, license_tier, amount_paid, currency, stripe_session_id,
                        contact_id, stage_changed_at, created_at, updated_at)
                       VALUES (?, ?, '', 'stripe', 'closed_won', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (email.split("@")[0], email, license_key,
                     display_tier, tx.get("amount", 0), tx.get("currency", "usd"), sid,
                     contact_id, tx.get("timestamp", now), tx.get("timestamp", now), now),
                )
                lead_id = cursor.lastrowid
                conn.execute(
                    "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, changed_at) VALUES (?, NULL, 'closed_won', 'stripe_import', ?)",
                    (lead_id, now),
                )
            imported += 1
        except Exception as e:
            logger.warning("Failed to import transaction %s: %s", sid, e)
            skipped += 1

    log_access(
        session.get("username", "api"), "import", "leads",
        ip_address=request.remote_addr,
        details=f"imported={imported} skipped={skipped}",
    )

    return jsonify({"imported": imported, "skipped": skipped, "total_transactions": len(transactions)})


# ── CRM Lead Batch Import (Excel) ─────────────────────────────────────────

@app.route("/api/crm/leads/template")
@require_auth
def crm_download_lead_template():
    """Generate and serve an Excel template for batch lead import."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads Import"

    columns = [
        ("Contact Name", 25, "Jane Smith"),
        ("Email", 30, "jane@lawfirm.com"),
        ("Company", 25, "Smith & Associates"),
        ("Phone", 18, "(555) 123-4567"),
        ("State", 8, "CA"),
        ("URL", 30, "https://smithlaw.com"),
        ("Lead Source", 18, "referral"),
        ("Stage", 18, "prospect"),
        ("Notes", 35, "Interested in Pro license"),
        ("Follow-up Date", 18, "2026-04-01"),
        ("Assigned To", 18, "Dan"),
    ]

    header_fill = PatternFill(start_color="1E3A5F", end_color="1E3A5F", fill_type="solid")
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    for col_idx, (name, width, _) in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width

    example_font = Font(name="Calibri", color="999999", italic=True, size=10)
    for col_idx, (_, _, example) in enumerate(columns, 1):
        cell = ws.cell(row=2, column=col_idx, value=example)
        cell.font = example_font
        cell.border = thin_border

    instructions = wb.create_sheet("Instructions")
    instructions.column_dimensions["A"].width = 20
    instructions.column_dimensions["B"].width = 70
    instructions_data = [
        ("Column", "Description"),
        ("Contact Name", "Required. Full name of the lead/contact."),
        ("Email", "Required. Email address (used for duplicate detection)."),
        ("Company", "Optional. Company or law firm name."),
        ("Phone", "Optional. Phone number (max 50 chars)."),
        ("State", "Optional. US state abbreviation (2 chars, e.g. CA, NY, TX)."),
        ("URL", "Optional. Website URL (max 500 chars)."),
        ("Lead Source", "Optional. One of: website, referral, demo_download, cold_outreach, trade_show, manual (default: manual)."),
        ("Stage", "Optional. One of: prospect, demo_requested, demo_active, trial, negotiation, closed_won, closed_lost (default: prospect)."),
        ("Notes", "Optional. Any notes about the lead (max 2000 chars)."),
        ("Follow-up Date", "Optional. Next follow-up date in YYYY-MM-DD format."),
        ("Assigned To", "Optional. Team member assigned to this lead (max 100 chars)."),
    ]
    for row_idx, (col_a, col_b) in enumerate(instructions_data, 1):
        cell_a = instructions.cell(row=row_idx, column=1, value=col_a)
        cell_b = instructions.cell(row=row_idx, column=2, value=col_b)
        if row_idx == 1:
            cell_a.font = Font(bold=True)
            cell_b.font = Font(bold=True)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="leads_import_template.xlsx",
    )


@app.route("/api/crm/leads/batch", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def crm_batch_import_leads():
    """Import leads from an uploaded Excel file."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    suffix = Path(file.filename).suffix.lower()
    if suffix not in (".xlsx", ".xls"):
        return jsonify({"error": "Only Excel files (.xlsx, .xls) are accepted"}), 400

    try:
        import openpyxl
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    try:
        wb = openpyxl.load_workbook(io.BytesIO(file.read()), read_only=True, data_only=True)
        ws = wb.active
        if ws is None:
            return jsonify({"error": "Excel file has no active worksheet"}), 400
    except Exception as e:
        return jsonify({"error": f"Cannot read Excel file: {e}"}), 400

    headers = []
    for cell in next(ws.iter_rows(min_row=1, max_row=1, values_only=False)):
        val = str(cell.value or "").strip().lower()
        headers.append(val)

    col_map = {}
    header_aliases = {
        "contact_name": ["contact name", "name", "contact_name", "lead name"],
        "contact_email": ["email", "contact email", "contact_email", "email address"],
        "company": ["company", "firm", "organization", "org", "law firm"],
        "phone": ["phone", "phone number", "tel", "telephone"],
        "state": ["state", "us state", "st"],
        "url": ["url", "website", "website url", "web"],
        "lead_source": ["lead source", "lead_source", "source"],
        "stage": ["stage", "status", "pipeline stage"],
        "notes": ["notes", "note", "comments"],
        "follow_up_date": ["follow-up date", "follow_up_date", "follow up", "followup", "next follow-up"],
        "assigned_to": ["assigned to", "assigned_to", "owner", "rep"],
    }
    for field, aliases in header_aliases.items():
        for i, h in enumerate(headers):
            if h in aliases:
                col_map[field] = i
                break

    if "contact_name" not in col_map or "contact_email" not in col_map:
        return jsonify({
            "error": "Excel file must have 'Contact Name' and 'Email' columns",
            "found_headers": headers,
        }), 400

    # If update_existing=true is passed as form field, update duplicates instead of skipping
    update_existing = request.form.get("update_existing", "").lower() in ("true", "1", "yes")

    results = {"imported": 0, "updated": 0, "skipped": 0, "errors": [], "skip_reasons": {"duplicate": 0, "missing_fields": 0, "invalid_email": 0}}
    now = datetime.now(timezone.utc).isoformat()

    row_num = 1
    try:
        with transaction() as conn:
            for row in ws.iter_rows(min_row=2, values_only=True):
                row_num += 1
                if not row or all(v is None for v in row):
                    continue

                def cell(field, default=""):
                    idx = col_map.get(field)
                    if idx is not None and idx < len(row) and row[idx] is not None:
                        return str(row[idx]).strip()
                    return default

                name = cell("contact_name")
                email = cell("contact_email")

                # Strip all unicode whitespace (non-breaking spaces, zero-width, etc.)
                if email:
                    email = re.sub(r'[\s\u00a0\u200b\u200c\u200d\ufeff]+', '', email)

                if not name or not email:
                    results["skipped"] += 1
                    results["skip_reasons"]["missing_fields"] += 1
                    results["errors"].append(f"Row {row_num}: Missing {'name' if not name else 'email'}")
                    continue

                if not re.match(r"^[a-zA-Z0-9._%+\-']+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email):
                    results["errors"].append(f"Row {row_num}: Invalid email '{email}'")
                    results["skipped"] += 1
                    results["skip_reasons"]["invalid_email"] += 1
                    continue

                email = email.lower()

                lead_source = cell("lead_source", "manual").lower()
                if lead_source not in VALID_LEAD_SOURCES:
                    lead_source = "manual"

                stage = cell("stage", "prospect").lower()
                if stage not in VALID_LEAD_STAGES:
                    stage = "prospect"

                follow_up = cell("follow_up_date") or None
                state_val = sanitize_string(cell("state"), 2).upper() or None
                url_val = sanitize_string(cell("url"), 500) or None

                # Check for duplicate email
                existing = conn.execute(
                    "SELECT id, stage FROM leads WHERE contact_email = ? LIMIT 1", (email,)
                ).fetchone()
                if existing:
                    if update_existing:
                        # Update the existing lead with new data (only non-empty fields)
                        updates = []
                        params = []
                        company_val = sanitize_string(cell("company"), 300)
                        phone_val = sanitize_string(cell("phone"), 50)
                        notes_val = sanitize_string(cell("notes"), 2000)
                        assigned_val = sanitize_string(cell("assigned_to"), 100) or None
                        if name:
                            updates.append("contact_name = ?"); params.append(sanitize_string(name, 200))
                        if company_val:
                            updates.append("company = ?"); params.append(company_val)
                        if phone_val:
                            updates.append("phone = ?"); params.append(phone_val)
                        if state_val:
                            updates.append("state = ?"); params.append(state_val)
                        if url_val:
                            updates.append("url = ?"); params.append(url_val)
                        if notes_val:
                            updates.append("notes = ?"); params.append(notes_val)
                        if follow_up:
                            updates.append("follow_up_date = ?"); params.append(follow_up)
                        if assigned_val:
                            updates.append("assigned_to = ?"); params.append(assigned_val)
                        if updates:
                            updates.append("updated_at = ?"); params.append(now)
                            params.append(existing["id"])
                            conn.execute(f"UPDATE leads SET {', '.join(updates)} WHERE id = ?", params)
                            results["updated"] += 1
                        else:
                            results["skipped"] += 1
                            results["skip_reasons"]["duplicate"] += 1
                    else:
                        results["skipped"] += 1
                        results["skip_reasons"]["duplicate"] += 1
                    continue

                # Auto-link to contacts table
                contact_id = None
                match = conn.execute(
                    "SELECT id FROM contacts WHERE contact_email = ? LIMIT 1", (email,)
                ).fetchone()
                if match:
                    contact_id = match["id"]

                cursor = conn.execute(
                    """INSERT INTO leads
                       (contact_name, contact_email, company, phone, state, url,
                        lead_source, stage,
                        notes, follow_up_date, assigned_to, contact_id,
                        stage_changed_at, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (sanitize_string(name, 200), email,
                     sanitize_string(cell("company"), 300),
                     sanitize_string(cell("phone"), 50),
                     state_val, url_val,
                     lead_source, stage,
                     sanitize_string(cell("notes"), 2000),
                     follow_up, sanitize_string(cell("assigned_to"), 100) or None,
                     contact_id, now, now, now),
                )
                lead_id = cursor.lastrowid
                conn.execute(
                    "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, changed_at) VALUES (?, NULL, ?, ?, ?)",
                    (lead_id, stage, "excel_import", now),
                )
                results["imported"] += 1

    except Exception as e:
        logger.error("Lead batch import error at row %d: %s", row_num, e)
        return jsonify({
            "error": f"Import failed at row {row_num}: {e}",
            "partial_results": results,
        }), 500
    finally:
        wb.close()

    log_access(
        session.get("username", "api"), "batch_import", "leads",
        ip_address=request.remote_addr,
        details=f"imported={results['imported']} updated={results['updated']} skipped={results['skipped']}",
    )
    logger.info("Lead batch import: %d imported, %d updated, %d skipped", results["imported"], results["updated"], results["skipped"])

    parts = []
    if results["imported"]:
        parts.append(f"{results['imported']} imported")
    if results["updated"]:
        parts.append(f"{results['updated']} updated")
    if results["skipped"]:
        reasons = results["skip_reasons"]
        reason_parts = []
        if reasons.get("duplicate"):
            reason_parts.append(f"{reasons['duplicate']} duplicates")
        if reasons.get("missing_fields"):
            reason_parts.append(f"{reasons['missing_fields']} missing fields")
        if reasons.get("invalid_email"):
            reason_parts.append(f"{reasons['invalid_email']} invalid emails")
        skip_detail = f" ({', '.join(reason_parts)})" if reason_parts else ""
        parts.append(f"{results['skipped']} skipped{skip_detail}")
    message = ". ".join(parts) + "." if parts else "No leads processed."

    return jsonify({
        "message": message,
        "results": results,
    })


@app.route("/api/crm/leads/export")
@require_auth
@rate_limit(requests_per_minute=10)
def crm_export_leads():
    """Export all leads to an Excel file."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    conn = get_db()
    try:
        leads = conn.execute(
            "SELECT * FROM leads ORDER BY created_at DESC"
        ).fetchall()
    finally:
        conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads Export"

    export_columns = [
        ("ID", 6), ("Contact Name", 25), ("Email", 30), ("Company", 25),
        ("Phone", 18), ("State", 8), ("URL", 30), ("Lead Source", 15), ("Stage", 18),
        ("Notes", 35), ("Follow-up Date", 15), ("Assigned To", 15),
        ("Amount Paid", 12), ("License Tier", 12), ("License Key", 20),
        ("Created", 20), ("Updated", 20),
    ]

    header_fill = PatternFill(start_color="1E3A5F", end_color="1E3A5F", fill_type="solid")
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    for col_idx, (name, width) in enumerate(export_columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width

    for row_idx, lead in enumerate(leads, 2):
        lead = dict(lead)
        values = [
            lead.get("id"), lead.get("contact_name"), lead.get("contact_email"),
            lead.get("company"), lead.get("phone"), lead.get("state"), lead.get("url"),
            lead.get("lead_source"),
            lead.get("stage"), lead.get("notes"), lead.get("follow_up_date"),
            lead.get("assigned_to"), lead.get("amount_paid", 0),
            lead.get("license_tier"), lead.get("license_key"),
            lead.get("created_at"), lead.get("updated_at"),
        ]
        for col_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.border = thin_border

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    log_access(
        session.get("username", "api"), "export", "leads",
        ip_address=request.remote_addr,
        details=f"total={len(leads)}",
    )

    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"leads_export_{datetime.now().strftime('%Y%m%d')}.xlsx",
    )


def _sync_google_sheet_leads(sheet_id, caller="manual"):
    """Fetch leads from a public Google Sheet via CSV export and import into CRM.

    The sheet must be shared as 'Anyone with the link can view'.
    Returns dict with imported/skipped counts.
    """
    import csv
    import requests as req_lib
    from datetime import timedelta

    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv"
    try:
        resp = req_lib.get(url, timeout=30)
        resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Failed to fetch Google Sheet: {e}")

    # Detect HTML error page (sheet not shared publicly)
    content_type = resp.headers.get("Content-Type", "")
    if "text/html" in content_type:
        raise RuntimeError(
            "Google Sheet returned HTML instead of CSV. "
            "Please share the sheet as 'Anyone with the link can view'."
        )

    text = resp.text
    if not text.strip():
        return {"imported": 0, "skipped": 0, "errors": ["Sheet is empty"]}

    reader = csv.DictReader(io.StringIO(text))

    # Flexible header matching (same aliases as batch import)
    raw_headers = reader.fieldnames or []
    header_aliases = {
        "contact_name": ["contact name", "name", "contact_name", "lead name", "full name"],
        "contact_email": ["email", "contact email", "contact_email", "email address"],
        "company": ["company", "firm", "organization", "org", "law firm"],
        "phone": ["phone", "phone number", "tel", "telephone"],
        "state": ["state", "us state", "st"],
        "url": ["url", "website", "website url", "web"],
    }
    col_map = {}
    for field, aliases in header_aliases.items():
        for h in raw_headers:
            if h.strip().lower() in aliases:
                col_map[field] = h
                break

    if "contact_email" not in col_map:
        return {"imported": 0, "skipped": 0, "errors": [
            f"No email column found. Sheet headers: {raw_headers}"
        ]}

    results = {"imported": 0, "skipped": 0, "errors": []}
    now = datetime.now(timezone.utc).isoformat()
    demo_expires = (datetime.now(timezone.utc) + timedelta(days=14)).isoformat()

    row_num = 1
    try:
        with transaction() as conn:
            for row in reader:
                row_num += 1
                email_val = (row.get(col_map.get("contact_email", ""), "") or "").strip().lower()
                if not email_val:
                    results["skipped"] += 1
                    continue

                if not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email_val):
                    results["errors"].append(f"Row {row_num}: Invalid email '{email_val}'")
                    results["skipped"] += 1
                    continue

                # Dedup by email
                existing = conn.execute(
                    "SELECT id FROM leads WHERE contact_email = ? LIMIT 1", (email_val,)
                ).fetchone()
                if existing:
                    results["skipped"] += 1
                    continue

                name_val = (row.get(col_map.get("contact_name", ""), "") or "").strip()
                if not name_val:
                    name_val = email_val.split("@")[0]

                company_val = (row.get(col_map.get("company", ""), "") or "").strip()
                phone_val = (row.get(col_map.get("phone", ""), "") or "").strip()
                state_val = (row.get(col_map.get("state", ""), "") or "").strip()[:2].upper() or None
                url_val = (row.get(col_map.get("url", ""), "") or "").strip()[:500] or None

                # Auto-link to contacts table
                contact_id = None
                match = conn.execute(
                    "SELECT id FROM contacts WHERE contact_email = ? LIMIT 1", (email_val,)
                ).fetchone()
                if match:
                    contact_id = match["id"]

                cursor = conn.execute(
                    """INSERT INTO leads
                       (contact_name, contact_email, company, phone, state, url,
                        lead_source, stage,
                        demo_sent_date, demo_expires, contact_id,
                        stage_changed_at, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, 'google_sheets', 'demo_active', ?, ?, ?, ?, ?, ?)""",
                    (name_val[:200].strip(), email_val,
                     company_val[:300].strip(),
                     phone_val[:50].strip(),
                     state_val, url_val,
                     now, demo_expires, contact_id, now, now, now),
                )
                lead_id = cursor.lastrowid
                conn.execute(
                    "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, changed_at) VALUES (?, NULL, 'demo_active', ?, ?)",
                    (lead_id, caller, now),
                )
                results["imported"] += 1

    except Exception as e:
        if "Failed to fetch" in str(e) or "HTML instead of CSV" in str(e):
            raise
        logger.error("Google Sheet sync error at row %d: %s", row_num, e)
        results["errors"].append(f"Error at row {row_num}: {e}")

    return results


@app.route("/api/crm/leads/sync-sheets", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def crm_sync_google_sheets():
    """Sync leads from a Google Sheet into the CRM."""
    config = load_config()
    sheet_id = (request.get_json(silent=True) or {}).get("sheet_id")
    if not sheet_id:
        sheet_id = config.get("crm", {}).get("google_sheet_id")
    if not sheet_id:
        return jsonify({"error": "No Google Sheet ID configured. Set crm.google_sheet_id in config.yaml."}), 400

    caller = session.get("username", "api")
    try:
        results = _sync_google_sheet_leads(sheet_id, caller=caller)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error("Google Sheet sync failed: %s", e)
        return jsonify({"error": f"Sync failed: {e}"}), 500

    log_access(
        caller, "google_sheet_sync", "leads",
        ip_address=request.remote_addr,
        details=f"imported={results['imported']} skipped={results['skipped']}",
    )
    logger.info("Google Sheet sync: %d imported, %d skipped", results["imported"], results["skipped"])

    return jsonify({
        "message": f"Synced {results['imported']} new leads from Google Sheets.",
        "results": results,
    })


@app.route("/api/crm/revenue")
@require_auth
@rate_limit(requests_per_minute=60)
def crm_revenue():
    """Revenue breakdown by month and tier."""
    period = request.args.get("period", "all").strip()

    conn = get_db()
    try:
        # Total revenue
        total_row = conn.execute("SELECT COALESCE(SUM(amount_paid), 0) as total FROM leads WHERE stage = 'closed_won'").fetchone()
        total_revenue = total_row["total"]

        # By tier
        tier_rows = conn.execute(
            "SELECT license_tier, COALESCE(SUM(amount_paid), 0) as total, COUNT(*) as cnt FROM leads WHERE stage = 'closed_won' AND license_tier IS NOT NULL GROUP BY license_tier"
        ).fetchall()
        by_tier = {r["license_tier"]: {"revenue": r["total"], "count": r["cnt"]} for r in tier_rows}

        # Period filter
        period_filter = ""
        if period != "all":
            days = {"30": "-30 days", "90": "-90 days", "365": "-365 days"}.get(period)
            if days:
                period_filter = f"AND created_at >= datetime('now', '{days}')"

        period_row = conn.execute(
            f"SELECT COALESCE(SUM(amount_paid), 0) as total FROM leads WHERE stage = 'closed_won' {period_filter}"
        ).fetchone()
        period_revenue = period_row["total"]

        # By month
        month_rows = conn.execute(
            f"""SELECT strftime('%Y-%m', created_at) as month,
                       COALESCE(SUM(amount_paid), 0) as revenue,
                       COUNT(*) as count
                FROM leads WHERE stage = 'closed_won' {period_filter}
                GROUP BY month ORDER BY month DESC LIMIT 12"""
        ).fetchall()
        by_month = [{"month": r["month"], "revenue": r["revenue"], "count": r["count"]} for r in month_rows]
    finally:
        conn.close()

    return jsonify({
        "total_revenue": total_revenue,
        "period_revenue": period_revenue,
        "by_tier": by_tier,
        "by_month": by_month,
    })


@app.route("/api/crm/demo-download", methods=["POST"])
@rate_limit(requests_per_minute=10, burst=5)
def crm_demo_download():
    """Public endpoint for tracking demo downloads from the website.

    No auth required — called by the website download form.
    Creates a lead with stage=demo_active, source=demo_download.
    CORS headers added for cross-origin website calls.
    """
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    if not email or not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email):
        return jsonify({"error": "Valid email is required"}), 400

    name = sanitize_string(data.get("name", email.split("@")[0]), 200)
    company = sanitize_string(data.get("company", ""), 300)
    now = datetime.now(timezone.utc).isoformat()

    # Check if lead already exists for this email
    conn = get_db()
    try:
        existing = conn.execute("SELECT id, stage FROM leads WHERE contact_email = ? LIMIT 1", (email,)).fetchone()
    finally:
        conn.close()

    if existing:
        # Don't create duplicate — just return success
        resp = jsonify({"success": True, "message": "Download tracked", "lead_id": existing["id"]})
        resp.headers["Access-Control-Allow-Origin"] = "*"
        return resp

    # Auto-link to contacts table
    contact_id = None
    conn = get_db()
    try:
        match = conn.execute("SELECT id FROM contacts WHERE contact_email = ? LIMIT 1", (email,)).fetchone()
        if match:
            contact_id = match["id"]
    finally:
        conn.close()

    # Set demo expiry to 14 days from now
    from datetime import timedelta
    demo_expires = (datetime.now(timezone.utc) + timedelta(days=14)).isoformat()

    try:
        with transaction() as conn:
            cursor = conn.execute(
                """INSERT INTO leads
                   (contact_name, contact_email, company, lead_source, stage,
                    demo_sent_date, demo_expires, contact_id,
                    stage_changed_at, created_at, updated_at)
                   VALUES (?, ?, ?, 'demo_download', 'demo_active', ?, ?, ?, ?, ?, ?)""",
                (name, email, company, now, demo_expires, contact_id, now, now, now),
            )
            lead_id = cursor.lastrowid
            conn.execute(
                "INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, changed_by, changed_at) VALUES (?, NULL, 'demo_active', 'website', ?)",
                (lead_id, now),
            )
    except Exception as e:
        logger.error("Failed to track demo download: %s", e)
        return jsonify({"error": "Failed to track download"}), 500

    log_access("website", "demo_download", "lead", str(lead_id), ip_address=request.remote_addr)

    resp = jsonify({"success": True, "message": "Download tracked", "lead_id": lead_id})
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp, 201


@app.route("/api/crm/demo-download", methods=["OPTIONS"])
def crm_demo_download_cors():
    """Handle CORS preflight for the demo download endpoint."""
    resp = jsonify({})
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp


# ── Campaign System: SMTP Profiles API ────────────────────────────────────────

@app.route("/api/settings/smtp-profiles")
@require_auth
@rate_limit(requests_per_minute=30)
def list_smtp_profiles():
    """List all SMTP profiles (passwords masked)."""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM smtp_profiles ORDER BY is_default DESC, profile_name"
        ).fetchall()
    finally:
        conn.close()

    profiles = []
    for r in rows:
        d = dict(r)
        d["smtp_password"] = "********" if d.get("smtp_password_encrypted") else ""
        d.pop("smtp_password_encrypted", None)
        profiles.append(d)

    return jsonify(profiles)


@app.route("/api/settings/smtp-profiles", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def create_smtp_profile():
    """Create a new SMTP profile."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    required = ["profile_name", "smtp_host", "smtp_username", "from_name", "from_email"]
    missing = [f for f in required if not (data.get(f) or "").strip()]
    if missing:
        return jsonify({"error": f"Missing required fields: {', '.join(missing)}"}), 400

    profile_name = data["profile_name"].strip()[:100]
    smtp_host = data["smtp_host"].strip()[:200]
    smtp_port = int(data.get("smtp_port", 587))
    smtp_username = data["smtp_username"].strip()[:200]
    smtp_password = data.get("smtp_password", "")
    from_name = data["from_name"].strip()[:200]
    from_email = data["from_email"].strip()[:254]
    reply_to = (data.get("reply_to_email") or "").strip()[:254] or None
    is_default = 1 if data.get("is_default") else 0
    daily_limit = min(max(int(data.get("daily_send_limit", 500)), 1), 10000)
    enabled = 1 if data.get("enabled", True) else 0

    now = datetime.now(timezone.utc).isoformat()

    try:
        with transaction() as conn:
            # If this is set as default, unset others
            if is_default:
                conn.execute("UPDATE smtp_profiles SET is_default = 0")

            from security_vault import Vault
            smtp_password_enc = Vault.encrypt_field(smtp_password) if smtp_password else ""
            conn.execute("""
                INSERT INTO smtp_profiles (profile_name, smtp_host, smtp_port,
                    smtp_username, smtp_password_encrypted, from_name, from_email,
                    reply_to_email, is_default, daily_send_limit, enabled,
                    created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (profile_name, smtp_host, smtp_port, smtp_username, smtp_password_enc,
                  from_name, from_email, reply_to, is_default, daily_limit, enabled,
                  now, now))

            profile_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    except sqlite3.IntegrityError:
        return jsonify({"error": f"Profile name '{profile_name}' already exists"}), 409
    except Exception as e:
        logger.error("SMTP profile create error: %s", e)
        return jsonify({"error": "Failed to create profile"}), 500

    logger.info("SMTP profile created: id=%d", profile_id)
    return jsonify({"success": True, "id": profile_id, "message": "Profile created"}), 201


@app.route("/api/settings/smtp-profiles/<int:profile_id>", methods=["PUT"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def update_smtp_profile(profile_id):
    """Update an existing SMTP profile."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    conn = get_db()
    try:
        existing = conn.execute("SELECT * FROM smtp_profiles WHERE id = ?", (profile_id,)).fetchone()
    finally:
        conn.close()

    if not existing:
        return jsonify({"error": "Profile not found"}), 404

    now = datetime.now(timezone.utc).isoformat()

    # Build update fields
    updates = {}
    for field in ["profile_name", "smtp_host", "smtp_username", "from_name", "from_email", "reply_to_email"]:
        if field in data:
            updates[field] = (data[field] or "").strip()[:254]
    if "smtp_port" in data:
        updates["smtp_port"] = int(data["smtp_port"])
    if "daily_send_limit" in data:
        updates["daily_send_limit"] = min(max(int(data["daily_send_limit"]), 1), 10000)
    if "enabled" in data:
        updates["enabled"] = 1 if data["enabled"] else 0
    if "is_default" in data:
        updates["is_default"] = 1 if data["is_default"] else 0

    # Handle password: don't overwrite if masked value sent back; encrypt before storing
    if "smtp_password" in data and data["smtp_password"] != "********":
        from security_vault import Vault
        updates["smtp_password_encrypted"] = Vault.encrypt_field(data["smtp_password"]) if data["smtp_password"] else ""

    updates["updated_at"] = now

    try:
        with transaction() as conn:
            if updates.get("is_default"):
                conn.execute("UPDATE smtp_profiles SET is_default = 0")

            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [profile_id]
            conn.execute(f"UPDATE smtp_profiles SET {set_clause} WHERE id = ?", values)
    except sqlite3.IntegrityError:
        return jsonify({"error": "Profile name already exists"}), 409
    except Exception as e:
        logger.error("SMTP profile update error: %s", e)
        return jsonify({"error": "Failed to update profile"}), 500

    return jsonify({"success": True, "message": "Profile updated"})


@app.route("/api/settings/smtp-profiles/<int:profile_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def delete_smtp_profile(profile_id):
    """Delete an SMTP profile."""
    try:
        with transaction() as conn:
            row = conn.execute("SELECT profile_name FROM smtp_profiles WHERE id = ?", (profile_id,)).fetchone()
            if not row:
                return jsonify({"error": "Profile not found"}), 404
            conn.execute("DELETE FROM smtp_profiles WHERE id = ?", (profile_id,))
    except Exception as e:
        logger.error("SMTP profile delete error: %s", e)
        return jsonify({"error": "Failed to delete profile"}), 500

    logger.info("SMTP profile deleted: id=%d", profile_id)
    return jsonify({"success": True, "message": "Profile deleted"})


@app.route("/api/settings/smtp-profiles/<int:profile_id>/test", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def test_smtp_profile(profile_id):
    """Test SMTP connection for a profile."""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM smtp_profiles WHERE id = ?", (profile_id,)).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Profile not found"}), 404

    from security_vault import Vault
    smtp_host = row["smtp_host"]
    smtp_port = row["smtp_port"]
    smtp_user = row["smtp_username"]
    smtp_pass = Vault.decrypt_field(row["smtp_password_encrypted"]) if row["smtp_password_encrypted"] else ""

    # Allow override password from request body (for unsaved profiles)
    data = request.get_json(silent=True) or {}
    if "smtp_password" in data and data["smtp_password"] != "********":
        smtp_pass = data["smtp_password"]

    try:
        import smtplib
        with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as s:
            s.ehlo()
            s.starttls()
            s.ehlo()
            if smtp_user and smtp_pass:
                s.login(smtp_user, smtp_pass)
            result = {"status": "ok", "message": f"SMTP connection to {smtp_host}:{smtp_port} successful"}
    except Exception as e:
        result = {"status": "error", "message": str(e)}

    return jsonify(result)


# ── Campaign System: Campaign CRUD + Draft Generation ─────────────────────────

VALID_CAMPAIGN_TYPES = {"sales_outreach", "demo_followup", "nurture", "announcement"}
VALID_CAMPAIGN_STATUSES = {"draft", "generating", "review", "approved", "sending", "sent", "paused", "failed"}

# Track active generation/send threads
_campaign_threads = {}


@app.route("/api/crm/campaigns")
@require_auth
@rate_limit(requests_per_minute=30)
def list_campaigns():
    """List all campaigns with optional filtering."""
    status = request.args.get("status")
    campaign_type = request.args.get("type")

    conn = get_db()
    try:
        query = "SELECT * FROM campaigns"
        params = []
        conditions = []
        if status and status in VALID_CAMPAIGN_STATUSES:
            conditions.append("status = ?")
            params.append(status)
        if campaign_type and campaign_type in VALID_CAMPAIGN_TYPES:
            conditions.append("campaign_type = ?")
            params.append(campaign_type)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY created_at DESC"
        rows = conn.execute(query, params).fetchall()
    finally:
        conn.close()

    campaigns = [dict(r) for r in rows]
    return jsonify({"campaigns": campaigns})


@app.route("/api/crm/campaigns", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def create_campaign():
    """Create a new campaign in draft status."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    name = (data.get("name") or "").strip()[:200]
    campaign_type = data.get("campaign_type", "")
    prompt = (data.get("prompt") or "").strip()
    subject_template = (data.get("subject_template") or "").strip()[:500]
    smtp_profile_id = data.get("smtp_profile_id")
    target_filter_json = json.dumps(data.get("target_filter", {})) if data.get("target_filter") else None

    if not name:
        return jsonify({"error": "Campaign name is required"}), 400
    if campaign_type not in VALID_CAMPAIGN_TYPES:
        return jsonify({"error": f"campaign_type must be one of: {', '.join(sorted(VALID_CAMPAIGN_TYPES))}"}), 400
    if not prompt:
        return jsonify({"error": "Prompt/brief is required for draft generation"}), 400

    now = datetime.now(timezone.utc).isoformat()
    username = session.get("username", "api")

    try:
        with transaction() as conn:
            conn.execute("""
                INSERT INTO campaigns (name, campaign_type, status, smtp_profile_id,
                    subject_template, prompt, target_filter_json, created_by,
                    created_at, updated_at)
                VALUES (?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?)
            """, (name, campaign_type, smtp_profile_id, subject_template, prompt,
                  target_filter_json, username, now, now))
            campaign_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    except Exception as e:
        logger.error("Campaign create error: %s", e)
        return jsonify({"error": "Failed to create campaign"}), 500

    logger.info("Campaign created: id=%d by %s", campaign_id, username)
    return jsonify({"success": True, "id": campaign_id, "message": "Campaign created"}), 201


@app.route("/api/crm/campaigns/<int:campaign_id>")
@require_auth
@rate_limit(requests_per_minute=30)
def get_campaign(campaign_id):
    """Get campaign details with message summary counts."""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
        if not row:
            return jsonify({"error": "Campaign not found"}), 404

        campaign = dict(row)

        # Get message status counts
        msg_stats = conn.execute("""
            SELECT status, COUNT(*) as cnt
            FROM campaign_messages WHERE campaign_id = ?
            GROUP BY status
        """, (campaign_id,)).fetchall()
        campaign["message_stats"] = {r["status"]: r["cnt"] for r in msg_stats}
    finally:
        conn.close()

    return jsonify(campaign)


@app.route("/api/crm/campaigns/<int:campaign_id>", methods=["PUT"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def update_campaign(campaign_id):
    """Update a campaign (only in draft status)."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    conn = get_db()
    try:
        existing = conn.execute("SELECT status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
    finally:
        conn.close()

    if not existing:
        return jsonify({"error": "Campaign not found"}), 404
    if existing["status"] not in ("draft", "failed"):
        return jsonify({"error": "Can only edit campaigns in draft or failed status"}), 400

    now = datetime.now(timezone.utc).isoformat()
    updates = {}
    for field in ["name", "prompt", "subject_template"]:
        if field in data:
            updates[field] = (data[field] or "").strip()
    if "campaign_type" in data and data["campaign_type"] in VALID_CAMPAIGN_TYPES:
        updates["campaign_type"] = data["campaign_type"]
    if "smtp_profile_id" in data:
        updates["smtp_profile_id"] = data["smtp_profile_id"]
    if "target_filter" in data:
        updates["target_filter_json"] = json.dumps(data["target_filter"])
    updates["updated_at"] = now

    try:
        with transaction() as conn:
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [campaign_id]
            conn.execute(f"UPDATE campaigns SET {set_clause} WHERE id = ?", values)
    except Exception as e:
        logger.error("Campaign update error: %s", e)
        return jsonify({"error": "Failed to update campaign"}), 500

    return jsonify({"success": True, "message": "Campaign updated"})


@app.route("/api/crm/campaigns/<int:campaign_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def delete_campaign(campaign_id):
    """Delete a campaign and its messages."""
    try:
        with transaction() as conn:
            row = conn.execute("SELECT name, status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
            if not row:
                return jsonify({"error": "Campaign not found"}), 404
            conn.execute("DELETE FROM campaign_messages WHERE campaign_id = ?", (campaign_id,))
            conn.execute("DELETE FROM campaigns WHERE id = ?", (campaign_id,))
    except Exception as e:
        logger.error("Campaign delete error: %s", e)
        return jsonify({"error": "Failed to delete campaign"}), 500

    logger.info("Campaign deleted: id=%d", campaign_id)
    return jsonify({"success": True, "message": "Campaign deleted"})


@app.route("/api/crm/campaigns/<int:campaign_id>/generate", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def generate_campaign_drafts(campaign_id):
    """Generate email drafts for all target leads using Claude API. Runs in background thread."""
    conn = get_db()
    try:
        campaign = conn.execute("SELECT * FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
        if not campaign:
            return jsonify({"error": "Campaign not found"}), 404
        if campaign["status"] not in ("draft", "failed"):
            return jsonify({"error": "Can only generate drafts for campaigns in draft or failed status"}), 400
        campaign = dict(campaign)
    finally:
        conn.close()

    # Check if already generating
    if campaign_id in _campaign_threads and _campaign_threads[campaign_id].is_alive():
        return jsonify({"error": "Draft generation already in progress"}), 409

    # Read model backend preference from request
    data = request.get_json(silent=True) or {}
    model_backend = data.get("model_backend", "claude")
    if model_backend not in ("claude", "ollama"):
        model_backend = "claude"
    ollama_model_override = data.get("ollama_model")  # e.g. "llama3.1:8b"

    # Mark as generating
    with transaction() as conn:
        conn.execute("UPDATE campaigns SET status = 'generating', updated_at = ? WHERE id = ?",
                     (datetime.now(timezone.utc).isoformat(), campaign_id))
        # Clear any existing draft messages from previous attempts
        conn.execute("DELETE FROM campaign_messages WHERE campaign_id = ?", (campaign_id,))

    # Launch background thread
    t = threading.Thread(target=_generate_drafts_worker, args=(campaign_id, campaign, model_backend, ollama_model_override), daemon=True)
    _campaign_threads[campaign_id] = t
    t.start()

    return jsonify({"success": True, "message": "Draft generation started"})


def _generate_drafts_worker(campaign_id, campaign, model_backend="claude", ollama_model_override=None):
    """Background worker: generate email drafts via Claude or Ollama."""
    config = load_config()
    try:
        # All LLM calls route through AWS Bedrock (HIPAA-compliant via BAA)
        from dispatch import call_bedrock
        bedrock_cfg = config.get("bedrock", {})
        model = bedrock_cfg.get("chat_model", bedrock_cfg.get("model", "us.anthropic.claude-sonnet-4-5-v2:0"))
        logger.info("Campaign %d: using Bedrock (%s) for draft generation", campaign_id, model.split(".")[-1])

        # Fetch target leads
        conn = get_db()
        try:
            target_filter = json.loads(campaign.get("target_filter_json") or "{}") if campaign.get("target_filter_json") else {}
            query = "SELECT * FROM leads WHERE 1=1"
            params = []

            if target_filter.get("stages"):
                placeholders = ", ".join("?" for _ in target_filter["stages"])
                query += f" AND stage IN ({placeholders})"
                params.extend(target_filter["stages"])
            if target_filter.get("sources"):
                placeholders = ", ".join("?" for _ in target_filter["sources"])
                query += f" AND lead_source IN ({placeholders})"
                params.extend(target_filter["sources"])
            if target_filter.get("tiers"):
                placeholders = ", ".join("?" for _ in target_filter["tiers"])
                query += f" AND prospect_tier IN ({placeholders})"
                params.extend(target_filter["tiers"])

            # Exclude leads without email
            query += " AND contact_email IS NOT NULL AND contact_email != ''"
            query += " ORDER BY created_at DESC"

            leads = [dict(r) for r in conn.execute(query, params).fetchall()]
        finally:
            conn.close()

        if not leads:
            with transaction() as conn:
                conn.execute("UPDATE campaigns SET status = 'failed', updated_at = ? WHERE id = ?",
                             (datetime.now(timezone.utc).isoformat(), campaign_id))
            logger.warning("Campaign %d: no leads match the target filter", campaign_id)
            return

        # Update total recipients
        with transaction() as conn:
            conn.execute("UPDATE campaigns SET total_recipients = ?, updated_at = ? WHERE id = ?",
                         (len(leads), datetime.now(timezone.utc).isoformat(), campaign_id))

        # Build system prompt for email drafting
        campaign_type_labels = {
            "sales_outreach": "Sales Outreach",
            "demo_followup": "Demo Follow-up",
            "nurture": "Nurture / Relationship Building",
            "announcement": "Product Announcement",
        }

        system_prompt = f"""You are a professional sales copywriter for MedRecords AI, a medical records retrieval and AI-powered summarization platform for personal injury law firms.

Campaign type: {campaign_type_labels.get(campaign['campaign_type'], campaign['campaign_type'])}

BRIEF FROM THE USER:
{campaign['prompt']}

RULES:
- Write personalized, professional emails that feel human-written
- Keep emails concise (150-300 words)
- Use the lead's name and company for personalization
- Match the tone to the campaign type (sales: confident but not pushy, follow-up: helpful, nurture: informative, announcement: exciting)
- Do NOT include subject lines in the email body
- Write in plain text format (no HTML/markdown)
- Include a clear call to action
- When suggesting a meeting or call, use ONLY this scheduling link: https://calendar.google.com/calendar/appointments/schedules/AcZssZ0BgIw4t3vuLvfdFV1xlCBZEhFre0Dumk-3QFY_oLoMLfJuIT0b6-6rvBy-NGsY1CFXFqiED0IP
- Do NOT invent or fabricate any URLs — only use the scheduling link above
- Sign off professionally

For each lead, write ONE complete email. Separate each email with the delimiter ===NEXT_EMAIL=== on its own line.
Do NOT include any labels, headers, or metadata — just the email body text for each lead."""

        # Process leads in batches of 5
        batch_size = 5
        all_messages = []

        for i in range(0, len(leads), batch_size):
            batch = leads[i:i + batch_size]

            # Build per-lead context
            lead_contexts = []
            for lead in batch:
                days_since = "unknown"
                if lead.get("created_at"):
                    try:
                        created = datetime.fromisoformat(lead["created_at"].replace("Z", "+00:00"))
                        days_since = (datetime.now(timezone.utc) - created).days
                    except Exception:
                        pass

                context = f"""Lead: {lead['contact_name']}
Company: {lead.get('company') or 'Unknown'}
Email: {lead['contact_email']}
Stage: {lead.get('stage', 'prospect')}
Source: {lead.get('lead_source', 'unknown')}
Prospect Tier: {lead.get('prospect_tier') or 'not specified'}
License Quantity: {lead.get('license_quantity', 1)}
Notes: {lead.get('notes') or 'none'}
Days since added: {days_since}"""
                lead_contexts.append(context)

            user_message = "Write personalized emails for these leads:\n\n" + "\n\n---\n\n".join(lead_contexts)

            try:
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ]
                response_text = call_bedrock(
                    model_id=model,
                    messages=messages,
                    config=config,
                    timeout_override=120,
                    max_tokens_override=4096,
                )
            except Exception as e:
                logger.error("Campaign %d: %s API error on batch %d: %s", campaign_id, model_backend, i // batch_size, e)
                # Mark remaining leads as failed
                for lead in batch:
                    all_messages.append({
                        "lead": lead,
                        "body": "",
                        "error": str(e),
                    })
                continue

            # Parse response — split by delimiter
            email_texts = [t.strip() for t in response_text.split("===NEXT_EMAIL===") if t.strip()]

            for j, lead in enumerate(batch):
                body = email_texts[j] if j < len(email_texts) else ""
                all_messages.append({
                    "lead": lead,
                    "body": body,
                    "error": None if body else "No draft generated",
                })

        # Generate subject lines from template
        subject_template = campaign.get("subject_template") or "Quick question for {contact_name}"

        # Save all messages to DB
        now = datetime.now(timezone.utc).isoformat()
        with transaction() as conn:
            for msg in all_messages:
                lead = msg["lead"]
                subject = subject_template.replace("{contact_name}", lead.get("contact_name", ""))
                subject = subject.replace("{company}", lead.get("company") or "your team")

                status = "draft" if msg["body"] else "failed"
                conn.execute("""
                    INSERT INTO campaign_messages (campaign_id, lead_id, subject, body_text,
                        status, personalization_context, error_message, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (campaign_id, lead["id"], subject, msg["body"] or "",
                      status, json.dumps({"name": lead["contact_name"], "company": lead.get("company")}),
                      msg.get("error"), now, now))

            # Update campaign status
            conn.execute("""
                UPDATE campaigns SET status = 'review', total_recipients = ?,
                    updated_at = ? WHERE id = ?
            """, (len(all_messages), now, campaign_id))

        logger.info("Campaign %d: generated %d drafts (%d failed)",
                    campaign_id, sum(1 for m in all_messages if m["body"]),
                    sum(1 for m in all_messages if not m["body"]))

    except Exception as e:
        logger.error("Campaign %d: draft generation failed: %s", campaign_id, e)
        try:
            with transaction() as conn:
                conn.execute("UPDATE campaigns SET status = 'failed', updated_at = ? WHERE id = ?",
                             (datetime.now(timezone.utc).isoformat(), campaign_id))
        except Exception:
            pass


@app.route("/api/crm/campaigns/<int:campaign_id>/messages")
@require_auth
@rate_limit(requests_per_minute=30)
def list_campaign_messages(campaign_id):
    """List draft messages for a campaign with lead info."""
    page = max(1, int(request.args.get("page", 1)))
    per_page = min(50, max(10, int(request.args.get("per_page", 20))))
    offset = (page - 1) * per_page
    status_filter = request.args.get("status")

    conn = get_db()
    try:
        # Verify campaign exists
        campaign = conn.execute("SELECT id FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
        if not campaign:
            return jsonify({"error": "Campaign not found"}), 404

        query = """
            SELECT cm.*, l.contact_name, l.contact_email, l.company, l.stage
            FROM campaign_messages cm
            JOIN leads l ON cm.lead_id = l.id
            WHERE cm.campaign_id = ?
        """
        params = [campaign_id]
        if status_filter:
            query += " AND cm.status = ?"
            params.append(status_filter)
        query += " ORDER BY cm.id ASC LIMIT ? OFFSET ?"
        params.extend([per_page, offset])

        rows = conn.execute(query, params).fetchall()

        # Count total
        count_query = "SELECT COUNT(*) FROM campaign_messages WHERE campaign_id = ?"
        count_params = [campaign_id]
        if status_filter:
            count_query += " AND status = ?"
            count_params.append(status_filter)
        total = conn.execute(count_query, count_params).fetchone()[0]
    finally:
        conn.close()

    messages = [dict(r) for r in rows]
    return jsonify({
        "messages": messages,
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
    })


@app.route("/api/crm/campaigns/<int:campaign_id>/messages/<int:msg_id>", methods=["PUT"])
@require_auth
@rate_limit(requests_per_minute=30)
def update_campaign_message(campaign_id, msg_id):
    """Edit a draft message's subject or body."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    now = datetime.now(timezone.utc).isoformat()
    updates = {}
    if "subject" in data:
        updates["subject"] = (data["subject"] or "").strip()[:500]
    if "body_text" in data:
        updates["body_text"] = (data["body_text"] or "").strip()
    if "status" in data and data["status"] in ("draft", "skipped"):
        updates["status"] = data["status"]
    updates["updated_at"] = now

    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    try:
        with transaction() as conn:
            row = conn.execute(
                "SELECT id FROM campaign_messages WHERE id = ? AND campaign_id = ?",
                (msg_id, campaign_id)
            ).fetchone()
            if not row:
                return jsonify({"error": "Message not found"}), 404

            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [msg_id]
            conn.execute(f"UPDATE campaign_messages SET {set_clause} WHERE id = ?", values)
    except Exception as e:
        logger.error("Campaign message update error: %s", e)
        return jsonify({"error": "Failed to update message"}), 500

    return jsonify({"success": True, "message": "Message updated"})


@app.route("/api/crm/campaigns/<int:campaign_id>/approve", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def approve_campaign(campaign_id):
    """Approve all draft messages in a campaign for sending."""
    now = datetime.now(timezone.utc).isoformat()
    username = session.get("username", "api")

    try:
        with transaction() as conn:
            campaign = conn.execute("SELECT status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
            if not campaign:
                return jsonify({"error": "Campaign not found"}), 404
            if campaign["status"] not in ("review", "draft"):
                return jsonify({"error": "Campaign must be in review status to approve"}), 400

            # Approve all draft messages (skip ones marked as skipped)
            conn.execute("""
                UPDATE campaign_messages SET status = 'approved', updated_at = ?
                WHERE campaign_id = ? AND status = 'draft'
            """, (now, campaign_id))

            approved_count = conn.execute(
                "SELECT COUNT(*) FROM campaign_messages WHERE campaign_id = ? AND status = 'approved'",
                (campaign_id,)
            ).fetchone()[0]

            conn.execute("""
                UPDATE campaigns SET status = 'approved', approved_by = ?,
                    approved_at = ?, updated_at = ? WHERE id = ?
            """, (username, now, now, campaign_id))
    except Exception as e:
        logger.error("Campaign approve error: %s", e)
        return jsonify({"error": "Failed to approve campaign"}), 500

    logger.info("Campaign %d approved by %s: %d messages", campaign_id, username, approved_count)
    return jsonify({"success": True, "message": f"Campaign approved with {approved_count} messages"})


@app.route("/api/crm/campaigns/<int:campaign_id>/send", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def send_campaign(campaign_id):
    """Start sending approved campaign messages. Runs in background thread."""
    conn = get_db()
    try:
        campaign = conn.execute("SELECT * FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
        if not campaign:
            return jsonify({"error": "Campaign not found"}), 404
        if campaign["status"] != "approved":
            return jsonify({"error": "Campaign must be approved before sending"}), 400
        campaign = dict(campaign)

        # Get SMTP profile
        smtp_profile = None
        if campaign.get("smtp_profile_id"):
            smtp_profile = conn.execute(
                "SELECT * FROM smtp_profiles WHERE id = ? AND enabled = 1",
                (campaign["smtp_profile_id"],)
            ).fetchone()
        if not smtp_profile:
            smtp_profile = conn.execute(
                "SELECT * FROM smtp_profiles WHERE is_default = 1 AND enabled = 1"
            ).fetchone()
        if not smtp_profile:
            return jsonify({"error": "No enabled SMTP profile configured. Add one in Email Profiles."}), 400
        smtp_profile = dict(smtp_profile)
    finally:
        conn.close()

    # Check if already sending
    if campaign_id in _campaign_threads and _campaign_threads[campaign_id].is_alive():
        return jsonify({"error": "Campaign is already being sent"}), 409

    # Mark as sending
    with transaction() as conn:
        conn.execute("UPDATE campaigns SET status = 'sending', sent_at = ?, updated_at = ? WHERE id = ?",
                     (datetime.now(timezone.utc).isoformat(), datetime.now(timezone.utc).isoformat(), campaign_id))

    # Launch send thread
    t = threading.Thread(target=_send_campaign_worker, args=(campaign_id, smtp_profile), daemon=True)
    _campaign_threads[campaign_id] = t
    t.start()

    return jsonify({"success": True, "message": "Campaign sending started"})


def _send_campaign_worker(campaign_id, smtp_profile):
    """Background worker: send approved campaign messages."""
    from retrieval_bot import send_campaign_email, check_and_increment_send_count

    try:
        conn = get_db()
        try:
            messages = conn.execute("""
                SELECT cm.*, l.contact_email
                FROM campaign_messages cm
                JOIN leads l ON cm.lead_id = l.id
                WHERE cm.campaign_id = ? AND cm.status = 'approved'
                ORDER BY cm.id
            """, (campaign_id,)).fetchall()
        finally:
            conn.close()

        total_sent = 0
        total_failed = 0

        for msg in messages:
            # Check if campaign was paused
            conn = get_db()
            try:
                status = conn.execute("SELECT status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
                if status and status["status"] == "paused":
                    logger.info("Campaign %d: paused by user", campaign_id)
                    return
            finally:
                conn.close()

            msg = dict(msg)

            # Check daily send limit
            if not check_and_increment_send_count(smtp_profile["id"]):
                logger.warning("Campaign %d: daily send limit reached for profile %s",
                             campaign_id, smtp_profile["profile_name"])
                with transaction() as conn:
                    conn.execute("UPDATE campaigns SET status = 'paused', updated_at = ? WHERE id = ?",
                                 (datetime.now(timezone.utc).isoformat(), campaign_id))
                return

            # Send the email
            message_id, error = send_campaign_email(
                smtp_profile, msg["contact_email"], msg["subject"], msg["body_text"]
            )

            now = datetime.now(timezone.utc).isoformat()
            if message_id:
                total_sent += 1
                with transaction() as conn:
                    conn.execute("""
                        UPDATE campaign_messages SET status = 'sent', message_id = ?,
                            sent_at = ?, updated_at = ? WHERE id = ?
                    """, (message_id, now, now, msg["id"]))
            else:
                total_failed += 1
                retry = (msg.get("retry_count") or 0) + 1
                with transaction() as conn:
                    conn.execute("""
                        UPDATE campaign_messages SET status = 'failed', error_message = ?,
                            retry_count = ?, updated_at = ? WHERE id = ?
                    """, (error, retry, now, msg["id"]))

            # Update campaign counters
            with transaction() as conn:
                conn.execute("""
                    UPDATE campaigns SET total_sent = ?, total_failed = ?, updated_at = ? WHERE id = ?
                """, (total_sent, total_failed, now, campaign_id))

            # Rate throttle: 1.5 seconds between sends
            time.sleep(1.5)

        # Mark campaign as sent
        with transaction() as conn:
            conn.execute("UPDATE campaigns SET status = 'sent', updated_at = ? WHERE id = ?",
                         (datetime.now(timezone.utc).isoformat(), campaign_id))

        logger.info("Campaign %d: completed. Sent: %d, Failed: %d", campaign_id, total_sent, total_failed)

    except Exception as e:
        logger.error("Campaign %d: send failed: %s", campaign_id, e)
        try:
            with transaction() as conn:
                conn.execute("UPDATE campaigns SET status = 'failed', updated_at = ? WHERE id = ?",
                             (datetime.now(timezone.utc).isoformat(), campaign_id))
        except Exception:
            pass


@app.route("/api/crm/campaigns/<int:campaign_id>/pause", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def pause_campaign(campaign_id):
    """Pause a sending campaign."""
    try:
        with transaction() as conn:
            campaign = conn.execute("SELECT status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
            if not campaign:
                return jsonify({"error": "Campaign not found"}), 404
            if campaign["status"] != "sending":
                return jsonify({"error": "Can only pause a campaign that is currently sending"}), 400
            conn.execute("UPDATE campaigns SET status = 'paused', updated_at = ? WHERE id = ?",
                         (datetime.now(timezone.utc).isoformat(), campaign_id))
    except Exception as e:
        logger.error("Campaign pause error: %s", e)
        return jsonify({"error": "Failed to pause campaign"}), 500

    return jsonify({"success": True, "message": "Campaign paused"})


@app.route("/api/crm/campaigns/<int:campaign_id>/target-count")
@require_auth
@rate_limit(requests_per_minute=30)
def campaign_target_count(campaign_id):
    """Get the count of leads matching the campaign's target filter (or provided filter)."""
    # Accept filter from query params for live preview
    stages = request.args.getlist("stages")
    sources = request.args.getlist("sources")
    tiers = request.args.getlist("tiers")

    conn = get_db()
    try:
        query = "SELECT COUNT(*) FROM leads WHERE contact_email IS NOT NULL AND contact_email != ''"
        params = []
        if stages:
            placeholders = ", ".join("?" for _ in stages)
            query += f" AND stage IN ({placeholders})"
            params.extend(stages)
        if sources:
            placeholders = ", ".join("?" for _ in sources)
            query += f" AND lead_source IN ({placeholders})"
            params.extend(sources)
        if tiers:
            placeholders = ", ".join("?" for _ in tiers)
            query += f" AND prospect_tier IN ({placeholders})"
            params.extend(tiers)
        count = conn.execute(query, params).fetchone()[0]
    finally:
        conn.close()

    return jsonify({"count": count})


# ── License Validation API ────────────────────────────────────────────────────

@app.route("/api/license/validate", methods=["POST"])
@rate_limit(requests_per_minute=10)
def validate_license():
    """Validate a license key. No auth required (client-side validation)."""
    data = request.get_json(silent=True)
    if not data or not data.get("license_key"):
        return jsonify({"valid": False, "reason": "license_key required"}), 400

    try:
        from licensing import validate_license_key
        result = validate_license_key(data["license_key"])
        if result.get("valid"):
            log_access("api", "validate_license", "license",
                       details=f"valid key, tier={result.get('tier')}",
                       ip_address=request.remote_addr)
        return jsonify(result)
    except Exception as e:
        logger.error("License validation error: %s", e)
        return jsonify({"valid": False, "reason": "Validation error"}), 500


# ── Service / Customer Success API ────────────────────────────────────────────

@app.route("/api/service/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def service_stats():
    """Dashboard stats for the Service / Customer Success page."""
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        core_count = conn.execute("SELECT COUNT(*) FROM customers WHERE license_tier='core'").fetchone()[0]
        pro_count = conn.execute("SELECT COUNT(*) FROM customers WHERE license_tier='pro'").fetchone()[0]
        total_mrr = conn.execute("SELECT COALESCE(SUM(mrr),0) FROM customers WHERE health_status != 'churned'").fetchone()[0]
        avg_health = conn.execute("SELECT COALESCE(AVG(health_score),0) FROM customers WHERE health_status != 'churned'").fetchone()[0]
        at_risk = conn.execute("SELECT COUNT(*) FROM customers WHERE health_status='at_risk'").fetchone()[0]
        renewals_30d = conn.execute(
            "SELECT COUNT(*) FROM customers WHERE renewal_date IS NOT NULL AND renewal_date <= date('now', '+30 days') AND health_status != 'churned'"
        ).fetchone()[0]
        churned = conn.execute("SELECT COUNT(*) FROM customers WHERE health_status='churned'").fetchone()[0]
        onboarding_active = conn.execute("SELECT COUNT(*) FROM customers WHERE onboarding_status='in_progress'").fetchone()[0]

        # Extended metrics
        healthy = conn.execute("SELECT COUNT(*) FROM customers WHERE health_status='healthy'").fetchone()[0]
        mrr_at_risk = conn.execute("SELECT COALESCE(SUM(mrr),0) FROM customers WHERE health_status='at_risk'").fetchone()[0]
        mrr_churned = conn.execute("SELECT COALESCE(SUM(mrr),0) FROM customers WHERE health_status='churned'").fetchone()[0]
        churn_rate = round((churned / total * 100) if total > 0 else 0, 1)
        nrr = round((total_mrr / (total_mrr + mrr_churned) * 100) if (total_mrr + mrr_churned) > 0 else 100, 1)
        onboarding_not_started = conn.execute("SELECT COUNT(*) FROM customers WHERE onboarding_status='not_started'").fetchone()[0]
        onboarding_completed = conn.execute("SELECT COUNT(*) FROM customers WHERE onboarding_status='completed'").fetchone()[0]
    finally:
        conn.close()
    return jsonify({
        "total_customers": total,
        "core_licenses": core_count,
        "pro_licenses": pro_count,
        "total_mrr": total_mrr,
        "avg_health_score": round(avg_health, 1),
        "at_risk_count": at_risk,
        "renewals_due_30d": renewals_30d,
        "churned_count": churned,
        "onboarding_active": onboarding_active,
        "churn_rate": churn_rate,
        "mrr_at_risk": mrr_at_risk,
        "nrr": nrr,
        "health_distribution": {"healthy": healthy, "at_risk": at_risk, "churned": churned},
        "onboarding_distribution": {"not_started": onboarding_not_started, "in_progress": onboarding_active, "completed": onboarding_completed},
    })


@app.route("/api/service/customers", methods=["GET"])
@require_auth
@rate_limit(requests_per_minute=60)
def service_customers_list():
    """List customers with pagination, search, and filters."""
    page = max(1, request.args.get("page", 1, type=int))
    per_page = min(100, max(1, request.args.get("per_page", 50, type=int)))
    search = request.args.get("search", "").strip()
    health_status = request.args.get("health_status", "")
    tier = request.args.get("tier", "")
    onboarding = request.args.get("onboarding", "")
    sort_by = request.args.get("sort_by", "created_at")
    sort_dir = request.args.get("sort_dir", "desc")

    allowed_sorts = {"created_at", "contact_name", "company", "health_score", "mrr", "renewal_date", "last_login_at", "state"}
    if sort_by not in allowed_sorts:
        sort_by = "created_at"
    if sort_dir not in ("asc", "desc"):
        sort_dir = "desc"

    where = []
    params = []
    if search:
        where.append("(contact_name LIKE ? OR contact_email LIKE ? OR company LIKE ?)")
        s = f"%{search}%"
        params.extend([s, s, s])
    if health_status:
        where.append("health_status = ?")
        params.append(health_status)
    if tier:
        where.append("license_tier = ?")
        params.append(tier)
    if onboarding:
        where.append("onboarding_status = ?")
        params.append(onboarding)

    where_clause = ("WHERE " + " AND ".join(where)) if where else ""

    conn = get_db()
    try:
        total = conn.execute(f"SELECT COUNT(*) FROM customers {where_clause}", params).fetchone()[0]
        rows = conn.execute(
            f"SELECT * FROM customers {where_clause} ORDER BY {sort_by} {sort_dir} LIMIT ? OFFSET ?",
            params + [per_page, (page - 1) * per_page],
        ).fetchall()
    finally:
        conn.close()

    return jsonify({
        "customers": [dict(r) for r in rows],
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": max(1, -(-total // per_page)),
    })


@app.route("/api/service/customers", methods=["POST"])
@require_auth

@rate_limit(requests_per_minute=30)
def service_customer_create():
    """Create a new customer record."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    name = (data.get("contact_name") or "").strip()
    email = (data.get("contact_email") or "").strip().lower()
    if not name or not email:
        return jsonify({"error": "contact_name and contact_email are required"}), 400
    if not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email):
        return jsonify({"error": "Invalid email format"}), 400

    fields = {
        "contact_name": name[:200],
        "contact_email": email,
        "company": (data.get("company") or "")[:300].strip(),
        "phone": (data.get("phone") or "")[:50].strip(),
        "state": (data.get("state") or "")[:2].upper().strip(),
        "url": (data.get("url") or "")[:500].strip(),
        "license_key": data.get("license_key"),
        "license_tier": data.get("license_tier"),
        "license_quantity": data.get("license_quantity", 1),
        "activated_at": data.get("activated_at"),
        "expires_at": data.get("expires_at"),
        "amount_paid": data.get("amount_paid", 0),
        "mrr": data.get("mrr", 0),
        "arr": data.get("arr", 0),
        "currency": data.get("currency", "usd"),
        "stripe_customer_id": data.get("stripe_customer_id"),
        "stripe_subscription_id": data.get("stripe_subscription_id"),
        "stripe_session_id": data.get("stripe_session_id"),
        "health_score": data.get("health_score", 100),
        "health_status": data.get("health_status", "healthy"),
        "onboarding_status": data.get("onboarding_status", "not_started"),
        "renewal_date": data.get("renewal_date"),
        "contract_start": data.get("contract_start"),
        "contract_end": data.get("contract_end"),
        "csm_assigned": data.get("csm_assigned"),
        "lead_id": data.get("lead_id"),
        "notes": data.get("notes"),
        "tags": data.get("tags"),
    }

    cols = ", ".join(fields.keys())
    placeholders = ", ".join("?" for _ in fields)
    now = datetime.now(timezone.utc).isoformat()

    try:
        with transaction() as conn:
            cursor = conn.execute(
                f"INSERT INTO customers ({cols}, created_at, updated_at) VALUES ({placeholders}, ?, ?)",
                list(fields.values()) + [now, now],
            )
            customer_id = cursor.lastrowid
            conn.execute(
                "INSERT INTO customer_events (customer_id, event_type, description, created_by) VALUES (?, 'note', 'Customer created', ?)",
                (customer_id, session.get("username", "api")),
            )
    except sqlite3.IntegrityError as e:
        return jsonify({"error": f"Integrity error: {e}"}), 409

    log_access(session.get("username", "api"), "create", "customer", str(customer_id),
               request.remote_addr, f"Created customer: {name}")
    return jsonify({"id": customer_id, "message": "Customer created"}), 201


@app.route("/api/service/customers/<int:cid>")
@require_auth
@rate_limit(requests_per_minute=60)
def service_customer_detail(cid):
    """Get customer detail with recent events and health history."""
    conn = get_db()
    try:
        cust = conn.execute("SELECT * FROM customers WHERE id = ?", (cid,)).fetchone()
        if not cust:
            return jsonify({"error": "Customer not found"}), 404
        events = conn.execute(
            "SELECT * FROM customer_events WHERE customer_id = ? ORDER BY created_at DESC LIMIT 50",
            (cid,),
        ).fetchall()
        health_history = conn.execute(
            "SELECT * FROM customer_health_scores WHERE customer_id = ? ORDER BY recorded_at DESC LIMIT 30",
            (cid,),
        ).fetchall()
    finally:
        conn.close()

    return jsonify({
        "customer": dict(cust),
        "events": [dict(e) for e in events],
        "health_history": [dict(h) for h in health_history],
    })


@app.route("/api/service/customers/<int:cid>", methods=["PUT"])
@require_auth

@rate_limit(requests_per_minute=30)
def service_customer_update(cid):
    """Update a customer record."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    allowed = {
        "contact_name", "contact_email", "company", "phone", "state", "url",
        "license_key", "license_tier", "license_quantity", "activated_at", "expires_at",
        "amount_paid", "mrr", "arr", "currency",
        "stripe_customer_id", "stripe_subscription_id", "stripe_session_id",
        "health_score", "health_status", "nps_score",
        "onboarding_status", "onboarding_completed_at",
        "last_login_at", "cases_processed", "documents_uploaded", "total_logins",
        "open_tickets", "total_tickets", "avg_response_time_hours",
        "renewal_date", "contract_start", "contract_end", "churned_at", "churn_reason",
        "csm_assigned", "lead_id", "notes", "tags",
    }
    updates = {k: v for k, v in data.items() if k in allowed}
    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    now = datetime.now(timezone.utc).isoformat()
    updates["updated_at"] = now
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    params = list(updates.values()) + [cid]

    with transaction() as conn:
        existing = conn.execute("SELECT id FROM customers WHERE id = ?", (cid,)).fetchone()
        if not existing:
            return jsonify({"error": "Customer not found"}), 404
        conn.execute(f"UPDATE customers SET {set_clause} WHERE id = ?", params)

        if "health_score" in data:
            conn.execute(
                "INSERT INTO customer_health_scores (customer_id, score, recorded_at) VALUES (?, ?, ?)",
                (cid, data["health_score"], now),
            )
            conn.execute(
                "INSERT INTO customer_events (customer_id, event_type, description, created_by) VALUES (?, 'health_score_change', ?, ?)",
                (cid, f"Health score updated to {data['health_score']}", session.get("username", "api")),
            )

    log_access(session.get("username", "api"), "update", "customer", str(cid),
               request.remote_addr, f"Updated fields: {list(updates.keys())}")
    return jsonify({"message": "Customer updated"})


@app.route("/api/service/customers/<int:cid>", methods=["DELETE"])
@require_auth

@rate_limit(requests_per_minute=10)
def service_customer_delete(cid):
    """Delete a customer record."""
    with transaction() as conn:
        existing = conn.execute("SELECT contact_name FROM customers WHERE id = ?", (cid,)).fetchone()
        if not existing:
            return jsonify({"error": "Customer not found"}), 404
        conn.execute("DELETE FROM customers WHERE id = ?", (cid,))

    log_access(session.get("username", "api"), "delete", "customer", str(cid),
               request.remote_addr, f"Deleted customer: {existing['contact_name']}")
    return jsonify({"message": "Customer deleted"})


@app.route("/api/service/customers/bulk-delete", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def service_bulk_delete_customers():
    """Bulk-delete multiple customer records."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    customer_ids = data.get("customer_ids")
    if not customer_ids or not isinstance(customer_ids, list):
        return jsonify({"error": "customer_ids must be a non-empty list"}), 400
    if len(customer_ids) > 500:
        return jsonify({"error": "Maximum 500 customers per request"}), 400
    if not all(isinstance(i, int) for i in customer_ids):
        return jsonify({"error": "customer_ids must be integers"}), 400

    placeholders = ",".join("?" for _ in customer_ids)
    try:
        with transaction() as txn:
            txn.execute(f"DELETE FROM customer_events WHERE customer_id IN ({placeholders})", customer_ids)
            txn.execute(f"DELETE FROM customer_health_scores WHERE customer_id IN ({placeholders})", customer_ids)
            txn.execute(f"DELETE FROM customers WHERE id IN ({placeholders})", customer_ids)
            deleted = txn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk delete customers error: %s", e)
        return jsonify({"error": "Failed to delete customers"}), 500

    log_access(
        session.get("username", "api"), "bulk_delete", "customer",
        ip_address=request.remote_addr,
        details=f"deleted={deleted}",
    )
    return jsonify({"success": True, "deleted": deleted})


@app.route("/api/service/customers/bulk-update-health", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def service_bulk_update_health():
    """Bulk-update health_status for multiple customers."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    customer_ids = data.get("customer_ids")
    new_status = data.get("health_status")
    if not customer_ids or not isinstance(customer_ids, list):
        return jsonify({"error": "customer_ids must be a non-empty list"}), 400
    if len(customer_ids) > 500:
        return jsonify({"error": "Maximum 500 customers per request"}), 400
    if not all(isinstance(i, int) for i in customer_ids):
        return jsonify({"error": "customer_ids must be integers"}), 400
    valid_statuses = {"healthy", "at_risk", "churned"}
    if new_status not in valid_statuses:
        return jsonify({"error": f"Invalid health_status. Must be one of: {', '.join(sorted(valid_statuses))}"}), 400

    # Auto-adjust health_score if inconsistent with new status
    score_adjust = {"healthy": 80, "at_risk": 40, "churned": 0}
    now = datetime.now(timezone.utc).isoformat()
    username = session.get("username", "api")

    try:
        placeholders = ",".join("?" for _ in customer_ids)
        with transaction() as conn:
            conn.execute(
                f"""UPDATE customers SET health_status = ?, updated_at = ?,
                    health_score = CASE WHEN (health_status != ? AND
                        ((? = 'healthy' AND health_score < 60) OR
                         (? = 'at_risk' AND (health_score >= 80 OR health_score <= 20)) OR
                         (? = 'churned' AND health_score > 20)))
                    THEN ? ELSE health_score END
                    WHERE id IN ({placeholders})""",
                [new_status, now, new_status, new_status, new_status, new_status,
                 score_adjust[new_status]] + customer_ids,
            )
            updated = conn.execute("SELECT changes()").fetchone()[0]
            # Record health_score_change events
            for cid in customer_ids:
                conn.execute(
                    "INSERT INTO customer_events (customer_id, event_type, description, created_at) VALUES (?, ?, ?, ?)",
                    (cid, "health_score_change", f"Bulk health status set to {new_status} by {username}", now),
                )
    except Exception as e:
        logger.error("Bulk update health error: %s", e)
        return jsonify({"error": "Failed to update health status"}), 500

    log_access(username, "bulk_update_health", "customer", ip_address=request.remote_addr,
               details=f"status={new_status}, updated={updated}")
    return jsonify({"success": True, "updated": updated})


@app.route("/api/service/customers/bulk-update-tier", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def service_bulk_update_tier():
    """Bulk-update license_tier for multiple customers."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    customer_ids = data.get("customer_ids")
    new_tier = data.get("tier")
    if not customer_ids or not isinstance(customer_ids, list):
        return jsonify({"error": "customer_ids must be a non-empty list"}), 400
    if len(customer_ids) > 500:
        return jsonify({"error": "Maximum 500 customers per request"}), 400
    if not all(isinstance(i, int) for i in customer_ids):
        return jsonify({"error": "customer_ids must be integers"}), 400
    valid_tiers = {"core", "pro"}
    if new_tier is not None and new_tier not in valid_tiers:
        return jsonify({"error": f"Invalid tier. Must be one of: {', '.join(sorted(valid_tiers))} or null"}), 400

    now = datetime.now(timezone.utc).isoformat()
    try:
        placeholders = ",".join("?" for _ in customer_ids)
        with transaction() as conn:
            conn.execute(
                f"UPDATE customers SET license_tier = ?, updated_at = ? WHERE id IN ({placeholders})",
                [new_tier, now] + customer_ids,
            )
            updated = conn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk update tier error: %s", e)
        return jsonify({"error": "Failed to update tier"}), 500

    log_access(session.get("username", "api"), "bulk_update_tier", "customer",
               ip_address=request.remote_addr, details=f"tier={new_tier}, updated={updated}")
    return jsonify({"success": True, "updated": updated})


@app.route("/api/service/customers/bulk-update-onboarding", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def service_bulk_update_onboarding():
    """Bulk-update onboarding_status for multiple customers."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    customer_ids = data.get("customer_ids")
    new_status = data.get("onboarding_status")
    if not customer_ids or not isinstance(customer_ids, list):
        return jsonify({"error": "customer_ids must be a non-empty list"}), 400
    if len(customer_ids) > 500:
        return jsonify({"error": "Maximum 500 customers per request"}), 400
    if not all(isinstance(i, int) for i in customer_ids):
        return jsonify({"error": "customer_ids must be integers"}), 400
    valid_statuses = {"not_started", "in_progress", "completed"}
    if new_status not in valid_statuses:
        return jsonify({"error": f"Invalid onboarding_status. Must be one of: {', '.join(sorted(valid_statuses))}"}), 400

    now = datetime.now(timezone.utc).isoformat()
    try:
        placeholders = ",".join("?" for _ in customer_ids)
        with transaction() as conn:
            sets = ["onboarding_status = ?", "updated_at = ?"]
            params = [new_status, now]
            if new_status == "completed":
                sets.append("onboarding_completed_at = ?")
                params.append(now)
            conn.execute(
                f"UPDATE customers SET {', '.join(sets)} WHERE id IN ({placeholders})",
                params + customer_ids,
            )
            updated = conn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk update onboarding error: %s", e)
        return jsonify({"error": "Failed to update onboarding status"}), 500

    log_access(session.get("username", "api"), "bulk_update_onboarding", "customer",
               ip_address=request.remote_addr, details=f"status={new_status}, updated={updated}")
    return jsonify({"success": True, "updated": updated})


@app.route("/api/service/events", methods=["GET"])
@require_auth
@rate_limit(requests_per_minute=60)
def service_events_list():
    """List customer events with optional filters."""
    customer_id = request.args.get("customer_id", type=int)
    event_type = request.args.get("type", "")
    limit = min(200, max(1, request.args.get("limit", 100, type=int)))

    where = []
    params = []
    if customer_id:
        where.append("ce.customer_id = ?")
        params.append(customer_id)
    if event_type:
        where.append("ce.event_type = ?")
        params.append(event_type)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""

    conn = get_db()
    try:
        rows = conn.execute(
            f"""SELECT ce.*, c.contact_name, c.company
                FROM customer_events ce
                JOIN customers c ON c.id = ce.customer_id
                {where_clause}
                ORDER BY ce.created_at DESC LIMIT ?""",
            params + [limit],
        ).fetchall()
    finally:
        conn.close()

    return jsonify({"events": [dict(r) for r in rows]})


@app.route("/api/service/events", methods=["POST"])
@require_auth

@rate_limit(requests_per_minute=30)
def service_event_create():
    """Create a customer event."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    customer_id = data.get("customer_id")
    event_type = data.get("event_type", "")
    description = data.get("description", "")

    valid_types = {
        "onboarding_call", "support_ticket", "check_in", "renewal",
        "escalation", "nps_survey", "feature_request", "health_score_change",
        "license_activated", "payment_received", "churn", "note",
    }
    if not customer_id or event_type not in valid_types:
        return jsonify({"error": "customer_id and valid event_type required"}), 400

    with transaction() as conn:
        cust = conn.execute("SELECT id FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not cust:
            return jsonify({"error": "Customer not found"}), 404
        cursor = conn.execute(
            "INSERT INTO customer_events (customer_id, event_type, description, metadata_json, created_by) VALUES (?, ?, ?, ?, ?)",
            (customer_id, event_type, description[:2000],
             json.dumps(data.get("metadata")) if data.get("metadata") else None,
             session.get("username", "api")),
        )

    return jsonify({"id": cursor.lastrowid, "message": "Event created"}), 201


@app.route("/api/service/customers/<int:cid>/health-score", methods=["POST"])
@require_auth

@rate_limit(requests_per_minute=30)
def service_record_health_score(cid):
    """Record a health score snapshot for trend tracking."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    score = data.get("score")
    if score is None or not (0 <= int(score) <= 100):
        return jsonify({"error": "score must be 0-100"}), 400

    now = datetime.now(timezone.utc).isoformat()
    with transaction() as conn:
        cust = conn.execute("SELECT id FROM customers WHERE id = ?", (cid,)).fetchone()
        if not cust:
            return jsonify({"error": "Customer not found"}), 404
        conn.execute(
            "INSERT INTO customer_health_scores (customer_id, score, factors_json, recorded_at) VALUES (?, ?, ?, ?)",
            (cid, int(score), json.dumps(data.get("factors")) if data.get("factors") else None, now),
        )
        conn.execute("UPDATE customers SET health_score = ?, updated_at = ? WHERE id = ?", (int(score), now, cid))
        # Auto-update health_status based on score
        if int(score) >= 70:
            status = "healthy"
        elif int(score) >= 40:
            status = "at_risk"
        else:
            status = "churned"
        conn.execute("UPDATE customers SET health_status = ? WHERE id = ?", (status, cid))
        conn.execute(
            "INSERT INTO customer_events (customer_id, event_type, description, created_by) VALUES (?, 'health_score_change', ?, ?)",
            (cid, f"Health score: {score} ({status})", session.get("username", "api")),
        )

    return jsonify({"message": "Health score recorded", "score": int(score), "status": status})


@app.route("/api/service/customers/<int:cid>/health-history")
@require_auth
@rate_limit(requests_per_minute=60)
def service_health_history(cid):
    """Get health score trend for a customer."""
    conn = get_db()
    try:
        cust = conn.execute("SELECT id, contact_name FROM customers WHERE id = ?", (cid,)).fetchone()
        if not cust:
            return jsonify({"error": "Customer not found"}), 404
        rows = conn.execute(
            "SELECT score, factors_json, recorded_at FROM customer_health_scores WHERE customer_id = ? ORDER BY recorded_at DESC LIMIT 90",
            (cid,),
        ).fetchall()
    finally:
        conn.close()

    return jsonify({"customer_id": cid, "name": cust["contact_name"], "history": [dict(r) for r in rows]})


@app.route("/api/service/customers/sync-sheets", methods=["POST"])
@require_auth

@rate_limit(requests_per_minute=5)
def service_sync_sheets():
    """Sync customers from a Google Sheet (same pattern as CRM sync)."""
    import csv
    import requests as req_lib

    config = load_config()
    sheet_id = request.get_json(silent=True) or {}
    sheet_id = sheet_id.get("sheet_id") or config.get("service", {}).get("google_sheet_id")
    if not sheet_id:
        return jsonify({"error": "No sheet_id provided or configured"}), 400

    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv"
    try:
        resp = req_lib.get(url, timeout=30)
        resp.raise_for_status()
    except Exception as e:
        return jsonify({"error": f"Failed to fetch sheet: {e}"}), 502

    if "text/html" in resp.headers.get("Content-Type", ""):
        return jsonify({"error": "Sheet returned HTML. Ensure it is shared publicly."}), 400

    text = resp.text
    if not text.strip():
        return jsonify({"imported": 0, "skipped": 0, "errors": ["Sheet is empty"]})

    reader = csv.DictReader(io.StringIO(text))
    raw_headers = reader.fieldnames or []
    header_aliases = {
        "contact_name": ["contact name", "name", "contact_name", "customer name", "full name"],
        "contact_email": ["email", "contact email", "contact_email", "email address"],
        "company": ["company", "firm", "organization", "org", "law firm"],
        "phone": ["phone", "phone number", "tel"],
        "license_tier": ["tier", "license_tier", "license tier", "plan"],
        "license_key": ["license_key", "license key", "key"],
    }
    col_map = {}
    for field, aliases in header_aliases.items():
        for h in raw_headers:
            if h.strip().lower() in aliases:
                col_map[field] = h
                break

    if "contact_email" not in col_map:
        return jsonify({"imported": 0, "skipped": 0, "errors": [f"No email column found. Headers: {raw_headers}"]})

    results = {"imported": 0, "updated": 0, "skipped": 0, "errors": []}
    now = datetime.now(timezone.utc).isoformat()

    try:
        with transaction() as conn:
            for row_num, row in enumerate(reader, start=2):
                email_val = (row.get(col_map.get("contact_email", ""), "") or "").strip().lower()
                if not email_val:
                    results["skipped"] += 1
                    continue

                name_val = (row.get(col_map.get("contact_name", ""), "") or "").strip() or email_val.split("@")[0]
                company_val = (row.get(col_map.get("company", ""), "") or "").strip()
                phone_val = (row.get(col_map.get("phone", ""), "") or "").strip()
                tier_val = (row.get(col_map.get("license_tier", ""), "") or "").strip().lower()
                key_val = (row.get(col_map.get("license_key", ""), "") or "").strip()

                if tier_val not in ("core", "pro"):
                    tier_val = None

                existing = conn.execute("SELECT id FROM customers WHERE contact_email = ?", (email_val,)).fetchone()
                if existing:
                    results["skipped"] += 1
                    continue

                conn.execute(
                    """INSERT INTO customers (contact_name, contact_email, company, phone,
                       license_tier, license_key, health_status, onboarding_status, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, 'healthy', 'not_started', ?, ?)""",
                    (name_val[:200], email_val, company_val[:300], phone_val[:50], tier_val, key_val, now, now),
                )
                results["imported"] += 1
    except Exception as e:
        results["errors"].append(str(e))

    return jsonify(results)


@app.route("/api/service/customers/sync-stripe", methods=["POST"])
@require_auth

@rate_limit(requests_per_minute=5)
def service_sync_stripe():
    """Sync customer data from Stripe API (subscriptions + charges)."""
    try:
        import stripe as stripe_lib
    except ImportError:
        return jsonify({"error": "stripe package not installed"}), 500

    stripe_key = os.environ.get("STRIPE_SECRET_KEY")
    if not stripe_key:
        return jsonify({"error": "STRIPE_SECRET_KEY not configured"}), 400

    stripe_lib.api_key = stripe_key
    results = {"created": 0, "updated": 0, "errors": []}
    now = datetime.now(timezone.utc).isoformat()

    try:
        customers_iter = stripe_lib.Customer.list(limit=100)
        with transaction() as conn:
            for sc in customers_iter.auto_paging_iter():
                email = (sc.get("email") or "").strip().lower()
                if not email:
                    continue

                existing = conn.execute("SELECT id FROM customers WHERE contact_email = ?", (email,)).fetchone()

                # Get active subscriptions
                sub_mrr = 0
                sub_id = None
                renewal_date = None
                subs = stripe_lib.Subscription.list(customer=sc["id"], status="active", limit=1)
                if subs.data:
                    sub = subs.data[0]
                    sub_id = sub["id"]
                    sub_mrr = (sub.get("plan", {}).get("amount", 0) or 0) // 100
                    if sub.get("current_period_end"):
                        renewal_date = datetime.fromtimestamp(sub["current_period_end"], tz=timezone.utc).isoformat()

                if existing:
                    conn.execute(
                        """UPDATE customers SET stripe_customer_id=?, stripe_subscription_id=?,
                           mrr=?, renewal_date=?, updated_at=? WHERE id=?""",
                        (sc["id"], sub_id, sub_mrr, renewal_date, now, existing["id"]),
                    )
                    results["updated"] += 1
                else:
                    name = sc.get("name") or email.split("@")[0]
                    conn.execute(
                        """INSERT INTO customers (contact_name, contact_email, company,
                           stripe_customer_id, stripe_subscription_id, mrr, renewal_date,
                           health_status, onboarding_status, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 'healthy', 'not_started', ?, ?)""",
                        (name[:200], email, sc.get("metadata", {}).get("company", ""),
                         sc["id"], sub_id, sub_mrr, renewal_date, now, now),
                    )
                    results["created"] += 1
    except Exception as e:
        results["errors"].append(str(e))

    return jsonify(results)


@app.route("/api/service/customers/export")
@require_auth
@rate_limit(requests_per_minute=10)
def service_customers_export():
    """Export customers as JSON or CSV."""
    fmt = request.args.get("format", "json")
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM customers ORDER BY created_at DESC").fetchall()
    finally:
        conn.close()

    customers = [dict(r) for r in rows]

    if fmt == "csv":
        import csv
        output = io.StringIO()
        if customers:
            writer = csv.DictWriter(output, fieldnames=customers[0].keys())
            writer.writeheader()
            writer.writerows(customers)
        resp = make_response(output.getvalue())
        resp.headers["Content-Type"] = "text/csv"
        resp.headers["Content-Disposition"] = "attachment; filename=customers_export.csv"
        return resp

    return jsonify({"customers": customers, "total": len(customers)})


# ── Main ─────────────────────────────────────────────────────────────────────

def _check_port_available(host: str, port: int) -> bool:
    """Check if the port is available before starting Flask.
    Uses SO_REUSEADDR to avoid false positives from TIME_WAIT sockets on Windows."""
    import socket
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
        return True
    except OSError:
        return False


def main():
    parser = argparse.ArgumentParser(description="Medical Records Web UI")
    parser.add_argument("--port", type=int, default=None, help="Port to listen on")
    args = parser.parse_args()

    try:
        # Ensure vault directories exist
        for d in [VAULT_INCOMING, VAULT_SUMMARIES, VAULT_AUDIT, PIPELINE_STATUS_DIR]:
            d.mkdir(parents=True, exist_ok=True)

        config = load_config()
        ui_config = config.get("web_ui", {})

        host = ui_config.get("host", "127.0.0.1")
        port = args.port or ui_config.get("port", 8080)
        max_mb = ui_config.get("max_upload_mb", 100)
        app.config["MAX_CONTENT_LENGTH"] = max_mb * 1024 * 1024

        # Initialize database
        init_db()

        # Ensure dependencies (Ollama + Models)
        from dependency_manager import DependencyManager
        deps = DependencyManager(config)
        deps.check_disk_space()
        deps.check_all()

        # Check if port is available
        if not _check_port_available(host, port):
            logger.error(
                "Port %d is already in use. Another instance may be running. "
                "Stop it first or use --port to specify a different port.", port
            )
            raise SystemExit(1)

        # Validate startup configuration
        issues = validate_startup_config(app, config, logger)
        critical = [i for i in issues if i.startswith("CRITICAL")]
        if critical:
            logger.error("Startup blocked by %d critical issue(s). Fix and retry.", len(critical))
            for c in critical:
                logger.error("  %s", c)
            raise SystemExit(1)

        # Startup sync: pull leads from Google Sheet if configured
        sheet_id = config.get("crm", {}).get("google_sheet_id")
        if sheet_id:
            try:
                results = _sync_google_sheet_leads(sheet_id, caller="startup")
                logger.info(
                    "Startup Google Sheet sync: %d imported, %d skipped",
                    results["imported"], results["skipped"],
                )
            except Exception as e:
                logger.warning("Startup Google Sheet sync failed (non-blocking): %s", e)

        logger.info("Medical Records UI starting on http://%s:%d", host, port)
        logger.info("Health check: http://%s:%d/health", host, port)
        app.run(host=host, port=port, debug=False, threaded=True)

    except SystemExit:
        raise
    except Exception as e:
        logger.error("Fatal startup error: %s", e, exc_info=True)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
