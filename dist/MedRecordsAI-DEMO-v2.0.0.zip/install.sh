#!/usr/bin/env bash
#
# MedRecords AI - Installer (Mac/Linux)
# AI Productivity Dev
#

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ---------------------------------------------------------------
#  Banner
# ---------------------------------------------------------------
echo ""
echo "  ================================================================"
echo "    MedRecords AI - Intelligent Document Analysis Platform"
echo "    HIPAA-Compliant Medical Record Summarization & Demand Packages"
echo "  ================================================================"
echo ""

# ---------------------------------------------------------------
#  Demo build detection
# ---------------------------------------------------------------
IS_DEMO=0
if [ -f "$SCRIPT_DIR/.demo_build" ]; then
    IS_DEMO=1
    echo "  [INFO] Demo build detected."
    echo "         This installation is limited to 14 days and 3 cases."
    echo ""
fi

# ---------------------------------------------------------------
#  EULA display and acceptance
# ---------------------------------------------------------------
EULA_FILE="$SCRIPT_DIR/EULA.txt"

if [ ! -f "$EULA_FILE" ]; then
    echo "  [ERROR] EULA.txt not found. Cannot proceed with installation."
    exit 1
fi

echo "  Please review the End User License Agreement:"
echo "  ----------------------------------------------------------------"
echo ""

# Display EULA with paging if available
if command -v less >/dev/null 2>&1; then
    less "$EULA_FILE"
elif command -v more >/dev/null 2>&1; then
    more "$EULA_FILE"
else
    cat "$EULA_FILE"
fi

echo ""
echo "  ----------------------------------------------------------------"
echo ""

while true; do
    printf "  Do you accept the End User License Agreement? (Y/N): "
    read -r EULA_RESPONSE
    case "$EULA_RESPONSE" in
        [Yy]|[Yy][Ee][Ss])
            echo ""
            echo "  [OK] License agreement accepted."
            echo ""
            break
            ;;
        [Nn]|[Nn][Oo])
            echo ""
            echo "  Installation cancelled. You must accept the EULA to proceed."
            exit 1
            ;;
        *)
            echo "  Please enter Y or N."
            ;;
    esac
done

# ---------------------------------------------------------------
#  Python version check
# ---------------------------------------------------------------
echo "  Checking Python installation..."
echo ""

PYTHON_CMD=""

# Try python3 first, then python
if command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_CMD="python"
fi

if [ -z "$PYTHON_CMD" ]; then
    echo "  [ERROR] Python not found."
    echo "          Install Python 3.10+ from https://www.python.org"
    echo ""
    echo "          On macOS:   brew install python3"
    echo "          On Ubuntu:  sudo apt install python3"
    echo "          On Fedora:  sudo dnf install python3"
    exit 1
fi

# Verify version is 3.10+
PYTHON_VERSION=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)

if [ -z "$PYTHON_VERSION" ]; then
    echo "  [ERROR] Could not determine Python version."
    exit 1
fi

PYTHON_MAJOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.major)" 2>/dev/null)
PYTHON_MINOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.minor)" 2>/dev/null)

if [ "$PYTHON_MAJOR" -lt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 10 ]; }; then
    echo "  [ERROR] Python 3.10 or higher is required."
    echo "          Found: Python $PYTHON_VERSION"
    echo "          Please upgrade Python from https://www.python.org"
    exit 1
fi

echo "  [OK] Python $PYTHON_VERSION found"
echo ""

# ---------------------------------------------------------------
#  Run setup
# ---------------------------------------------------------------
echo "  Running setup..."
echo ""

if ! $PYTHON_CMD "$SCRIPT_DIR/setup_medical.py" --product-mode; then
    echo ""
    echo "  [ERROR] Setup encountered errors. See output above."
    echo ""
    exit 1
fi

# ---------------------------------------------------------------
#  Success
# ---------------------------------------------------------------
echo ""
echo "  ================================================================"
echo "    Installation Complete!"
echo ""
if [ "$IS_DEMO" -eq 1 ]; then
    echo "    Demo License: 14 days | 3 cases | Watermarked output"
    echo ""
fi
echo "    To start MedRecords AI:"
echo "      Run: ./launch.sh"
echo "      Or:  $PYTHON_CMD start_medical.py"
echo ""
echo "    Dashboard: http://localhost:8080"
echo "  ================================================================"
echo ""
