"""
start_team.py — Launch all 5 agent Slack bots + the task runner in one command.

Usage:
  python start_team.py

Each agent runs as a subprocess. Press Ctrl+C to stop all.
Requires all AGENT_SLACK_BOT_TOKEN / AGENT_SLACK_APP_TOKEN vars to be set in .env
"""

import os
import subprocess
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent
AGENTS = ["aria", "forge", "nova", "scout", "sage"]

processes = {}


def start_agent(name):
    env = {**os.environ, "AGENT_NAME": name}
    proc = subprocess.Popen(
        [sys.executable, str(BASE_DIR / "agent_bot.py")],
        env=env,
    )
    print(f"  ✓ {name:10} started (pid={proc.pid})")
    return proc


def start_runner():
    proc = subprocess.Popen(
        [sys.executable, str(BASE_DIR / "runner.py")],
    )
    print(f"  ✓ runner     started (pid={proc.pid})")
    return proc


def main():
    print("\n=== Starting AI Team ===\n")

    for name in AGENTS:
        processes[name] = start_agent(name)
        time.sleep(0.5)

    processes["runner"] = start_runner()

    print("\nAll processes started. Press Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(15)
            # Health check — restart any that have crashed
            for name, proc in list(processes.items()):
                if proc.poll() is not None:
                    print(f"[!] {name} exited (code={proc.returncode}), restarting...")
                    if name == "runner":
                        processes[name] = start_runner()
                    else:
                        processes[name] = start_agent(name)
    except KeyboardInterrupt:
        print("\nStopping all processes...")
        for name, proc in processes.items():
            proc.terminate()
        print("Done.")


if __name__ == "__main__":
    main()
