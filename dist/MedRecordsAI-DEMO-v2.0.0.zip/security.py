"""
security.py -- Production security middleware for MedRecords AI.

Provides:
- Session-based authentication with login/logout
- Rate limiting (in-memory token bucket)
- CSRF double-submit cookie protection
- Security response headers (CSP, X-Frame-Options, etc.)
- Input sanitization and validation utilities
- XSS-safe HTML escaping

Usage:
    from security import init_security, require_auth, rate_limit

    app = Flask(__name__)
    init_security(app)

    @app.route("/api/data")
    @require_auth
    @rate_limit(requests_per_minute=30)
    def protected():
        ...
"""

import functools
import hashlib
import hmac
import html
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import datetime, timezone

from flask import (
    Flask, request, session, jsonify, redirect, url_for,
    make_response, g,
)


# ── Configuration ─────────────────────────────────────────────────────────────

# Default credentials - MUST be changed via environment variables
DEFAULT_ADMIN_USER = "admin"


def _get_password_hash(password: str) -> str:
    """Hash a password with SHA-256 + salt for storage."""
    salt = os.getenv("AUTH_SALT", "medrecords-default-salt")
    return hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()


# ── Rate Limiter (In-Memory Token Bucket) ────────────────────────────────────

class RateLimiter:
    """Simple in-memory rate limiter using token bucket algorithm."""

    def __init__(self):
        self._buckets = defaultdict(lambda: {"tokens": 0, "last_refill": 0.0})

    def is_allowed(self, key: str, max_tokens: int, refill_rate: float) -> bool:
        """
        Check if request is allowed.
        max_tokens: maximum burst size
        refill_rate: tokens added per second
        """
        now = time.time()
        bucket = self._buckets[key]

        # Refill tokens
        elapsed = now - bucket["last_refill"]
        bucket["tokens"] = min(max_tokens, bucket["tokens"] + elapsed * refill_rate)
        bucket["last_refill"] = now

        if bucket["tokens"] >= 1:
            bucket["tokens"] -= 1
            return True
        return False

    def cleanup(self, max_age_seconds: int = 3600):
        """Remove stale entries to prevent memory leaks."""
        now = time.time()
        stale = [k for k, v in self._buckets.items()
                 if now - v["last_refill"] > max_age_seconds]
        for k in stale:
            del self._buckets[k]


_limiter = RateLimiter()
_last_cleanup = time.time()


def rate_limit(requests_per_minute: int = 30, burst: int = None):
    """
    Decorator: rate-limit an endpoint by client IP.
    Uses token bucket for smooth rate limiting with burst tolerance.
    """
    burst = burst or requests_per_minute
    refill_rate = requests_per_minute / 60.0

    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            global _last_cleanup
            client_ip = request.remote_addr or "unknown"
            key = f"{f.__name__}:{client_ip}"

            if not _limiter.is_allowed(key, burst, refill_rate):
                return jsonify({
                    "error": "Rate limit exceeded. Please try again later.",
                }), 429

            # Periodic cleanup (every 10 min)
            now = time.time()
            if now - _last_cleanup > 600:
                _limiter.cleanup()
                _last_cleanup = now

            return f(*args, **kwargs)
        return wrapper
    return decorator


# ── CSRF Protection ──────────────────────────────────────────────────────────

def _generate_csrf_token() -> str:
    """Generate a new CSRF token and store in session."""
    token = secrets.token_hex(32)
    session["_csrf_token"] = token
    return token


def get_csrf_token() -> str:
    """Get the current CSRF token, or generate one if missing."""
    if "_csrf_token" not in session:
        return _generate_csrf_token()
    return session["_csrf_token"]


def _validate_csrf():
    """Validate CSRF token on state-changing requests."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return

    # Skip CSRF for login (no session exists yet) and token-authenticated uploads
    if request.path in ("/login", "/logout"):
        return
    if request.path.startswith("/api/secure-upload/"):
        return

    # Skip for API key auth (non-browser clients)
    if request.headers.get("X-API-Key"):
        return

    token = (
        request.headers.get("X-CSRF-Token")
        or request.form.get("_csrf_token")
        or (request.get_json(silent=True) or {}).get("_csrf_token")
    )
    expected = session.get("_csrf_token")

    if not token or not expected or not hmac.compare_digest(token, expected):
        return jsonify({"error": "CSRF validation failed"}), 403


# ── Authentication ───────────────────────────────────────────────────────────

def require_auth(f):
    """Decorator: require authenticated session or valid API key."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        # Check session auth
        if session.get("authenticated"):
            g.auth_user = session.get("username", "session_user")
            return f(*args, **kwargs)

        # Check API key auth
        api_key = request.headers.get("X-API-Key")
        expected_key = os.getenv("API_KEY")
        if api_key and expected_key and hmac.compare_digest(api_key, expected_key):
            g.auth_user = "api_key_user"
            return f(*args, **kwargs)

        # Not authenticated
        if request.path.startswith("/api/"):
            return jsonify({"error": "Authentication required"}), 401
        return redirect("/login")

    return wrapper


def _check_credentials(username: str, password: str) -> bool:
    """Validate login credentials against environment variables."""
    expected_user = os.getenv("AUTH_USERNAME", DEFAULT_ADMIN_USER)
    expected_hash = os.getenv("AUTH_PASSWORD_HASH")

    if not expected_hash:
        # Fallback: use AUTH_PASSWORD env var (hash it on the fly)
        expected_password = os.getenv("AUTH_PASSWORD", "")
        if not expected_password:
            return False
        expected_hash = _get_password_hash(expected_password)

    provided_hash = _get_password_hash(password)
    return (
        hmac.compare_digest(username, expected_user)
        and hmac.compare_digest(provided_hash, expected_hash)
    )


# ── Security Headers ─────────────────────────────────────────────────────────

def _add_security_headers(response):
    """Add security headers to every response."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"

    # Content Security Policy
    csp = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "font-src 'self'; "
        "connect-src 'self' http://localhost:11434; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    )
    response.headers["Content-Security-Policy"] = csp

    # Cache control for sensitive data
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
        response.headers["Pragma"] = "no-cache"

    return response


# ── Input Validation ─────────────────────────────────────────────────────────

EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
MAX_FIELD_LENGTHS = {
    "contact_name": 200,
    "contact_email": 254,
    "organization": 300,
    "patient_case_ref": 100,
    "record_type_needed": 100,
    "notes": 2000,
    "priority": 20,
    "contact_type": 50,
}


def validate_contact_input(data: dict) -> list:
    """Validate contact creation/update input. Returns list of error strings."""
    errors = []

    if not data:
        return ["Request body is required"]

    name = data.get("contact_name", "").strip()
    email = data.get("contact_email", "").strip()

    if not name:
        errors.append("contact_name is required")
    if not email:
        errors.append("contact_email is required")
    elif not EMAIL_RE.match(email):
        errors.append("contact_email is not a valid email address")

    # Length validation
    for field, max_len in MAX_FIELD_LENGTHS.items():
        value = data.get(field, "")
        if isinstance(value, str) and len(value) > max_len:
            errors.append(f"{field} exceeds maximum length of {max_len} characters")

    # Enum validation
    valid_types = {"custodian", "counsel", "patient", "provider"}
    if data.get("contact_type") and data["contact_type"] not in valid_types:
        errors.append(f"contact_type must be one of: {', '.join(valid_types)}")

    valid_priorities = {"normal", "high", "urgent"}
    if data.get("priority") and data["priority"] not in valid_priorities:
        errors.append(f"priority must be one of: {', '.join(valid_priorities)}")

    return errors


def sanitize_string(value: str, max_length: int = 500) -> str:
    """Sanitize a string: trim, limit length, escape HTML entities."""
    if not isinstance(value, str):
        return ""
    return html.escape(value.strip()[:max_length])


# ── Startup Validation ───────────────────────────────────────────────────────

def validate_startup_config(app, config: dict, logger) -> list:
    """
    Validate critical configuration at startup.
    Returns list of warnings. Raises SystemExit on critical failures.
    """
    warnings = []
    errors = []

    # Flask secret key
    secret = app.secret_key
    if not secret or secret in ("dev-secret-change-me", "change-this"):
        errors.append(
            "CRITICAL: Flask secret key is not set or uses default value. "
            "Set FLASK_SECRET_KEY environment variable."
        )

    # Auth credentials
    auth_password = os.getenv("AUTH_PASSWORD", "")
    auth_hash = os.getenv("AUTH_PASSWORD_HASH", "")
    if not auth_password and not auth_hash:
        warnings.append(
            "WARNING: No AUTH_PASSWORD or AUTH_PASSWORD_HASH set. "
            "Login will be disabled. Set AUTH_PASSWORD in .env for production."
        )

    # API key
    api_key = os.getenv("API_KEY", "")
    if not api_key:
        warnings.append(
            "WARNING: No API_KEY set. API key authentication is disabled."
        )

    # SMTP config (only warn, not required)
    smtp_host = os.getenv("SMTP_HOST", "")
    if smtp_host and smtp_host in ("smtp.example.com", ""):
        warnings.append(
            "WARNING: SMTP_HOST is not configured. Email retrieval bot will not function."
        )

    # Ollama endpoint
    ollama_cfg = config.get("ollama", {})
    if not ollama_cfg.get("endpoint"):
        warnings.append("WARNING: Ollama endpoint not configured in config.yaml")

    for w in warnings:
        logger.warning(w)
    for e in errors:
        logger.error(e)

    return warnings + errors


# ── Audit Signing (HMAC) ────────────────────────────────────────────────────

def sign_audit_entry(entry: dict) -> str:
    """
    Generate HMAC-SHA256 signature for an audit entry.
    Uses AUDIT_HMAC_KEY from environment, or derives from Flask secret.
    """
    key = os.getenv("AUDIT_HMAC_KEY", os.getenv("FLASK_SECRET_KEY", ""))
    if not key:
        key = "unsigned-audit-entry"

    # Canonical representation: sorted JSON without the signature field
    canonical = {k: v for k, v in sorted(entry.items()) if k != "hmac_signature"}
    import json
    payload = json.dumps(canonical, sort_keys=True, default=str)
    return hmac.new(key.encode(), payload.encode(), hashlib.sha256).hexdigest()


def verify_audit_signature(entry: dict) -> bool:
    """Verify an audit entry's HMAC signature."""
    stored_sig = entry.get("hmac_signature")
    if not stored_sig:
        return False
    expected_sig = sign_audit_entry(entry)
    return hmac.compare_digest(stored_sig, expected_sig)


# ── Init ─────────────────────────────────────────────────────────────────────

def init_security(app: Flask):
    """
    Initialize all security middleware on the Flask app.
    Call this once after app creation.
    """
    # Ensure secret key is set
    secret = os.getenv("FLASK_SECRET_KEY", "")
    if secret:
        app.secret_key = secret
    elif not app.secret_key:
        app.secret_key = secrets.token_hex(32)
        app.logger.warning(
            "No FLASK_SECRET_KEY set. Generated ephemeral key (sessions won't "
            "survive restart). Set FLASK_SECRET_KEY in .env for production."
        )

    # Session config
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = os.getenv("FLASK_ENV") == "production"
    app.config["PERMANENT_SESSION_LIFETIME"] = 28800  # 8 hours

    # Register CSRF check before every request
    @app.before_request
    def csrf_check():
        result = _validate_csrf()
        if result:
            return result

    # Inject CSRF token into template context
    @app.context_processor
    def inject_csrf():
        return {"csrf_token": get_csrf_token}

    # Add security headers after every response
    app.after_request(_add_security_headers)

    # Make CSRF token available via API for SPA
    @app.route("/api/csrf-token")
    def csrf_token_endpoint():
        return jsonify({"csrf_token": get_csrf_token()})
