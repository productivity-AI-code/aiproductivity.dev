"""
agent_bot.py — Generic Slack bot for AI team members.

Each agent (aria, forge, nova, scout, sage) runs this script with their
own AGENT_NAME and Slack credentials. They respond using their local
Ollama model and their personality from agents/<name>/prompt.md.

Usage:
  Windows:  set AGENT_NAME=aria && python agent_bot.py
  Mac/Linux: AGENT_NAME=aria python agent_bot.py
"""

import json
import logging
import os
import subprocess
import threading
from pathlib import Path

import requests
from dotenv import load_dotenv
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler

load_dotenv()

BASE_DIR = Path(__file__).parent
AGENTS_DIR = BASE_DIR / "agents"
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")

AGENT_NAME = os.environ.get("AGENT_NAME", "").lower()
if not AGENT_NAME:
    raise ValueError(
        "AGENT_NAME env var must be set. "
        "Example: set AGENT_NAME=aria && python agent_bot.py"
    )

# Load agent config and personality
config_file = AGENTS_DIR / AGENT_NAME / "config.json"
prompt_file = AGENTS_DIR / AGENT_NAME / "prompt.md"

with open(config_file) as f:
    config = json.load(f)

SYSTEM_PROMPT = prompt_file.read_text(encoding="utf-8")
MODEL = config["model"]
ROLE = config["role"]

# Load this agent's Slack credentials
token_key = f"{AGENT_NAME.upper()}_SLACK_BOT_TOKEN"
app_token_key = f"{AGENT_NAME.upper()}_SLACK_APP_TOKEN"
BOT_TOKEN = os.environ.get(token_key)
APP_TOKEN = os.environ.get(app_token_key)

if not BOT_TOKEN or not APP_TOKEN:
    raise ValueError(
        f"Missing Slack credentials. Set {token_key} and {app_token_key} in .env"
    )

# Logging
log_file = BASE_DIR / f"{AGENT_NAME}-slack.log"
logging.basicConfig(
    level=logging.INFO,
    format=f"%(asctime)s [{AGENT_NAME}] [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S UTC",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(AGENT_NAME)

app = App(token=BOT_TOKEN)

# Per-channel conversation history
conversations = {}


def get_history(channel_id):
    if channel_id not in conversations:
        conversations[channel_id] = []
    return conversations[channel_id]


def call_ollama(user_message, channel_id):
    """Send message to Ollama using the REST API for proper multi-turn conversation."""
    history = get_history(channel_id)
    history.append({"role": "user", "content": user_message})

    # Keep last 10 exchanges
    if len(history) > 20:
        history = history[-20:]
        conversations[channel_id] = history

    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history

    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={"model": MODEL, "messages": messages, "stream": False},
            timeout=300,
        )
        response.raise_for_status()
        reply = response.json()["message"]["content"].strip()
        history.append({"role": "assistant", "content": reply})
        return reply
    except requests.exceptions.ConnectionError:
        return f"I can't reach Ollama right now. Make sure Ollama is running at {OLLAMA_URL}."
    except requests.exceptions.Timeout:
        return "My response timed out. For long tasks, use the dispatch queue instead."
    except Exception as e:
        logger.error("Ollama error: %s", e)
        return f"Something went wrong on my end. Try again in a moment."


def respond_async(user_message, channel_id, say):
    """Run Ollama in a background thread so Slack doesn't time out."""
    say(f"_Working on it... (running on {MODEL})_")

    def worker():
        logger.info("INCOMING | channel=%s | message=%r", channel_id, user_message[:100])
        reply = call_ollama(user_message, channel_id)
        say(reply)
        logger.info("OUTGOING | channel=%s | reply=%r", channel_id, reply[:100])

    threading.Thread(target=worker, daemon=True).start()


@app.event("app_mention")
def handle_mention(event, say):
    channel = event["channel"]
    text = event.get("text", "")
    user_message = text.split(">", 1)[-1].strip() or "Hello!"
    respond_async(user_message, channel, say)


@app.event("message")
def handle_dm(event, say):
    if event.get("channel_type") != "im":
        return
    if event.get("bot_id"):
        return
    user_message = event.get("text", "")
    if not user_message:
        return
    respond_async(user_message, event["channel"], say)


if __name__ == "__main__":
    logger.info("%s (%s) is online — model: %s", AGENT_NAME.title(), ROLE, MODEL)
    handler = SocketModeHandler(app, APP_TOKEN, ping_interval=10)
    handler.start()
