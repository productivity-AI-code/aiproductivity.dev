"""
orchestrator.py — Runs the full 5-stage project pipeline.

Called by clawbot when a project is assigned via Slack. Dispatches tasks
to each agent in sequence, waits for completion, chains outputs, and posts
status updates + final completion back to Slack.

Usage (called by clawbot automatically, or manually):
  python orchestrator.py --brief "Build a customer service chatbot for a bakery" \
                         --channel C1234567 \
                         --user U1234567
"""

import argparse
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import requests
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent
AGENTS_DIR = BASE_DIR / "agents"
INBOX_DIR = BASE_DIR / "queues" / "inbox"
OUTBOX_DIR = BASE_DIR / "queues" / "outbox"
STAGING_DIR = BASE_DIR / "staging"
BOT_LOG = BASE_DIR / "BOT_LOG.md"

POLL_INTERVAL = 30          # seconds between completion checks
MAX_WAIT = 5 * 8 * 3600    # 5 business days in seconds
MAX_STAGE_ATTEMPTS = 2      # original attempt + 1 retry on failure
CASCADE_ABORT_THRESHOLD = 2 # abort pipeline if N consecutive stages fail

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [orchestrator] [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S UTC",
    handlers=[
        logging.FileHandler(BASE_DIR / "orchestrator.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("orchestrator")


def load_agents():
    agents = {}
    for agent_dir in AGENTS_DIR.iterdir():
        config_file = agent_dir / "config.json"
        if config_file.exists():
            with open(config_file) as f:
                agents[agent_dir.name] = json.load(f)
    return agents


def dispatch_task(agent_name, task, context, agents, project_id):
    """Write a task JSON to the agent's inbox. Returns task_id."""
    task_id = f"{project_id}_{agent_name}"
    inbox = INBOX_DIR / agent_name
    inbox.mkdir(parents=True, exist_ok=True)

    payload = {
        "task_id": task_id,
        "project_id": project_id,
        "agent": agent_name,
        "model": agents[agent_name]["model"],
        "role": agents[agent_name]["role"],
        "task": task,
        "context": context,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "started_at": None,
        "completed_at": None,
    }

    with open(inbox / f"{task_id}.json", "w") as f:
        json.dump(payload, f, indent=2)

    logger.info("Dispatched %s -> %s", agent_name, task_id)
    return task_id


def wait_for_task(task_id, notify_fn):
    """Poll OUTBOX_DIR until task_id.json appears. Returns (status, output)."""
    result_file = OUTBOX_DIR / f"{task_id}.json"
    waited = 0

    while waited < MAX_WAIT:
        if result_file.exists():
            with open(result_file) as f:
                result = json.load(f)
            return result.get("status", "unknown"), result.get("output", "")

        time.sleep(POLL_INTERVAL)
        waited += POLL_INTERVAL

        # Progress pings every 10 minutes
        if waited % 600 == 0:
            notify_fn(f"Still working on `{task_id}`... ({waited // 60}m elapsed)")

    return "timeout", ""


def read_staging(task_id, agent_name):
    """Read the output file from staging."""
    output_file = STAGING_DIR / task_id / f"{agent_name}_output.md"
    if output_file.exists():
        return output_file.read_text(encoding="utf-8")
    return ""


def log_to_bot_log(project_id, line):
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    with open(BOT_LOG, "a", encoding="utf-8") as f:
        f.write(f"\n## [{timestamp}] {project_id}\n{line}\n")


# ── Autonomous stage runner ───────────────────────────────────────────────────

def run_stage(stage_num, agent_name, task, context, agents, project_id, notify_fn):
    """
    Dispatch a stage and wait for completion. Retries once with trimmed context on failure.
    Returns (status, output).
    """
    for attempt in range(1, MAX_STAGE_ATTEMPTS + 1):
        attempt_context = context
        if attempt > 1:
            max_len = int(len(context) * 0.60)
            attempt_context = context[:max_len] + "\n\n[Context trimmed for retry — see staging for full outputs]"
            notify_fn(
                f"Retrying *{agent_name}* (attempt {attempt}/{MAX_STAGE_ATTEMPTS}) "
                f"with trimmed context ({max_len} chars)..."
            )

        task_id = dispatch_task(agent_name, task, attempt_context, agents, project_id)
        status, _ = wait_for_task(task_id, notify_fn)
        output = read_staging(task_id, agent_name)

        if status == "completed":
            return status, output, task_id

        if attempt < MAX_STAGE_ATTEMPTS:
            notify_fn(
                f"Stage {stage_num} (*{agent_name}*) {status} on attempt {attempt}. "
                f"Retrying with reduced context..."
            )

    return status, output, task_id


def _cascade_abort(project_id, failure_count, last_agent, notify_fn):
    """Post an actionable abort alert and log it."""
    message = (
        f"PIPELINE ABORTED — Project `{project_id}`\n\n"
        f"{failure_count} consecutive stages have failed. "
        f"Last: *{last_agent}*. Continuing would produce unusable output.\n\n"
        f"*Next steps:*\n"
        f"• Check Ollama: `ollama ps`\n"
        f"• Check task log: `python dispatch.py --status`\n"
        f"• Restart runner: `pm2 restart runner`\n"
        f"• Re-run: `python orchestrator.py --brief \"...\" --channel C... --user U...`"
    )
    notify_fn(message)
    log_to_bot_log(project_id, f"- **STATUS: ABORTED** — {failure_count} consecutive failures at {last_agent}")
    logger.error("Project %s aborted after %d consecutive failures at %s",
                 project_id, failure_count, last_agent)


# ── Main pipeline ─────────────────────────────────────────────────────────────

_SAFE_ID_RE = re.compile(r'^[a-zA-Z0-9_-]+$')


def _validate_project_id(project_id):
    """Reject project IDs that could cause path traversal in staging/."""
    if not _SAFE_ID_RE.match(project_id):
        raise ValueError(
            f"Invalid project_id {project_id!r}: only alphanumeric, dash, "
            "and underscore are allowed."
        )
    return project_id


def run_project(brief, notify_fn, project_id=None):
    """
    Full 5-stage pipeline: aria -> nova -> forge -> scout -> sage.
    Retries each stage once on failure. Aborts if 2+ consecutive stages fail.
    notify_fn(message) posts updates to Slack.
    """
    if not project_id:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        project_id = f"proj_{ts}_{uuid4().hex[:6]}"
    else:
        _validate_project_id(project_id)

    agents = load_agents()
    consecutive_failures = 0

    log_to_bot_log(project_id, f"- **STATUS:** STARTED\n- **Brief:** {brief[:200]}")
    notify_fn(
        f"Project `{project_id}` started\n"
        f"> {brief}\n\n"
        f"The team is on it. I'll update you after each stage."
    )

    # ── Stage 1: aria ── requirements spec ───────────────────────────────────
    notify_fn("Stage 1/5 — *aria* is analyzing the brief and writing the spec...")
    status, aria_output, aria_id = run_stage(
        1, "aria",
        f"Analyze this project brief and produce a full structured specification:\n\n{brief}",
        brief, agents, project_id, notify_fn,
    )
    if status == "completed":
        consecutive_failures = 0
        notify_fn(f"OK *aria* finished — spec saved to `staging/{aria_id}/`")
    else:
        consecutive_failures += 1
        notify_fn(
            f"WARN *aria* {status} after {MAX_STAGE_ATTEMPTS} attempts. "
            f"Pipeline will continue with brief as fallback context."
        )
    log_to_bot_log(project_id, f"- **aria** ({aria_id}): {status}")

    if consecutive_failures >= CASCADE_ABORT_THRESHOLD:
        _cascade_abort(project_id, consecutive_failures, "aria", notify_fn)
        return project_id

    spec_context = aria_output or brief

    # ── Stage 2: nova ── synthetic data ──────────────────────────────────────
    notify_fn("Stage 2/5 — *nova* is generating the synthetic test dataset...")
    status, nova_output, nova_id = run_stage(
        2, "nova",
        "Generate a synthetic evaluation dataset for this project.",
        f"PROJECT SPEC:\n{spec_context}",
        agents, project_id, notify_fn,
    )
    if status == "completed":
        consecutive_failures = 0
        notify_fn(f"OK *nova* finished — dataset saved to `staging/{nova_id}/`")
    else:
        consecutive_failures += 1
        notify_fn(
            f"WARN *nova* {status} after {MAX_STAGE_ATTEMPTS} attempts. "
            f"Forge will proceed without synthetic data."
        )
    log_to_bot_log(project_id, f"- **nova** ({nova_id}): {status}")

    if consecutive_failures >= CASCADE_ABORT_THRESHOLD:
        _cascade_abort(project_id, consecutive_failures, "nova", notify_fn)
        return project_id

    # ── Stage 3: forge ── build ───────────────────────────────────────────────
    notify_fn("Stage 3/5 — *forge* is building the AI system...")
    status, forge_output, forge_id = run_stage(
        3, "forge",
        "Build the AI system as described in the specification. Output all code to /staging.",
        f"SPECIFICATION:\n{spec_context}\n\nSYNTHETIC TEST DATA: staging/{nova_id}/",
        agents, project_id, notify_fn,
    )
    if status == "completed":
        consecutive_failures = 0
        notify_fn(f"OK *forge* finished — build saved to `staging/{forge_id}/`")
    else:
        consecutive_failures += 1
        notify_fn(
            f"WARN *forge* {status} after {MAX_STAGE_ATTEMPTS} attempts. "
            f"Scout will attempt QA on available output."
        )
    log_to_bot_log(project_id, f"- **forge** ({forge_id}): {status}")

    if consecutive_failures >= CASCADE_ABORT_THRESHOLD:
        _cascade_abort(project_id, consecutive_failures, "forge", notify_fn)
        return project_id

    # ── Stage 4: scout ── QA ─────────────────────────────────────────────────
    notify_fn("Stage 4/5 — *scout* is running QA tests...")
    status, scout_output, scout_id = run_stage(
        4, "scout",
        "Run a full QA evaluation on the built system against all acceptance criteria.",
        (
            f"SPECIFICATION:\n{spec_context}\n\n"
            f"BUILD OUTPUT:\n{forge_output[:3000] if forge_output else f'See staging/{forge_id}/'}\n\n"
            f"TEST DATA: staging/{nova_id}/"
        ),
        agents, project_id, notify_fn,
    )
    if status == "completed":
        consecutive_failures = 0
        notify_fn(f"OK *scout* finished — QA report saved to `staging/{scout_id}/`")
    else:
        consecutive_failures += 1
        notify_fn(
            f"WARN *scout* {status} after {MAX_STAGE_ATTEMPTS} attempts. "
            f"Sage will proceed without QA report."
        )
    log_to_bot_log(project_id, f"- **scout** ({scout_id}): {status}")

    if consecutive_failures >= CASCADE_ABORT_THRESHOLD:
        _cascade_abort(project_id, consecutive_failures, "scout", notify_fn)
        return project_id

    # ── Stage 5: sage ── documentation ───────────────────────────────────────
    notify_fn("Stage 5/5 — *sage* is writing the documentation...")
    status, _, sage_id = run_stage(
        5, "sage",
        "Write complete user documentation for the delivered AI system.",
        (
            f"SPECIFICATION:\n{spec_context}\n\n"
            f"QA REPORT:\n{scout_output[:3000] if scout_output else f'See staging/{scout_id}/'}"
        ),
        agents, project_id, notify_fn,
    )
    if status == "completed":
        notify_fn(f"OK *sage* finished — docs saved to `staging/{sage_id}/`")
    else:
        notify_fn(f"WARN *sage* {status} after {MAX_STAGE_ATTEMPTS} attempts.")
    log_to_bot_log(project_id, f"- **sage** ({sage_id}): {status}")

    # ── Complete ──────────────────────────────────────────────────────────────
    log_to_bot_log(project_id, "- **STATUS: COMPLETE**")
    notify_fn(
        f"Project `{project_id}` is complete!\n\n"
        f"All deliverables in `/staging/`:\n"
        f"  Spec       -> staging/{aria_id}/\n"
        f"  Test data  -> staging/{nova_id}/\n"
        f"  Build      -> staging/{forge_id}/\n"
        f"  QA report  -> staging/{scout_id}/\n"
        f"  Docs       -> staging/{sage_id}/\n\n"
        f"Next: Claude Code will run a final security and logic audit before anything is merged."
    )

    logger.info("Project %s complete.", project_id)
    return project_id


def main():
    parser = argparse.ArgumentParser(description="Run the full AI team project pipeline.")
    parser.add_argument("--brief", required=True, help="Project brief / description")
    parser.add_argument("--channel", required=True, help="Slack channel ID to post updates")
    parser.add_argument("--user", required=True, help="Slack user ID who requested the project")
    parser.add_argument("--project-id", default=None, help="Optional custom project ID")
    args = parser.parse_args()

    slack_token = os.environ.get("SLACK_BOT_TOKEN")
    if not slack_token:
        raise ValueError("SLACK_BOT_TOKEN must be set in .env")

    def notify_fn(message):
        try:
            requests.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {slack_token}"},
                json={"channel": args.channel, "text": message},
                timeout=10,
            )
        except Exception as e:
            logger.error("Slack post failed: %s", e)

    run_project(args.brief, notify_fn, args.project_id)


if __name__ == "__main__":
    main()
