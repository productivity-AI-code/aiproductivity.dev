"""
runner.py — Processes inbox tasks by running them through Ollama.

Runs as a daemon, polling for new tasks every POLL_INTERVAL seconds.
Tasks are processed one at a time per agent (sequential per-agent queue).

Usage:
  python runner.py                    # Run continuously
  python runner.py --once             # Process all pending tasks once and exit
  python runner.py --agent aria       # Only process tasks for a specific agent
  python runner.py --dry-run          # Show what would run without executing
"""

import argparse
import atexit
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

BASE_DIR = Path(__file__).parent
sys.path.insert(0, str(BASE_DIR))
AGENTS_DIR = BASE_DIR / "agents"
LOCK_FILE = BASE_DIR / "runner.lock"
INBOX_DIR = BASE_DIR / "queues" / "inbox"
OUTBOX_DIR = BASE_DIR / "queues" / "outbox"
COMPLETED_DIR = BASE_DIR / "queues" / "completed"
STAGING_DIR = BASE_DIR / "staging"
BOT_LOG = BASE_DIR / "BOT_LOG.md"

POLL_INTERVAL = 30  # seconds between inbox scans

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S UTC",
    handlers=[
        logging.FileHandler(BASE_DIR / "runner.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("runner")

from error_tracker import record_error, inject_into_prompt


# ── Single-instance lock ─────────────────────────────────────────────────────

def _acquire_lock():
    """Prevent duplicate runner instances. Exits if another is already running."""
    if LOCK_FILE.exists():
        try:
            pid = int(LOCK_FILE.read_text(encoding="utf-8").strip())
            try:
                os.kill(pid, 0)
                # Process is alive
                logger.error(
                    "Another runner instance is already running (pid=%d). "
                    "Exiting. Delete %s to force a restart.", pid, LOCK_FILE
                )
                sys.exit(0)
            except PermissionError:
                # Process exists but we can't signal it — still running
                logger.error(
                    "Another runner instance is running (pid=%d). Exiting.", pid
                )
                sys.exit(0)
            except OSError:
                # Process is gone — stale lock
                logger.warning("Removing stale lock from previous run (pid=%d).", pid)
                LOCK_FILE.unlink(missing_ok=True)
        except (ValueError, OSError):
            LOCK_FILE.unlink(missing_ok=True)

    LOCK_FILE.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(lambda: LOCK_FILE.unlink(missing_ok=True))


def load_agent_prompt(agent_name):
    prompt_file = AGENTS_DIR / agent_name / "prompt.md"
    if prompt_file.exists():
        return prompt_file.read_text(encoding="utf-8")
    return f"You are {agent_name}, an AI assistant."


def build_full_prompt(task_payload):
    agent = task_payload["agent"]
    system_prompt = inject_into_prompt(agent, load_agent_prompt(agent))
    task = task_payload["task"]
    context = task_payload.get("context", "")
    task_id = task_payload["task_id"]

    parts = [
        system_prompt,
        "\n\n---\n",
        f"## Task ID: {task_id}",
        f"## Your Task\n{task}",
    ]
    if context:
        parts.append(f"\n## Context / Spec\n{context}")

    parts.append(f"\n## Output\nProduce your output now. Reference task ID {task_id} in your response.")
    return "\n".join(parts)


def check_dependencies(task_payload):
    """Return True if all dependencies are completed."""
    depends_on = task_payload.get("depends_on", [])
    if not depends_on:
        return True

    completed_ids = {
        f.stem for f in OUTBOX_DIR.rglob("*.json")
    } | {
        f.stem for f in COMPLETED_DIR.rglob("*.json")
    }

    unmet = [dep for dep in depends_on if dep not in completed_ids]
    if unmet:
        logger.info("Task %s waiting on: %s", task_payload["task_id"], unmet)
        return False
    return True


def run_ollama(model, prompt, timeout_minutes=120, endpoint="http://localhost:11434"):
    """Call Ollama via REST API and return (stdout, stderr, returncode).

    Uses the HTTP API rather than the CLI to avoid flag-injection risk
    from user-controlled prompt content passed as a subprocess argument.
    """
    logger.info("Running ollama model=%s via REST (timeout=%dm)", model, timeout_minutes)
    try:
        r = requests.post(
            f"{endpoint}/api/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
            },
            timeout=timeout_minutes * 60,
        )
        r.raise_for_status()
        content = r.json()["message"]["content"]
        return content, "", 0
    except requests.exceptions.Timeout:
        return "", f"TIMEOUT after {timeout_minutes} minutes", -1
    except requests.exceptions.ConnectionError:
        return "", f"ERROR: Cannot connect to Ollama at {endpoint}", -1
    except Exception as e:
        return "", f"ERROR: {e}", -1


def save_output(task_payload, stdout, stderr, returncode):
    task_id = task_payload["task_id"]
    agent = task_payload["agent"]

    OUTBOX_DIR.mkdir(parents=True, exist_ok=True)
    output_file = OUTBOX_DIR / f"{task_id}.json"

    result = {
        **task_payload,
        "status": "completed" if returncode == 0 else "failed",
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "output": stdout,
        "stderr": stderr,
        "returncode": returncode,
    }

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    # Also save raw output to staging for review
    staging_dir = STAGING_DIR / task_id
    staging_dir.mkdir(parents=True, exist_ok=True)
    (staging_dir / f"{agent}_output.md").write_text(stdout or stderr, encoding="utf-8")
    (staging_dir / "task_spec.json").write_text(
        json.dumps(task_payload, indent=2), encoding="utf-8"
    )

    return output_file


def append_bot_log(task_payload, status, output_preview):
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    task_id = task_payload["task_id"]
    agent = task_payload["agent"]
    model = task_payload["model"]
    task = task_payload["task"]

    entry = f"""
## [{timestamp}] {task_id}
- **Agent:** {agent} ({task_payload.get('role', '')})
- **Model:** {model}
- **Status:** {status}
- **Task:** {task[:120]}
- **Output:** /staging/{task_id}/
- **Preview:** {output_preview[:200]}
- **Next Action:** Pending Claude Code review
"""
    with open(BOT_LOG, "a", encoding="utf-8") as f:
        f.write(entry)

    logger.info("BOT_LOG updated for task %s", task_id)


def process_task(task_file, dry_run=False):
    with open(task_file, encoding="utf-8") as f:
        task_payload = json.load(f)

    task_id = task_payload["task_id"]
    agent = task_payload["agent"]
    model = task_payload["model"]

    if task_payload.get("status") not in ("pending", None):
        logger.info("Skipping %s — status is %s", task_id, task_payload.get("status"))
        return

    if not check_dependencies(task_payload):
        return

    logger.info("Processing task %s | agent=%s | model=%s", task_id, agent, model)

    if dry_run:
        logger.info("[DRY RUN] Would run: ollama run %s <prompt>", model)
        return

    # Mark as running
    task_payload["status"] = "running"
    task_payload["started_at"] = datetime.now(timezone.utc).isoformat()
    with open(task_file, "w", encoding="utf-8") as f:
        json.dump(task_payload, f, indent=2)

    prompt = build_full_prompt(task_payload)
    config_file = AGENTS_DIR / agent / "config.json"
    timeout = 120
    if config_file.exists():
        with open(config_file) as f:
            cfg = json.load(f)
        timeout = cfg.get("max_runtime_minutes", 120)

    stdout, stderr, returncode = run_ollama(model, prompt, timeout_minutes=timeout)

    status = "PASS" if returncode == 0 else "FAIL"
    output_file = save_output(task_payload, stdout, stderr, returncode)
    append_bot_log(task_payload, status, stdout[:200] if stdout else stderr[:200])

    # Move task file to completed
    COMPLETED_DIR.mkdir(parents=True, exist_ok=True)
    task_file.rename(COMPLETED_DIR / task_file.name)

    logger.info("Task %s completed — status=%s | output=%s", task_id, status, output_file)


def get_pending_tasks(agent_filter=None):
    tasks = []
    for agent_inbox in INBOX_DIR.iterdir():
        if not agent_inbox.is_dir():
            continue
        if agent_filter and agent_inbox.name != agent_filter:
            continue
        for task_file in sorted(agent_inbox.glob("*.json")):
            tasks.append(task_file)
    return tasks


def run_loop(agent_filter=None, once=False, dry_run=False):
    logger.info("Runner started. agent_filter=%s | once=%s | dry_run=%s",
                agent_filter, once, dry_run)
    while True:
        tasks = get_pending_tasks(agent_filter)
        if tasks:
            logger.info("Found %d pending task(s)", len(tasks))
            for task_file in tasks:
                try:
                    process_task(task_file, dry_run=dry_run)
                except Exception as e:
                    logger.error("Failed to process %s: %s", task_file, e)
                    try:
                        with open(task_file) as f:
                            tp = json.load(f)
                        record_error(tp.get("task_id","unknown"), tp.get("agent","unknown"),
                                     str(e), tp.get("task",""), tp.get("model",""))
                    except Exception:
                        pass
        else:
            logger.info("No pending tasks. Sleeping %ds...", POLL_INTERVAL)

        if once:
            break
        time.sleep(POLL_INTERVAL)


def main():
    parser = argparse.ArgumentParser(description="Process AI team task queue via Ollama.")
    parser.add_argument("--once", action="store_true", help="Process all pending tasks once and exit")
    parser.add_argument("--agent", help="Only process tasks for this agent")
    parser.add_argument("--dry-run", action="store_true", help="Show tasks without executing")
    args = parser.parse_args()

    _acquire_lock()
    run_loop(agent_filter=args.agent, once=args.once, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
