"""
watchdog.py — Autonomous monitor for orphaned tasks, Ollama health, and failure streaks.

Runs as a daemon under PM2. Scans every scan_interval_seconds (default: 120s).

What it does:
  1. Detects tasks stuck "running" past their deadline with no output — resets and redispatches.
  2. Tracks consecutive failures per agent — posts Slack alert when streak exceeds threshold.
  3. Verifies Ollama is reachable before redispatching — waits up to configured max_wait.

Usage:
  python watchdog.py           # run continuously (PM2 mode)
  python watchdog.py --once    # single scan and exit (for testing / cron)
  python watchdog.py --dry-run # report issues without taking action
"""

import argparse
import json
import logging
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
import yaml
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [watchdog] [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S UTC",
    handlers=[
        logging.FileHandler(BASE_DIR / "watchdog.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("watchdog")


# ── Config & persistence ──────────────────────────────────────────────────────

def load_config():
    with open(BASE_DIR / "config.yaml", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_tasks_db(config):
    db_file = BASE_DIR / config["paths"]["tasks_db"]
    if db_file.exists():
        with open(db_file, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_tasks_db(config, tasks):
    """Atomic write to tasks.json via temp file to prevent corruption."""
    db_file = BASE_DIR / config["paths"]["tasks_db"]
    tmp_file = db_file.with_suffix(".tmp")
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2)
    tmp_file.replace(db_file)


# ── Ollama health ─────────────────────────────────────────────────────────────

def check_ollama_health(endpoint, max_wait=120):
    """
    Poll /api/tags every 5s until Ollama responds or max_wait seconds elapse.
    Returns True if healthy, False if still unreachable.
    """
    url = f"{endpoint}/api/tags"
    elapsed = 0
    interval = 5
    while elapsed < max_wait:
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                return True
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            pass
        logger.info("Ollama not ready at %s, retrying in %ds... (%d/%ds)", url, interval, elapsed, max_wait)
        time.sleep(interval)
        elapsed += interval
    return False


def warmup_model(model, endpoint, timeout=60):
    """
    Send a minimal ping to load the model into Ollama VRAM before redispatch.
    Non-fatal — logs warning on failure.
    """
    try:
        r = requests.post(
            f"{endpoint}/api/chat",
            json={"model": model, "messages": [{"role": "user", "content": "ok"}], "stream": False},
            timeout=timeout,
        )
        r.raise_for_status()
        logger.info("Model %s warmed up successfully.", model)
        return True
    except Exception as e:
        logger.warning("Model warmup failed for %s (non-fatal): %s", model, e)
        return False


# ── Slack notifications ───────────────────────────────────────────────────────

def post_slack_alert(message, config):
    """Post a plain-text alert to the configured alert channel. Fire-and-forget.

    Uses WATCHDOG_SLACK_BOT_TOKEN if set (dedicated watchdog Slack app with its
    own avatar). Falls back to SLACK_BOT_TOKEN (clawbot) if not configured.
    """
    notifications = config.get("notifications", {})
    if not notifications.get("enabled", True):
        return False

    channel = notifications.get("alert_channel", "")
    if not channel:
        logger.warning("notifications.alert_channel not configured in config.yaml — skipping Slack alert.")
        return False

    token = os.environ.get("WATCHDOG_SLACK_BOT_TOKEN") or os.environ.get("SLACK_BOT_TOKEN")
    if not token:
        logger.warning("Neither WATCHDOG_SLACK_BOT_TOKEN nor SLACK_BOT_TOKEN set — skipping Slack alert.")
        return False

    # Use customize fields only when falling back to clawbot token
    # (dedicated watchdog app sets name/icon in its Slack app profile)
    using_dedicated_token = bool(os.environ.get("WATCHDOG_SLACK_BOT_TOKEN"))
    payload = {"channel": channel, "text": message}
    if not using_dedicated_token:
        payload["username"] = "Watchdog"
        payload["icon_emoji"] = ":dog:"

    try:
        r = requests.post(
            "https://slack.com/api/chat.postMessage",
            headers={"Authorization": f"Bearer {token}"},
            json=payload,
            timeout=10,
        )
        r.raise_for_status()
        return True
    except Exception as e:
        logger.error("Slack alert failed: %s", e)
        return False


# ── Orphan detection & recovery ───────────────────────────────────────────────

def _orphan_deadline(task, config):
    """Return the UTC timestamp after which this task is considered orphaned."""
    started_at = task.get("started_at")
    if not started_at:
        return None
    try:
        dt = datetime.fromisoformat(started_at)
    except ValueError:
        return None
    wdog = config.get("watchdog", {})
    timeout = config["ollama"]["timeout"]       # seconds per attempt
    retries = config["ollama"]["retries"]       # number of attempts
    grace = wdog.get("orphan_grace_multiplier", 1.1)
    deadline_seconds = timeout * retries * grace
    return dt.timestamp() + deadline_seconds


def is_orphaned(task, config):
    """
    Return True if:
    - status is "running"
    - started_at is set
    - current time is past the orphan deadline
    - output file is missing or empty
    """
    if task.get("status") != "running":
        return False
    deadline = _orphan_deadline(task, config)
    if deadline is None:
        return False
    if time.time() <= deadline:
        return False
    # Check output
    output_path = task.get("output_path")
    if output_path:
        p = Path(output_path)
        if p.exists() and p.stat().st_size > 0:
            return False  # Has output — not orphaned, just slow to update status
    return True


def reset_task(task_id, tasks):
    """
    Mark an orphaned task as "orphan_reset". Sets watchdog_resets counter.
    Returns updated task. Caller must save tasks.
    """
    task = tasks[task_id]
    task["status"] = "orphan_reset"
    task["started_at"] = None
    task["completed_at"] = datetime.now(timezone.utc).isoformat()
    task["error"] = "Watchdog: task was orphaned (no output past deadline)"
    task["watchdog_resets"] = task.get("watchdog_resets", 0) + 1
    task["last_reset_at"] = datetime.now(timezone.utc).isoformat()
    return task


_ALLOWED_AGENTS = {"aria", "forge", "nova", "scout", "sage"}


def redispatch_task(task, config, dry_run=False):
    """
    Call dispatch.py as a subprocess to re-queue the task with trimmed context.
    Returns True on success (exit code 0).
    """
    agent = task.get("agent", "")
    if agent not in _ALLOWED_AGENTS:
        logger.error("Refusing to redispatch task with unknown agent %r — possible data corruption.", agent)
        return False
    task_desc = task.get("task", "")[:500]
    context = task.get("context", "") or ""
    context_limit = config.get("watchdog", {}).get("redispatch_context_limit", 2000)
    trimmed_context = context[:context_limit]
    if len(context) > context_limit:
        trimmed_context += "\n\n[Context trimmed by watchdog — see staging files for full details]"

    cmd = [
        sys.executable, str(BASE_DIR / "dispatch.py"),
        "--agent", agent,
        "--task", task_desc,
        "--context", trimmed_context,
    ]

    if dry_run:
        logger.info("[DRY RUN] Would redispatch: --agent %s --task %r", agent, task_desc[:80])
        return True

    logger.info("Redispatching %s to agent %s...", task["task_id"], agent)
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=str(BASE_DIR),
        )
        if result.returncode == 0:
            logger.info("Redispatch of %s succeeded.", task["task_id"])
            return True
        else:
            logger.error("Redispatch of %s failed (exit %d): %s",
                         task["task_id"], result.returncode, result.stderr[:300])
            return False
    except subprocess.TimeoutExpired:
        logger.error("Redispatch subprocess timed out for %s.", task["task_id"])
        return False
    except Exception as e:
        logger.error("Redispatch failed for %s: %s", task["task_id"], e)
        return False


def scan_for_orphans(config, failure_streaks, dry_run=False):
    """
    Detect orphaned tasks, reset them, and redispatch.
    Returns list of task_ids that were processed.
    """
    tasks = load_tasks_db(config)
    max_resets = config.get("watchdog", {}).get("max_resets_per_task", 3)
    endpoint = config["ollama"]["endpoint"]
    max_wait = config.get("watchdog", {}).get("ollama_health_max_wait", 120)
    processed = []

    for task_id, task in tasks.items():
        if not isinstance(task, dict): continue
        if not is_orphaned(task, config):
            continue

        resets_so_far = task.get("watchdog_resets", 0)
        agent = task.get("agent", "unknown")
        model = task.get("model", "unknown")

        # Check if we've hit the max resets for this task
        if resets_so_far >= max_resets:
            logger.warning("Task %s has been reset %d times (max=%d). Skipping.", task_id, resets_so_far, max_resets)
            post_slack_alert(
                f"[WATCHDOG] Task abandoned after {max_resets} auto-resets\n\n"
                f"Task ID : {task_id}\n"
                f"Agent   : {agent} | Model: {model}\n"
                f"Action  : Manual review required\n"
                f"Check   : python dispatch.py --status",
                config,
            )
            continue

        # Calculate how long it's been stuck
        deadline = _orphan_deadline(task, config)
        started_at = task.get("started_at", "")
        try:
            stuck_seconds = int(time.time() - datetime.fromisoformat(started_at).timestamp())
            stuck_min = stuck_seconds // 60
        except Exception:
            stuck_min = "?"

        logger.warning("Orphaned task detected: %s (agent=%s, stuck ~%s min)", task_id, agent, stuck_min)

        # Check Ollama health before redispatching
        if not dry_run:
            logger.info("Checking Ollama health before redispatch...")
            if not check_ollama_health(endpoint, max_wait=max_wait):
                logger.error("Ollama is unreachable. Skipping redispatch of %s.", task_id)
                post_slack_alert(
                    f"[WATCHDOG] Orphaned task found but Ollama is down\n\n"
                    f"Task ID : {task_id}\n"
                    f"Agent   : {agent}\n"
                    f"Action  : Waiting for Ollama to come back online\n"
                    f"Fix     : Ensure Ollama is running, then watchdog will retry",
                    config,
                )
                continue

            # Warm the model
            warmup_model(model, endpoint)

        # Reset and save before redispatching
        reset_task(task_id, tasks)
        save_tasks_db(config, tasks)

        # Redispatch
        success = redispatch_task(task, config, dry_run=dry_run)
        new_resets = resets_so_far + 1

        if success:
            post_slack_alert(
                f"[WATCHDOG] Orphaned task detected and redispatched\n\n"
                f"Task ID : {task_id}\n"
                f"Agent   : {agent} | Model: {model}\n"
                f"Stuck   : ~{stuck_min} min past deadline\n"
                f"Action  : Reset, context trimmed, redispatched\n"
                f"Resets  : {new_resets} of {max_resets} allowed",
                config,
            )
        else:
            post_slack_alert(
                f"[WATCHDOG] Orphaned task reset but redispatch failed\n\n"
                f"Task ID : {task_id}\n"
                f"Agent   : {agent}\n"
                f"Action  : Task reset to orphan_reset — retry manually\n"
                f"Command : python dispatch.py --agent {agent} --task \"...\"",
                config,
            )

        processed.append(task_id)

    if not processed:
        logger.info("No orphaned tasks found.")

    return processed


# ── Failure streak detection ──────────────────────────────────────────────────

def check_failure_streaks(config, failure_streaks, already_alerted):
    """
    Scan recent tasks for consecutive failures per agent.
    Updates failure_streaks in-place. Posts Slack alert once per streak.
    """
    tasks = load_tasks_db(config)
    threshold = config.get("watchdog", {}).get("failure_streak_threshold", 3)
    now = time.time()
    two_hours_ago = now - 7200

    # Group tasks by agent, sorted by completion time
    by_agent = {}
    for task in tasks.values():
        if not isinstance(task, dict): continue
        agent = task.get("agent")
        completed_at = task.get("completed_at")
        status = task.get("status")
        if not agent or not completed_at or status not in ("completed", "failed"):
            continue
        try:
            ts = datetime.fromisoformat(completed_at).timestamp()
        except ValueError:
            continue
        if ts < two_hours_ago:
            continue
        by_agent.setdefault(agent, []).append((ts, status, task.get("task_id", "")))

    for agent, records in by_agent.items():
        records.sort()  # ascending by time
        streak = 0
        last_failed_id = ""
        for _, status, task_id in records:
            if status == "failed":
                streak += 1
                last_failed_id = task_id
            else:
                streak = 0
                already_alerted[agent] = False
        failure_streaks[agent] = streak

        if streak >= threshold and not already_alerted.get(agent, False):
            logger.warning("Failure streak for %s: %d consecutive failures", agent, streak)
            post_slack_alert(
                f"[WATCHDOG] Failure streak: *{agent}* has failed {streak} consecutive tasks\n\n"
                f"Last failed task : {last_failed_id}\n"
                f"Action           : No further auto-redispatch for {agent}\n"
                f"Check            : python error_tracker.py --report --agent {agent}\n"
                f"Resolve          : python dispatch.py --status",
                config,
            )
            already_alerted[agent] = True
        elif streak < threshold:
            already_alerted[agent] = False


# ── Main loop ─────────────────────────────────────────────────────────────────

def run_watchdog(once=False, dry_run=False):
    """Main daemon loop. Runs indefinitely unless --once is passed."""
    config = load_config()
    scan_interval = config.get("watchdog", {}).get("scan_interval_seconds", 120)

    failure_streaks = {}
    already_alerted = {}

    logger.info("Watchdog started. scan_interval=%ds | dry_run=%s", scan_interval, dry_run)

    while True:
        try:
            config = load_config()  # reload config each iteration to pick up changes
            scan_for_orphans(config, failure_streaks, dry_run=dry_run)
            check_failure_streaks(config, failure_streaks, already_alerted)
        except Exception as e:
            logger.error("Watchdog scan error: %s", e, exc_info=True)

        if once:
            logger.info("--once flag set. Exiting.")
            break

        logger.info("Scan complete. Sleeping %ds...", scan_interval)
        time.sleep(scan_interval)


def main():
    parser = argparse.ArgumentParser(description="Watchdog: autonomous task monitor and recovery.")
    parser.add_argument("--once", action="store_true", help="Run one scan and exit")
    parser.add_argument("--dry-run", action="store_true", help="Report issues without taking action")
    args = parser.parse_args()

    run_watchdog(once=args.once, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
