"""
monitor.py — Live dashboard for AI team task status.

Usage:
  python monitor.py              # Full status overview
  python monitor.py --watch      # Refresh every 10 seconds
  python monitor.py --task <id>  # Detail view for a specific task
"""

import argparse
import json
import time
from pathlib import Path

import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.live import Live
from rich.layout import Layout

BASE_DIR = Path(__file__).parent
console = Console()

STATUS_COLORS = {
    "queued":    "yellow",
    "running":   "cyan",
    "completed": "green",
    "failed":    "red",
}


def load_config():
    with open(BASE_DIR / "config.yaml") as f:
        return yaml.safe_load(f)


def load_tasks(config):
    db_file = BASE_DIR / config["paths"]["tasks_db"]
    if db_file.exists():
        with open(db_file, encoding="utf-8") as f:
            return json.load(f)
    return {}


def build_table(tasks):
    table = Table(
        title="AI Team — Task Monitor",
        box=box.ROUNDED,
        show_lines=True,
        highlight=True,
    )
    table.add_column("Task ID", style="dim", min_width=28)
    table.add_column("Agent", style="bold", min_width=7)
    table.add_column("Model", min_width=20)
    table.add_column("Status", min_width=10)
    table.add_column("Created", min_width=19)
    table.add_column("Task", min_width=40)

    sorted_tasks = sorted(tasks.values(), key=lambda x: x["created_at"], reverse=True)

    for t in sorted_tasks:
        status = t.get("status", "unknown")
        color = STATUS_COLORS.get(status, "white")
        table.add_row(
            t.get("task_id", ""),
            t.get("agent", ""),
            t.get("model", ""),
            Text(status, style=color),
            t.get("created_at", "")[:19],
            t.get("task", "")[:60],
        )

    return table


def show_summary(tasks):
    counts = {}
    for t in tasks.values():
        s = t.get("status", "unknown")
        counts[s] = counts.get(s, 0) + 1

    parts = []
    for status, color in STATUS_COLORS.items():
        n = counts.get(status, 0)
        parts.append(f"[{color}]{status}: {n}[/{color}]")

    console.print(Panel("  |  ".join(parts), title="Summary", expand=False))


def show_task_detail(task_id, tasks):
    t = tasks.get(task_id)
    if not t:
        console.print(f"[red]Task '{task_id}' not found.[/red]")
        return

    console.print(Panel(
        f"[bold]Agent:[/bold]     {t.get('agent')}\n"
        f"[bold]Role:[/bold]      {t.get('role')}\n"
        f"[bold]Model:[/bold]     {t.get('model')}\n"
        f"[bold]Status:[/bold]    [{STATUS_COLORS.get(t.get('status',''), 'white')}]{t.get('status')}[/]\n"
        f"[bold]Created:[/bold]   {t.get('created_at', '')[:19]}\n"
        f"[bold]Started:[/bold]   {(t.get('started_at') or '—')[:19]}\n"
        f"[bold]Completed:[/bold] {(t.get('completed_at') or '—')[:19]}\n\n"
        f"[bold]Task:[/bold]\n{t.get('task', '')}\n\n"
        f"[bold]Output:[/bold] {t.get('output_path', '—')}",
        title=f"Task: {task_id}",
    ))

    if t.get("error"):
        console.print(Panel(f"[red]{t['error']}[/red]", title="Error"))

    output_path = t.get("output_path")
    if output_path and Path(output_path).exists():
        output = Path(output_path).read_text(encoding="utf-8")
        console.print(Panel(output[:1000] + ("..." if len(output) > 1000 else ""),
                            title="Output Preview"))


def render(config):
    tasks = load_tasks(config)
    show_summary(tasks)
    if tasks:
        console.print(build_table(tasks))
    else:
        console.print("[dim]No tasks yet. Use dispatch.py to queue work.[/dim]")


def main():
    parser = argparse.ArgumentParser(description="Monitor AI team task queue.")
    parser.add_argument("--watch", action="store_true", help="Refresh every 10 seconds")
    parser.add_argument("--task", help="Show details for a specific task ID")
    args = parser.parse_args()

    config = load_config()

    if args.task:
        tasks = load_tasks(config)
        show_task_detail(args.task, tasks)
        return

    if args.watch:
        with Live(console=console, refresh_per_second=0.1) as live:
            while True:
                tasks = load_tasks(config)
                table = build_table(tasks)
                live.update(table)
                time.sleep(10)
    else:
        render(config)


if __name__ == "__main__":
    main()
