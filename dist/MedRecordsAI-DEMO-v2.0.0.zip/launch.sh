#!/usr/bin/env bash
#
# MedRecords AI - Launcher (Mac/Linux)
# AI Productivity Dev
#

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "  ================================================"
echo "    MedRecords AI - Starting Services..."
echo "  ================================================"
echo ""

# Determine Python command
PYTHON_CMD=""
if command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_CMD="python"
else
    echo "  [ERROR] Python not found. Run install.sh first."
    exit 1
fi

# Start services and open browser
if ! $PYTHON_CMD "$SCRIPT_DIR/start_medical.py" --auto-open; then
    echo ""
    echo "  [ERROR] Failed to start. Run install.sh first."
    echo ""
    exit 1
fi

echo ""
echo "  Dashboard: http://localhost:8080"
echo ""
echo "  Press Enter to stop all services..."
read -r

echo ""
echo "  Stopping services..."
$PYTHON_CMD "$SCRIPT_DIR/start_medical.py" --stop
echo "  Done."
sleep 2
