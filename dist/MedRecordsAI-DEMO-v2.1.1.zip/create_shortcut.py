"""
create_shortcut.py -- Create a desktop shortcut for MedRecords AI.

Uses PowerShell's WScript.Shell COM object to create a .lnk file
on the user's Desktop. Works on Windows without admin rights.
"""

import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
BAT_PATH = BASE_DIR / "MedRecordsAI.bat"
SHORTCUT_NAME = "MedRecords AI.lnk"


def create_shortcut():
    """Create a desktop shortcut pointing to MedRecordsAI.bat."""
    desktop = Path.home() / "Desktop"
    if not desktop.exists():
        # Fallback: try OneDrive Desktop
        onedrive_desktop = Path.home() / "OneDrive" / "Desktop"
        if onedrive_desktop.exists():
            desktop = onedrive_desktop
        else:
            print("Could not find Desktop folder.")
            return False

    shortcut_path = desktop / SHORTCUT_NAME

    # PowerShell script to create .lnk shortcut
    ps_script = f"""
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut('{shortcut_path}')
$sc.TargetPath = '{BAT_PATH}'
$sc.WorkingDirectory = '{BASE_DIR}'
$sc.Description = 'MedRecords AI - Medical Record Analysis'
$sc.WindowStyle = 1
$sc.Save()
"""

    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0:
            print(f"Desktop shortcut created: {shortcut_path}")
            return True
        else:
            print(f"PowerShell error: {result.stderr.strip()}")
            return False
    except Exception as e:
        print(f"Error creating shortcut: {e}")
        return False


if __name__ == "__main__":
    success = create_shortcut()
    sys.exit(0 if success else 1)
