"""Rule-based case reference detection from filenames.

Suggests a case_ref for uploaded files by matching filename patterns
against known conventions and existing cases in the system.
"""

import re
import os
from difflib import SequenceMatcher


# Explicit case-reference patterns  (high confidence)
_CASE_PATTERNS = [
    re.compile(r"(CASE[_\-\s]?\d{2,}[_\-]?\d{0,})", re.IGNORECASE),
    re.compile(r"(FILE[_\-\s]?\d{4,})", re.IGNORECASE),
    re.compile(r"(CLAIM[_\-\s]?\d{4,})", re.IGNORECASE),
    re.compile(r"(DOCKET[_\-\s]?\d+)", re.IGNORECASE),
]

# Medical record / patient ID patterns  (medium confidence)
_MRN_PATTERNS = [
    re.compile(r"(MRN[_\-\s]?\d{4,})", re.IGNORECASE),
    re.compile(r"(PID[_\-\s]?\d{4,})", re.IGNORECASE),
    re.compile(r"(PT[_\-\s]?ID[_\-\s]?\d{4,})", re.IGNORECASE),
    re.compile(r"(PATIENT[_\-\s]?\d{4,})", re.IGNORECASE),
]

# Name patterns: "LastName_FirstName" or "LastName, FirstName"
_NAME_PATTERN = re.compile(
    r"^([A-Z][a-z]+)[_\-,\s]+([A-Z][a-z]+)", re.UNICODE
)


def _normalize(text: str) -> str:
    """Lowercase, strip extension, replace separators with spaces."""
    text = os.path.splitext(text)[0]
    return re.sub(r"[_\-.,]+", " ", text).strip().lower()


def _tokenize(text: str) -> set:
    """Return set of meaningful tokens (>= 2 chars) from text."""
    return {t for t in _normalize(text).split() if len(t) >= 2}


def suggest_case_ref(
    filename: str,
    existing_cases: list[str] | None = None,
) -> dict | None:
    """Suggest a case_ref for the given filename.

    Args:
        filename: The uploaded filename (with or without path).
        existing_cases: List of existing case_ref strings in the system.

    Returns:
        dict with keys "suggestion", "source", "confidence" or None.
        confidence is one of "high", "medium", "low".
    """
    if not filename:
        return None

    basename = os.path.basename(filename)
    existing_cases = existing_cases or []
    existing_lower = {c.lower(): c for c in existing_cases if c}

    # ---- Rule 1: Explicit case/file/claim pattern (high) ----
    for pat in _CASE_PATTERNS:
        m = pat.search(basename)
        if m:
            raw = m.group(1).strip()
            normalized = re.sub(r"[\s]+", "-", raw).upper()
            # Match against existing cases
            for el, orig in existing_lower.items():
                if normalized.lower() == el or normalized.lower().replace("-", "") == el.replace("-", ""):
                    return {"suggestion": orig, "source": "case_pattern", "confidence": "high"}
            return {"suggestion": normalized, "source": "case_pattern", "confidence": "high"}

    # ---- Rule 2: MRN / Patient ID pattern (medium) ----
    for pat in _MRN_PATTERNS:
        m = pat.search(basename)
        if m:
            raw = m.group(1).strip()
            normalized = re.sub(r"[\s]+", "-", raw).upper()
            for el, orig in existing_lower.items():
                if normalized.lower() in el or el in normalized.lower():
                    return {"suggestion": orig, "source": "mrn_pattern", "confidence": "medium"}
            return {"suggestion": normalized, "source": "mrn_pattern", "confidence": "medium"}

    # ---- Rule 3: Patient name pattern → match existing cases (medium) ----
    name_match = _NAME_PATTERN.match(basename)
    if name_match and existing_cases:
        last = name_match.group(1).lower()
        first = name_match.group(2).lower()
        for el, orig in existing_lower.items():
            el_norm = _normalize(el)
            if last in el_norm and first in el_norm:
                return {"suggestion": orig, "source": "name_match", "confidence": "medium"}
            if last in el_norm:
                return {"suggestion": orig, "source": "name_match", "confidence": "low"}

    # ---- Rule 4: Token overlap with existing cases (low) ----
    if existing_cases:
        file_tokens = _tokenize(basename)
        # Filter out very common tokens
        noise = {"medical", "records", "record", "report", "pdf", "doc",
                 "scan", "copy", "page", "pages", "file", "files",
                 "the", "and", "for", "from", "with"}
        file_tokens -= noise
        if len(file_tokens) >= 2:
            best_match = None
            best_score = 0
            for case in existing_cases:
                case_tokens = _tokenize(case) - noise
                if not case_tokens:
                    continue
                overlap = file_tokens & case_tokens
                if len(overlap) >= 2:
                    score = len(overlap) / max(len(file_tokens), len(case_tokens))
                    if score > best_score:
                        best_score = score
                        best_match = case
            if best_match and best_score >= 0.3:
                return {"suggestion": best_match, "source": "token_overlap", "confidence": "low"}

        # Fuzzy string similarity as last resort
        file_norm = _normalize(basename)
        for case in existing_cases:
            case_norm = _normalize(case)
            ratio = SequenceMatcher(None, file_norm, case_norm).ratio()
            if ratio >= 0.6:
                return {"suggestion": case, "source": "fuzzy_match", "confidence": "low"}

    return None
