"""
verify_install.py -- Post-install verification for MedRecords AI beta.

Runs an end-to-end smoke test:
  1. Verifies Flask starts and serves the UI
  2. Tests file upload via API
  3. Tests the schema validation pipeline with synthetic data
  4. Verifies Ollama connectivity
  5. Checks all vault directories are writable

Usage:
  python verify_install.py         # Run all checks
  python verify_install.py --quick # Skip Ollama connectivity test
"""

import argparse
import json
import os
import sys
import tempfile
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent

class C:
    OK = "\033[92m"
    WARN = "\033[93m"
    FAIL = "\033[91m"
    BOLD = "\033[1m"
    END = "\033[0m"

passed = 0
failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        print(f"  {C.OK}PASS{C.END}  {name}")
        passed += 1
    else:
        print(f"  {C.FAIL}FAIL{C.END}  {name}")
        if detail:
            print(f"        {detail}")
        failed += 1


def test_imports():
    print(f"\n{C.BOLD}1. Module Imports{C.END}")

    modules = [
        ("flask", "Flask web framework"),
        ("yaml", "YAML configuration"),
        ("openpyxl", "Excel file handling"),
        ("dotenv", "Environment file loading"),
    ]

    for mod, desc in modules:
        try:
            __import__(mod)
            check(f"import {mod} ({desc})", True)
        except ImportError:
            check(f"import {mod} ({desc})", False, f"pip install {mod}")


def test_project_files():
    print(f"\n{C.BOLD}2. Project Files{C.END}")

    required_files = [
        "config.yaml",
        "pipeline_schemas.py",
        "medical_app.py",
        "summarization_watcher.py",
        "retrieval_bot.py",
        "dispatch.py",
        ".env.example",
        "requirements.txt",
        "ui/index.html",
        "ui/js/app.js",
        "ui/css/tailwind.js",
        "agents/ingestion/config.json",
        "agents/ingestion/prompt.md",
        "agents/privacy/config.json",
        "agents/privacy/prompt.md",
        "agents/summarizer/config.json",
        "agents/summarizer/prompt.md",
        "agents/auditor/config.json",
        "agents/auditor/prompt.md",
        "email_templates/custodian_request.txt",
        "email_templates/counsel_request.txt",
        "email_templates/patient_request.txt",
    ]

    for f in required_files:
        path = BASE_DIR / f
        check(f, path.exists(), f"Missing: {path}")


def test_directories():
    print(f"\n{C.BOLD}3. Vault Directories{C.END}")

    dirs = [
        "vault/incoming",
        "vault/processing",
        "vault/processed",
        "vault/summaries",
        "vault/audit",
        "vault/pipeline_status",
        "templates",
        "logs",
    ]

    for d in dirs:
        path = BASE_DIR / d
        exists = path.exists() and path.is_dir()
        check(f"{d}/", exists, f"Run: python setup_medical.py")

        if exists:
            # Test writability
            test_file = path / ".write_test"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except PermissionError:
                check(f"{d}/ (writable)", False, "Permission denied")


def test_schema_validators():
    print(f"\n{C.BOLD}4. Pipeline Schema Validators{C.END}")

    try:
        from pipeline_schemas import (
            validate_ingestion_output,
            validate_privacy_output,
            validate_summary_output,
            validate_audit_output,
            extract_json_from_response,
        )
    except ImportError as e:
        check("Import pipeline_schemas", False, str(e))
        return

    check("Import pipeline_schemas", True)

    # Test extract_json_from_response
    try:
        result = extract_json_from_response('```json\n{"test": true}\n```')
        check("JSON extraction (markdown fences)", result == {"test": True})
    except Exception as e:
        check("JSON extraction (markdown fences)", False, str(e))

    # Valid ingestion
    valid = {
        "document_id": "test",
        "source_file": "test.pdf",
        "ingestion_timestamp": "2024-01-01T00:00:00Z",
        "document_type": "clinical_note",
        "sections": [{"section_id": "s1", "section_type": "notes", "content": "test", "confidence": 0.9}],
    }
    errors = validate_ingestion_output(valid)
    check("Ingestion validator (valid data)", len(errors) == 0, str(errors))

    # Invalid ingestion (missing fields)
    errors = validate_ingestion_output({"sections": []})
    check("Ingestion validator (catches missing fields)", len(errors) > 0)

    # Valid privacy with incomplete redaction (should flag CRITICAL)
    incomplete = {
        "document_id": "test",
        "privacy_timestamp": "2024-01-01T00:00:00Z",
        "sections": [{"section_id": "s1", "section_type": "notes", "content": "test"}],
        "phi_summary": {
            "total_identifiers_found": 5,
            "total_redacted": 3,
            "redaction_complete": False,
        },
    }
    errors = validate_privacy_output(incomplete)
    critical = [e for e in errors if "CRITICAL" in e]
    check("Privacy validator (detects incomplete redaction)", len(critical) > 0)

    # PHI leak detection
    from pipeline_schemas import check_for_phi_leak
    leaks = check_for_phi_leak("Patient SSN: 123-45-6789, Phone: 555-123-4567")
    check("PHI leak detection", len(leaks) >= 2)


def test_flask_app():
    print(f"\n{C.BOLD}5. Flask Application{C.END}")

    try:
        sys.path.insert(0, str(BASE_DIR))

        # Ensure auth credentials are set (setdefault won't overwrite .env values)
        os.environ.setdefault("AUTH_USERNAME", "test")
        os.environ.setdefault("AUTH_PASSWORD", "test")
        os.environ.setdefault("FLASK_SECRET_KEY", "verify-install-test-key")

        from medical_app import app
        check("Flask app import", True)

        app.config["TESTING"] = True

        with app.test_client() as client:
            # Login via JSON (the login endpoint expects JSON, not form data)
            login_resp = client.post("/login",
                json={
                    "username": os.environ.get("AUTH_USERNAME", "test"),
                    "password": os.environ.get("AUTH_PASSWORD", "test"),
                },
                content_type="application/json",
            )
            logged_in = login_resp.status_code == 200
            if not logged_in:
                # Bypass auth by directly setting session
                with client.session_transaction() as sess:
                    sess["authenticated"] = True
                    sess["username"] = "verify_test"

            # Test index page
            resp = client.get("/")
            check("GET / (serve UI)", resp.status_code == 200,
                  f"Got {resp.status_code}" if resp.status_code != 200 else "")

            # Test API endpoints
            resp = client.get("/api/status")
            check("GET /api/status", resp.status_code == 200)
            data = resp.get_json()
            check("API returns JSON", isinstance(data, dict))
            check("Status has 'system' field", data.get("system") == "operational")

            # Test summaries endpoint
            resp = client.get("/api/summaries")
            check("GET /api/summaries", resp.status_code == 200)

            # Test audit endpoint
            resp = client.get("/api/audit")
            check("GET /api/audit", resp.status_code == 200)

    except Exception as e:
        check("Flask app test", False, str(e))


def test_ollama(quick=False):
    print(f"\n{C.BOLD}6. Ollama LLM Engine{C.END}")

    if quick:
        print("  [SKIP] Ollama tests (--quick mode)")
        return

    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        check("Ollama server reachable", True)

        models = [m["name"] for m in data.get("models", [])]
        for required in ["qwen2.5:7b", "glm4:9b"]:
            found = any(required in m for m in models)
            check(f"Model: {required}", found, "Run: ollama pull " + required)

    except Exception as e:
        check("Ollama server reachable", False, f"Start Ollama: ollama serve ({e})")


def test_config():
    print(f"\n{C.BOLD}7. Configuration{C.END}")

    try:
        import yaml
        with open(BASE_DIR / "config.yaml") as f:
            config = yaml.safe_load(f)
        check("config.yaml loads", True)

        sections = ["medical_agents", "retrieval", "summarization", "web_ui"]
        for section in sections:
            check(f"config.yaml has '{section}'", section in config)

        agents = config.get("medical_agents", {})
        for agent in ["ingestion", "privacy", "summarizer", "auditor"]:
            check(f"Agent configured: {agent}", agent in agents)

    except Exception as e:
        check("config.yaml", False, str(e))


def main():
    parser = argparse.ArgumentParser(description="MedRecords AI - Installation Verifier")
    parser.add_argument("--quick", action="store_true", help="Skip Ollama tests")
    args = parser.parse_args()

    print(f"\n{C.BOLD}MedRecords AI - Installation Verification{C.END}")
    print(f"{'='*50}")

    test_imports()
    test_project_files()
    test_directories()
    test_schema_validators()
    test_flask_app()
    test_ollama(quick=args.quick)
    test_config()

    print(f"\n{'='*50}")
    print(f"  Results: {C.OK}{passed} passed{C.END}, {C.FAIL}{failed} failed{C.END}")

    if failed == 0:
        print(f"\n  {C.OK}{C.BOLD}All checks passed! MedRecords AI is ready.{C.END}")
        print(f"  Run: python start_medical.py")
    else:
        print(f"\n  {C.WARN}Fix the failures above, then re-run this script.{C.END}")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
