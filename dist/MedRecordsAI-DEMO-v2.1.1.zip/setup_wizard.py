#!/usr/bin/env python3
"""
setup_wizard.py -- Browser-based setup wizard for MedRecords AI.

Serves a local web UI on a temporary port that guides users through
first-time installation. Replaces the command-line prompts in MedRecordsAI.bat
with a modern browser-based experience.

Usage:
    python setup_wizard.py              # Start wizard (opens browser)
    python setup_wizard.py --port 9090  # Custom port
"""

import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

# Flask is installed by setup_medical.py, but we need it here.
# If not available, fall back to CLI setup.
try:
    from flask import Flask, jsonify, request, send_from_directory
except ImportError:
    print("[INFO] Flask not yet installed. Running CLI setup first...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "-q"])
    from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).parent
SETUP_PORT = 9876  # Temporary port for setup wizard

app = Flask(__name__, static_folder=str(BASE_DIR / "ui"))


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

setup_state = {
    "step": "welcome",  # welcome, eula, api_key, installing, done, error
    "progress": 0,
    "message": "",
    "error": None,
    "eula_text": "",
    "is_demo": False,
    "version": "2.0.0",
}


def load_initial_state():
    """Load EULA text, version, and demo status."""
    eula_path = BASE_DIR / "EULA.txt"
    if eula_path.exists():
        setup_state["eula_text"] = eula_path.read_text(encoding="utf-8", errors="replace")

    version_path = BASE_DIR / "VERSION"
    if version_path.exists():
        setup_state["version"] = version_path.read_text(encoding="utf-8").strip()

    demo_path = BASE_DIR / ".demo_build"
    if demo_path.exists():
        setup_state["is_demo"] = True
        try:
            demo_info = json.loads(demo_path.read_text(encoding="utf-8"))
            setup_state["version"] = demo_info.get("version", setup_state["version"])
        except (json.JSONDecodeError, OSError):
            pass


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def serve_setup_page():
    return send_from_directory(str(BASE_DIR / "ui"), "setup.html")


@app.route("/api/state")
def get_state():
    return jsonify(setup_state)


@app.route("/api/eula", methods=["POST"])
def accept_eula():
    data = request.get_json(silent=True) or {}
    if data.get("accepted"):
        setup_state["step"] = "api_key"
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "EULA must be accepted"}), 400


@app.route("/api/install", methods=["POST"])
def start_install():
    data = request.get_json(silent=True) or {}
    api_key = data.get("api_key", "").strip()
    use_ollama = data.get("use_ollama", False)
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    setup_state["step"] = "installing"
    setup_state["progress"] = 0
    setup_state["message"] = "Starting installation..."

    # Run setup in background thread
    t = threading.Thread(
        target=run_setup,
        args=(api_key, use_ollama, username, password),
        daemon=True,
    )
    t.start()

    return jsonify({"ok": True})


@app.route("/api/launch", methods=["POST"])
def launch_app():
    """Shut down the wizard so the bat file can launch the app."""
    def delayed_exit():
        time.sleep(0.5)
        os._exit(0)

    t = threading.Thread(target=delayed_exit, daemon=True)
    t.start()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Setup runner
# ---------------------------------------------------------------------------

def run_setup(api_key: str, use_ollama: bool, username: str = "", password: str = ""):
    """Run the full setup process, updating state as we go."""
    try:
        # Step 1: Install dependencies
        setup_state["progress"] = 10
        setup_state["message"] = "Installing Python dependencies..."
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r",
             str(BASE_DIR / "requirements.txt"), "-q"],
            capture_output=True, text=True, cwd=str(BASE_DIR),
        )
        if result.returncode != 0:
            raise RuntimeError(f"pip install failed: {result.stderr}")

        # Step 2: Create vault directories
        setup_state["progress"] = 30
        setup_state["message"] = "Creating vault directories..."
        for d in ["vault/incoming", "vault/processing", "vault/processed",
                   "vault/failed", "vault/tmp", "logs"]:
            (BASE_DIR / d).mkdir(parents=True, exist_ok=True)

        # Step 3: Initialize database
        setup_state["progress"] = 45
        setup_state["message"] = "Initializing database..."
        subprocess.run(
            [sys.executable, "-c",
             "import sys; sys.path.insert(0,'.'); from db import init_db; init_db()"],
            cwd=str(BASE_DIR), capture_output=True, text=True,
        )

        # Step 4: Create .env file
        setup_state["progress"] = 60
        setup_state["message"] = "Configuring environment..."
        write_env_file(api_key, username, password)

        # Step 5: Configure config.yaml for selected backend
        setup_state["progress"] = 70
        setup_state["message"] = "Setting up AI backend..."
        configure_backend(api_key, use_ollama)

        # Step 6: Register demo if applicable
        if setup_state["is_demo"]:
            setup_state["progress"] = 80
            setup_state["message"] = "Registering demo license..."
            subprocess.run(
                [sys.executable, "-c",
                 "import sys; sys.path.insert(0,'.'); "
                 "from licensing import register_demo; register_demo()"],
                cwd=str(BASE_DIR), capture_output=True, text=True,
            )

        # Step 7: Create desktop shortcut
        setup_state["progress"] = 90
        setup_state["message"] = "Creating desktop shortcut..."
        subprocess.run(
            [sys.executable, str(BASE_DIR / "create_shortcut.py")],
            cwd=str(BASE_DIR), capture_output=True, text=True,
        )

        # Step 8: Mark as installed
        (BASE_DIR / ".installed").write_text("installed\n", encoding="utf-8")

        setup_state["progress"] = 100
        setup_state["message"] = "Installation complete!"
        setup_state["step"] = "done"

        # Auto-shutdown after 2 minutes so the bat file can continue
        # even if user closes browser tab without clicking "Open Dashboard"
        def auto_shutdown():
            time.sleep(120)
            os._exit(0)
        threading.Thread(target=auto_shutdown, daemon=True).start()

    except Exception as e:
        setup_state["step"] = "error"
        setup_state["error"] = str(e)
        setup_state["message"] = f"Installation failed: {e}"


def write_env_file(api_key: str, username: str = "", password: str = ""):
    """Create or update the .env file with secure defaults."""
    env_path = BASE_DIR / ".env"
    env_vars = {}

    # Read existing .env if present
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env_vars[k.strip()] = v.strip()

    # Set defaults
    if "FLASK_SECRET_KEY" not in env_vars:
        env_vars["FLASK_SECRET_KEY"] = secrets.token_hex(32)

    # Use custom credentials if provided, otherwise auto-generate
    env_vars["AUTH_USERNAME"] = username if username else "admin"
    env_vars["AUTH_PASSWORD"] = password if password else secrets.token_urlsafe(12)

    # Store credentials in state so the UI can display them
    setup_state["generated_username"] = env_vars["AUTH_USERNAME"]
    setup_state["generated_password"] = env_vars["AUTH_PASSWORD"]

    if api_key:
        env_vars["ANTHROPIC_API_KEY"] = api_key

    # Write .env
    lines = [f"{k}={v}" for k, v in sorted(env_vars.items())]
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def configure_backend(api_key: str, use_ollama: bool):
    """Update config.yaml to use the selected AI backend."""
    config_path = BASE_DIR / "config.yaml"
    example_path = BASE_DIR / "config.yaml.example"

    # If no config.yaml, copy from example
    if not config_path.exists() and example_path.exists():
        import shutil
        shutil.copy2(example_path, config_path)

    if not config_path.exists():
        return

    text = config_path.read_text(encoding="utf-8")

    if use_ollama:
        # Set backend to ollama
        text = re.sub(
            r"(llm_backend:\s*).*",
            r"\1ollama",
            text,
        )
    elif api_key:
        # Set backend to claude
        text = re.sub(
            r"(llm_backend:\s*).*",
            r"\1claude",
            text,
        )

    config_path.write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="MedRecords AI Setup Wizard")
    parser.add_argument("--port", type=int, default=SETUP_PORT)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    load_initial_state()

    # Open browser after short delay
    if not args.no_browser:
        def open_browser():
            time.sleep(1.5)
            webbrowser.open(f"http://localhost:{args.port}")
        threading.Thread(target=open_browser, daemon=True).start()

    print(f"\n  MedRecords AI Setup Wizard")
    print(f"  Open http://localhost:{args.port} in your browser\n")

    app.run(host="127.0.0.1", port=args.port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
