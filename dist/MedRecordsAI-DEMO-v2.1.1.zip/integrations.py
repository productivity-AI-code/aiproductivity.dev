"""
integrations.py -- Case management platform integration framework.

Supports pushing completed summaries, demand packages, and deposition analyses
to external case management platforms via REST API/webhook.

Architecture:
- Generic webhook connector (works with any platform that accepts JSON POST)
- Platform-specific adapters for Filevine, CASEpeer, Litify
- Configuration stored in config.yaml under 'integrations' key
- All pushes are logged for audit trail

Core feature: available in both Core and Pro tiers.

Usage:
    from integrations import push_to_integration, list_integrations, test_connection
    result = push_to_integration("filevine", run_id, data_type="summary")
"""

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
import yaml

logger = logging.getLogger("integrations")

BASE_DIR = Path(__file__).parent
INTEGRATIONS_LOG = BASE_DIR / "vault" / "integration_log.json"
CONFIG_PATH = BASE_DIR / "config.yaml"


# ── Integration Definitions ──────────────────────────────────────────────────

SUPPORTED_PLATFORMS = {
    "webhook": {
        "name": "Generic Webhook",
        "description": "Push data to any URL via HTTP POST. Works with Zapier, Make, n8n, or custom endpoints.",
        "config_fields": [
            {"key": "url", "label": "Webhook URL", "type": "url", "required": True},
            {"key": "auth_header", "label": "Authorization Header", "type": "password", "required": False,
             "placeholder": "Bearer your-token-here"},
            {"key": "custom_headers", "label": "Custom Headers (JSON)", "type": "json", "required": False},
        ],
    },
    "filevine": {
        "name": "Filevine",
        "description": "Push summaries and documents directly into Filevine case records.",
        "config_fields": [
            {"key": "api_key", "label": "API Key", "type": "password", "required": True},
            {"key": "org_id", "label": "Organization ID", "type": "text", "required": True},
            {"key": "base_url", "label": "API Base URL", "type": "url", "required": False,
             "default": "https://api.filevine.io"},
        ],
    },
    "casepeer": {
        "name": "CASEpeer",
        "description": "Sync case data and push summaries to CASEpeer.",
        "config_fields": [
            {"key": "api_key", "label": "API Key", "type": "password", "required": True},
            {"key": "base_url", "label": "API Base URL", "type": "url", "required": False,
             "default": "https://api.casepeer.com/v1"},
        ],
    },
    "litify": {
        "name": "Litify",
        "description": "Push summaries to Litify (Salesforce-based) case management.",
        "config_fields": [
            {"key": "client_id", "label": "Connected App Client ID", "type": "text", "required": True},
            {"key": "client_secret", "label": "Connected App Client Secret", "type": "password", "required": True},
            {"key": "instance_url", "label": "Salesforce Instance URL", "type": "url", "required": True,
             "placeholder": "https://yourorg.my.salesforce.com"},
        ],
    },
}

# Data types that can be pushed
PUSHABLE_DATA_TYPES = {
    "summary": "Medical Record Summary",
    "demand_package": "Demand Package",
    "deposition": "Deposition Summary",
    "negligence": "Negligence Analysis",
    "valuation": "Case Valuation",
}


# ── Configuration ────────────────────────────────────────────────────────────

def _load_integrations_config():
    """Load integrations config from config.yaml."""
    if not CONFIG_PATH.exists():
        return {}
    with open(CONFIG_PATH, encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    return config.get("integrations", {})


def _save_integrations_config(integrations_config):
    """Save integrations config back to config.yaml."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    else:
        config = {}

    config["integrations"] = integrations_config

    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


def list_integrations():
    """Return all supported platforms and their current configuration status."""
    config = _load_integrations_config()
    result = []
    for platform_id, platform_def in SUPPORTED_PLATFORMS.items():
        platform_config = config.get(platform_id, {})
        result.append({
            "id": platform_id,
            "name": platform_def["name"],
            "description": platform_def["description"],
            "config_fields": platform_def["config_fields"],
            "configured": bool(platform_config.get("enabled")),
            "enabled": platform_config.get("enabled", False),
            "last_push": platform_config.get("last_push"),
            "push_count": platform_config.get("push_count", 0),
        })
    return result


def configure_integration(platform_id, settings):
    """Configure an integration platform."""
    if platform_id not in SUPPORTED_PLATFORMS:
        raise ValueError(f"Unknown platform: {platform_id}")

    platform_def = SUPPORTED_PLATFORMS[platform_id]
    config = _load_integrations_config()

    # Validate required fields
    for field in platform_def["config_fields"]:
        if field["required"] and not settings.get(field["key"]):
            raise ValueError(f"Missing required field: {field['label']}")

    # Save config
    platform_config = config.get(platform_id, {})
    platform_config.update(settings)
    platform_config["enabled"] = True
    platform_config["configured_at"] = datetime.now(timezone.utc).isoformat()
    config[platform_id] = platform_config

    _save_integrations_config(config)
    return {"ok": True, "platform": platform_id, "status": "configured"}


def disable_integration(platform_id):
    """Disable an integration without deleting its config."""
    config = _load_integrations_config()
    if platform_id in config:
        config[platform_id]["enabled"] = False
        _save_integrations_config(config)
    return {"ok": True, "platform": platform_id, "status": "disabled"}


# ── Data Push ────────────────────────────────────────────────────────────────

def push_to_integration(platform_id, data, data_type="summary", case_ref=None):
    """
    Push data to an integration platform.

    Args:
        platform_id: 'webhook', 'filevine', 'casepeer', or 'litify'
        data: The data dict to push (summary, demand package, etc.)
        data_type: Type of data being pushed
        case_ref: Optional case reference for filing

    Returns:
        dict with push result
    """
    if platform_id not in SUPPORTED_PLATFORMS:
        raise ValueError(f"Unknown platform: {platform_id}")

    config = _load_integrations_config()
    platform_config = config.get(platform_id, {})

    if not platform_config.get("enabled"):
        raise ValueError(f"Integration '{platform_id}' is not enabled. Configure it first.")

    # Route to platform-specific handler
    handlers = {
        "webhook": _push_webhook,
        "filevine": _push_filevine,
        "casepeer": _push_casepeer,
        "litify": _push_litify,
    }

    handler = handlers.get(platform_id)
    if not handler:
        raise ValueError(f"No handler for platform: {platform_id}")

    # Build payload
    payload = {
        "source": "MedRecords AI",
        "data_type": data_type,
        "data_type_label": PUSHABLE_DATA_TYPES.get(data_type, data_type),
        "case_ref": case_ref,
        "pushed_at": datetime.now(timezone.utc).isoformat(),
        "data": data,
    }

    try:
        result = handler(platform_config, payload)
        result["data_type"] = data_type
        result["platform"] = platform_id

        # Update push stats
        platform_config["last_push"] = datetime.now(timezone.utc).isoformat()
        platform_config["push_count"] = platform_config.get("push_count", 0) + 1
        config[platform_id] = platform_config
        _save_integrations_config(config)

        # Log the push
        _log_push(platform_id, data_type, case_ref, "success", result)

        return result

    except Exception as e:
        _log_push(platform_id, data_type, case_ref, "failed", {"error": str(e)})
        raise


def test_connection(platform_id):
    """Test connectivity to an integration platform."""
    config = _load_integrations_config()
    platform_config = config.get(platform_id, {})

    if not platform_config.get("enabled"):
        return {"ok": False, "error": "Integration not configured"}

    if platform_id == "webhook":
        url = platform_config.get("url")
        if not url:
            return {"ok": False, "error": "No webhook URL configured"}
        try:
            headers = {"Content-Type": "application/json"}
            auth = platform_config.get("auth_header")
            if auth:
                headers["Authorization"] = auth
            resp = requests.post(
                url, json={"test": True, "source": "MedRecords AI"},
                headers=headers, timeout=10,
            )
            return {
                "ok": resp.status_code < 400,
                "status_code": resp.status_code,
                "message": f"Webhook responded with {resp.status_code}",
            }
        except requests.RequestException as e:
            return {"ok": False, "error": str(e)}

    elif platform_id == "filevine":
        return _test_filevine(platform_config)
    elif platform_id == "casepeer":
        return _test_casepeer(platform_config)
    elif platform_id == "litify":
        return _test_litify(platform_config)

    return {"ok": False, "error": "Unknown platform"}


# ── Platform Handlers ────────────────────────────────────────────────────────

def _push_webhook(config, payload):
    """Push data via generic webhook (HTTP POST)."""
    url = config.get("url")
    if not url:
        raise ValueError("No webhook URL configured")

    headers = {"Content-Type": "application/json"}
    auth = config.get("auth_header")
    if auth:
        headers["Authorization"] = auth

    custom = config.get("custom_headers")
    if custom:
        if isinstance(custom, str):
            try:
                custom = json.loads(custom)
            except json.JSONDecodeError:
                pass
        if isinstance(custom, dict):
            headers.update(custom)

    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    resp.raise_for_status()

    return {
        "ok": True,
        "status_code": resp.status_code,
        "response": resp.text[:500] if resp.text else "",
    }


def _push_filevine(config, payload):
    """Push data to Filevine via their API."""
    api_key = config.get("api_key")
    org_id = config.get("org_id")
    base_url = config.get("base_url", "https://api.filevine.io")

    if not api_key or not org_id:
        raise ValueError("Filevine API key and Organization ID required")

    headers = {
        "Content-Type": "application/json",
        "x-fv-sessionid": api_key,
        "x-fv-orgid": org_id,
    }

    # Push as a note on the case
    case_ref = payload.get("case_ref")
    note_body = _format_as_note(payload)

    # If no specific project ID, push to the notes endpoint
    endpoint = f"{base_url}/core/notes"
    note_data = {
        "body": note_body,
        "subject": f"MedRecords AI - {payload.get('data_type_label', 'Analysis')}",
    }

    resp = requests.post(endpoint, json=note_data, headers=headers, timeout=30)
    resp.raise_for_status()

    return {"ok": True, "status_code": resp.status_code, "note_id": resp.json().get("noteId")}


def _push_casepeer(config, payload):
    """Push data to CASEpeer."""
    api_key = config.get("api_key")
    base_url = config.get("base_url", "https://api.casepeer.com/v1")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    note_body = _format_as_note(payload)
    note_data = {
        "content": note_body,
        "title": f"MedRecords AI - {payload.get('data_type_label', 'Analysis')}",
    }

    resp = requests.post(f"{base_url}/notes", json=note_data, headers=headers, timeout=30)
    resp.raise_for_status()

    return {"ok": True, "status_code": resp.status_code}


def _push_litify(config, payload):
    """Push data to Litify (Salesforce)."""
    instance_url = config.get("instance_url", "").rstrip("/")
    client_id = config.get("client_id")
    client_secret = config.get("client_secret")
    access_token = config.get("_access_token")

    if not access_token:
        # OAuth token exchange
        token_resp = requests.post(f"{instance_url}/services/oauth2/token", data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }, timeout=15)
        token_resp.raise_for_status()
        access_token = token_resp.json()["access_token"]

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}",
    }

    note_body = _format_as_note(payload)
    # Create a ContentNote in Salesforce
    note_data = {
        "Title": f"MedRecords AI - {payload.get('data_type_label', 'Analysis')}",
        "Content": note_body,
    }

    resp = requests.post(
        f"{instance_url}/services/data/v59.0/sobjects/ContentNote",
        json=note_data, headers=headers, timeout=30,
    )
    resp.raise_for_status()

    return {"ok": True, "status_code": resp.status_code, "record_id": resp.json().get("id")}


# ── Test Handlers ────────────────────────────────────────────────────────────

def _test_filevine(config):
    """Test Filevine API connection."""
    try:
        headers = {
            "x-fv-sessionid": config.get("api_key", ""),
            "x-fv-orgid": config.get("org_id", ""),
        }
        base_url = config.get("base_url", "https://api.filevine.io")
        resp = requests.get(f"{base_url}/core/users/me", headers=headers, timeout=10)
        return {"ok": resp.status_code == 200, "status_code": resp.status_code}
    except requests.RequestException as e:
        return {"ok": False, "error": str(e)}


def _test_casepeer(config):
    """Test CASEpeer API connection."""
    try:
        headers = {"Authorization": f"Bearer {config.get('api_key', '')}"}
        base_url = config.get("base_url", "https://api.casepeer.com/v1")
        resp = requests.get(f"{base_url}/me", headers=headers, timeout=10)
        return {"ok": resp.status_code == 200, "status_code": resp.status_code}
    except requests.RequestException as e:
        return {"ok": False, "error": str(e)}


def _test_litify(config):
    """Test Litify/Salesforce connection."""
    try:
        instance_url = config.get("instance_url", "").rstrip("/")
        token_resp = requests.post(f"{instance_url}/services/oauth2/token", data={
            "grant_type": "client_credentials",
            "client_id": config.get("client_id", ""),
            "client_secret": config.get("client_secret", ""),
        }, timeout=10)
        return {"ok": token_resp.status_code == 200, "status_code": token_resp.status_code}
    except requests.RequestException as e:
        return {"ok": False, "error": str(e)}


# ── Helpers ──────────────────────────────────────────────────────────────────

def _format_as_note(payload):
    """Format push payload as a readable note for case management systems."""
    data_type = payload.get("data_type", "summary")
    data = payload.get("data", {})

    lines = [
        f"=== MedRecords AI {payload.get('data_type_label', 'Report')} ===",
        f"Generated: {payload.get('pushed_at', '')}",
    ]

    if payload.get("case_ref"):
        lines.append(f"Case Reference: {payload['case_ref']}")

    lines.append("")

    if data_type == "summary":
        summary = data.get("summary", {})
        lines.append("EXECUTIVE SUMMARY:")
        lines.append(summary.get("bluf", summary.get("summary_narrative", "See attached summary.")))
        lines.append("")
        diagnoses = summary.get("active_diagnoses", [])
        if diagnoses:
            lines.append("ACTIVE DIAGNOSES:")
            for d in diagnoses[:10]:
                if isinstance(d, dict):
                    lines.append(f"  - {d.get('diagnosis', d.get('name', str(d)))}")
                else:
                    lines.append(f"  - {d}")

    elif data_type == "deposition":
        lines.append("DEPOSITION SUMMARY:")
        lines.append(data.get("summary_narrative", "See attached analysis."))
        lines.append("")
        admissions = data.get("admissions", [])
        if admissions:
            lines.append(f"KEY ADMISSIONS ({len(admissions)}):")
            for a in admissions[:5]:
                lines.append(f"  - {a.get('statement', str(a))}")

    elif data_type == "negligence":
        findings = data.get("findings", [])
        lines.append(f"NEGLIGENCE FINDINGS ({len(findings)}):")
        for f in findings[:10]:
            lines.append(f"  [{f.get('severity', '?').upper()}] {f.get('title', str(f))}")

    elif data_type == "valuation":
        lines.append(f"Estimated Range: ${data.get('low_estimate', 0):,.0f} - ${data.get('high_estimate', 0):,.0f}")
        lines.append(f"Median Estimate: ${data.get('median_estimate', 0):,.0f}")

    lines.append("")
    lines.append("--- Generated by MedRecords AI (https://aiproductivity.dev) ---")

    return "\n".join(lines)


def _log_push(platform_id, data_type, case_ref, status, details):
    """Log integration push for audit trail."""
    INTEGRATIONS_LOG.parent.mkdir(parents=True, exist_ok=True)

    log_entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "platform": platform_id,
        "data_type": data_type,
        "case_ref": case_ref,
        "status": status,
        "details": details,
    }

    # Append to log file
    log = []
    if INTEGRATIONS_LOG.exists():
        try:
            with open(INTEGRATIONS_LOG, encoding="utf-8") as f:
                log = json.load(f)
        except (json.JSONDecodeError, Exception):
            log = []

    log.append(log_entry)

    # Keep last 500 entries
    if len(log) > 500:
        log = log[-500:]

    with open(INTEGRATIONS_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)


def get_push_history(limit=50):
    """Get recent push history."""
    if not INTEGRATIONS_LOG.exists():
        return []
    try:
        with open(INTEGRATIONS_LOG, encoding="utf-8") as f:
            log = json.load(f)
        return log[-limit:][::-1]  # Most recent first
    except Exception:
        return []
