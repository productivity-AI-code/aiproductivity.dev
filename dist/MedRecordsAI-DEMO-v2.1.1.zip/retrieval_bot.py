"""
retrieval_bot.py -- Medical Records Retrieval Daemon.

Polls contacts_tracking.xlsx hourly for new contacts.
Sends request emails via SMTP, monitors inbox via IMAP for replies/attachments.
Downloads attachments to vault/incoming/.
Provides secure upload tokens for contacts to upload records via web.

Usage:
  python retrieval_bot.py                    # Run continuously (PM2)
  python retrieval_bot.py --once             # Single cycle and exit
  python retrieval_bot.py --dry-run          # Preview without sending emails
"""

import argparse
import email
import email.utils
import hashlib
import imaplib
import json
import logging
import os
import re
import secrets
import smtplib
import sqlite3
import ssl
import sys
import time
from datetime import datetime, timezone, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import openpyxl
import yaml
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent
VAULT_INCOMING = BASE_DIR / "vault" / "incoming"
VAULT_AUDIT = BASE_DIR / "vault" / "audit"
TRACKING_DB = BASE_DIR / "tracking.db"
TEMPLATES_DIR = BASE_DIR / "email_templates"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("retrieval_bot")


# ── Configuration ────────────────────────────────────────────────────────────

def load_config():
    with open(BASE_DIR / "config.yaml") as f:
        return yaml.safe_load(f)


def _load_email_config_from_db():
    """Load email config from the email_config SQLite table (set via UI)."""
    try:
        conn = sqlite3.connect(str(TRACKING_DB))
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM email_config WHERE enabled = 1 ORDER BY id DESC LIMIT 1").fetchone()
        conn.close()
        if row:
            return dict(row)
    except Exception:
        pass
    return None


def get_smtp_config():
    db_cfg = _load_email_config_from_db()
    if db_cfg and db_cfg.get("smtp_host"):
        return {
            "host": db_cfg["smtp_host"],
            "port": int(db_cfg.get("smtp_port", 587)),
            "username": db_cfg.get("smtp_username", ""),
            "password": db_cfg.get("smtp_password_encrypted", ""),
        }
    return {
        "host": os.getenv("SMTP_HOST", ""),
        "port": int(os.getenv("SMTP_PORT", "587")),
        "username": os.getenv("SMTP_USERNAME", ""),
        "password": os.getenv("SMTP_PASSWORD", ""),
    }


def get_imap_config():
    db_cfg = _load_email_config_from_db()
    if db_cfg and db_cfg.get("imap_host"):
        return {
            "host": db_cfg["imap_host"],
            "port": int(db_cfg.get("imap_port", 993)),
            "username": db_cfg.get("imap_username", ""),
            "password": db_cfg.get("imap_password_encrypted", ""),
        }
    return {
        "host": os.getenv("IMAP_HOST", ""),
        "port": int(os.getenv("IMAP_PORT", "993")),
        "username": os.getenv("IMAP_USERNAME", ""),
        "password": os.getenv("IMAP_PASSWORD", ""),
    }


def get_sender_info():
    db_cfg = _load_email_config_from_db()
    if db_cfg and db_cfg.get("sender_name"):
        return {
            "sender_name": db_cfg["sender_name"],
            "sender_organization": db_cfg.get("sender_organization", ""),
            "sender_phone": db_cfg.get("sender_phone", ""),
        }
    return {
        "sender_name": os.getenv("SENDER_NAME", "Records Department"),
        "sender_organization": os.getenv("SENDER_ORGANIZATION", ""),
        "sender_phone": os.getenv("SENDER_PHONE", ""),
    }


# ── SQLite Tracking Database ────────────────────────────────────────────────

def init_tracking_db():
    conn = sqlite3.connect(str(TRACKING_DB))
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            contact_name TEXT NOT NULL,
            contact_email TEXT NOT NULL,
            contact_type TEXT NOT NULL CHECK(contact_type IN ('custodian','counsel','patient')),
            organization TEXT,
            patient_case_ref TEXT,
            record_type_needed TEXT,
            date_added TEXT NOT NULL,
            status TEXT DEFAULT 'new' CHECK(status IN ('new','contacted','awaiting','received','failed')),
            last_contact_date TEXT,
            thread_id TEXT,
            upload_token TEXT,
            notes TEXT,
            priority TEXT DEFAULT 'normal',
            excel_row INTEGER,
            follow_up_count INTEGER DEFAULT 0,
            last_follow_up_at TEXT,
            expected_receipt_date TEXT,
            follow_up_tier TEXT DEFAULT 'polite',
            last_reply_text TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )
    """)

    # Migration: add new columns to existing tables
    for col, col_type, default in [
        ("last_follow_up_at", "TEXT", None),
        ("expected_receipt_date", "TEXT", None),
        ("follow_up_tier", "TEXT", "'polite'"),
        ("last_reply_text", "TEXT", None),
    ]:
        try:
            default_clause = f" DEFAULT {default}" if default else ""
            c.execute(f"ALTER TABLE contacts ADD COLUMN {col} {col_type}{default_clause}")
        except sqlite3.OperationalError:
            pass  # Column already exists

    c.execute("""
        CREATE TABLE IF NOT EXISTS email_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            contact_id INTEGER REFERENCES contacts(id),
            direction TEXT CHECK(direction IN ('outbound','inbound')),
            message_id TEXT,
            subject TEXT,
            timestamp TEXT,
            has_attachments INTEGER DEFAULT 0,
            attachment_paths TEXT
        )
    """)

    conn.commit()
    return conn


def get_db():
    conn = sqlite3.connect(str(TRACKING_DB))
    conn.row_factory = sqlite3.Row
    return conn


# ── Excel ↔ SQLite Sync ─────────────────────────────────────────────────────

def sync_excel_to_db(excel_path):
    """Read Excel file, upsert new contacts into SQLite."""
    if not Path(excel_path).exists():
        logger.warning("Excel file not found: %s", excel_path)
        return 0

    wb = openpyxl.load_workbook(excel_path, data_only=True)
    ws = wb["Contacts"]
    conn = get_db()
    c = conn.cursor()
    new_count = 0

    for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=False), start=2):
        values = [cell.value for cell in row]
        if not values[0] or not values[1]:
            continue  # Skip rows without name/email

        name = str(values[0]).strip()
        email_addr = str(values[1]).strip()
        contact_type = str(values[2] or "custodian").strip().lower()
        if contact_type not in ("custodian", "counsel", "patient"):
            contact_type = "custodian"

        organization = str(values[3] or "").strip()
        case_ref = str(values[4] or "").strip()
        record_type = str(values[5] or "").strip()
        date_added = values[6]
        if not date_added:
            date_added = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        elif hasattr(date_added, "strftime"):
            date_added = date_added.strftime("%Y-%m-%d")
        else:
            date_added = str(date_added)

        status = str(values[7] or "new").strip().lower()
        notes = str(values[11] or "").strip() if len(values) > 11 else ""
        priority = str(values[12] or "normal").strip().lower() if len(values) > 12 else "normal"

        # Check if this contact already exists (by email + case_ref)
        existing = c.execute(
            "SELECT id FROM contacts WHERE contact_email = ? AND patient_case_ref = ?",
            (email_addr, case_ref),
        ).fetchone()

        if not existing:
            upload_token = secrets.token_urlsafe(32)
            c.execute(
                """INSERT INTO contacts
                (contact_name, contact_email, contact_type, organization,
                 patient_case_ref, record_type_needed, date_added, status,
                 upload_token, notes, priority, excel_row)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (name, email_addr, contact_type, organization,
                 case_ref, record_type, date_added, status,
                 upload_token, notes, priority, row_num),
            )
            new_count += 1
            logger.info("New contact: %s <%s> [%s]", name, email_addr, contact_type)

    conn.commit()
    conn.close()
    wb.close()
    return new_count


def sync_db_to_excel(excel_path):
    """Write status updates from SQLite back to Excel."""
    if not Path(excel_path).exists():
        return

    wb = openpyxl.load_workbook(excel_path)
    ws = wb["Contacts"]
    conn = get_db()

    contacts = conn.execute(
        "SELECT excel_row, status, last_contact_date, thread_id, upload_token FROM contacts WHERE excel_row IS NOT NULL"
    ).fetchall()

    for contact in contacts:
        row = contact["excel_row"]
        if row and row >= 2:
            ws.cell(row=row, column=8, value=contact["status"])        # Status
            ws.cell(row=row, column=9, value=contact["last_contact_date"])  # Last Contact
            ws.cell(row=row, column=10, value=contact["thread_id"])    # Thread ID
            ws.cell(row=row, column=11, value=contact["upload_token"]) # Upload Token

    wb.save(excel_path)
    wb.close()
    conn.close()


# ── Email Templates ──────────────────────────────────────────────────────────

def load_email_template(contact_type):
    """Load the appropriate email template for the contact type."""
    template_map = {
        "custodian": "custodian_request.txt",
        "counsel": "counsel_request.txt",
        "patient": "patient_request.txt",
    }
    template_file = TEMPLATES_DIR / template_map.get(contact_type, "custodian_request.txt")
    if template_file.exists():
        return template_file.read_text(encoding="utf-8")
    logger.error("Template not found: %s", template_file)
    return None


def render_template(template_text, contact, upload_url):
    """Fill in template placeholders with contact data."""
    sender = get_sender_info()
    replacements = {
        "{contact_name}": contact["contact_name"],
        "{patient_case_ref}": contact["patient_case_ref"] or "N/A",
        "{record_type_needed}": contact["record_type_needed"] or "Complete medical records",
        "{upload_link}": upload_url,
        "{sender_name}": sender["sender_name"],
        "{sender_organization}": sender["sender_organization"],
        "{sender_phone}": sender["sender_phone"],
    }
    result = template_text
    for key, value in replacements.items():
        result = result.replace(key, value)
    return result


# ── SMTP: Send Emails ────────────────────────────────────────────────────────

def send_email(to_email, subject, body, reply_to_msg_id=None):
    """Send an email via SMTP/TLS. Returns the Message-ID."""
    smtp_cfg = get_smtp_config()
    if not smtp_cfg["host"] or not smtp_cfg["username"]:
        logger.error("SMTP not configured. Set SMTP_HOST and SMTP_USERNAME in .env")
        return None

    msg = MIMEMultipart()
    msg["From"] = f"{get_sender_info()['sender_name']} <{smtp_cfg['username']}>"
    msg["To"] = to_email
    msg["Subject"] = subject
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg["Message-ID"] = email.utils.make_msgid(domain=smtp_cfg["host"].split(".")[-2] + "." + smtp_cfg["host"].split(".")[-1] if "." in smtp_cfg["host"] else "local")

    if reply_to_msg_id:
        msg["In-Reply-To"] = reply_to_msg_id
        msg["References"] = reply_to_msg_id

    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_cfg["host"], smtp_cfg["port"]) as server:
            server.starttls(context=context)
            server.login(smtp_cfg["username"], smtp_cfg["password"])
            server.send_message(msg)
        logger.info("Email sent to %s: %s", to_email, subject)
        return msg["Message-ID"]
    except Exception as e:
        logger.error("Failed to send email to %s: %s", to_email, e)
        return None


def send_request_email(contact, dry_run=False):
    """Send initial records request email to a contact."""
    template = load_email_template(contact["contact_type"])
    if not template:
        return None

    upload_base = os.getenv("UPLOAD_BASE_URL", "http://localhost:8080")
    upload_url = f"{upload_base}/api/secure-upload/{contact['upload_token']}"

    rendered = render_template(template, contact, upload_url)

    # Extract subject from template (first line starting with "Subject:")
    lines = rendered.split("\n")
    subject = "Medical Records Request"
    body_start = 0
    for i, line in enumerate(lines):
        if line.startswith("Subject:"):
            subject = line.replace("Subject:", "").strip()
            # Fill in subject placeholders
            subject = subject.replace("{patient_case_ref}", contact["patient_case_ref"] or "N/A")
            body_start = i + 1
            break

    body = "\n".join(lines[body_start:]).strip()

    if dry_run:
        logger.info("[DRY RUN] Would send to %s: %s", contact["contact_email"], subject)
        return "dry-run-message-id"

    return send_email(contact["contact_email"], subject, body)


# ── IMAP: Check Inbox ────────────────────────────────────────────────────────

ALLOWED_EXTENSIONS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif",
    ".dcm", ".dicom", ".doc", ".docx", ".txt", ".zip",
    ".csv", ".json", ".xml", ".log", ".xlsx", ".xls",
    ".html", ".htm",
}


def check_inbox_for_replies():
    """
    Check IMAP inbox for replies to our sent emails.
    Match by In-Reply-To/References headers against stored thread_ids.
    Download any attachments to vault/incoming/.
    """
    imap_cfg = get_imap_config()
    if not imap_cfg["host"] or not imap_cfg["username"]:
        logger.warning("IMAP not configured. Skipping inbox check.")
        return []

    conn = get_db()
    # Get all active thread_ids
    active_threads = {}
    for row in conn.execute(
        "SELECT id, thread_id, contact_name, patient_case_ref FROM contacts WHERE thread_id IS NOT NULL AND status IN ('contacted', 'awaiting')"
    ).fetchall():
        active_threads[row["thread_id"]] = {"id": row["id"], "name": row["contact_name"], "case_ref": row["patient_case_ref"]}

    if not active_threads:
        conn.close()
        return []

    results = []

    try:
        context = ssl.create_default_context()
        mail = imaplib.IMAP4_SSL(imap_cfg["host"], imap_cfg["port"], ssl_context=context)
        mail.login(imap_cfg["username"], imap_cfg["password"])
        mail.select("INBOX")

        # Search for recent unseen messages (last 7 days to avoid large mailbox issues)
        since_date = (datetime.now(timezone.utc) - timedelta(days=7)).strftime("%d-%b-%Y")
        status, message_ids = mail.search(None, f'(UNSEEN SINCE {since_date})')
        if status != "OK" or not message_ids[0]:
            mail.logout()
            conn.close()
            return []

        for msg_id in message_ids[0].split():
            # Use BODY.PEEK to avoid auto-marking as SEEN
            status, msg_data = mail.fetch(msg_id, "(BODY.PEEK[])")
            if status != "OK":
                continue

            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)

            # Check if this is a reply to one of our threads
            in_reply_to = msg.get("In-Reply-To", "")
            references = msg.get("References", "")
            matched_contact = None

            for thread_id, contact_info in active_threads.items():
                if thread_id in in_reply_to or thread_id in references:
                    matched_contact = contact_info
                    break

            if not matched_contact:
                # Not our thread — mark as seen so we don't re-check it
                mail.store(msg_id, '+FLAGS', '\\Seen')
                continue

            contact_id = matched_contact["id"]
            logger.info("Reply from %s (contact_id=%d)", matched_contact["name"], contact_id)

            # Download attachments
            attachment_paths = []
            for part in msg.walk():
                if part.get_content_maintype() == "multipart":
                    continue
                filename = part.get_filename()
                if not filename:
                    continue

                ext = Path(filename).suffix.lower()
                if ext not in ALLOWED_EXTENSIONS:
                    logger.warning("Skipping disallowed file type: %s", filename)
                    continue

                # Save to vault/incoming/{contact_id}/
                contact_dir = VAULT_INCOMING / str(contact_id)
                contact_dir.mkdir(parents=True, exist_ok=True)

                timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
                safe_filename = f"{timestamp}_{filename}"
                save_path = contact_dir / safe_filename

                with open(save_path, "wb") as f:
                    f.write(part.get_payload(decode=True))

                attachment_paths.append(str(save_path))
                logger.info("  Saved attachment: %s", save_path)

                # Register in documents table with case_ref from contact
                case_ref = matched_contact.get("case_ref")
                # Auto-detect case_ref if contact has none
                if not case_ref:
                    try:
                        from case_detector import suggest_case_ref as _suggest
                        existing_rows = conn.execute(
                            "SELECT DISTINCT case_ref FROM documents WHERE case_ref IS NOT NULL AND case_ref != ''"
                        ).fetchall()
                        existing_cases = [r["case_ref"] for r in existing_rows]
                        det = _suggest(filename, existing_cases)
                        if det and det["confidence"] in ("high", "medium"):
                            case_ref = det["suggestion"]
                            logger.info("  Auto-detected case_ref=%s for %s (source=%s)", case_ref, filename, det["source"])
                    except Exception as det_err:
                        logger.debug("Case detection skipped for %s: %s", filename, det_err)
                try:
                    file_hash = hashlib.sha256(save_path.read_bytes()).hexdigest()
                    conn.execute(
                        """INSERT INTO documents
                           (filename, original_path, current_path, file_hash, file_size,
                            extension, vault_zone, status, uploaded_by, upload_source,
                            contact_id, case_ref)
                           VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', 'email_bot', 'email', ?, ?)""",
                        (filename, str(save_path), str(save_path), file_hash,
                         save_path.stat().st_size, ext,
                         contact_id, case_ref),
                    )
                except Exception as doc_err:
                    logger.warning("Failed to register email attachment as document: %s", doc_err)

            # Update contact status
            new_status = "received" if attachment_paths else "awaiting"
            now = datetime.now(timezone.utc).isoformat()

            # Extract reply body text for ETA parsing (text-only replies)
            reply_body = ""
            if not attachment_paths:
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            reply_body = payload.decode("utf-8", errors="replace")
                            break

            # Parse expected delivery date from reply text
            expected_date = _parse_expected_date_from_reply(reply_body) if reply_body else None

            update_fields = "status = ?, last_contact_date = ?, updated_at = ?"
            update_params = [new_status, now, now]

            if reply_body:
                update_fields += ", last_reply_text = ?"
                update_params.append(reply_body[:2000])

            if expected_date:
                update_fields += ", expected_receipt_date = ?"
                update_params.append(expected_date)
                logger.info("  Detected expected receipt date: %s from %s", expected_date, matched_contact["name"])

            # If files received, clear the expected date
            if attachment_paths:
                update_fields += ", expected_receipt_date = NULL"

            update_params.append(contact_id)
            conn.execute(
                f"UPDATE contacts SET {update_fields} WHERE id = ?",
                update_params,
            )

            # Log the inbound email
            conn.execute(
                """INSERT INTO email_log (contact_id, direction, message_id, subject, timestamp, has_attachments, attachment_paths)
                VALUES (?, 'inbound', ?, ?, ?, ?, ?)""",
                (contact_id, msg.get("Message-ID", ""), msg.get("Subject", ""),
                 now, 1 if attachment_paths else 0, json.dumps(attachment_paths)),
            )

            # Audit log
            audit_log("file_received" if attachment_paths else "email_received", contact_id,
                       f"{'Attachments' if attachment_paths else 'Text reply'} from {matched_contact['name']}")

            results.append({
                "contact_id": contact_id,
                "attachments": attachment_paths,
                "status": new_status,
            })

            # Only mark as SEEN after successful processing
            mail.store(msg_id, '+FLAGS', '\\Seen')

        mail.logout()

    except Exception as e:
        logger.error("IMAP error: %s", e)

    conn.commit()
    conn.close()
    return results


# ── Follow-Up Protocol ────────────────────────────────────────────────────────

def _get_follow_up_config(config):
    """Extract follow-up configuration with defaults."""
    fu = config.get("retrieval", {}).get("follow_up", {})
    return {
        "initial_wait_hours": fu.get("initial_wait_hours", 4),
        "morning_hour": fu.get("morning_hour", 9),
        "evening_hour": fu.get("evening_hour", 17),
        "max_follow_ups": fu.get("max_follow_ups", 20),
        "deadline_grace_hours": fu.get("deadline_grace_hours", 2),
        "tiers": fu.get("escalation_tiers", {
            "polite": 0, "firm": 4, "urgent": 8, "final": 12,
        }),
    }


def _get_follow_up_tier(follow_up_count, tiers):
    """Determine the escalation tier based on follow-up count."""
    tier = "polite"
    for name in ("polite", "firm", "urgent", "final"):
        threshold = tiers.get(name, 999)
        if follow_up_count >= threshold:
            tier = name
    return tier


def _load_follow_up_template(tier, is_deadline_passed=False):
    """Load the appropriate follow-up email template for the given escalation tier."""
    if is_deadline_passed:
        template_file = TEMPLATES_DIR / "follow_up_deadline_passed.txt"
        if template_file.exists():
            return template_file.read_text(encoding="utf-8")

    template_map = {
        "polite": "follow_up_polite.txt",
        "firm": "follow_up_firm.txt",
        "urgent": "follow_up_urgent.txt",
        "final": "follow_up_final.txt",
    }
    template_file = TEMPLATES_DIR / template_map.get(tier, "follow_up_polite.txt")
    if template_file.exists():
        return template_file.read_text(encoding="utf-8")
    # Fallback to polite
    fallback = TEMPLATES_DIR / "follow_up_polite.txt"
    if fallback.exists():
        return fallback.read_text(encoding="utf-8")
    return None


def _render_follow_up(template_text, contact, upload_url):
    """Fill in follow-up template placeholders."""
    sender = get_sender_info()
    replacements = {
        "{contact_name}": contact.get("contact_name", ""),
        "{patient_case_ref}": contact.get("patient_case_ref") or "N/A",
        "{record_type_needed}": contact.get("record_type_needed") or "Complete medical records",
        "{upload_link}": upload_url,
        "{sender_name}": sender["sender_name"],
        "{sender_organization}": sender["sender_organization"],
        "{sender_phone}": sender["sender_phone"],
        "{follow_up_count}": str(contact.get("follow_up_count", 0)),
        "{original_request_date}": (contact.get("date_added") or "N/A")[:10],
        "{expected_date}": (contact.get("expected_receipt_date") or "N/A")[:10],
    }
    result = template_text
    for key, value in replacements.items():
        result = result.replace(key, str(value))
    return result


def _send_follow_up_email(contact, tier, config, is_deadline_passed=False, dry_run=False):
    """Send a follow-up email at the given tier. Returns message_id or None."""
    template = _load_follow_up_template(tier, is_deadline_passed)
    if not template:
        logger.warning("No template for tier=%s, deadline_passed=%s", tier, is_deadline_passed)
        return None

    upload_base = os.getenv("UPLOAD_BASE_URL", "http://localhost:8080")
    upload_url = f"{upload_base}/api/secure-upload/{contact.get('upload_token', '')}"

    rendered = _render_follow_up(template, contact, upload_url)

    # Extract subject and body
    lines = rendered.split("\n")
    subject = f"Follow-Up: Medical Records - {contact.get('patient_case_ref', 'N/A')}"
    body_start = 0
    for i, line in enumerate(lines):
        if line.startswith("Subject:"):
            subject = line.replace("Subject:", "").strip()
            for key, val in {
                "{patient_case_ref}": contact.get("patient_case_ref") or "N/A",
                "{expected_date}": (contact.get("expected_receipt_date") or "N/A")[:10],
            }.items():
                subject = subject.replace(key, val)
            body_start = i + 1
            break

    body = "\n".join(lines[body_start:]).strip()

    if dry_run:
        logger.info("[DRY RUN] Follow-up (%s) to %s: %s", tier, contact["contact_email"], subject)
        return "dry-run-follow-up"

    # Thread the follow-up on the original conversation
    reply_to = contact.get("thread_id")
    return send_email(contact["contact_email"], subject, body, reply_to_msg_id=reply_to)


def _is_business_hours_window(fu_config):
    """Check if current local time is within a follow-up window (morning or evening)."""
    now = datetime.now()
    hour = now.hour
    morning = fu_config["morning_hour"]
    evening = fu_config["evening_hour"]

    # Morning window: morning_hour to morning_hour + 1
    if morning <= hour < morning + 1:
        return "morning"
    # Evening window: evening_hour to evening_hour + 1
    if evening <= hour < evening + 1:
        return "evening"
    return None


def _parse_expected_date_from_reply(reply_text):
    """
    Attempt to extract a promised delivery date from an email reply.
    Looks for common patterns like 'by Friday', 'within 3 days', 'by 02/28', etc.
    Returns an ISO date string or None.
    """
    if not reply_text:
        return None

    text = reply_text.lower()
    now = datetime.now(timezone.utc)

    # Pattern: "within N days/business days"
    m = re.search(r'within\s+(\d+)\s+(?:business\s+)?days?', text)
    if m:
        days = int(m.group(1))
        return (now + timedelta(days=days)).strftime("%Y-%m-%d")

    # Pattern: "by end of week" / "by end of the week"
    if "end of" in text and "week" in text:
        days_until_friday = (4 - now.weekday()) % 7 or 7
        return (now + timedelta(days=days_until_friday)).strftime("%Y-%m-%d")

    # Pattern: "by MM/DD" or "by MM-DD" or "by YYYY-MM-DD"
    m = re.search(r'by\s+(\d{1,2})[/\-](\d{1,2})(?:[/\-](\d{2,4}))?', text)
    if m:
        month, day = int(m.group(1)), int(m.group(2))
        year = int(m.group(3)) if m.group(3) else now.year
        if year < 100:
            year += 2000
        try:
            target = datetime(year, month, day, tzinfo=timezone.utc)
            if target < now:
                target = target.replace(year=now.year + 1)
            return target.strftime("%Y-%m-%d")
        except ValueError:
            pass

    # Pattern: day names "by Monday", "by Friday", etc.
    day_names = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                 "friday": 4, "saturday": 5, "sunday": 6}
    for day_name, day_num in day_names.items():
        if f"by {day_name}" in text or f"on {day_name}" in text:
            days_ahead = (day_num - now.weekday()) % 7 or 7
            return (now + timedelta(days=days_ahead)).strftime("%Y-%m-%d")

    # Pattern: "tomorrow"
    if "tomorrow" in text:
        return (now + timedelta(days=1)).strftime("%Y-%m-%d")

    # Pattern: "next week"
    if "next week" in text:
        days_until_monday = (7 - now.weekday()) % 7 or 7
        return (now + timedelta(days=days_until_monday)).strftime("%Y-%m-%d")

    return None


def send_follow_ups(config, dry_run=False):
    """
    Aggressive follow-up protocol:

    1. Twice daily (morning + evening) follow-ups for unresponsive contacts
    2. Immediate follow-up when a promised deadline passes without file receipt
    3. Escalating tiers: polite → firm → urgent → final notice
    4. Parse replies for ETA/deadline promises and track them
    5. Only send during business hours windows unless deadline-triggered
    """
    fu_config = _get_follow_up_config(config)
    max_follow_ups = fu_config["max_follow_ups"]
    tiers = fu_config["tiers"]
    initial_wait = timedelta(hours=fu_config["initial_wait_hours"])
    deadline_grace = timedelta(hours=fu_config["deadline_grace_hours"])

    now = datetime.now(timezone.utc)
    conn = get_db()

    # ── Phase 1: Deadline-triggered follow-ups (any time of day) ──────────

    # Find contacts with a passed expected_receipt_date who haven't received files
    deadline_contacts = conn.execute(
        """SELECT * FROM contacts
           WHERE status IN ('contacted', 'awaiting')
           AND expected_receipt_date IS NOT NULL
           AND expected_receipt_date != ''
           AND follow_up_count < ?""",
        (max_follow_ups,),
    ).fetchall()

    for contact in deadline_contacts:
        try:
            expected = datetime.fromisoformat(contact["expected_receipt_date"]).replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            # Try parsing date-only format
            try:
                expected = datetime.strptime(contact["expected_receipt_date"][:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                continue

        # Add grace period
        if now < expected + deadline_grace:
            continue

        contact_dict = dict(contact)
        tier = _get_follow_up_tier(contact["follow_up_count"], tiers)
        logger.info("Deadline passed for %s (expected %s) — sending follow-up #%d (%s, deadline-triggered)",
                     contact["contact_name"], contact["expected_receipt_date"], contact["follow_up_count"] + 1, tier)

        msg_id = _send_follow_up_email(contact_dict, tier, config, is_deadline_passed=True, dry_run=dry_run)
        if msg_id:
            update_now = now.isoformat()
            conn.execute(
                """UPDATE contacts SET follow_up_count = follow_up_count + 1,
                   last_follow_up_at = ?, last_contact_date = ?, follow_up_tier = ?,
                   expected_receipt_date = NULL, updated_at = ?
                   WHERE id = ?""",
                (update_now, update_now, tier, update_now, contact["id"]),
            )
            conn.execute(
                """INSERT INTO email_log (contact_id, direction, message_id, subject, timestamp)
                VALUES (?, 'outbound', ?, ?, ?)""",
                (contact["id"], msg_id, f"Follow-up (deadline passed, {tier})", update_now),
            )
            audit_log("follow_up_deadline", contact["id"],
                       f"Deadline-triggered follow-up #{contact['follow_up_count'] + 1} ({tier})")

    # ── Phase 2: Scheduled twice-daily follow-ups (business hours only) ───

    window = _is_business_hours_window(fu_config)
    if window:
        # Find contacts that need regular follow-ups
        eligible = conn.execute(
            """SELECT * FROM contacts
               WHERE status IN ('contacted', 'awaiting')
               AND follow_up_count < ?
               AND (expected_receipt_date IS NULL OR expected_receipt_date = '')""",
            (max_follow_ups,),
        ).fetchall()

        for contact in eligible:
            # Check initial wait period (don't follow up too soon after first contact)
            last_contact = contact["last_contact_date"]
            if last_contact:
                try:
                    last_dt = datetime.fromisoformat(last_contact).replace(tzinfo=timezone.utc)
                except (ValueError, TypeError):
                    last_dt = now - initial_wait - timedelta(hours=1)
                if now - last_dt < initial_wait:
                    continue

            # Don't send more than one follow-up per window (check last_follow_up_at)
            last_fu = contact["last_follow_up_at"]
            if last_fu:
                try:
                    last_fu_dt = datetime.fromisoformat(last_fu).replace(tzinfo=timezone.utc)
                    # Skip if we already sent a follow-up within the last 4 hours
                    if now - last_fu_dt < timedelta(hours=4):
                        continue
                except (ValueError, TypeError):
                    pass

            contact_dict = dict(contact)
            tier = _get_follow_up_tier(contact["follow_up_count"], tiers)
            logger.info("Scheduled %s follow-up #%d to %s (%s tier)",
                         window, contact["follow_up_count"] + 1, contact["contact_name"], tier)

            msg_id = _send_follow_up_email(contact_dict, tier, config, dry_run=dry_run)
            if msg_id:
                update_now = now.isoformat()
                conn.execute(
                    """UPDATE contacts SET follow_up_count = follow_up_count + 1,
                       last_follow_up_at = ?, last_contact_date = ?, follow_up_tier = ?,
                       updated_at = ?
                       WHERE id = ?""",
                    (update_now, update_now, tier, update_now, contact["id"]),
                )
                conn.execute(
                    """INSERT INTO email_log (contact_id, direction, message_id, subject, timestamp)
                    VALUES (?, 'outbound', ?, ?, ?)""",
                    (contact["id"], msg_id, f"Follow-up #{contact['follow_up_count'] + 1} ({window}, {tier})", update_now),
                )
                audit_log("follow_up_scheduled", contact["id"],
                           f"{window.title()} follow-up #{contact['follow_up_count'] + 1} ({tier})")

    # ── Phase 3: Mark exhausted contacts as failed ────────────────────────

    conn.execute(
        """UPDATE contacts SET status = 'failed', updated_at = datetime('now')
           WHERE status IN ('contacted', 'awaiting') AND follow_up_count >= ?""",
        (max_follow_ups,),
    )

    conn.commit()
    conn.close()


# ── Audit Logging ────────────────────────────────────────────────────────────

def audit_log(action, contact_id=None, details=""):
    """Write an audit entry to vault/audit/."""
    VAULT_AUDIT.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc)
    entry = {
        "timestamp": timestamp.isoformat(),
        "action": action,
        "source": "retrieval_bot",
        "contact_id": contact_id,
        "details": details,
        "user_or_system": "system",
    }
    filename = f"{timestamp.strftime('%Y%m%d-%H%M%S')}_{action}.json"
    out_path = VAULT_AUDIT / filename
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(entry, f, indent=2)


# ── Main Cycle ───────────────────────────────────────────────────────────────

def run_cycle(config, dry_run=False):
    """Single pass: sync Excel, send pending emails, check inbox, follow up."""
    excel_path = BASE_DIR / config.get("retrieval", {}).get("excel_file", "templates/contacts_tracking.xlsx")

    # 1. Sync Excel → SQLite
    new_contacts = sync_excel_to_db(str(excel_path))
    if new_contacts:
        logger.info("Imported %d new contacts from Excel", new_contacts)

    # 2. Send initial emails to new contacts
    conn = get_db()
    new_rows = conn.execute("SELECT * FROM contacts WHERE status = 'new'").fetchall()

    for contact in new_rows:
        contact_dict = dict(contact)
        msg_id = send_request_email(contact_dict, dry_run=dry_run)
        if msg_id and not dry_run:
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "UPDATE contacts SET status = 'contacted', thread_id = ?, last_contact_date = ?, updated_at = ? WHERE id = ?",
                (msg_id, now, now, contact["id"]),
            )
            conn.execute(
                """INSERT INTO email_log (contact_id, direction, message_id, subject, timestamp)
                VALUES (?, 'outbound', ?, 'Initial request', ?)""",
                (contact["id"], msg_id, now),
            )
            audit_log("email_sent", contact["id"], f"Initial request to {contact['contact_name']}")

    conn.commit()
    conn.close()

    # 3. Check inbox for replies
    replies = check_inbox_for_replies()
    if replies:
        logger.info("Processed %d inbox replies", len(replies))

    # 4. Send follow-ups for stale contacts
    send_follow_ups(config, dry_run=dry_run)

    # 5. Sync SQLite → Excel
    sync_db_to_excel(str(excel_path))

    logger.info("Cycle complete: %d new, %d replies", new_contacts, len(replies))


def run_loop(config, dry_run=False):
    """Main daemon loop with aggressive follow-up scheduling.

    Timing:
    - Full cycle (Excel sync + send + inbox + follow-up): every poll_interval
    - Inbox check: every inbox_check_interval
    - Follow-up check: every 30 minutes (checks business hours + deadlines)
    """
    poll_interval = config.get("retrieval", {}).get("poll_interval_seconds", 3600)
    inbox_interval = config.get("retrieval", {}).get("inbox_check_interval_seconds", 600)
    follow_up_interval = 1800  # Check follow-up conditions every 30 minutes

    logger.info("Retrieval bot started. Poll: %ds, Inbox: %ds, Follow-up check: %ds",
                poll_interval, inbox_interval, follow_up_interval)

    last_full_cycle = 0
    last_inbox_check = 0
    last_follow_up_check = 0

    while True:
        now = time.time()

        # Full cycle (Excel sync + send + inbox + follow-up) every poll_interval
        if now - last_full_cycle >= poll_interval:
            try:
                run_cycle(config, dry_run=dry_run)
            except Exception as e:
                logger.error("Cycle error: %s", e)
            last_full_cycle = now
            last_inbox_check = now  # inbox was checked in run_cycle
            last_follow_up_check = now  # follow-ups were checked in run_cycle

        # More frequent inbox checks
        elif now - last_inbox_check >= inbox_interval:
            try:
                replies = check_inbox_for_replies()
                if replies:
                    logger.info("Inbox check: %d replies", len(replies))
                    excel_path = BASE_DIR / config.get("retrieval", {}).get(
                        "excel_file", "templates/contacts_tracking.xlsx"
                    )
                    sync_db_to_excel(str(excel_path))
            except Exception as e:
                logger.error("Inbox check error: %s", e)
            last_inbox_check = now

        # Frequent follow-up checks (deadline-triggered + business hours windows)
        elif now - last_follow_up_check >= follow_up_interval:
            try:
                send_follow_ups(config, dry_run=dry_run)
            except Exception as e:
                logger.error("Follow-up check error: %s", e)
            last_follow_up_check = now

        time.sleep(30)  # Check conditions every 30 seconds


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Medical Records Retrieval Bot")
    parser.add_argument("--once", action="store_true", help="Run one cycle and exit")
    parser.add_argument("--dry-run", action="store_true", help="Preview without sending emails")
    args = parser.parse_args()

    config = load_config()
    init_tracking_db()

    if args.once:
        run_cycle(config, dry_run=args.dry_run)
    else:
        run_loop(config, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
