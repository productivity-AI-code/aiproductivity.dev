"""
setup_medical.py -- One-click setup for MedRecords AI.

Run this ONCE on the target machine to:
  1. Check Python version and required tools
  2. Install Python dependencies
  3. Create vault directory structure
  4. Initialize SQLite tracking database
  5. Generate Excel contacts template
  6. Create .env with secure defaults (or from .env.example)
  7. Verify Ollama is running and pull required models (dev mode)
  8. Run a schema validation self-test

Usage:
  python setup_medical.py                  # Full setup (developer mode)
  python setup_medical.py --product-mode   # Product installer (Claude API, no Ollama)
  python setup_medical.py --check          # Check only, no changes
  python setup_medical.py --skip-models    # Skip Ollama model download
"""

import argparse
import json
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent

# Colors for terminal output
class C:
    OK = "\033[92m"
    WARN = "\033[93m"
    FAIL = "\033[91m"
    BOLD = "\033[1m"
    END = "\033[0m"


def header(msg):
    print(f"\n{C.BOLD}{'='*60}{C.END}")
    print(f"{C.BOLD}  {msg}{C.END}")
    print(f"{C.BOLD}{'='*60}{C.END}")


def ok(msg):
    print(f"  {C.OK}[OK]{C.END} {msg}")


def warn(msg):
    print(f"  {C.WARN}[WARN]{C.END} {msg}")


def fail(msg):
    print(f"  {C.FAIL}[FAIL]{C.END} {msg}")


def step(msg):
    print(f"\n  {C.BOLD}>> {msg}{C.END}")


# ── Step 1: Check Python ─────────────────────────────────────────────────────

def check_python():
    header("Step 1: Checking Python Environment")
    v = sys.version_info
    print(f"  Python {v.major}.{v.minor}.{v.micro}")
    if v.major < 3 or (v.major == 3 and v.minor < 10):
        fail("Python 3.10+ required")
        return False
    ok("Python version OK")
    return True


# ── Step 2: Install Dependencies ─────────────────────────────────────────────

def install_deps(check_only=False):
    header("Step 2: Python Dependencies")
    req_file = BASE_DIR / "requirements.txt"
    if not req_file.exists():
        fail("requirements.txt not found")
        return False

    if check_only:
        step("Checking installed packages...")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--format=json"],
            capture_output=True, text=True,
        )
        installed = {p["name"].lower() for p in json.loads(result.stdout)}
        required = []
        for line in req_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                pkg = line.split(">=")[0].split("==")[0].split(">")[0].split("<")[0].strip().lower()
                required.append(pkg)

        missing = [p for p in required if p.replace("-", "_") not in installed
                   and p.replace("_", "-") not in installed
                   and p not in installed]
        if missing:
            warn(f"Missing packages: {', '.join(missing)}")
            print("    Run: pip install -r requirements.txt")
            return False
        ok("All required packages installed")
        return True

    step("Installing packages from requirements.txt...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(req_file)],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        fail("pip install failed")
        print(f"    {result.stderr[:500]}")
        return False
    ok("Dependencies installed")
    return True


# ── Step 3: Create Directory Structure ────────────────────────────────────────

def create_directories():
    header("Step 3: Directory Structure")
    dirs = [
        "vault/incoming",
        "vault/processing",
        "vault/processing/failed",
        "vault/processed",
        "vault/summaries",
        "vault/audit",
        "vault/pipeline_status",
        "templates",
        "logs",
    ]
    for d in dirs:
        path = BASE_DIR / d
        path.mkdir(parents=True, exist_ok=True)
        ok(f"  {d}/")
    return True


# ── Step 4: Initialize SQLite ─────────────────────────────────────────────────

def init_database(check_only=False):
    header("Step 4: Tracking Database")
    db_path = BASE_DIR / "tracking.db"

    if check_only:
        if db_path.exists():
            ok(f"Database exists: {db_path}")
            return True
        warn("Database not yet created")
        return False

    step("Initializing tracking.db via db.py...")
    try:
        sys.path.insert(0, str(BASE_DIR))
        from db import init_db
        init_db()
        ok("tracking.db created with full schema (all tables)")
        return True
    except Exception as e:
        fail(f"Database init failed: {e}")
        return False


# ── Step 5: Generate Excel Template ──────────────────────────────────────────

def create_excel_template(check_only=False):
    header("Step 5: Excel Contacts Template")
    excel_path = BASE_DIR / "templates" / "contacts_tracking.xlsx"

    if excel_path.exists():
        ok("Excel template already exists")
        return True

    if check_only:
        warn("Excel template not yet created")
        return False

    step("Generating contacts_tracking.xlsx...")
    try:
        from openpyxl import Workbook
        from openpyxl.worksheet.datavalidation import DataValidation

        wb = Workbook()
        ws = wb.active
        ws.title = "Contacts"

        headers = [
            "Contact Name", "Contact Email", "Contact Type", "Organization",
            "Patient/Case Ref", "Record Type Needed", "Date Added", "Status",
            "Last Contact Date", "Thread ID", "Upload Token", "Notes", "Priority",
        ]
        ws.append(headers)

        # Column widths
        widths = [20, 30, 15, 25, 20, 25, 15, 12, 15, 15, 40, 30, 10]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[chr(64 + i)].width = w

        # Data validations
        type_dv = DataValidation(type="list", formula1='"custodian,counsel,patient"', allow_blank=True)
        type_dv.prompt = "Select contact type"
        ws.add_data_validation(type_dv)
        type_dv.add(f"C2:C1000")

        status_dv = DataValidation(
            type="list",
            formula1='"new,contacted,awaiting,received,failed"',
            allow_blank=True,
        )
        ws.add_data_validation(status_dv)
        status_dv.add(f"H2:H1000")

        priority_dv = DataValidation(type="list", formula1='"high,normal,low"', allow_blank=True)
        ws.add_data_validation(priority_dv)
        priority_dv.add(f"M2:M1000")

        wb.save(str(excel_path))
        ok(f"Created: {excel_path}")
        return True
    except ImportError:
        fail("openpyxl not installed. Run: pip install openpyxl")
        return False


# ── Step 6: Environment File ─────────────────────────────────────────────────

def check_env_file(check_only=False):
    header("Step 6: Environment Configuration")
    env_file = BASE_DIR / ".env"
    env_example = BASE_DIR / ".env.example"

    if env_file.exists():
        ok(".env file exists")
        # Check for placeholder values
        content = env_file.read_text()
        placeholders = []
        for line in content.splitlines():
            if "=" in line and not line.startswith("#"):
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip()
                if key.startswith("SMTP_") or key.startswith("IMAP_"):
                    if "example.com" in val or "your-" in val.lower() or not val:
                        placeholders.append(key)
                if key == "FLASK_SECRET_KEY" and ("change-this" in val or not val):
                    placeholders.append(key)
        if placeholders:
            warn(f"Configure these in .env: {', '.join(placeholders)}")
            print("    (Email features disabled until SMTP/IMAP are configured)")
        return True

    if check_only:
        warn(".env file not found")
        return False

    if env_example.exists():
        step("Copying .env.example to .env...")
        shutil.copy2(str(env_example), str(env_file))
        ok(".env created from .env.example")
        warn("IMPORTANT: Edit .env with your actual credentials")
        print("    Required for email features: SMTP_*, IMAP_*")
        print("    Required for security: FLASK_SECRET_KEY")
        return True
    else:
        fail(".env.example not found")
        return False


def setup_env_product_mode():
    """Product-mode .env setup: prompts for API key, auto-generates secure defaults."""
    header("Step 6: Configuration")
    env_file = BASE_DIR / ".env"

    # Check if .env already exists with a valid API key
    if env_file.exists():
        content = env_file.read_text()
        has_api_key = False
        for line in content.splitlines():
            if line.startswith("ANTHROPIC_API_KEY=") and len(line.split("=", 1)[1].strip()) > 10:
                has_api_key = True
                break
        if has_api_key:
            ok(".env configured with API key")
            return True

    # Generate secure defaults
    flask_secret = secrets.token_hex(32)
    admin_password = secrets.token_urlsafe(16)
    audit_key = secrets.token_hex(32)

    # Prompt for API key
    print()
    print(f"  {C.BOLD}Anthropic API Key Required{C.END}")
    print(f"  Get your key at: https://console.anthropic.com/settings/keys")
    print()

    api_key = ""
    while not api_key:
        try:
            api_key = input(f"  Enter your Anthropic API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            fail("Setup cancelled")
            return False

    if not api_key.startswith("sk-"):
        warn("API key doesn't start with 'sk-' — double-check it's correct")

    # Write .env
    env_content = f"""# ================================================================
# MedRecords AI — Configuration
# Generated during installation
# ================================================================

# Anthropic Claude API Key (REQUIRED)
ANTHROPIC_API_KEY={api_key}

# Flask Web UI & Authentication
FLASK_SECRET_KEY={flask_secret}
AUTH_USERNAME=admin
AUTH_PASSWORD={admin_password}
API_KEY=
AUDIT_HMAC_KEY={audit_key}
UPLOAD_BASE_URL=http://localhost:8080

# Email Configuration (optional — configure later in Settings)
SMTP_HOST=
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
IMAP_HOST=
IMAP_PORT=993
IMAP_USERNAME=
IMAP_PASSWORD=
SENDER_NAME=Records Department
SENDER_ORGANIZATION=
SENDER_PHONE=
"""
    env_file.write_text(env_content)
    ok(".env created with secure defaults")
    print()
    print(f"  {C.BOLD}Login Credentials:{C.END}")
    print(f"  {C.OK}  Username: admin{C.END}")
    print(f"  {C.OK}  Password: {admin_password}{C.END}")
    print(f"  {C.WARN}  Save these credentials — they won't be shown again.{C.END}")
    print()
    return True


# ── Step 7: Ollama Check ─────────────────────────────────────────────────────

def check_ollama(skip_models=False):
    header("Step 7: Ollama LLM Engine")

    # Check if Ollama is installed
    result = subprocess.run(
        ["ollama", "--version"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        fail("Ollama not found. Install from https://ollama.com/download")
        return False
    ok(f"Ollama installed: {result.stdout.strip()}")

    # Check if Ollama is running
    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            installed_models = [m["name"] for m in data.get("models", [])]
    except Exception as e:
        fail(f"Ollama not running: {e}")
        print("    Start Ollama: ollama serve")
        return False
    ok("Ollama server running")

    # Check required models
    required = ["qwen2.5:7b", "glm4:9b"]
    for model in required:
        # Check both exact match and base name match
        found = any(model in m or model.split(":")[0] in m for m in installed_models)
        if found:
            ok(f"Model available: {model}")
        else:
            if skip_models:
                warn(f"Model not found: {model} (skipped)")
            else:
                step(f"Pulling model: {model} (this may take a while)...")
                pull_result = subprocess.run(
                    ["ollama", "pull", model],
                    timeout=3600,
                )
                if pull_result.returncode == 0:
                    ok(f"Model pulled: {model}")
                else:
                    fail(f"Failed to pull {model}")
                    return False

    return True


# ── Step 8: Self-Test ─────────────────────────────────────────────────────────

def run_self_test():
    header("Step 8: Schema Validation Self-Test")

    try:
        from pipeline_schemas import (
            validate_ingestion_output,
            validate_privacy_output,
            validate_summary_output,
            validate_audit_output,
            extract_json_from_response,
            INGESTION_SCHEMA_EXAMPLE,
        )
    except ImportError as e:
        fail(f"Cannot import pipeline_schemas: {e}")
        return False

    # Test JSON extraction
    step("Testing JSON extraction...")
    test_cases = [
        ('{"key": "value"}', True),
        ('```json\n{"key": "value"}\n```', True),
        ('Here is the result:\n{"key": "value"}\nDone.', True),
        ('no json here', False),
    ]
    for text, should_pass in test_cases:
        try:
            extract_json_from_response(text)
            if should_pass:
                ok(f"Correctly parsed: {text[:40]}...")
            else:
                fail(f"Should have failed: {text[:40]}...")
                return False
        except ValueError:
            if not should_pass:
                ok(f"Correctly rejected: {text[:40]}...")
            else:
                fail(f"Should have passed: {text[:40]}...")
                return False

    # Test validators with valid data
    step("Testing schema validators...")
    valid_ingestion = {
        "document_id": "abc123",
        "source_file": "test.pdf",
        "ingestion_timestamp": "2024-01-01T00:00:00Z",
        "document_type": "clinical_note",
        "page_count": 1,
        "sections": [{
            "section_id": "sec_001",
            "section_type": "notes",
            "heading": "Test",
            "content": "Test content",
            "confidence": 0.95,
            "ocr_quality": "high",
        }],
    }
    errors = validate_ingestion_output(valid_ingestion)
    if errors:
        fail(f"Ingestion validator false positive: {errors}")
        return False
    ok("Ingestion validator: PASS")

    valid_privacy = {
        "document_id": "abc123",
        "privacy_timestamp": "2024-01-01T00:00:00Z",
        "sections": [{
            "section_id": "sec_001",
            "section_type": "notes",
            "content": "[REDACTED_NAME] presented with symptoms",
            "redactions_applied": [{"type": "NAME", "count": 1}],
        }],
        "phi_summary": {
            "total_identifiers_found": 1,
            "total_redacted": 1,
            "by_type": {"NAME": 1},
            "redaction_complete": True,
        },
    }
    errors = validate_privacy_output(valid_privacy)
    if errors:
        fail(f"Privacy validator false positive: {errors}")
        return False
    ok("Privacy validator: PASS")

    valid_summary = {
        "document_id": "abc123",
        "summary_timestamp": "2024-01-01T00:00:00Z",
        "summary": {
            "chief_complaint": {"text": "Back pain", "citation": "sec_001:p1", "confidence": 0.9},
            "chronological_events": [],
            "active_diagnoses": [],
            "medications": [],
            "key_findings": [],
            "contradictions_flagged": [],
            "timeline_gaps": [],
            "overall_confidence": 0.9,
        },
        "verification": {
            "total_claims": 1,
            "claims_with_citations": 1,
            "citation_coverage": 1.0,
            "low_confidence_claims": 0,
        },
    }
    errors = validate_summary_output(valid_summary)
    if errors:
        fail(f"Summary validator false positive: {errors}")
        return False
    ok("Summary validator: PASS")

    valid_audit = {
        "audit_id": "uuid-123",
        "timestamp": "2024-01-01T00:00:00Z",
        "pipeline_run_id": "test_run",
        "source_file_hash": "sha256_hash",
        "stages_completed": ["ingestion", "privacy", "summarizer", "auditor"],
        "phi_identifiers_found": 1,
        "phi_identifiers_redacted": 1,
        "summary_claims_count": 1,
        "citation_coverage": 1.0,
        "overall_confidence": 0.9,
        "compliance_status": "PASS",
        "anomalies": [],
    }
    errors = validate_audit_output(valid_audit)
    if errors:
        fail(f"Audit validator false positive: {errors}")
        return False
    ok("Audit validator: PASS")

    # Test PHI leak detection
    step("Testing PHI leak detection...")
    from pipeline_schemas import check_for_phi_leak
    should_detect = [
        "SSN: 123-45-6789",
        "Call 555-123-4567",
        "email john@example.com",
    ]
    for text in should_detect:
        warnings = check_for_phi_leak(text)
        if warnings:
            ok(f"Correctly detected PHI: {text}")
        else:
            fail(f"Missed PHI: {text}")
            return False

    ok("All self-tests passed")
    return True


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="MedRecords AI - Setup Script",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python setup_medical.py                  # Full setup (developer mode)
  python setup_medical.py --product-mode   # Product installer (Claude API, no Ollama)
  python setup_medical.py --check          # Check only, no changes
  python setup_medical.py --skip-models    # Skip Ollama model download
        """,
    )
    parser.add_argument("--check", action="store_true", help="Check only, don't make changes")
    parser.add_argument("--skip-models", action="store_true", help="Skip Ollama model download")
    parser.add_argument("--product-mode", action="store_true",
                        help="Product installer: Claude API, auto-generate credentials, skip Ollama")
    args = parser.parse_args()

    product = args.product_mode

    print(f"\n{C.BOLD}MedRecords AI - {'Installation' if product else 'Setup'}{C.END}")
    print(f"{'='*60}")
    print(f"  Install directory: {BASE_DIR}")
    if not product:
        print(f"  Mode: {'CHECK ONLY' if args.check else 'FULL SETUP'}")

    results = {}
    results["python"] = check_python()
    results["deps"] = install_deps(check_only=args.check)
    results["dirs"] = create_directories() if not args.check else True
    results["db"] = init_database(check_only=args.check)
    results["excel"] = create_excel_template(check_only=args.check)

    if product:
        results["config"] = setup_env_product_mode()
        # Set config.yaml to use Claude backend
        try:
            config_path = BASE_DIR / "config.yaml"
            if config_path.exists():
                content = config_path.read_text()
                content = content.replace("llm_backend: ollama", "llm_backend: claude")
                config_path.write_text(content)
                ok("LLM backend set to Claude API")
        except Exception:
            pass
        results["self_test"] = run_self_test()
    else:
        results["env"] = check_env_file(check_only=args.check)
        results["ollama"] = check_ollama(skip_models=args.skip_models or args.check)
        results["self_test"] = run_self_test()

    # Step 9: Record demo install date (demo builds only)
    demo_marker = BASE_DIR / ".demo_build"
    if demo_marker.exists():
        header("Step 9: Demo Registration")
        try:
            from licensing import record_install_date, check_demo_expiration
            record_install_date()
            ok("Demo install date recorded")
            status = check_demo_expiration()
            ok(f"Demo expires in {status['days_remaining']} days")
            results["demo_registration"] = True
        except Exception as e:
            warn(f"Could not record install date: {e}")
            results["demo_registration"] = False

    header("Setup Summary")
    all_ok = True
    for name, passed in results.items():
        status = f"{C.OK}PASS{C.END}" if passed else f"{C.FAIL}FAIL{C.END}"
        print(f"  {name:20s} {status}")
        if not passed:
            all_ok = False

    if all_ok:
        print(f"\n{C.OK}{C.BOLD}  Setup complete! Ready to launch.{C.END}")
        if product:
            print(f"\n  {C.BOLD}Next:{C.END}")
            print(f"    Double-click {C.OK}launch.bat{C.END} to start MedRecords AI")
            print(f"    Or run: python start_medical.py --auto-open")
        else:
            print(f"\n  Next steps:")
            print(f"    1. Edit .env with your email credentials (if using email retrieval)")
            print(f"    2. Run: python start_medical.py")
            print(f"    3. Open: http://localhost:8080")
    else:
        print(f"\n{C.WARN}  Some checks failed. Fix the issues above and re-run setup.{C.END}")

    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
