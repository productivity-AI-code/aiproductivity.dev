============================================================================
MARTINEZ MVA - DEMO CASE
============================================================================

Case:       Martinez, Roberto A. - Motor Vehicle Accident
DOB:        07/22/1985
DOI:        03/01/2024 (Date of Incident)
Case Type:  Personal Injury - Motor Vehicle Accident

SUMMARY:
Roberto Martinez, a 38-year-old warehouse operations manager, was the
restrained driver of a sedan rear-ended on I-45 in Houston, TX, causing a
secondary impact with a concrete median barrier. He sustained cervical disc
herniations (C5-C6 protrusion, C6-C7 extrusion with left C7 nerve root
compression), lumbar strain, and a complex left knee medial meniscus tear
with MCL sprain.

INCLUDED MEDICAL RECORDS:

  01_ER_Visit.txt              Emergency Department visit note from date of
                               accident (03/01/2024). Memorial Hermann
                               Hospital. Initial evaluation, imaging, and
                               discharge.

  02_Orthopedic_Consult.txt    Orthopedic surgery consultation one week
                               post-accident (03/08/2024). Dr. Ramesh Patel
                               at Texas Orthopedic & Sports Medicine.
                               Detailed exam, treatment plan, MRI orders.

  03_Physical_Therapy_Notes.txt Physical therapy initial evaluation and
                               progress notes spanning 03/15/2024 through
                               05/03/2024 (16 visits). Lone Star
                               Rehabilitation. Includes outcome measures
                               and billing summary.

  04_MRI_Report.txt            MRI cervical spine and MRI left knee reports
                               (03/12/2024). Houston Advanced Imaging
                               Center. Confirms C6-C7 disc extrusion and
                               complex medial meniscus tear.

  05_Pain_Management.txt       Pain management consultation and cervical
                               epidural steroid injection procedure note
                               (04/18/2024). Dr. Anita Deshmukh at Gulf
                               Coast Pain Management Specialists.

TOTAL MEDICAL CHARGES (as documented in records):
  Emergency Department:          $  7,134.00
  Orthopedic Consultation:       $    715.00
  Physical Therapy (16 visits):  $  6,730.00
  MRI Imaging (2 studies):       $  5,500.00
  Pain Management:               $  3,580.00
                                 -----------
  TOTAL:                         $ 23,659.00

NOTES:
- This is a DEMO CASE with fictional patient data for demonstration purposes.
- All names, MRNs, dates, and facility details are fabricated.
- This file (README.txt) is excluded from medical record processing.
- The medical records are designed to demonstrate realistic clinical
  documentation, billing codes, and injury progression for a personal
  injury MVA case.
============================================================================
