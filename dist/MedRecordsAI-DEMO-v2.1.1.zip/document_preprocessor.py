"""
document_preprocessor.py — PDF extraction, page quality assessment, classification,
simhash deduplication, handwriting detection/transcription, and chunking for
the Thorough processing pipeline.

Enhanced OCR pipeline:
  - Image pre-processing (deskew, denoise, contrast, binarize) via OpenCV/Pillow
  - Tesseract hybrid layer for fast local OCR before Vision API
  - Context-engineered medical Vision prompts with adjacent page context
  - Medical terminology post-processing corrections
  - Ollama vision model support (llava, moondream) as local alternative

Usage:
    from document_preprocessor import preprocess_case, PreprocessingResult
    result = preprocess_case(file_paths, config, mode="auto")
"""

import hashlib
import io
import logging
import re
import struct
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# ── Medical OCR Post-Processing ─────────────────────────────────────────────

# Common OCR misreads in medical documents (pattern -> correction)
_MEDICAL_OCR_CORRECTIONS = {
    # Medications
    r'\bmetforrnin\b': 'metformin',
    r'\blisinopnl\b': 'lisinopril',
    r'\batorvastatin\b': 'atorvastatin',  # already correct, just ensuring
    r'\bomeprazo1e\b': 'omeprazole',
    r'\bgabapentln\b': 'gabapentin',
    r'\bhydrocodone\b': 'hydrocodone',
    r'\bacetarninophen\b': 'acetaminophen',
    r'\bibuprofen\b': 'ibuprofen',
    r'\bamoxici1lin\b': 'amoxicillin',
    r'\bprednlsone\b': 'prednisone',
    r'\bcyclobenzaprlne\b': 'cyclobenzaprine',
    r'\bmeloxlcam\b': 'meloxicam',
    r'\btramado1\b': 'tramadol',
    r'\bnaproxen\b': 'naproxen',
    r'\bdiclofenac\b': 'diclofenac',
    # Medical terms with common OCR errors (l/1/I confusion, rn/m confusion)
    r'\bdiagnos[l1]s\b': 'diagnosis',
    r'\bexarn[l1]nation\b': 'examination',
    r'\bmed[l1]cation\b': 'medication',
    r'\bprescr[l1]ption\b': 'prescription',
    r'\btreatrnent\b': 'treatment',
    r'\bassessrnent\b': 'assessment',
    r'\bmanagernent\b': 'management',
    r'\bpat[l1]ent\b': 'patient',
    r'\bsyrnptoms\b': 'symptoms',
    r'\bexarn\b': 'exam',
    r'\bab[d0]omen\b': 'abdomen',
    r'\bcerv[l1]cal\b': 'cervical',
    r'\blurnbar\b': 'lumbar',
    r'\bthorac[l1]c\b': 'thoracic',
    r'\brad[l1]culopathy\b': 'radiculopathy',
    r'\bstenos[l1]s\b': 'stenosis',
    r'\bhern[l1]ation\b': 'herniation',
    r'\bfracture\b': 'fracture',
    r'\bcontus[l1]on\b': 'contusion',
    r'\blacerat[l1]on\b': 'laceration',
    r'\babras[l1]on\b': 'abrasion',
    r'\bsurg[l1]cal\b': 'surgical',
    r'\borthoped[l1]c\b': 'orthopedic',
    r'\bneurologlcal\b': 'neurological',
    r'\bradiolog[l1]cal\b': 'radiological',
    # Abbreviations with common OCR errors
    r'\bMR[l1]\b': 'MRI',
    r'\bC[B8]C\b': 'CBC',
    r'\b[B8]MP\b': 'BMP',
    r'\bCMP\b': 'CMP',
    r'\bEKG\b': 'EKG',
    r'\b[l1]CD-10\b': 'ICD-10',
    r'\bCPT\b': 'CPT',
    r'\bH[l1]PAA\b': 'HIPAA',
    r'\bPH[l1]\b': 'PHI',
    # Units
    r'\brng/dL\b': 'mg/dL',
    r'\bmg/d[l1]\b': 'mg/dL',
    r'\brn[l1]/min\b': 'mL/min',
    r'\brnrn\b(?=\s*Hg|\s*$)': 'mm',
}

# Compile patterns once
_COMPILED_CORRECTIONS = [
    (re.compile(pattern, re.IGNORECASE), replacement)
    for pattern, replacement in _MEDICAL_OCR_CORRECTIONS.items()
]


def _medical_postprocess(text):
    """Apply medical terminology corrections to OCR output.

    Fixes common OCR misreads specific to medical documents:
    - l/1/I confusion (lisinopnl -> lisinopril)
    - rn/m confusion (treatrnent -> treatment)
    - 0/O confusion (ab0omen -> abdomen)
    - Common abbreviation errors
    """
    if not text:
        return text

    for pattern, replacement in _COMPILED_CORRECTIONS:
        text = pattern.sub(replacement, text)

    return text


# ── Image Pre-Processing ────────────────────────────────────────────────────

def _preprocess_image(image_bytes):
    """Pre-process medical document image for optimal OCR.

    Pipeline:
    1. Convert to grayscale
    2. Denoise (non-local means)
    3. Contrast enhancement (CLAHE)
    4. Deskew detection and correction
    5. Adaptive thresholding (binarization)

    Returns: processed image bytes (PNG), or original if processing fails.
    """
    try:
        import cv2
        import numpy as np

        # Decode image
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return image_bytes

        # 1. Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 2. Denoise
        denoised = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)

        # 3. Contrast enhancement (CLAHE — adaptive histogram equalization)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)

        # 4. Deskew
        coords = np.column_stack(np.where(enhanced < 128))
        if len(coords) > 100:
            angle = cv2.minAreaRect(coords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle
            # Only correct if skew is significant but not extreme
            if 0.5 < abs(angle) < 15:
                h, w = enhanced.shape
                center = (w // 2, h // 2)
                M = cv2.getRotationMatrix2D(center, angle, 1.0)
                enhanced = cv2.warpAffine(enhanced, M, (w, h),
                                          flags=cv2.INTER_CUBIC,
                                          borderMode=cv2.BORDER_REPLICATE)
                logger.debug("Deskewed image by %.1f degrees", angle)

        # 5. Adaptive thresholding (binarization)
        binary = cv2.adaptiveThreshold(
            enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 15, 8
        )

        # Encode back to PNG
        _, buffer = cv2.imencode('.png', binary)
        return buffer.tobytes()

    except ImportError:
        logger.debug("OpenCV not available, skipping image pre-processing")
        return image_bytes
    except Exception as e:
        logger.warning("Image pre-processing failed: %s", e)
        return image_bytes


# ── Tesseract Hybrid OCR ────────────────────────────────────────────────────

def _tesseract_ocr(image_bytes, preprocess=True):
    """Run Tesseract OCR on image bytes. Returns (text, confidence).

    Uses pre-processed image for better accuracy. Falls back gracefully
    if Tesseract is not installed.

    Args:
        image_bytes: Raw image bytes (PNG/JPEG)
        preprocess: Whether to apply image pre-processing first

    Returns:
        (text, confidence) tuple. confidence is 0-100 from Tesseract.
    """
    try:
        import pytesseract
        from PIL import Image

        # Pre-process if enabled
        if preprocess:
            processed_bytes = _preprocess_image(image_bytes)
        else:
            processed_bytes = image_bytes

        # Open with Pillow
        img = Image.open(io.BytesIO(processed_bytes))

        # Run Tesseract with medical-optimized config
        # --psm 6: Assume uniform block of text
        # --oem 3: Default LSTM engine
        custom_config = r'--oem 3 --psm 6'

        # Get text
        text = pytesseract.image_to_string(img, config=custom_config)

        # Get confidence data
        try:
            data = pytesseract.image_to_data(img, config=custom_config,
                                              output_type=pytesseract.Output.DICT)
            confidences = [int(c) for c in data['conf'] if int(c) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        except Exception:
            avg_confidence = 0

        return text.strip(), avg_confidence

    except ImportError:
        logger.debug("pytesseract not available, skipping Tesseract OCR")
        return "", 0
    except Exception as e:
        logger.warning("Tesseract OCR failed: %s", e)
        return "", 0


# ── Ollama Vision OCR ───────────────────────────────────────────────────────

def _call_ollama_vision(model, prompt, image_bytes, config, timeout=120):
    """Call an Ollama vision model (llava, moondream) for OCR.

    Args:
        model: Ollama model name (e.g. "llava:13b", "moondream")
        prompt: Text prompt for the model
        image_bytes: Image bytes
        config: Full config dict
        timeout: Request timeout in seconds

    Returns:
        Response text from the vision model
    """
    import base64
    import requests

    endpoint = config.get("ollama", {}).get("endpoint", "http://localhost:11434")
    b64_image = base64.b64encode(image_bytes).decode("ascii")

    try:
        resp = requests.post(
            f"{endpoint}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "images": [b64_image],
                "stream": False,
            },
            timeout=timeout,
        )
        resp.raise_for_status()
        return resp.json().get("response", "").strip()
    except Exception as e:
        logger.warning("Ollama vision call to %s failed: %s", model, e)
        return ""


def _get_available_vision_model(config):
    """Check which Ollama vision models are available locally.

    Returns model name or None if none available.
    Priority: llava:13b > moondream > glm-ocr
    """
    import requests

    endpoint = config.get("ollama", {}).get("endpoint", "http://localhost:11434")
    try:
        resp = requests.get(f"{endpoint}/api/tags", timeout=5)
        if resp.status_code != 200:
            return None
        models = [m["name"] for m in resp.json().get("models", [])]
    except Exception:
        return None

    # Priority order
    for candidate in ["llava:13b", "llava:7b", "moondream", "glm-ocr:latest", "glm-ocr"]:
        if candidate in models:
            return candidate
    return None

# ── Data Structures ──────────────────────────────────────────────────────────

@dataclass
class PageInfo:
    page_number: int           # 1-indexed within source file
    source_file: str           # Original filename
    text_content: str          # Extracted or transcribed text
    quality: str               # typed_clean, typed_scanned, handwritten, mixed, blank, noise
    category: str              # clinical, imaging_report, lab_results, billing, consent, fax_cover, blank
    confidence: float          # 0.0-1.0
    content_hash: str          # SHA-256 of normalized text
    simhash: int               # 64-bit simhash for near-duplicate detection
    char_count: int
    has_handwriting: bool
    image_data: bytes | None   # PNG bytes if page needs Vision API
    is_duplicate: bool = False
    duplicate_of: str | None = None  # "filename:page_N"


@dataclass
class PreprocessingResult:
    pages: list[PageInfo] = field(default_factory=list)
    total_pages: int = 0
    unique_pages: int = 0
    duplicate_pages: int = 0
    blank_pages: int = 0
    noise_pages: int = 0
    handwritten_pages: int = 0
    clinical_pages: int = 0
    chunks: list[dict] = field(default_factory=list)
    recommended_mode: str = "fast"  # "fast" or "thorough"
    dedup_stats: dict = field(default_factory=dict)


# ── Page Extraction ──────────────────────────────────────────────────────────

def _extract_pages_pdf(file_path, extract_images=True, dpi=300, use_tesseract=True):
    """Extract pages from a PDF using PyMuPDF with hybrid Tesseract OCR.

    For pages with little extractable text (<50 chars), the pipeline:
    1. Render page as image at specified DPI
    2. Pre-process image (deskew, denoise, contrast, binarize)
    3. Run Tesseract OCR as fast local transcription
    4. If Tesseract yields good results (>60% confidence), use it
    5. If Tesseract fails, flag page for Vision API transcription later

    Returns list of PageInfo.
    """
    import fitz  # PyMuPDF

    pages = []
    doc = fitz.open(str(file_path))
    filename = Path(file_path).name
    tesseract_used = 0
    tesseract_succeeded = 0

    for i, page in enumerate(doc, 1):
        text = page.get_text().strip()
        char_count = len(text)

        # If page has very little text, it might be scanned — render as image
        image_data = None
        if extract_images and char_count < 50:
            try:
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                pix = page.get_pixmap(matrix=mat)
                image_data = pix.tobytes("png")
            except Exception as e:
                logger.warning("Failed to render page %d of %s as image: %s", i, filename, e)

            # Hybrid OCR: try Tesseract first (fast, free, local)
            if image_data and use_tesseract:
                tesseract_used += 1
                tess_text, tess_conf = _tesseract_ocr(image_data, preprocess=True)
                if tess_text and tess_conf > 40 and len(tess_text) > 20:
                    # Apply medical post-processing corrections
                    tess_text = _medical_postprocess(tess_text)
                    text = tess_text
                    char_count = len(text)
                    tesseract_succeeded += 1
                    logger.debug("Tesseract OCR page %d of %s: %d chars (%.0f%% conf)",
                                i, filename, char_count, tess_conf)
                    # Keep image_data for potential Vision API re-OCR if quality is low
                    if tess_conf > 70:
                        image_data = None  # High confidence — no need for Vision API

        page_info = PageInfo(
            page_number=i,
            source_file=filename,
            text_content=text,
            quality="",  # Assessed later
            category="",  # Classified later
            confidence=0.0,
            content_hash="",
            simhash=0,
            char_count=char_count,
            has_handwriting=False,
            image_data=image_data,
        )
        pages.append(page_info)

    doc.close()

    if tesseract_used > 0:
        logger.info("Tesseract OCR: %d/%d scanned pages processed (%d succeeded)",
                    tesseract_succeeded, tesseract_used, tesseract_succeeded)

    return pages


def _extract_pages_image(file_path):
    """Handle standalone image files — single page with image data."""
    filename = Path(file_path).name
    try:
        img_bytes = Path(file_path).read_bytes()
    except Exception as e:
        logger.warning("Failed to read image %s: %s", filename, e)
        return []

    ext = Path(file_path).suffix.lower()
    page_info = PageInfo(
        page_number=1,
        source_file=filename,
        text_content="",
        quality="typed_scanned",
        category="",
        confidence=0.0,
        content_hash="",
        simhash=0,
        char_count=0,
        has_handwriting=False,
        image_data=img_bytes,
    )
    return [page_info]


def _extract_pages_text(file_path, page_size=3000):
    """Extract pages from text files — split into logical pages of ~page_size chars."""
    filename = Path(file_path).name
    try:
        ext = Path(file_path).suffix.lower()
        if ext == ".xlsx":
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
            parts = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = []
                for row in ws.iter_rows(values_only=True):
                    rows.append("\t".join(str(c) if c is not None else "" for c in row))
                if rows:
                    parts.append(f"--- Sheet: {sheet_name} ---\n" + "\n".join(rows))
            wb.close()
            text = "\n\n".join(parts) if parts else ""
        elif ext == ".xls":
            import xlrd
            wb = xlrd.open_workbook(str(file_path))
            parts = []
            for sheet in wb.sheets():
                rows = []
                for rx in range(sheet.nrows):
                    row = [str(sheet.cell_value(rx, cx)) for cx in range(sheet.ncols)]
                    rows.append("\t".join(row))
                if rows:
                    parts.append(f"--- Sheet: {sheet.name} ---\n" + "\n".join(rows))
            text = "\n\n".join(parts) if parts else ""
        else:
            text = Path(file_path).read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        logger.warning("Failed to read %s: %s", filename, e)
        return []

    if not text.strip():
        return [PageInfo(
            page_number=1, source_file=filename, text_content="",
            quality="blank", category="blank", confidence=1.0,
            content_hash="", simhash=0, char_count=0,
            has_handwriting=False, image_data=None,
        )]

    # Split text into page-sized chunks on paragraph boundaries
    pages = []
    paragraphs = text.split("\n\n")
    current_chunk = ""
    page_num = 1

    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 > page_size and current_chunk:
            pages.append(PageInfo(
                page_number=page_num, source_file=filename,
                text_content=current_chunk.strip(),
                quality="", category="", confidence=0.0,
                content_hash="", simhash=0,
                char_count=len(current_chunk.strip()),
                has_handwriting=False, image_data=None,
            ))
            page_num += 1
            current_chunk = para + "\n\n"
        else:
            current_chunk += para + "\n\n"

    if current_chunk.strip():
        pages.append(PageInfo(
            page_number=page_num, source_file=filename,
            text_content=current_chunk.strip(),
            quality="", category="", confidence=0.0,
            content_hash="", simhash=0,
            char_count=len(current_chunk.strip()),
            has_handwriting=False, image_data=None,
        ))

    return pages


def extract_pages(file_path, extract_images=True, dpi=300):
    """Route to appropriate extractor based on file type."""
    ext = Path(file_path).suffix.lower()
    if ext == ".pdf":
        return _extract_pages_pdf(file_path, extract_images=extract_images, dpi=dpi)
    elif ext in (".png", ".jpg", ".jpeg", ".tiff", ".tif"):
        return _extract_pages_image(file_path)
    else:
        return _extract_pages_text(file_path)


# ── Page Quality Assessment ──────────────────────────────────────────────────

def _assess_page_quality(page):
    """Assess page quality based on text characteristics.

    Sets page.quality to one of:
        typed_clean, typed_scanned, handwritten, blank, noise
    """
    text = page.text_content

    # Blank page
    if page.char_count < 10:
        page.quality = "blank"
        page.confidence = 1.0
        return

    # Noise detection: high ratio of non-alphanumeric characters
    alnum_count = sum(1 for c in text if c.isalnum())
    alnum_ratio = alnum_count / max(page.char_count, 1)

    if alnum_ratio < 0.3:
        page.quality = "noise"
        page.confidence = 0.9
        return

    # Check for garbled OCR indicators
    # Lots of isolated single characters, excessive special chars
    words = text.split()
    if words:
        avg_word_len = sum(len(w) for w in words) / len(words)
        single_char_ratio = sum(1 for w in words if len(w) == 1) / len(words)

        if single_char_ratio > 0.4 or avg_word_len < 2.0:
            page.quality = "noise"
            page.confidence = 0.7
            return

    # If we have image data but minimal text, likely scanned/handwritten
    if page.image_data and page.char_count < 100:
        page.quality = "typed_scanned"
        page.has_handwriting = True  # Needs Vision API to determine
        page.confidence = 0.6
        return

    # Typed/clean text
    if alnum_ratio > 0.5 and page.char_count > 50:
        page.quality = "typed_clean"
        page.confidence = 0.9
    else:
        page.quality = "typed_scanned"
        page.confidence = 0.7


# ── Page Classification ──────────────────────────────────────────────────────

# Keyword sets for rule-based classification
_CLINICAL_KEYWORDS = {
    "diagnosis", "treatment", "medication", "prescription", "assessment",
    "history", "examination", "symptoms", "patient", "clinical",
    "chief complaint", "hpi", "ros", "physical exam", "plan",
    "follow-up", "vital signs", "blood pressure", "pulse", "temperature",
    "impression", "prognosis", "discharge", "admit", "surgery",
    "operative", "procedure", "anesthesia", "pre-op", "post-op",
    "progress note", "soap", "subjective", "objective",
}

_IMAGING_KEYWORDS = {
    "x-ray", "xray", "mri", "ct scan", "ultrasound", "radiology",
    "imaging", "radiograph", "fluoroscopy", "mammogram", "pet scan",
    "impression:", "findings:", "comparison:", "technique:",
}

_LAB_KEYWORDS = {
    "lab results", "laboratory", "cbc", "bmp", "cmp", "hemoglobin",
    "hematocrit", "wbc", "platelet", "glucose", "creatinine",
    "reference range", "specimen", "urinalysis", "culture",
}

_BILLING_KEYWORDS = {
    "billing", "invoice", "charges", "payment", "insurance",
    "copay", "deductible", "claim", "cpt", "icd-10", "icd-9",
    "balance due", "amount", "total charges", "adjustment",
}

_CONSENT_KEYWORDS = {
    "consent", "authorization", "signature", "hereby authorize",
    "i understand", "risks and benefits", "informed consent",
    "hipaa", "privacy", "release of information",
}

_NOISE_KEYWORDS = {
    "fax cover", "fax transmission", "cover sheet", "pages including",
    "confidentiality notice", "if you received this",
    "table of contents", "index",
}


def _classify_page(page):
    """Classify page into category using keyword matching.

    Sets page.category to one of:
        clinical, imaging_report, lab_results, billing, consent, fax_cover, blank
    """
    if page.quality == "blank":
        page.category = "blank"
        page.confidence = 1.0
        return

    if page.quality == "noise":
        page.category = "fax_cover"
        page.confidence = 0.7
        return

    text_lower = page.text_content.lower()

    # Score each category
    scores = {}
    for cat, keywords in [
        ("clinical", _CLINICAL_KEYWORDS),
        ("imaging_report", _IMAGING_KEYWORDS),
        ("lab_results", _LAB_KEYWORDS),
        ("billing", _BILLING_KEYWORDS),
        ("consent", _CONSENT_KEYWORDS),
        ("fax_cover", _NOISE_KEYWORDS),
    ]:
        score = sum(1 for kw in keywords if kw in text_lower)
        scores[cat] = score

    if not any(scores.values()):
        # No keywords matched — default to clinical (most common in medical records)
        page.category = "clinical"
        page.confidence = 0.4
        return

    best_cat = max(scores, key=scores.get)
    total_matches = sum(scores.values())
    page.category = best_cat
    page.confidence = min(0.95, scores[best_cat] / max(total_matches, 1))


# ── Content Hashing & Simhash ────────────────────────────────────────────────

def _normalize_text(text):
    """Normalize text for hashing: lowercase, strip whitespace/punctuation."""
    import re
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _compute_content_hash(text):
    """SHA-256 of normalized text."""
    normalized = _normalize_text(text)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _compute_simhash(text, hash_bits=64):
    """Compute simhash from 3-character shingles for near-duplicate detection.

    Algorithm:
    1. Generate 3-char shingles (sliding window)
    2. Hash each shingle (MD5, truncated to hash_bits)
    3. For each bit position: +1 if bit=1, -1 if bit=0 across all hashes
    4. Final hash: bit=1 if aggregate > 0
    """
    normalized = _normalize_text(text)
    if len(normalized) < 3:
        return 0

    # Generate shingles
    shingles = [normalized[i:i+3] for i in range(len(normalized) - 2)]

    # Aggregate bit vectors
    v = [0] * hash_bits

    for shingle in shingles:
        h = hashlib.md5(shingle.encode("utf-8")).digest()
        # Use first hash_bits bits (8 bytes = 64 bits)
        hash_int = int.from_bytes(h[:hash_bits // 8], byteorder="big")

        for i in range(hash_bits):
            if hash_int & (1 << i):
                v[i] += 1
            else:
                v[i] -= 1

    # Build final hash
    simhash = 0
    for i in range(hash_bits):
        if v[i] > 0:
            simhash |= (1 << i)

    return simhash


def _hamming_distance(a, b):
    """Count differing bits between two integers."""
    x = a ^ b
    count = 0
    while x:
        count += 1
        x &= x - 1  # Clear lowest set bit
    return count


def _compute_hashes(pages):
    """Compute content_hash and simhash for all pages."""
    for page in pages:
        if page.quality in ("blank", "noise") or page.char_count < 10:
            page.content_hash = ""
            page.simhash = 0
            continue
        page.content_hash = _compute_content_hash(page.text_content)
        page.simhash = _compute_simhash(page.text_content)


# ── Deduplication ────────────────────────────────────────────────────────────

def _deduplicate_pages(pages, threshold=10):
    """Mark near-duplicate pages using simhash hamming distance.

    Cross-file dedup: compares pages from all files.
    Keeps the first (highest quality) copy, marks others as duplicates.

    Args:
        pages: List of PageInfo with simhash computed
        threshold: Max hamming distance to consider near-duplicate (out of 64 bits)

    Returns:
        (unique_pages, duplicate_count, dedup_stats)
    """
    # Only consider pages with real content
    content_pages = [p for p in pages if p.quality not in ("blank", "noise") and p.char_count >= 10]

    duplicate_count = 0
    exact_dupes = 0
    near_dupes = 0
    seen_hashes = {}  # content_hash -> "filename:page_N"
    seen_simhashes = []  # (simhash, "filename:page_N")

    for page in content_pages:
        page_id = f"{page.source_file}:page_{page.page_number}"

        # Exact duplicate check (same content hash)
        if page.content_hash in seen_hashes:
            page.is_duplicate = True
            page.duplicate_of = seen_hashes[page.content_hash]
            duplicate_count += 1
            exact_dupes += 1
            continue

        # Near-duplicate check (simhash hamming distance)
        is_near_dupe = False
        for existing_hash, existing_id in seen_simhashes:
            if _hamming_distance(page.simhash, existing_hash) <= threshold:
                page.is_duplicate = True
                page.duplicate_of = existing_id
                duplicate_count += 1
                near_dupes += 1
                is_near_dupe = True
                break

        if not is_near_dupe:
            seen_hashes[page.content_hash] = page_id
            seen_simhashes.append((page.simhash, page_id))

    dedup_stats = {
        "total_compared": len(content_pages),
        "exact_duplicates": exact_dupes,
        "near_duplicates": near_dupes,
        "total_duplicates": duplicate_count,
        "unique_pages": len(content_pages) - duplicate_count,
    }

    return pages, duplicate_count, dedup_stats


# ── Handwriting Detection & Transcription ────────────────────────────────────

def detect_handwritten_pages(pages):
    """Identify pages that likely contain handwriting and need Vision API transcription.

    Returns list of pages that need transcription.
    """
    handwritten = []
    for page in pages:
        if page.is_duplicate or page.quality == "blank":
            continue
        # Pages with image data but little text are candidates
        if page.image_data and page.char_count < 100:
            page.has_handwriting = True
            handwritten.append(page)
    return handwritten


def _build_context_prompt(page, all_pages):
    """Build a context-engineered Vision prompt with adjacent page context.

    Provides the AI with:
    - What kind of medical document this likely is
    - Text from adjacent pages for continuity context
    - Medical abbreviation awareness
    """
    # Find adjacent pages from the same file for context
    same_file_pages = [p for p in all_pages if p.source_file == page.source_file]
    same_file_pages.sort(key=lambda p: p.page_number)

    prev_context = ""
    next_context = ""
    for p in same_file_pages:
        if p.page_number == page.page_number - 1 and p.text_content:
            prev_text = p.text_content[-300:]  # Last 300 chars of previous page
            prev_context = f"\n\nCONTEXT — Previous page ended with:\n\"{prev_text}\""
        elif p.page_number == page.page_number + 1 and p.text_content:
            next_text = p.text_content[:300:]  # First 300 chars of next page
            next_context = f"\n\nCONTEXT — Next page begins with:\n\"{next_text}\""

    system_prompt = """You are a medical document transcription specialist with deep expertise in:
- Clinical progress notes, SOAP notes, and physician orders
- Handwritten prescriptions and medication lists
- Medical abbreviations (PRN, BID, TID, QID, QHS, PO, IM, IV, SubQ, etc.)
- Vital signs notation (BP, HR, RR, T, SpO2, BMI)
- Lab values and reference ranges
- Radiology/imaging report formats
- Surgical operative notes
- Physical therapy/rehabilitation notes

TRANSCRIPTION RULES:
1. Transcribe ALL text visible in the image — both handwritten and typed
2. Preserve document structure: headers, sections, bullet points, tables, dates
3. Expand common medical abbreviations in brackets on first occurrence, e.g., "PRN [as needed]"
4. For partially illegible text, transcribe what you can and mark unclear portions as [illegible]
5. Preserve exact numbers, dates, dosages, and measurements — accuracy is critical
6. Note any checkboxes, circled items, or underlined text with markers like [checked], [circled], [underlined]
7. Do NOT add commentary, interpretation, or summary — pure transcription only"""

    text_prompt = f"Transcribe this medical document page (page {page.page_number} of {page.source_file}).{prev_context}{next_context}\n\nTranscribe all visible text accurately:"

    return system_prompt, text_prompt


def transcribe_handwritten_pages(pages, config, all_pages=None):
    """Transcribe handwritten/scanned pages using multi-tier OCR pipeline.

    Pipeline priority:
    1. Pre-process image (deskew, denoise, contrast, binarize)
    2. Tesseract OCR (fast, local) — already attempted in extraction
    3. Ollama vision model (llava/moondream) — if available and backend is ollama
    4. Claude Vision API — highest quality, uses context-engineered prompts

    Args:
        pages: List of PageInfo with has_handwriting=True and image_data
        config: Full config dict
        all_pages: All pages for adjacent context (optional)

    Returns:
        Number of pages successfully transcribed
    """
    from dispatch import call_claude_vision

    modes_cfg = config.get("processing_modes", {}).get("thorough", {})
    model = modes_cfg.get("handwriting_model", "claude-haiku-4-5-20251001")
    ocr_cfg = config.get("ocr", {})
    use_ollama_vision = ocr_cfg.get("use_ollama_vision", True)
    ollama_vision_model = ocr_cfg.get("ollama_vision_model", "")
    backend = config.get("llm_backend", "claude")

    # Check for available Ollama vision model if not specified
    if use_ollama_vision and not ollama_vision_model and backend == "ollama":
        ollama_vision_model = _get_available_vision_model(config) or ""

    if all_pages is None:
        all_pages = pages

    transcribed = 0
    for page in pages:
        if not page.image_data:
            continue

        ext = Path(page.source_file).suffix.lower()
        media_type_map = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
        }
        media_type = media_type_map.get(ext, "image/png")

        # Pre-process the image for better OCR
        processed_image = _preprocess_image(page.image_data)

        text = ""

        # Tier 1: Try Ollama vision model (local, free) if available
        if ollama_vision_model and use_ollama_vision:
            try:
                system_prompt, text_prompt = _build_context_prompt(page, all_pages)
                text = _call_ollama_vision(
                    model=ollama_vision_model,
                    prompt=f"{system_prompt}\n\n{text_prompt}",
                    image_bytes=processed_image,
                    config=config,
                    timeout=120,
                )
                if text and len(text.strip()) > 20:
                    text = _medical_postprocess(text.strip())
                    logger.info("Ollama vision (%s) transcribed page %d of %s (%d chars)",
                               ollama_vision_model, page.page_number, page.source_file, len(text))
                else:
                    text = ""
            except Exception as e:
                logger.warning("Ollama vision failed for page %d of %s: %s",
                              page.page_number, page.source_file, e)
                text = ""

        # Tier 2: Claude Vision API (highest quality, context-engineered)
        if not text:
            try:
                system_prompt, text_prompt = _build_context_prompt(page, all_pages)
                text = call_claude_vision(
                    model=model,
                    system_prompt=system_prompt,
                    text_prompt=text_prompt,
                    images=[(processed_image, media_type)],
                    config=config,
                    timeout_override=90,
                    max_tokens_override=4096,
                )
                if text:
                    text = _medical_postprocess(text.strip())
            except Exception as e:
                logger.warning("Claude Vision failed for page %d of %s: %s",
                              page.page_number, page.source_file, e)
                text = ""

        # Apply transcription result
        if text and len(text.strip()) > 10:
            page.text_content = text.strip()
            page.char_count = len(page.text_content)
            page.quality = "handwritten"
            page.content_hash = _compute_content_hash(page.text_content)
            page.simhash = _compute_simhash(page.text_content)
            transcribed += 1
            logger.info("Transcribed page %d of %s (%d chars)",
                       page.page_number, page.source_file, page.char_count)

    return transcribed


# ── Chunking ─────────────────────────────────────────────────────────────────

def _build_chunks(pages, config):
    """Group unique clinical pages into encounter-bounded chunks.

    Chunks are ~chunk_size pages, split on natural boundaries (file transitions,
    date/encounter transitions when detectable).

    Args:
        pages: List of PageInfo (after dedup, quality, classification)
        config: Full config dict

    Returns:
        List of chunk dicts with keys: chunk_id, pages, text, page_count, source_files
    """
    modes_cfg = config.get("processing_modes", {}).get("thorough", {})
    chunk_size = modes_cfg.get("chunk_size_pages", 20)

    # Filter to unique, non-blank, non-noise, clinical-relevant pages
    eligible = [p for p in pages
                if not p.is_duplicate
                and p.quality not in ("blank", "noise")
                and p.category not in ("fax_cover", "blank")]

    if not eligible:
        return []

    chunks = []
    current_chunk_pages = []
    current_chunk_id = 1

    for page in eligible:
        current_chunk_pages.append(page)

        # Check if we should close this chunk
        should_split = False
        if len(current_chunk_pages) >= chunk_size:
            should_split = True
        # Also split on file boundary if we're past 75% of chunk size
        elif (len(current_chunk_pages) >= int(chunk_size * 0.75)
              and current_chunk_pages
              and page != eligible[-1]
              and eligible[eligible.index(page) + 1].source_file != page.source_file):
            should_split = True

        if should_split:
            chunk_text = "\n\n".join(
                f"[Source: {p.source_file}, Page {p.page_number}]\n{p.text_content}"
                for p in current_chunk_pages
            )
            source_files = list(set(p.source_file for p in current_chunk_pages))
            chunks.append({
                "chunk_id": current_chunk_id,
                "pages": current_chunk_pages,
                "text": chunk_text,
                "page_count": len(current_chunk_pages),
                "source_files": source_files,
            })
            current_chunk_id += 1
            current_chunk_pages = []

    # Final chunk
    if current_chunk_pages:
        chunk_text = "\n\n".join(
            f"[Source: {p.source_file}, Page {p.page_number}]\n{p.text_content}"
            for p in current_chunk_pages
        )
        source_files = list(set(p.source_file for p in current_chunk_pages))
        chunks.append({
            "chunk_id": current_chunk_id,
            "pages": current_chunk_pages,
            "text": chunk_text,
            "page_count": len(current_chunk_pages),
            "source_files": source_files,
        })

    return chunks


# ── Mode Auto-Detection ──────────────────────────────────────────────────────

def determine_processing_mode(result, preference="auto"):
    """Determine whether to use fast or thorough mode.

    Args:
        result: PreprocessingResult with page stats
        preference: "auto", "fast", or "thorough" — user preference

    Returns:
        "fast" or "thorough"
    """
    if preference in ("fast", "thorough"):
        return preference

    # Auto-detect based on thresholds
    if result.clinical_pages > 50:
        return "thorough"
    if result.handwritten_pages > 5:
        return "thorough"
    if result.duplicate_pages > 10:
        return "thorough"
    if result.total_pages > 80:
        return "thorough"

    return "fast"


# ── Main Entry Point ─────────────────────────────────────────────────────────

def preprocess_case(file_paths, config, mode="auto", transcribe=True):
    """Main preprocessing pipeline — extract, classify, dedup, chunk.

    Args:
        file_paths: List of Path objects to process
        config: Full config dict
        mode: "auto", "fast", or "thorough"
        transcribe: Whether to transcribe handwritten pages via Vision API

    Returns:
        PreprocessingResult with all stats and chunks
    """
    modes_cfg = config.get("processing_modes", {}).get("thorough", {})
    extract_images = modes_cfg.get("pdf_extract_images", True)
    dpi = modes_cfg.get("pdf_dpi", 300)
    dedup_threshold = modes_cfg.get("dedup_simhash_threshold", 10)

    all_pages = []

    # Phase 1: Extract pages from all files
    for fp in file_paths:
        fp = Path(fp)
        if not fp.exists():
            logger.warning("File not found: %s", fp)
            continue
        try:
            pages = extract_pages(fp, extract_images=extract_images, dpi=dpi)
            all_pages.extend(pages)
            logger.info("Extracted %d pages from %s", len(pages), fp.name)
        except Exception as e:
            logger.warning("Failed to extract pages from %s: %s", fp.name, e)

    if not all_pages:
        return PreprocessingResult()

    # Phase 2: Assess quality
    for page in all_pages:
        if not page.quality:  # Skip if already set (e.g., image files)
            _assess_page_quality(page)

    # Phase 3: Classify pages
    for page in all_pages:
        if not page.category:
            _classify_page(page)

    # Phase 4: Detect handwritten pages
    handwritten = detect_handwritten_pages(all_pages)

    # Phase 5: Transcribe handwritten pages (if enabled and in thorough mode)
    if transcribe and handwritten and mode != "fast":
        transcribed_count = transcribe_handwritten_pages(handwritten, config, all_pages=all_pages)
        logger.info("Transcribed %d/%d handwritten pages", transcribed_count, len(handwritten))

    # Phase 6: Compute hashes (after transcription so hashes reflect transcribed text)
    _compute_hashes(all_pages)

    # Phase 7: Deduplicate
    all_pages, dup_count, dedup_stats = _deduplicate_pages(all_pages, threshold=dedup_threshold)

    # Phase 8: Build chunks
    chunks = _build_chunks(all_pages, config)

    # Compile stats
    blank_pages = sum(1 for p in all_pages if p.quality == "blank")
    noise_pages = sum(1 for p in all_pages if p.quality == "noise")
    handwritten_count = sum(1 for p in all_pages if p.has_handwriting)
    clinical_count = sum(1 for p in all_pages
                        if p.category in ("clinical", "imaging_report", "lab_results")
                        and not p.is_duplicate
                        and p.quality not in ("blank", "noise"))

    result = PreprocessingResult(
        pages=all_pages,
        total_pages=len(all_pages),
        unique_pages=len(all_pages) - dup_count - blank_pages - noise_pages,
        duplicate_pages=dup_count,
        blank_pages=blank_pages,
        noise_pages=noise_pages,
        handwritten_pages=handwritten_count,
        clinical_pages=clinical_count,
        chunks=chunks,
        recommended_mode=determine_processing_mode(
            type("R", (), {
                "clinical_pages": clinical_count,
                "handwritten_pages": handwritten_count,
                "duplicate_pages": dup_count,
                "total_pages": len(all_pages),
            })(),
            mode,
        ),
        dedup_stats=dedup_stats,
    )

    logger.info(
        "Preprocessing complete: %d total pages, %d unique, %d duplicates, "
        "%d blank, %d noise, %d handwritten, %d chunks, recommended=%s",
        result.total_pages, result.unique_pages, result.duplicate_pages,
        result.blank_pages, result.noise_pages, result.handwritten_pages,
        len(chunks), result.recommended_mode,
    )

    return result
