// MedRecords AI — Frontend Application v3 (Production-Hardened)
// XSS-safe rendering, CSRF tokens, batch upload, paginated API,
// auth-aware fetch, toast notifications, pipeline visualization

const API = '';  // Same-origin
let selectedFiles = [];
let currentRunId = null;
let currentSummaryData = null;
let pollInterval = null;
let allSummaries = [];
let allAuditEntries = [];
let csrfToken = null;
let filesPage = 1;
let filesSearchTimeout = null;
const selectedFileIds = new Set();
let cachedCases = [];
let activeSubTab = 'summary';
let toolResults = { valuation: null, negligence: null, tasks: null, injuryMap: null, demand: null };

// ── XSS Protection ─────────────────────────────────────────────────────────

function esc(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
}

// ── CSRF Token ──────────────────────────────────────────────────────────────

async function fetchCsrfToken() {
    try {
        const res = await fetch(`${API}/api/csrf-token`);
        if (res.ok) {
            const data = await res.json();
            csrfToken = data.csrf_token;
        }
    } catch { /* will retry on next request */ }
}

function authHeaders(contentType = 'application/json') {
    const h = {};
    if (contentType) h['Content-Type'] = contentType;
    if (csrfToken) h['X-CSRF-Token'] = csrfToken;
    return h;
}

async function authFetch(url, options = {}, _retried = false) {
    if (!csrfToken) await fetchCsrfToken();
    // Inject CSRF token into headers if not already present
    if (csrfToken && options.method && options.method !== 'GET') {
        options.headers = options.headers || {};
        if (!options.headers['X-CSRF-Token']) {
            options.headers['X-CSRF-Token'] = csrfToken;
        }
    }
    const res = await fetch(url, options);
    if (res.status === 401) {
        window.location.href = '/login';
        throw new Error('Session expired');
    }
    if (res.status === 403 && !_retried) {
        const data = await res.clone().json().catch(() => ({}));
        if (data.error?.includes('CSRF')) {
            await fetchCsrfToken();
            // Update the CSRF token in headers and retry once
            if (options.headers) options.headers['X-CSRF-Token'] = csrfToken;
            return authFetch(url, options, true);
        }
    }
    return res;
}

// ── DOM Elements ────────────────────────────────────────────────────────────

const $ = id => document.getElementById(id);
const dropZone = $('drop-zone');
const fileInput = $('file-input');
const fileList = $('file-list');
const btnSummarize = $('btn-summarize');
const btnText = $('btn-text');
const btnSpinner = $('btn-spinner');
const resultsPlaceholder = $('results-placeholder');
const processingView = $('processing-view');
const summaryView = $('summary-view');
const processingHeader = $('processing-header');
const liveLog = $('live-log');
const exportButtons = $('export-buttons');

// ── Toast Notifications ─────────────────────────────────────────────────────

function showToast(message, type = 'info', duration = 4000) {
    const container = $('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icons = {
        success: '<svg class="w-4 h-4 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>',
        error: '<svg class="w-4 h-4 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"/></svg>',
        warning: '<svg class="w-4 h-4 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"/></svg>',
        info: '<svg class="w-4 h-4 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"/></svg>',
    };
    const icon = icons[type] || icons.info;
    const span = document.createElement('span');
    span.textContent = message;
    toast.innerHTML = icon;
    toast.appendChild(span);
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ── System Health Check ─────────────────────────────────────────────────────

async function checkSystemHealth() {
    try {
        const res = await fetch(`${API}/api/status`);
        if (res.status === 401) {
            window.location.href = '/login';
            return;
        }
        if (res.ok) {
            $('status-dot').className = 'w-2 h-2 bg-green-400 rounded-full';
            $('status-text').textContent = 'System Online';
        } else {
            $('status-dot').className = 'w-2 h-2 bg-yellow-400 rounded-full';
            $('status-text').textContent = 'Degraded';
        }
    } catch {
        $('status-dot').className = 'w-2 h-2 bg-red-400 rounded-full';
        $('status-text').textContent = 'Offline';
    }

    // Check LLM backend status
    try {
        const llmRes = await authFetch(`${API}/api/settings/llm`);
        if (llmRes.ok) {
            const llm = await llmRes.json();
            const backend = llm.backend || 'ollama';
            const isAvailable = backend === 'claude' ? llm.claude?.available : llm.ollama?.available;
            $('llm-dot').className = isAvailable
                ? 'w-2 h-2 bg-green-400 rounded-full'
                : 'w-2 h-2 bg-red-400 rounded-full';
            $('llm-label').textContent = backend === 'claude'
                ? `Claude (${(llm.claude?.model || '').split('-').pop() || 'API'})`
                : 'Ollama (Local)';
        }
    } catch {
        $('llm-dot').className = 'w-2 h-2 bg-gray-500 rounded-full';
        $('llm-label').textContent = 'LLM';
    }
}

// ── File Upload ─────────────────────────────────────────────────────────────

const ALLOWED_EXT = new Set(['pdf','png','jpg','jpeg','tiff','tif','dcm','dicom','doc','docx','txt','csv','json','xml','log','xlsx','xls','html','htm']);
const folderInput = $('folder-input');

dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', async (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    // Check if any dropped items are directories
    const items = e.dataTransfer.items;
    if (items && items.length) {
        const entries = [];
        for (let i = 0; i < items.length; i++) {
            const entry = items[i].webkitGetAsEntry?.();
            if (entry) entries.push(entry);
        }
        const hasDir = entries.some(en => en.isDirectory);
        if (hasDir) {
            const allFiles = await collectFilesFromEntries(entries);
            handleFiles(allFiles);
            return;
        }
    }
    handleFiles(e.dataTransfer.files);
});
fileInput.addEventListener('change', (e) => handleFiles(e.target.files));
$('btn-folder-upload')?.addEventListener('click', (e) => { e.stopPropagation(); folderInput.click(); });
folderInput?.addEventListener('change', (e) => {
    const files = Array.from(e.target.files).filter(f => {
        const ext = f.name.split('.').pop().toLowerCase();
        return ALLOWED_EXT.has(ext);
    });
    if (files.length === 0) {
        showToast('No supported files found in folder', 'error');
        return;
    }
    handleFiles(files);
});

// Recursively collect files from dropped directory entries
async function collectFilesFromEntries(entries) {
    const files = [];
    async function readEntry(entry) {
        if (entry.isFile) {
            const file = await new Promise(resolve => entry.file(resolve));
            const ext = file.name.split('.').pop().toLowerCase();
            if (ALLOWED_EXT.has(ext)) files.push(file);
        } else if (entry.isDirectory) {
            const reader = entry.createReader();
            const children = await new Promise(resolve => reader.readEntries(resolve));
            for (const child of children) await readEntry(child);
        }
    }
    for (const entry of entries) await readEntry(entry);
    return files;
}

let processingMode = 'individual';  // 'individual' or 'combined'
let speedMode = 'auto';  // 'fast', 'auto', or 'thorough'

function setSpeedMode(mode) {
    speedMode = mode;
    const descriptions = {
        fast: 'Processes quickly — best for small, clean files under 50 pages',
        auto: 'Auto-detects based on document complexity and size',
        thorough: 'Deep analysis — handles 500+ pages, duplicates, handwritten notes',
    };
    ['fast', 'auto', 'thorough'].forEach(m => {
        const btn = $('speed-' + m);
        if (!btn) return;
        if (m === mode) {
            btn.className = 'flex-1 py-1.5 px-2 text-center font-medium bg-blue-900 text-white transition-colors';
        } else {
            btn.className = 'flex-1 py-1.5 px-2 text-center font-medium bg-white text-gray-600 hover:bg-gray-50 transition-colors';
        }
    });
    const desc = $('speed-description');
    if (desc) desc.textContent = descriptions[mode] || descriptions.auto;
}
window.setSpeedMode = setSpeedMode;

function setProcessingMode(mode) {
    processingMode = mode;
    const btnInd = $('mode-individual');
    const btnCmb = $('mode-combined');
    const desc = $('mode-description');
    if (mode === 'individual') {
        btnInd.className = 'flex-1 py-1.5 px-3 text-center font-medium bg-blue-900 text-white transition-colors';
        btnCmb.className = 'flex-1 py-1.5 px-3 text-center font-medium bg-white text-gray-600 hover:bg-gray-50 transition-colors';
        desc.textContent = 'Each file gets its own summary, processed one-by-one';
    } else {
        btnCmb.className = 'flex-1 py-1.5 px-3 text-center font-medium bg-blue-900 text-white transition-colors';
        btnInd.className = 'flex-1 py-1.5 px-3 text-center font-medium bg-white text-gray-600 hover:bg-gray-50 transition-colors';
        desc.textContent = 'All files merged into one combined case summary';
    }
}
window.setProcessingMode = setProcessingMode;

function handleFiles(files, append = false) {
    if (append) {
        selectedFiles = selectedFiles.concat(Array.from(files));
    } else {
        selectedFiles = Array.from(files);
    }
    // Show/hide processing mode toggle
    const toggle = $('processing-mode-toggle');
    if (toggle) {
        if (selectedFiles.length > 1) toggle.classList.remove('hidden');
        else toggle.classList.add('hidden');
    }
    fileList.innerHTML = '';
    selectedFiles.forEach((f, i) => {
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between bg-slate-50 px-3 py-2 rounded-lg slide-up';
        div.style.animationDelay = `${i * 0.05}s`;
        const sizeStr = f.size > 1048576 ? `${(f.size / 1048576).toFixed(1)} MB` : `${(f.size / 1024).toFixed(0)} KB`;
        const ext = f.name.split('.').pop().toUpperCase();

        // Build safely with DOM methods
        const left = document.createElement('div');
        left.className = 'flex items-center space-x-2 min-w-0';
        const badge = document.createElement('span');
        badge.className = 'px-1.5 py-0.5 rounded text-xs font-mono bg-blue-100 text-blue-700';
        badge.textContent = ext;
        const nameSpan = document.createElement('span');
        nameSpan.className = 'truncate text-sm';
        nameSpan.textContent = f.name;
        left.appendChild(badge);
        left.appendChild(nameSpan);

        const right = document.createElement('div');
        right.className = 'flex items-center space-x-2';
        const sizeSpan = document.createElement('span');
        sizeSpan.className = 'text-gray-400 text-xs';
        sizeSpan.textContent = sizeStr;
        const removeBtn = document.createElement('button');
        removeBtn.className = 'text-gray-300 hover:text-red-500 transition-colors';
        removeBtn.innerHTML = '&times;';
        removeBtn.addEventListener('click', () => removeFile(i));
        right.appendChild(sizeSpan);
        right.appendChild(removeBtn);

        div.appendChild(left);
        div.appendChild(right);
        fileList.appendChild(div);
    });
    btnSummarize.disabled = selectedFiles.length === 0;
}

function removeFile(index) {
    selectedFiles.splice(index, 1);
    handleFiles(selectedFiles);
}

// ── Pipeline Code Viewer (SSA-inspired) ─────────────────────────────────────

function getPipelineCodeHTML() {
    const lines = [
        ['<span class="comment"># MedRecords AI - 4-Stage Pipeline</span>', ''],
        ['', ''],
        ['<span class="kw">def</span> <span class="fn">run_pipeline</span>(document):', ''],
        ['    <span class="comment"># Stage 1: Parse document into structured sections</span>', 'ingestion'],
        ['    sections = <span class="fn">ingestion_agent</span>(document)', 'ingestion'],
        ['    <span class="fn">validate_schema</span>(sections, INGESTION_SCHEMA)', 'ingestion'],
        ['', ''],
        ['    <span class="comment"># Stage 2: Detect and redact all 18 HIPAA identifiers</span>', 'privacy'],
        ['    redacted = <span class="fn">privacy_agent</span>(sections)', 'privacy'],
        ['    <span class="kw">assert</span> redacted.phi_summary.redaction_complete', 'privacy'],
        ['', ''],
        ['    <span class="comment"># Stage 3: Extract cited clinical summary</span>', 'summarizer'],
        ['    summary = <span class="fn">summarizer_agent</span>(redacted)', 'summarizer'],
        ['    <span class="kw">assert</span> summary.verification.citation_coverage == <span class="num">1.0</span>', 'summarizer'],
        ['', ''],
        ['    <span class="comment"># Stage 4: HIPAA compliance audit (zero PHI)</span>', 'auditor'],
        ['    audit = <span class="fn">auditor_agent</span>(summary)', 'auditor'],
        ['    <span class="fn">validate_no_phi</span>(audit)', 'auditor'],
        ['', ''],
        ['    <span class="kw">return</span> {<span class="str">"summary"</span>: summary, <span class="str">"audit"</span>: audit}', ''],
    ];

    return lines.map((line, i) =>
        `<div id="code-line-${i}" class="px-2 py-0.5 ${line[1] ? `code-stage-${line[1]}` : ''}" data-stage="${line[1]}">${line[0]}</div>`
    ).join('\n');
}

function highlightCodeStage(stageName) {
    const codeDisplay = $('code-display');
    if (!codeDisplay) return;
    codeDisplay.querySelectorAll('[data-stage]').forEach(el => el.classList.remove('line-active'));
    codeDisplay.querySelectorAll(`[data-stage="${stageName}"]`).forEach(el => el.classList.add('line-active'));
}

// ── Summarize ───────────────────────────────────────────────────────────────

btnSummarize.addEventListener('click', async () => {
    if (selectedFiles.length === 0) return;

    const caseRefInput = $('case-ref-input');
    const caseRef = caseRefInput ? caseRefInput.value.trim() : '';
    const fileCount = selectedFiles.length;
    const isMultiFile = fileCount > 1;
    const useIndividual = isMultiFile && processingMode === 'individual';

    btnSummarize.disabled = true;
    btnText.textContent = 'Processing...';
    btnSpinner.classList.remove('hidden');
    exportButtons.classList.add('hidden');

    // Hide the mode toggle while processing
    $('processing-mode-toggle')?.classList.add('hidden');

    try {
        // ── Show file queue during upload ──
        const qUpload = $('file-queue-progress');
        const qUploadLabel = $('queue-label');
        const qUploadCounter = $('queue-counter');
        const qUploadBar = $('queue-progress-bar');
        const qUploadFileList = $('queue-file-list');
        const uploadStatuses = selectedFiles.map(f => ({ name: f.name, status: 'queued' }));

        function renderUploadQueue() {
            if (!qUploadFileList) return;
            const icons = { queued: '\u23F3', uploading: '\u{1F4E4}', uploaded: '\u2705', failed: '\u274C', processing: '\u{1F504}', completed: '\u2705' };
            const colors = { queued: 'text-gray-400', uploading: 'text-blue-600 font-medium', uploaded: 'text-green-600', failed: 'text-red-600', processing: 'text-blue-800 font-medium', completed: 'text-green-600' };
            qUploadFileList.innerHTML = uploadStatuses.map(f =>
                `<div class="flex items-center justify-between py-0.5 ${colors[f.status] || ''}">
                    <span>${icons[f.status] || ''} ${esc(f.name)}</span>
                    <span class="text-gray-400">${f.status}</span>
                </div>`
            ).join('');
        }

        if (qUpload) {
            qUpload.classList.remove('hidden');
            qUploadLabel.textContent = `Uploading ${fileCount} file(s)...`;
            qUploadCounter.textContent = `0 / ${fileCount}`;
            qUploadBar.style.width = '0%';
            renderUploadQueue();
        }

        // ── Phase 1: Upload all files ──
        const uploadedFiles = [];
        for (let i = 0; i < fileCount; i++) {
            const file = selectedFiles[i];
            uploadStatuses[i].status = 'uploading';
            renderUploadQueue();

            const formData = new FormData();
            formData.append('file', file);
            if (caseRef) formData.append('case_ref', caseRef);

            const uploadRes = await authFetch(`${API}/api/upload`, {
                method: 'POST',
                headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {},
                body: formData,
            });
            const uploadData = await uploadRes.json();

            if (!uploadRes.ok) {
                uploadStatuses[i].status = 'failed';
                renderUploadQueue();
                showToast(`Upload failed: ${uploadData.error}`, 'error');
                resetButtons();
                return;
            }
            uploadStatuses[i].status = 'uploaded';
            uploadedFiles.push({ ...uploadData, name: file.name });
            if (qUploadCounter) qUploadCounter.textContent = `${i + 1} / ${fileCount}`;
            if (qUploadBar) qUploadBar.style.width = `${((i + 1) / fileCount) * 100}%`;
            renderUploadQueue();
        }

        showToast(`${fileCount} file(s) uploaded`, 'success');

        // ── Phase 2: Process ──
        if (useIndividual) {
            // Individual mode: process files one-by-one sequentially
            await processFilesIndividually(uploadedFiles, caseRef);
        } else {
            // Combined or single-file mode: use the pipeline processing view
            resultsPlaceholder.classList.add('hidden');
            summaryView.classList.add('hidden');
            processingView.classList.remove('hidden');
            liveLog.innerHTML = '';
            resetPipelineStages();
            $('code-display').innerHTML = getPipelineCodeHTML();
            processingHeader.textContent = isMultiFile
                ? `Processing ${fileCount} files${caseRef ? ` (Case: ${caseRef})` : ''}...`
                : `Processing: ${uploadedFiles[0].name}`;

            // ── Update file queue for processing phase ──
            if (qUpload) {
                qUploadLabel.textContent = isMultiFile ? 'Processing case files...' : 'Processing file...';
                qUploadBar.style.width = '0%';
                // Update all files to "processing" status
                uploadStatuses.forEach(f => f.status = 'processing');
                renderUploadQueue();
                // Store for later update when pipeline completes
                window._combinedQueueState = { fileStatuses: uploadStatuses, renderCombinedQueue: renderUploadQueue, queueLabel: qUploadLabel, queueCounter: qUploadCounter, queueBar: qUploadBar };
            }

            let sumRes;
            if (isMultiFile) {
                const effectiveCaseRef = caseRef || `Case-${new Date().toISOString().slice(0,10)}-${Date.now().toString(36)}`;
                if (!caseRef) logMessage(`Auto-assigned case reference: ${effectiveCaseRef}`);
                sumRes = await authFetch(`${API}/api/summarize`, {
                    method: 'POST',
                    headers: authHeaders(),
                    body: JSON.stringify({
                        case_ref: effectiveCaseRef,
                        file_paths: uploadedFiles.map(u => u.file_path),
                        mode: speedMode,
                    }),
                });
            } else {
                sumRes = await authFetch(`${API}/api/summarize`, {
                    method: 'POST',
                    headers: authHeaders(),
                    body: JSON.stringify({ file_path: uploadedFiles[0].file_path, mode: speedMode }),
                });
            }

            const sumData = await sumRes.json();
            if (!sumRes.ok) {
                logMessage(`Pipeline start failed: ${sumData.error}`, 'error');
                showToast('Pipeline failed to start', 'error');
                // Mark queue as failed
                if (window._combinedQueueState) {
                    window._combinedQueueState.fileStatuses.forEach(f => f.status = 'failed');
                    window._combinedQueueState.renderCombinedQueue(window._combinedQueueState.fileStatuses);
                    window._combinedQueueState.queueLabel.textContent = 'Pipeline failed';
                }
                resetButtons();
                return;
            }

            currentRunId = sumData.run_id;
            logMessage(`Pipeline started: ${currentRunId}`, 'info');
            showToast(isMultiFile ? 'Combined pipeline started...' : 'Pipeline started...', 'info', 6000);
            pollInterval = setInterval(() => pollPipelineStatus(currentRunId), 3000);
        }

    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
        resetButtons();
    }
});

// ── Individual (one-by-one) file processing ────────────────────────────────

async function processFilesIndividually(uploadedFiles, caseRef) {
    const total = uploadedFiles.length;
    const queueProgress = $('file-queue-progress');
    const queueLabel = $('queue-label');
    const queueCounter = $('queue-counter');
    const queueBar = $('queue-progress-bar');
    const queueFileList = $('queue-file-list');

    // Show the queue progress UI
    queueProgress?.classList.remove('hidden');
    resultsPlaceholder?.classList.add('hidden');
    summaryView?.classList.add('hidden');
    processingView?.classList.remove('hidden');
    liveLog.innerHTML = '';
    resetPipelineStages();
    $('code-display').innerHTML = getPipelineCodeHTML();

    // Build the file queue list
    const fileStatuses = uploadedFiles.map((f, i) => ({ name: f.name, status: 'queued', runId: null }));
    function renderQueue() {
        if (!queueFileList) return;
        queueFileList.innerHTML = fileStatuses.map((f, i) => {
            const icons = { queued: '\u23F3', processing: '\u{1F504}', completed: '\u2705', failed: '\u274C' };
            const colors = { queued: 'text-gray-400', processing: 'text-blue-800 font-medium', completed: 'text-green-600', failed: 'text-red-600' };
            return `<div class="flex items-center justify-between py-0.5 ${colors[f.status] || ''}">
                <span>${icons[f.status] || ''} ${esc(f.name)}</span>
                <span class="text-gray-400">${f.status}</span>
            </div>`;
        }).join('');
    }
    renderQueue();

    let completed = 0;
    let failed = 0;
    let lastRunId = null;

    for (let i = 0; i < total; i++) {
        const file = uploadedFiles[i];
        fileStatuses[i].status = 'processing';
        renderQueue();

        queueLabel.textContent = `Processing: ${file.name}`;
        queueCounter.textContent = `${i + 1} / ${total}`;
        queueBar.style.width = `${((i) / total) * 100}%`;

        processingHeader.textContent = `File ${i + 1} of ${total}: ${file.name}`;
        logMessage(`\u2500\u2500\u2500 File ${i + 1}/${total}: ${file.name} \u2500\u2500\u2500`, 'system');
        resetPipelineStages();

        try {
            // Trigger summarization for this single file
            const sumRes = await authFetch(`${API}/api/summarize`, {
                method: 'POST',
                headers: authHeaders(),
                body: JSON.stringify({ file_path: file.file_path, mode: speedMode }),
            });
            const sumData = await sumRes.json();

            if (!sumRes.ok) {
                logMessage(`Pipeline failed to start for ${file.name}: ${sumData.error}`, 'error');
                fileStatuses[i].status = 'failed';
                failed++;
                renderQueue();
                continue;
            }

            const runId = sumData.run_id;
            lastRunId = runId;
            fileStatuses[i].runId = runId;
            logMessage(`Pipeline started: ${runId}`, 'info');

            // Poll until this pipeline completes or fails
            const result = await waitForPipeline(runId);

            if (result === 'completed') {
                fileStatuses[i].status = 'completed';
                completed++;
                logMessage(`Completed: ${file.name}`, 'success');
            } else {
                fileStatuses[i].status = 'failed';
                failed++;
                logMessage(`Failed: ${file.name}`, 'error');
            }
        } catch (err) {
            fileStatuses[i].status = 'failed';
            failed++;
            logMessage(`Error processing ${file.name}: ${err.message}`, 'error');
        }

        renderQueue();
        queueBar.style.width = `${((i + 1) / total) * 100}%`;
    }

    // All done
    queueLabel.textContent = `Done: ${completed} completed, ${failed} failed`;
    queueCounter.textContent = `${total} / ${total}`;
    queueBar.style.width = '100%';

    processingHeader.textContent = `Processed ${total} files: ${completed} completed, ${failed} failed`;
    logMessage(`\u2500\u2500\u2500 All files processed: ${completed} completed, ${failed} failed \u2500\u2500\u2500`, completed === total ? 'success' : 'error');

    showToast(`${completed} of ${total} files summarized`, completed === total ? 'success' : 'error', 8000);

    // Load the last completed summary if any
    if (lastRunId && completed > 0) {
        try { await loadSummary(lastRunId); } catch { /* ignore */ }
    }

    resetButtons();
    loadPipelineRuns();
    refreshDashboard();
}

function waitForPipeline(runId) {
    return new Promise((resolve) => {
        const poll = setInterval(async () => {
            try {
                const res = await authFetch(`${API}/api/pipeline/${runId}`);
                if (!res.ok) return;
                const data = await res.json();

                // Update stage indicators
                const stageNames = ['ingestion', 'privacy', 'summarizer', 'auditor'];
                stageNames.forEach((name, i) => {
                    const stage = data.stages?.[name];
                    const el = $(`ps-${name}`);
                    const icon = el?.querySelector('.stage-icon');
                    const connector = $(`connector-${i + 1}`);
                    if (!icon) return;
                    if (stage?.status === 'completed') {
                        icon.className = 'stage-icon completed';
                        icon.innerHTML = '<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg>';
                        if (connector) connector.className = 'flex-1 h-0.5 bg-green-400 mx-1 transition-colors';
                        el.classList.remove('active');
                    } else if (stage?.status === 'running') {
                        icon.className = 'stage-icon running';
                        icon.textContent = i + 1;
                        el.classList.add('active');
                        highlightCodeStage(name);
                    } else if (stage?.status === 'failed') {
                        icon.className = 'stage-icon failed';
                        icon.innerHTML = '<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg>';
                        el.classList.remove('active');
                    }
                });

                updateETADisplay(data);

                if (data.status === 'completed' || data.status === 'failed') {
                    clearInterval(poll);
                    resolve(data.status);
                }
            } catch {
                // silently retry
            }
        }, 3000);
    });
}

// ── ETA Estimation ──────────────────────────────────────────────────────────

// Average stage durations in seconds (from historical pipeline runs)
const STAGE_AVG_SECONDS = { ingestion: 23, privacy: 25, summarizer: 100, auditor: 16 };
const STAGE_ORDER = ['ingestion', 'privacy', 'summarizer', 'auditor'];

function estimatePipelineETA(data) {
    if (!data?.stages || data.status === 'completed' || data.status === 'failed') return null;
    let remainingSec = 0;
    for (const stage of STAGE_ORDER) {
        const s = data.stages[stage];
        if (!s || s.status === 'pending') {
            remainingSec += STAGE_AVG_SECONDS[stage];
        } else if (s.status === 'running' && s.timestamp) {
            const elapsed = (Date.now() - new Date(s.timestamp).getTime()) / 1000;
            remainingSec += Math.max(0, STAGE_AVG_SECONDS[stage] - elapsed);
        }
        // completed/failed stages contribute 0
    }
    return Math.max(0, Math.ceil(remainingSec));
}

function formatETA(seconds) {
    if (seconds <= 0) return 'Finishing up...';
    if (seconds < 60) return `~${seconds}s remaining`;
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return s > 0 ? `~${m}m ${s}s remaining` : `~${m}m remaining`;
}

function updateETADisplay(data) {
    const etaEl = $('pipeline-eta');
    const etaText = $('eta-text');
    if (!etaEl || !etaText) return;
    const eta = estimatePipelineETA(data);
    if (eta === null) {
        etaEl.classList.add('hidden');
    } else {
        etaEl.classList.remove('hidden');
        etaText.textContent = formatETA(eta);
    }
}

async function pollPipelineStatus(runId) {
    try {
        const res = await authFetch(`${API}/api/pipeline/${runId}`);
        if (!res.ok) return;
        const data = await res.json();

        updateETADisplay(data);

        // Thorough mode progress
        if (data.mode === 'thorough') {
            updateThoroughProgress(data);
        }

        const stageNames = ['ingestion', 'privacy', 'summarizer', 'auditor'];
        stageNames.forEach((name, i) => {
            const stage = data.stages?.[name];
            const el = $(`ps-${name}`);
            const icon = el?.querySelector('.stage-icon');
            const connector = $(`connector-${i + 1}`);
            if (!icon) return;

            if (stage?.status === 'completed') {
                icon.className = 'stage-icon completed';
                icon.innerHTML = '<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg>';
                if (connector) connector.className = 'flex-1 h-0.5 bg-green-400 mx-1 transition-colors';
                el.classList.remove('active');
            } else if (stage?.status === 'running') {
                icon.className = 'stage-icon running';
                icon.textContent = i + 1;
                el.classList.add('active');
                highlightCodeStage(name);
                logMessage(`Stage: ${name} running...`, 'info');
            } else if (stage?.status === 'failed') {
                icon.className = 'stage-icon failed';
                icon.innerHTML = '<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg>';
                el.classList.remove('active');
                logMessage(`Stage ${name} FAILED: ${esc(stage.details || '')}`, 'error');
            }
        });

        if (data.status === 'completed' || data.status === 'failed') {
            clearInterval(pollInterval);
            pollInterval = null;

            // Update file queue if present
            if (window._combinedQueueState) {
                const qs = window._combinedQueueState;
                const finalStatus = data.status === 'completed' ? 'completed' : 'failed';
                qs.fileStatuses.forEach(f => f.status = finalStatus);
                qs.renderCombinedQueue(qs.fileStatuses);
                qs.queueBar.style.width = '100%';
                qs.queueCounter.textContent = `${qs.fileStatuses.length} / ${qs.fileStatuses.length}`;
                qs.queueLabel.textContent = data.status === 'completed'
                    ? `Done: ${qs.fileStatuses.length} file(s) processed`
                    : `Failed: pipeline error`;
                window._combinedQueueState = null;
            }

            if (data.status === 'completed') {
                logMessage('Pipeline complete!', 'success');
                showToast('Summarization complete!', 'success', 6000);
                await loadSummary(runId);
            } else {
                logMessage(`Pipeline failed: ${esc(data.error || 'Unknown error')}`, 'error');
                showToast('Pipeline failed. Check the log for details.', 'error', 8000);
            }
            resetButtons();
        }
    } catch { /* silently retry */ }
}

function updateThoroughProgress(data) {
    const thoroughEl = $('thorough-progress');
    if (!thoroughEl) return;
    thoroughEl.classList.remove('hidden');

    // Preprocessing stats
    const prep = data.preprocessing;
    if (prep && prep.status === 'completed' && prep.details) {
        const stats = $('preprocess-stats');
        if (stats) {
            stats.classList.remove('hidden');
            const d = prep.details;
            const tpTotal = $('tp-total');
            const tpUnique = $('tp-unique');
            const tpDupes = $('tp-dupes');
            const tpHw = $('tp-handwritten');
            if (tpTotal) tpTotal.textContent = d.total_pages || 0;
            if (tpUnique) tpUnique.textContent = d.unique_pages || 0;
            if (tpDupes) tpDupes.textContent = d.duplicate_pages || 0;
            if (tpHw) tpHw.textContent = d.handwritten_pages || 0;
        }
    }

    // Chunk progress
    const chunks = data.chunks;
    if (chunks) {
        const chunkEl = $('chunk-progress');
        if (chunkEl) {
            chunkEl.classList.remove('hidden');
            const d = chunks.details || chunks;
            const total = d.total || 0;
            const completed = d.completed || 0;
            const current = d.current || 0;
            const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

            const counter = $('chunk-counter');
            if (counter) counter.textContent = `${completed} / ${total}`;

            const bar = $('chunk-progress-bar');
            if (bar) bar.style.width = pct + '%';

            const phase = $('chunk-phase');
            if (phase) {
                if (chunks.status === 'running') {
                    phase.textContent = `Processing chunk ${current}...`;
                } else if (chunks.status === 'completed') {
                    phase.textContent = `All ${total} chunks processed`;
                }
            }
        }
    }

    // Merge status
    const merge = data.merge;
    if (merge) {
        const mergeEl = $('merge-status');
        if (mergeEl) {
            if (merge.status === 'running') mergeEl.textContent = 'Merging summaries...';
            else if (merge.status === 'completed') mergeEl.textContent = 'Merge complete';
            else if (merge.status === 'failed') mergeEl.textContent = 'Merge failed';
        }
    }

    // Update processing header
    const header = $('processing-header');
    if (header) {
        if (prep && prep.status === 'running') {
            header.textContent = 'Preprocessing documents...';
        } else if (chunks && chunks.status === 'running') {
            const d = chunks.details || chunks;
            header.textContent = `Processing chunk ${d.current || '?'} of ${d.total || '?'}...`;
        } else if (merge && merge.status === 'running') {
            header.textContent = 'Merging chunk summaries...';
        }
    }
}

async function loadSummary(runId) {
    try {
        const res = await authFetch(`${API}/api/summaries/${runId}`);
        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            showToast(`Failed to load summary: ${errData.error || `HTTP ${res.status}`}`, 'error');
            return;
        }
        const data = await res.json();
        currentSummaryData = data;
        currentRunId = runId;

        processingView.classList.add('hidden');
        summaryView.classList.remove('hidden');
        exportButtons.classList.remove('hidden');
        renderSummary(data);
    } catch (err) {
        showToast(`Error loading summary: ${err.message}`, 'error');
        logMessage(`Error loading summary: ${err.message}`, 'error');
    }
}

// ── Summary Rendering (XSS-safe) ───────────────────────────────────────────

function renderSummary(data) {
    const summary = data.summary?.summary || {};
    const audit = data.audit || {};
    const verification = data.summary?.verification || {};
    const content = $('subtab-summary');
    content.innerHTML = '';

    // Reset sub-tabs to Summary as default
    switchSubTab('summary');
    // Clear analysis and actions panels
    const analysisPanel = $('subtab-analysis');
    const actionsPanel = $('subtab-actions');
    if (analysisPanel) analysisPanel.innerHTML = getAnalysisEmptyState();
    if (actionsPanel) actionsPanel.innerHTML = getActionsEmptyState();
    // Reset tool results for insights strip
    toolResults = { valuation: null, negligence: null, tasks: null, injuryMap: null, demand: null };
    updateInsightsStrip();
    updateSubTabBadges();

    $('summary-title').textContent = `Summary: ${data.source_file || data.run_id}`;

    // Show demand package, valuation, and negligence buttons
    const demandBtn = $('btn-demand-package');
    if (demandBtn) demandBtn.classList.remove('hidden');
    const valBtn = $('btn-case-valuation');
    if (valBtn) valBtn.classList.remove('hidden');
    const negBtn = $('btn-negligence');
    if (negBtn) negBtn.classList.remove('hidden');
    const taskBtn = $('btn-auto-tasks');
    if (taskBtn) taskBtn.classList.remove('hidden');
    const diagramBtn = $('btn-injury-diagram');
    if (diagramBtn) diagramBtn.classList.remove('hidden');

    const badge = $('compliance-badge');
    const status = audit.compliance_status || 'UNKNOWN';
    badge.textContent = status;
    badge.className = `px-3 py-1 rounded-full text-xs font-bold ${
        status === 'PASS' ? 'bg-green-100 text-green-800' :
        status === 'REVIEW_NEEDED' ? 'bg-yellow-100 text-yellow-800' :
        'bg-gray-100 text-gray-800'
    }`;

    const conf = summary.overall_confidence || 0;
    const confBar = $('confidence-bar');
    const confColor = conf >= 0.8 ? 'bg-green-500' : conf >= 0.6 ? 'bg-yellow-500' : 'bg-red-500';
    const confTextColor = conf >= 0.8 ? 'text-green-700' : conf >= 0.6 ? 'text-yellow-700' : 'text-red-700';
    confBar.innerHTML = `
        <div class="flex items-center justify-between mb-1">
            <span class="text-xs text-gray-500">Overall Confidence</span>
            <span class="text-sm font-bold ${confTextColor}">${(conf * 100).toFixed(0)}%</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2.5">
            <div class="${confColor} h-2.5 rounded-full transition-all duration-700" style="width:${conf * 100}%"></div>
        </div>`;

    // Show trial watermark banner if present
    if (data._trial_watermark) {
        const wmBanner = document.createElement('div');
        wmBanner.className = 'bg-amber-50 border border-amber-300 rounded-lg p-4 mb-4 text-center';
        wmBanner.innerHTML = `
            <p class="text-amber-800 font-bold text-sm">TRIAL VERSION</p>
            <p class="text-amber-700 text-xs mt-1">Demo case limit reached. <a href="https://aiproductivity.dev/pricing" target="_blank" class="underline font-semibold">Purchase a license</a> to remove this watermark and process unlimited cases.</p>`;
        content.appendChild(wmBanner);
    }

    // Show preprocessing stats for thorough mode
    if (data.preprocessing) {
        const pp = data.preprocessing;
        const ppCard = document.createElement('div');
        ppCard.className = 'bg-blue-50 border border-blue-100 rounded-lg p-4 mb-4';
        ppCard.innerHTML = `
            <h4 class="text-sm font-bold text-blue-800 mb-2">Document Analysis (Thorough Mode)</h4>
            <div class="grid grid-cols-4 gap-3 text-center text-xs">
                <div><p class="text-gray-500">Total Pages</p><p class="text-lg font-bold text-slate-700">${pp.total_pages || 0}</p></div>
                <div><p class="text-gray-500">Unique</p><p class="text-lg font-bold text-green-600">${pp.unique_pages || 0}</p></div>
                <div><p class="text-gray-500">Duplicates Removed</p><p class="text-lg font-bold text-amber-600">${pp.duplicate_pages || 0}</p></div>
                <div><p class="text-gray-500">Handwritten</p><p class="text-lg font-bold text-purple-600">${pp.handwritten_pages || 0}</p></div>
            </div>
            <p class="text-xs text-blue-800 mt-2">${pp.chunks_processed || 0} of ${pp.chunks_total || 0} chunks processed</p>`;
        content.appendChild(ppCard);
    }

    const billingData = data.summary?.billing_data || null;
    const alertsData = data.summary?.alerts || [];
    content.appendChild(createSummaryCards(verification, billingData, alertsData));

    // BLUF Header (Bottom Line Up Front) — Phase 1: Executive Impact
    const bluf = data.summary?.bluf;
    if (bluf) {
        const blufDiv = document.createElement('div');
        blufDiv.className = 'mb-4 p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg border-2 border-emerald-300 shadow-sm';
        blufDiv.innerHTML = `
            <div class="flex items-start space-x-3">
                <svg class="w-7 h-7 text-emerald-600 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                <div class="flex-1">
                    <h3 class="text-sm font-bold text-emerald-900 uppercase tracking-wide mb-2">Bottom Line Up Front</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div class="p-2.5 bg-white rounded-lg border border-emerald-100">
                            <p class="text-[10px] font-bold uppercase text-emerald-700 mb-1">Primary Diagnosis</p>
                            <p class="text-sm text-gray-800 font-medium">${esc(bluf.primary_diagnosis || '')}</p>
                        </div>
                        <div class="p-2.5 bg-white rounded-lg border border-emerald-100">
                            <p class="text-[10px] font-bold uppercase text-emerald-700 mb-1">Objective Proof</p>
                            <p class="text-sm text-gray-800 font-medium">${esc(bluf.objective_proof || '')}</p>
                        </div>
                        <div class="p-2.5 bg-white rounded-lg border border-emerald-100">
                            <p class="text-[10px] font-bold uppercase text-emerald-700 mb-1">Future Outlook</p>
                            <p class="text-sm text-gray-800 font-medium">${esc(bluf.future_outlook || '')}</p>
                        </div>
                    </div>
                </div>
            </div>`;
        content.appendChild(blufDiv);
    }

    // Executive Strategy Banner
    const execStrategy = data.summary?.executive_strategy;
    if (execStrategy) {
        const stratDiv = document.createElement('div');
        stratDiv.className = 'mb-4 p-4 bg-gradient-to-r from-blue-50 to-slate-50 rounded-lg border border-blue-200';
        stratDiv.innerHTML = `
            <div class="flex items-start space-x-3">
                <svg class="w-6 h-6 text-blue-800 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                <div>
                    <h3 class="text-sm font-bold text-blue-900 uppercase tracking-wide mb-1">Summary</h3>
                    <p class="text-sm text-blue-800 leading-relaxed">${renderTextWithCitations(execStrategy)}</p>
                </div>
            </div>`;
        content.appendChild(stratDiv);
    }

    // Trial Strategy Note — moved up after Summary for top-of-document visibility
    const trialNote = data.summary?.trial_strategy_note;
    if (trialNote) {
        content.appendChild(createCollapsibleSection('Trial Strategy Note',
            `<div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <svg class="w-5 h-5 text-blue-800 float-left mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"/></svg>
                <p class="text-sm text-blue-900">${renderTextWithCitations(trialNote)}</p>
            </div>`, true));
    }

    // Case Alerts & Risk Factors
    if (alertsData && alertsData.length > 0) {
        const alertsHtml = renderAlertsSection(alertsData);
        const alertsSection = createCollapsibleSection(
            `Case Alerts & Risk Factors (${alertsData.length})`,
            alertsHtml, true
        );
        alertsSection.id = 'section-alerts';
        content.appendChild(alertsSection);
    }

    // Litigation Cheat Sheet (Win/Loss Table) — Phase 2
    const cheatSheet = data.summary?.litigation_cheat_sheet;
    if (cheatSheet && (cheatSheet.wins?.length || cheatSheet.risks?.length)) {
        const winsRows = (cheatSheet.wins || []).map(w => `
            <tr class="border-b border-green-100 hover:bg-green-50 transition-colors">
                <td class="py-2 px-3"><span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-green-100 text-green-800">WIN</span></td>
                <td class="py-2 px-3 text-sm text-gray-800">${esc(w.leverage || '')}</td>
                <td class="py-2 px-3 whitespace-nowrap">${renderCitation(w.source_ref)}</td>
            </tr>`).join('');
        const risksRows = (cheatSheet.risks || []).map(r => `
            <tr class="border-b border-red-100 hover:bg-red-50 transition-colors">
                <td class="py-2 px-3"><span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-red-100 text-red-800">RISK</span></td>
                <td class="py-2 px-3 text-sm text-gray-800">${esc(r.target || '')}</td>
                <td class="py-2 px-3 whitespace-nowrap">${renderCitation(r.source_ref)}</td>
            </tr>`).join('');
        const tableHtml = `
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead><tr class="border-b-2 border-gray-200 text-xs text-gray-500 uppercase tracking-wide">
                        <th class="text-left py-2 px-3 w-16">Type</th>
                        <th class="text-left py-2 px-3">Detail</th>
                        <th class="text-left py-2 px-3 w-24">Source</th>
                    </tr></thead>
                    <tbody>${winsRows}${risksRows}</tbody>
                </table>
            </div>`;
        const csSection = createCollapsibleSection(
            `Litigation Cheat Sheet (${cheatSheet.wins?.length || 0} wins, ${cheatSheet.risks?.length || 0} risks)`,
            `<div class="bg-slate-50 rounded-lg p-3 border border-slate-200">${tableHtml}</div>`,
            true
        );
        csSection.id = 'section-cheat-sheet';
        content.appendChild(csSection);
    }

    if (summary.chief_complaint) {
        const ccSection = createCollapsibleSection('Chief Complaint',
            renderClaimItem(summary.chief_complaint.text || '', summary.chief_complaint), true);
        ccSection.id = 'section-chief-complaint';
        content.appendChild(ccSection);
    }
    if (summary.active_diagnoses?.length) {
        const items = summary.active_diagnoses.map(d => renderClaimItem(d.diagnosis, d)).join('');
        const adSection = createCollapsibleSection(`Active Diagnoses (${summary.active_diagnoses.length})`, items, true);
        adSection.id = 'section-diagnoses';
        content.appendChild(adSection);
    }
    if (summary.medications?.length) {
        const items = summary.medications.map(m => renderClaimItem(`${m.name} ${m.dosage || ''}`, m)).join('');
        const medSection = createCollapsibleSection(`Medications (${summary.medications.length})`, items, true);
        medSection.id = 'section-medications';
        content.appendChild(medSection);
    }
    if (summary.key_findings?.length) {
        const items = summary.key_findings.map(f => renderClaimItem(f.finding, f)).join('');
        const kfSection = createCollapsibleSection(`Key Findings (${summary.key_findings.length})`, items, true);
        kfSection.id = 'section-findings';
        content.appendChild(kfSection);
    }
    // Master Chronology (new Strategic Litigation Auditor format)
    if (summary.master_chronology?.length) {
        const rows = summary.master_chronology.map(e => `
            <tr class="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                <td class="py-2 px-2 text-xs font-mono text-blue-800 whitespace-nowrap align-top">${esc(e.date || '?')}</td>
                <td class="py-2 px-2 text-sm text-gray-700 align-top">${esc(e.provider || '')}</td>
                <td class="py-2 px-2 text-sm text-gray-700 align-top">${esc(e.clinical_finding || '')}</td>
                <td class="py-2 px-2 text-sm text-blue-700 italic align-top">${esc(e.legal_leverage || '')}</td>
                <td class="py-2 px-2 align-top whitespace-nowrap">${renderConfidence(e.confidence)} ${renderCitation(e.citation)}</td>
            </tr>`).join('');
        const tableHtml = `
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead><tr class="border-b-2 border-gray-200 text-xs text-gray-500 uppercase tracking-wide">
                        <th class="text-left py-2 px-2">Date</th>
                        <th class="text-left py-2 px-2">Provider</th>
                        <th class="text-left py-2 px-2">Clinical Finding</th>
                        <th class="text-left py-2 px-2">Legal Leverage</th>
                        <th class="text-left py-2 px-2">Source</th>
                    </tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>`;
        const mcSection = createCollapsibleSection(`Master Chronology (${summary.master_chronology.length})`, tableHtml, true);
        mcSection.id = 'section-chronology';
        content.appendChild(mcSection);
    }
    // Legacy chronological_events fallback
    else if (summary.chronological_events?.length) {
        const items = summary.chronological_events.map(e => `
            <div class="flex items-start space-x-3 py-2 border-b border-gray-50 last:border-0">
                <span class="text-xs font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded whitespace-nowrap mt-0.5">${esc(e.date || '?')}</span>
                <div class="flex-1">
                    <span class="text-sm text-gray-700">${esc(e.event)}</span>
                    <div class="mt-0.5">${renderConfidence(e.confidence)} ${renderCitation(e.citation)}</div>
                </div>
            </div>`).join('');
        const tlSection = createCollapsibleSection(`Timeline (${summary.chronological_events.length})`, items, false);
        tlSection.id = 'section-chronology';
        content.appendChild(tlSection);
    }
    // Smoking Gun Quotes
    if (summary.smoking_gun_quotes?.length) {
        const items = summary.smoking_gun_quotes.map(q => `
            <div class="py-3 border-b border-red-100 last:border-0">
                <div class="flex items-start space-x-2">
                    <svg class="w-5 h-5 text-red-500 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
                    <div class="flex-1">
                        <blockquote class="text-sm font-medium text-gray-800 italic border-l-3 border-red-400 pl-3 mb-1">"${esc(q.quote || '')}"</blockquote>
                        <p class="text-xs text-red-700 mt-1">${esc(q.significance || '')}</p>
                        <div class="mt-1">${renderCitation(q.citation)}</div>
                    </div>
                </div>
            </div>`).join('');
        const sgSection = createCollapsibleSection(`Smoking Gun Quotes (${summary.smoking_gun_quotes.length})`,
            `<div class="bg-red-50 rounded-lg p-3 border border-red-200">${items}</div>`, true);
        sgSection.id = 'section-smoking-gun';
        content.appendChild(sgSection);
    }

    // Contradictions — supports both new object format and legacy string format
    if (summary.contradictions_flagged?.length) {
        const items = summary.contradictions_flagged.map(c => {
            if (typeof c === 'string') {
                return `<div class="flex items-start space-x-2 py-2 text-sm">
                    <svg class="w-4 h-4 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"/></svg>
                    <span class="text-amber-800">${esc(c)}</span>
                </div>`;
            }
            const citations = (c.citations || []).map(cit => renderCitation(cit)).join(' ');
            return `<div class="py-3 border-b border-amber-100 last:border-0">
                <p class="text-sm font-medium text-amber-900 mb-2">${esc(c.contradiction || '')}</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                    <div class="p-2 bg-white rounded border border-amber-100">
                        <p class="text-xs font-bold uppercase text-gray-500 mb-0.5">Subjective</p>
                        <p class="text-sm text-gray-700">${esc(c.subjective || '')}</p>
                    </div>
                    <div class="p-2 bg-white rounded border border-amber-100">
                        <p class="text-xs font-bold uppercase text-gray-500 mb-0.5">Objective</p>
                        <p class="text-sm text-gray-700">${esc(c.objective || '')}</p>
                    </div>
                </div>
                ${c.legal_note ? `<p class="text-xs text-amber-800 italic"><span class="font-semibold">Legal Note:</span> ${esc(c.legal_note)}</p>` : ''}
                ${citations ? `<div class="mt-1">${citations}</div>` : ''}
            </div>`;
        }).join('');
        const contradictionsSection = createCollapsibleSection(`Contradictions Detected (${summary.contradictions_flagged.length})`,
            `<div class="bg-amber-50 rounded-lg p-3 border border-amber-200">${items}</div>`, true);
        contradictionsSection.id = 'section-contradictions';
        content.appendChild(contradictionsSection);
    }

    // Discovery Deficiencies
    if (summary.discovery_deficiencies?.length) {
        const rows = summary.discovery_deficiencies.map(d => {
            const urgColor = (d.urgency || '').includes('HIGH') ? 'bg-red-100 text-red-700' : (d.urgency || '').includes('MEDIUM') ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700';
            return `<tr class="border-b border-orange-100">
                <td class="py-2 pr-3 text-sm text-gray-800 align-top" style="word-break:break-word">${esc(d.missing_item || '')}</td>
                <td class="py-2 pr-3 align-top" style="word-break:break-word"><span class="inline-block px-1.5 py-0.5 rounded text-xs font-medium ${urgColor}">${esc(d.urgency || 'N/A')}</span></td>
                <td class="py-2 pr-3 text-xs text-gray-600 align-top" style="word-break:break-word">${esc(d.evidence || '')}</td>
                <td class="py-2 text-xs text-gray-500 align-top text-center">${renderCitation(d.citation)}</td>
            </tr>`;
        }).join('');
        const table = `<div class="bg-orange-50 rounded-lg p-3 border border-orange-200 overflow-x-auto">
            <table class="w-full" style="table-layout:fixed">
                <colgroup><col style="width:28%"><col style="width:12%"><col style="width:48%"><col style="width:12%"></colgroup>
                <thead><tr class="border-b-2 border-orange-200 text-left">
                    <th class="pb-2 text-xs font-semibold text-orange-800 uppercase">Missing Item</th>
                    <th class="pb-2 text-xs font-semibold text-orange-800 uppercase">Priority</th>
                    <th class="pb-2 text-xs font-semibold text-orange-800 uppercase">Evidence</th>
                    <th class="pb-2 text-xs font-semibold text-orange-800 uppercase text-center">Source</th>
                </tr></thead>
                <tbody>${rows}</tbody>
            </table>
        </div>`;
        const discoverySection = createCollapsibleSection(`Discovery Deficiencies (${summary.discovery_deficiencies.length})`, table, true);
        discoverySection.id = 'section-discovery-gaps';
        content.appendChild(discoverySection);
    }
    if (summary.timeline_gaps?.length) {
        const items = summary.timeline_gaps.map(g => `
            <div class="flex items-start space-x-2 py-2 text-sm">
                <svg class="w-4 h-4 text-orange-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.828a1 1 0 101.415-1.414L11 9.586V6z"/></svg>
                <span class="text-orange-800">${esc(g)}</span>
            </div>`).join('');
        const tgSection = createCollapsibleSection('Timeline Gaps',
            `<div class="bg-orange-50 rounded-lg p-3 border border-orange-200">${items}</div>`, true);
        tgSection.id = 'section-timeline-gaps';
        content.appendChild(tgSection);
    }

    // Low Confidence Claims — collect items with confidence < 0.7
    const lowConfThreshold = 0.7;
    const lowConfItems = [];
    for (const d of (summary.active_diagnoses || [])) {
        if (d.confidence != null && d.confidence < lowConfThreshold) lowConfItems.push({ text: d.diagnosis, ...d });
    }
    for (const m of (summary.medications || [])) {
        if (m.confidence != null && m.confidence < lowConfThreshold) lowConfItems.push({ text: `${m.name} ${m.dosage || ''}`, ...m });
    }
    for (const f of (summary.key_findings || [])) {
        if (f.confidence != null && f.confidence < lowConfThreshold) lowConfItems.push({ text: f.finding, ...f });
    }
    for (const e of (summary.master_chronology || [])) {
        if (e.confidence != null && e.confidence < lowConfThreshold) lowConfItems.push({ text: e.clinical_finding, ...e });
    }
    if (lowConfItems.length) {
        const lcItems = lowConfItems.map(i => renderClaimItem(i.text || '', i)).join('');
        const lcSection = createCollapsibleSection(
            `Low Confidence Claims (${lowConfItems.length})`,
            `<div class="bg-yellow-50 rounded-lg p-3 border border-yellow-200">${lcItems}</div>`,
            true
        );
        lcSection.id = 'section-low-confidence';
        content.appendChild(lcSection);
    }

    const phi = data.privacy?.phi_summary;
    if (phi) {
        const complete = phi.redaction_complete !== false;
        const byType = Object.entries(phi.by_type || {}).map(([k, v]) =>
            `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs bg-slate-100 border border-slate-200"><span class="font-semibold mr-1">${esc(k)}</span>${esc(v)}</span>`
        ).join(' ');
        content.appendChild(createCollapsibleSection('PHI Redaction Summary', `
            <div class="flex items-center space-x-4 mb-3">
                <div class="text-center"><p class="text-2xl font-bold text-slate-700">${Number(phi.total_identifiers_found) || 0}</p><p class="text-xs text-gray-500">Found</p></div>
                <svg class="w-5 h-5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                <div class="text-center"><p class="text-2xl font-bold ${complete ? 'text-green-600' : 'text-red-600'}">${Number(phi.total_redacted) || 0}</p><p class="text-xs text-gray-500">Redacted</p></div>
                <div class="ml-4"><span class="px-2 py-1 rounded text-xs font-bold ${complete ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">${complete ? 'COMPLETE' : 'INCOMPLETE'}</span></div>
            </div>
            <div class="flex flex-wrap gap-1.5">${byType}</div>`, false));
    }

    // Medical Bills Summary
    if (billingData) {
        const billingHtml = renderBillingSection(billingData);
        if (billingHtml) {
            const billingSection = createCollapsibleSection(
                `Medical Bills Summary (${formatCurrency(Number(billingData.total_combined) || 0)})`,
                billingHtml, true
            );
            billingSection.id = 'section-billing';
            content.appendChild(billingSection);
        }
    }

    // PI Core Analysis
    const piCore = data.summary?.pi_core_analysis;
    if (piCore) {
        let piHtml = '';
        // MOI
        const moi = piCore.mechanism_of_injury;
        if (moi) {
            piHtml += `<div class="mb-3 p-3 rounded-lg ${moi.physics_match ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}">
                <p class="text-xs font-bold uppercase text-gray-500 mb-1">Mechanism of Injury</p>
                <p class="text-sm">${esc(moi.description || '')}</p>
                <p class="text-sm mt-1"><span class="font-semibold">Clinical Correlation:</span> ${esc(moi.clinical_correlation || '')}</p>
                <p class="text-xs mt-1"><span class="font-semibold">Physics Match:</span> <span class="${moi.physics_match ? 'text-green-700' : 'text-red-700'} font-bold">${moi.physics_match ? 'YES' : 'NO'}</span> ${renderCitation(moi.citation)}</p>
            </div>`;
        }
        // Treatment Gaps
        if (piCore.treatment_gaps?.length) {
            piHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-1">Treatment Gaps</p>';
            piHtml += piCore.treatment_gaps.map(g => {
                const riskColor = (g.defense_risk || '').includes('HIGH') ? 'bg-red-100 text-red-800' : (g.defense_risk || '').includes('MEDIUM') ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800';
                return `<div class="p-2 mb-2 rounded border ${(g.defense_risk || '').includes('HIGH') ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'}">
                    <div class="flex items-center space-x-2 text-sm">
                        <span class="px-2 py-0.5 rounded text-xs font-bold ${riskColor}">${esc(g.days || 0)}d</span>
                        <span>${esc(g.gap_start || '')} to ${esc(g.gap_end || '')}</span>
                        <span class="text-xs text-gray-500 italic">${esc(g.defense_risk || '')}</span>
                    </div>
                    ${g.neutralization ? `<p class="text-xs text-green-700 mt-1 ml-1"><span class="font-semibold">Neutralization:</span> ${esc(g.neutralization)}</p>` : ''}
                    ${g.citation ? `<div class="mt-1 ml-1">${renderCitation(g.citation)}</div>` : ''}
                </div>`;
            }).join('');
        }
        // Pre-existing
        if (piCore.pre_existing_conditions?.length) {
            piHtml += '<p class="text-xs font-bold uppercase text-gray-500 mt-3 mb-1">Pre-Existing Conditions</p>';
            piHtml += piCore.pre_existing_conditions.map(p => `
                <div class="py-1.5 text-sm border-b border-gray-50">
                    <span class="font-medium">${esc(p.condition || '')}</span>
                    <span class="ml-2 px-2 py-0.5 rounded text-xs font-bold ${p.new_vs_aggravation === 'new' ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'}">${esc(p.new_vs_aggravation || '')}</span>
                    ${p.eggshell_plaintiff_note ? `<p class="text-xs text-gray-500 mt-0.5 italic">${esc(p.eggshell_plaintiff_note)}</p>` : ''}
                    ${renderCitation(p.citation)}
                </div>`).join('');
        }
        const piSection = createCollapsibleSection('PI Core Analysis', piHtml, true);
        piSection.id = 'section-pi-core';
        content.appendChild(piSection);
    }

    // Specialty Insights
    const insights = data.summary?.specialty_insights;
    if (insights) {
        // TBI
        if (insights.tbi) {
            const tbi = insights.tbi;
            let tbiHtml = '';
            if (tbi.neuro_symptom_mapping?.length) {
                tbiHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-2">Neuro-Symptom Mapping</p><div class="space-y-1 mb-3">';
                tbiHtml += tbi.neuro_symptom_mapping.map(s => `
                    <div class="flex items-center justify-between text-sm py-1 border-b border-gray-50">
                        <span>${esc(s.symptom)}</span>
                        <div class="flex items-center space-x-2">
                            <span class="text-xs text-gray-400">Onset: ${esc(s.onset || '')}</span>
                            <span class="px-2 py-0.5 rounded text-xs font-medium ${s.current_status === 'persistent' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}">${esc(s.current_status || '')}</span>
                        </div>
                    </div>`).join('');
                tbiHtml += '</div>';
            }
            if (tbi.gcs_scores?.length) {
                tbiHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-1">GCS Scores</p>';
                tbiHtml += tbi.gcs_scores.map(g => `<span class="inline-flex items-center px-2 py-1 mr-2 rounded text-sm bg-slate-100">${esc(g.date || '')}: <span class="font-bold ml-1 ${g.score <= 8 ? 'text-red-600' : g.score <= 12 ? 'text-yellow-600' : 'text-green-600'}">${g.score}</span></span>`).join('');
                tbiHtml += '<br><br>';
            }
            if (tbi.imaging_results?.length) {
                tbiHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-1">Imaging</p>';
                tbiHtml += tbi.imaging_results.map(i => `<div class="text-sm py-1">${esc(i.type || '')} (${esc(i.date || '')}): <span class="font-bold ${i.result === 'negative' ? 'text-gray-600' : 'text-red-600'}">${esc(i.result || '')}</span> <span class="text-xs italic text-gray-500">${esc(i.significance || '')}</span> ${renderCitation(i.citation)}</div>`).join('');
            }
            if (tbi.neuropsych_testing?.length) {
                tbiHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-1 mt-3">Neuropsychological Testing</p>';
                tbiHtml += tbi.neuropsych_testing.map(t => `
                    <div class="flex items-start justify-between py-1.5 border-b border-gray-50 text-sm">
                        <div>
                            <span class="font-medium">${esc(t.test || '')}</span>
                            <span class="text-xs text-gray-400 ml-2">${esc(t.date || '')}</span>
                        </div>
                        <div class="text-right">
                            <span class="text-xs text-red-700">${esc(t.result || '')}</span>
                            ${renderCitation(t.citation)}
                        </div>
                    </div>`).join('');
            }
            if (tbi.functional_impact) {
                tbiHtml += `<div class="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                    <p class="text-xs font-bold uppercase text-amber-800 mb-1">Functional Impact</p>
                    ${tbi.functional_impact.adl_limitations?.length ? `<p class="text-sm"><span class="font-semibold">ADL Limitations:</span> ${tbi.functional_impact.adl_limitations.map(a => esc(a)).join('; ')}</p>` : ''}
                    ${tbi.functional_impact.vocational_impact ? `<p class="text-sm mt-1"><span class="font-semibold">Vocational:</span> ${esc(tbi.functional_impact.vocational_impact)}</p>` : ''}
                </div>`;
            }
            const tbiSection = createCollapsibleSection('TBI Analysis', `<div class="bg-purple-50 rounded-lg p-3 border border-purple-200">${tbiHtml}</div>`, true);
            tbiSection.id = 'section-tbi';
            content.appendChild(tbiSection);
        }

        // Spinal/Orthopedic
        if (insights.spinal_orthopedic) {
            const spine = insights.spinal_orthopedic;
            let spineHtml = '';
            if (spine.dermatome_mapping?.length) {
                spineHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-2">Dermatome Mapping</p>';
                spineHtml += spine.dermatome_mapping.map(d => `
                    <div class="p-2 mb-2 bg-blue-50 rounded border border-blue-100 text-sm">
                        <span class="font-bold text-blue-800">${esc(d.disc_level || '')}</span> → <span class="font-medium">${esc(d.nerve_root || '')} root</span>
                        <p class="text-xs mt-1">Complaints: ${(d.patient_complaints || []).map(c => esc(c)).join(', ')}</p>
                        <p class="text-xs text-green-700 italic">${esc(d.clinical_correlation || '')}</p>
                    </div>`).join('');
            }
            if (spine.objective_tests?.length) {
                spineHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-1 mt-3">Objective Tests</p>';
                spineHtml += '<div class="space-y-1">' + spine.objective_tests.map(t => {
                    const isPositive = (t.result || '').toUpperCase().includes('POSITIVE');
                    return `<div class="py-2 border-b border-gray-50 text-sm">
                        <div class="flex items-center justify-between">
                            <span class="font-medium">${esc(t.test || '')}${t.date ? ` <span class="text-xs text-gray-400">(${esc(t.date)})</span>` : ''}</span>
                            <span class="px-2 py-0.5 rounded text-xs font-bold ${isPositive ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}">${esc(t.result || '')}</span>
                        </div>
                        ${t.significance ? `<p class="text-xs text-green-700 italic mt-0.5">${esc(t.significance)}</p>` : ''}
                        ${t.citation ? `<div class="mt-0.5">${renderCitation(t.citation)}</div>` : ''}
                    </div>`;
                }).join('') + '</div>';
            }
            if (spine.surgical_pathway) {
                const sp = spine.surgical_pathway;
                const stageColors = { conservative_care: 'bg-green-100 text-green-800', surgical_candidacy: 'bg-orange-100 text-orange-800', post_surgical: 'bg-red-100 text-red-800' };
                spineHtml += `<div class="mt-3 p-3 bg-slate-50 rounded-lg border">
                    <p class="text-xs font-bold uppercase text-gray-500 mb-1">Surgical Pathway</p>
                    <span class="px-2 py-1 rounded text-xs font-bold ${stageColors[sp.current_stage] || 'bg-gray-100'}">${esc((sp.current_stage || '').replace(/_/g, ' ').toUpperCase())}</span>
                    ${sp.conservative_treatments?.length ? `<p class="text-sm mt-2">Conservative: ${sp.conservative_treatments.map(t => esc(t)).join(', ')}</p>` : ''}
                    ${sp.surgical_recommendation ? `<p class="text-sm mt-1 font-medium text-orange-700">${esc(sp.surgical_recommendation)}</p>` : ''}
                </div>`;
            }
            const spineSection = createCollapsibleSection('Spinal & Orthopedic Analysis', spineHtml, true);
            spineSection.id = 'section-spinal';
            content.appendChild(spineSection);
        }

        // Soft Tissue / MIST
        if (insights.soft_tissue) {
            const st = insights.soft_tissue;
            let stHtml = '';
            if (st.objective_findings?.length) {
                stHtml += '<p class="text-xs font-bold uppercase text-gray-500 mb-2">Objective Findings (MIST Defense Counters)</p>';
                stHtml += st.objective_findings.map(f => `
                    <div class="p-2 mb-2 bg-teal-50 rounded border border-teal-100">
                        <p class="text-sm font-medium text-teal-900">${esc(f.finding || '')}</p>
                        <p class="text-xs text-teal-700 mt-0.5 italic">${esc(f.significance || '')}</p>
                        ${f.citation ? `<div class="mt-1">${renderCitation(f.citation)}</div>` : ''}
                    </div>`).join('');
            }
            const stSection = createCollapsibleSection('Soft Tissue / MIST Analysis',
                `<div class="bg-teal-50 rounded-lg p-3 border border-teal-200">${stHtml}</div>`, true);
            stSection.id = 'section-soft-tissue';
            content.appendChild(stSection);
        }

        // Pain Management
        if (insights.pain_management) {
            const pain = insights.pain_management;
            let painHtml = '';
            if (pain.interventional_log?.length) {
                painHtml += `<table class="w-full text-sm mb-3"><thead><tr class="border-b text-xs text-gray-500 uppercase">
                    <th class="text-left py-2">Procedure</th><th class="text-left py-2">Date</th><th class="text-left py-2">Level</th><th class="text-right py-2">Relief</th></tr></thead><tbody>`;
                painHtml += pain.interventional_log.map(p => `<tr class="border-b border-gray-50">
                    <td class="py-1.5">${esc(p.procedure || '')}</td>
                    <td class="py-1.5 text-gray-500">${esc(p.date || '')}</td>
                    <td class="py-1.5">${esc(p.level || '')}</td>
                    <td class="py-1.5 text-right font-bold ${(p.relief_percentage || 0) >= 50 ? 'text-green-600' : 'text-red-600'}">${p.relief_percentage || 0}%</td>
                </tr>`).join('');
                painHtml += '</tbody></table>';
            }
            if (pain.pain_trajectory) {
                const trajColor = pain.pain_trajectory === 'worsening' ? 'text-red-600' : pain.pain_trajectory === 'improving' ? 'text-green-600' : 'text-yellow-600';
                painHtml += `<p class="text-sm">Pain Trajectory: <span class="font-bold ${trajColor}">${esc(pain.pain_trajectory)}</span></p>`;
            }
            const pmSection = createCollapsibleSection('Pain Management Analysis', painHtml, true);
            pmSection.id = 'section-pain-mgmt';
            content.appendChild(pmSection);
        }
    }

    content.appendChild(createCollapsibleSection('Processing Details', `
        <div class="grid grid-cols-2 gap-2 text-xs text-gray-600">
            <div><span class="font-semibold">Run ID:</span> ${esc(data.run_id || '-')}</div>
            <div><span class="font-semibold">Source:</span> ${esc(data.source_file || '-')}</div>
            <div><span class="font-semibold">Processed:</span> ${data.processed_at ? new Date(data.processed_at).toLocaleString() : '-'}</div>
            <div><span class="font-semibold">Hash:</span> <span class="font-mono">${esc((data.source_file_hash || '-').substring(0, 16))}...</span></div>
            ${data.case_ref ? `<div><span class="font-semibold">Case Ref:</span> ${esc(data.case_ref)}</div>` : ''}
            ${data.source_files?.length > 1 ? `<div class="col-span-2"><span class="font-semibold">Files (${data.source_files.length}):</span> ${data.source_files.map(f => esc(f)).join(', ')}</div>` : ''}
            ${data.summary?.case_type ? `<div><span class="font-semibold">Case Type:</span> <span class="font-mono">${esc(data.summary.case_type)}</span></div>` : ''}
            ${data.summary?.specialty_modules_triggered?.length ? `<div><span class="font-semibold">Modules:</span> ${data.summary.specialty_modules_triggered.map(m => esc(m)).join(', ')}</div>` : ''}
        </div>`, false));

    // RLHF Feedback buttons
    if (data.run_id) {
        const feedbackDiv = document.createElement('div');
        feedbackDiv.innerHTML = renderFeedbackButtons(data.run_id);
        content.appendChild(feedbackDiv);
    }
}

function createSummaryCards(verification, billingData, alertsData) {
    const div = document.createElement('div');
    div.className = 'grid grid-cols-2 md:grid-cols-4 lg:grid-cols-9 gap-3 mb-4';
    const tc = Number(verification.total_claims) || 0;
    const cc = Number(verification.claims_with_citations) || 0;
    const cov = Number(verification.citation_coverage) || 0;
    const lc = Number(verification.low_confidence_claims) || 0;
    const nv = Number(verification.needs_verification) || 0;
    const cf = Number(verification.contradictions_found) || 0;
    const dg = Number(verification.discovery_gaps) || 0;
    // Billing total
    const billingTotal = Number(billingData?.total_combined) || 0;
    const hasBilling = billingTotal > 0;
    // Alerts count
    const alertsArr = Array.isArray(alertsData) ? alertsData : [];
    const alertCount = alertsArr.length;
    const highAlerts = alertsArr.filter(a => a.severity === 'high').length;
    const alertColor = highAlerts > 0 ? 'text-red-600' : alertCount > 0 ? 'text-orange-600' : 'text-slate-700';
    const alertBg = highAlerts > 0 ? 'bg-red-50 border-red-200' : alertCount > 0 ? 'bg-orange-50 border-orange-200' : 'bg-slate-50 border-slate-100';
    // Cards with issues get clickable styling and scroll to their section
    const clickable = (count, target) => count > 0
        ? `cursor-pointer hover:ring-2 hover:ring-offset-1 hover:ring-blue-700 hover:shadow-md transition-all" onclick="scrollToSection('${target}')`
        : '';
    div.innerHTML = `
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100"><p class="text-xs text-gray-500 uppercase tracking-wide">Claims</p><p class="text-2xl font-bold text-slate-700">${tc}</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100"><p class="text-xs text-gray-500 uppercase tracking-wide">Cited</p><p class="text-2xl font-bold text-green-600">${cc}</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100 ${clickable(cov < 1 ? 1 : 0, 'section-discovery-gaps')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Coverage</p><p class="text-2xl font-bold ${cov >= 1 ? 'text-green-600' : 'text-red-600'}">${(cov * 100).toFixed(0)}%</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100 ${clickable(lc, 'section-low-confidence')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Low Conf.</p><p class="text-2xl font-bold ${lc > 0 ? 'text-amber-600' : 'text-slate-700'}">${lc}</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100 ${clickable(nv, 'section-discovery-gaps')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Needs Verify</p><p class="text-2xl font-bold ${nv > 0 ? 'text-red-600' : 'text-slate-700'}">${nv}</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100 ${clickable(cf, 'section-contradictions')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Contradictions</p><p class="text-2xl font-bold ${cf > 0 ? 'text-amber-600' : 'text-slate-700'}">${cf}</p></div>
        <div class="bg-slate-50 p-3 rounded-lg text-center stat-card border border-slate-100 ${clickable(dg, 'section-discovery-gaps')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Discovery Gaps</p><p class="text-2xl font-bold ${dg > 0 ? 'text-orange-600' : 'text-slate-700'}">${dg}</p></div>
        <div class="bg-green-50 p-3 rounded-lg text-center stat-card border border-green-200 ${hasBilling ? `cursor-pointer hover:ring-2 hover:ring-offset-1 hover:ring-green-400 hover:shadow-md transition-all" onclick="scrollToSection('section-billing')` : ''}"><p class="text-xs text-gray-500 uppercase tracking-wide">Medical Bills</p><p class="text-2xl font-bold text-green-700">${formatCurrency(billingTotal)}</p></div>
        <div class="${alertBg} p-3 rounded-lg text-center stat-card border ${clickable(alertCount, 'section-alerts')}"><p class="text-xs text-gray-500 uppercase tracking-wide">Alerts</p><p class="text-2xl font-bold ${alertColor}">${alertCount}</p></div>`;
    return div;
}

function scrollToSection(sectionId) {
    const el = document.getElementById(sectionId);
    if (!el) return;
    // Switch to the correct sub-tab if the element is in a different panel
    const panel = el.closest('.sub-tab-panel');
    if (panel) {
        const tabName = panel.id.replace('subtab-', '');
        if (tabName !== activeSubTab) switchSubTab(tabName);
    }
    setTimeout(() => {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (el.tagName === 'DETAILS' && !el.open) el.open = true;
        el.classList.add('ring-2', 'ring-blue-700');
        setTimeout(() => el.classList.remove('ring-2', 'ring-blue-700'), 2000);
    }, 100);
}

function renderAlertsSection(alerts) {
    // Sort alerts by severity: high first, then medium, then low
    const severityOrder = { high: 0, medium: 1, low: 2 };
    const sorted = [...alerts].sort((a, b) =>
        (severityOrder[a.severity] ?? 3) - (severityOrder[b.severity] ?? 3)
    );

    const severityConfig = {
        high: { bg: 'bg-red-50', border: 'border-red-200', badge: 'bg-red-600 text-white', icon: 'text-red-600', accent: 'bg-red-100' },
        medium: { bg: 'bg-amber-50', border: 'border-amber-200', badge: 'bg-amber-500 text-white', icon: 'text-amber-600', accent: 'bg-amber-100' },
        low: { bg: 'bg-blue-50', border: 'border-blue-200', badge: 'bg-blue-500 text-white', icon: 'text-blue-600', accent: 'bg-blue-100' },
    };

    const typeLabels = {
        treatment_gap: 'Treatment Gap',
        missing_provider: 'Missing Provider',
        pre_existing: 'Pre-Existing Condition',
        inconsistency: 'Inconsistency',
        compliance_issue: 'Compliance Issue',
        prior_injury: 'Prior Injury',
        medication_change: 'Medication Change',
    };

    const cards = sorted.map(alert => {
        const sev = severityConfig[alert.severity] || severityConfig.medium;
        const typeLabel = typeLabels[alert.type] || alert.type || 'Alert';
        return `
            <div class="${sev.bg} ${sev.border} border rounded-lg p-4 mb-3 transition-all hover:shadow-md">
                <div class="flex items-start justify-between mb-2">
                    <div class="flex items-center space-x-2">
                        <span class="${sev.badge} text-xs font-bold px-2 py-0.5 rounded-full uppercase">${esc(alert.severity || '')}</span>
                        <span class="text-xs font-medium text-gray-500 bg-white px-2 py-0.5 rounded border">${esc(typeLabel)}</span>
                    </div>
                    ${alert.date_range ? `<span class="text-xs text-gray-500 font-mono">${esc(alert.date_range)}</span>` : ''}
                </div>
                <h5 class="text-sm font-bold text-gray-900 mb-1.5">${esc(alert.title || '')}</h5>
                <p class="text-sm text-gray-700 mb-2 leading-relaxed">${esc(alert.description || '')}</p>
                ${alert.impact_estimate ? `<p class="text-sm italic text-gray-600 mb-2"><span class="font-semibold not-italic">Impact:</span> ${esc(alert.impact_estimate)}</p>` : ''}
                ${alert.recommended_action ? `<div class="${sev.accent} rounded-lg p-2.5 mb-2"><p class="text-xs font-bold uppercase text-gray-600 mb-0.5">Recommended Action</p><p class="text-sm text-gray-800">${esc(alert.recommended_action)}</p></div>` : ''}
                ${alert.citation ? `<div class="mt-1">${renderCitation(alert.citation)}</div>` : ''}
            </div>`;
    }).join('');

    // Summary counts by severity
    const highCount = sorted.filter(a => a.severity === 'high').length;
    const medCount = sorted.filter(a => a.severity === 'medium').length;
    const lowCount = sorted.filter(a => a.severity === 'low').length;

    const summaryBar = `
        <div class="flex items-center space-x-3 mb-4 p-3 bg-gray-50 rounded-lg border">
            <svg class="w-5 h-5 text-orange-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
            <span class="text-sm text-gray-700 font-medium">Proactive Intelligence:</span>
            ${highCount > 0 ? `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800">${highCount} High</span>` : ''}
            ${medCount > 0 ? `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">${medCount} Medium</span>` : ''}
            ${lowCount > 0 ? `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">${lowCount} Low</span>` : ''}
        </div>`;

    return summaryBar + cards;
}

function createCollapsibleSection(title, html, openByDefault = true) {
    const details = document.createElement('details');
    details.className = 'border rounded-lg overflow-hidden';
    if (openByDefault) details.open = true;
    details.innerHTML = `
        <summary class="section-toggle px-4 py-3 flex items-center justify-between">
            <h4 class="text-sm font-bold text-gray-700">${esc(title)}</h4>
            <svg class="w-4 h-4 text-gray-400 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </summary>
        <div class="px-4 pb-3">${html}</div>`;
    return details;
}

function renderClaimItem(text, claim) {
    return `
        <div class="flex items-start justify-between py-2 border-b border-gray-50 last:border-0">
            <span class="text-sm text-gray-700 flex-1">${esc(text)}</span>
            <div class="flex items-center space-x-2 ml-3 shrink-0">
                ${renderConfidence(claim.confidence)}
                ${renderCitation(claim.citation)}
            </div>
        </div>`;
}

function formatCurrency(amount) {
    const num = Number(amount) || 0;
    return '$' + num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function renderBillingSection(billingData) {
    if (!billingData) return null;
    const providers = billingData.providers || [];
    const totalPast = Number(billingData.total_past_medical) || 0;
    const totalFuture = Number(billingData.total_future_medical_estimate) || 0;
    const totalCombined = Number(billingData.total_combined) || 0;
    const futureBasis = billingData.future_care_basis || '';
    const notes = billingData.notes || '';

    if (providers.length === 0 && totalCombined === 0) return null;

    let tableRows = '';
    for (const prov of providers) {
        const provName = prov.provider_name || 'Unknown Provider';
        const services = prov.services || [];
        const subtotal = Number(prov.subtotal) || 0;

        if (services.length === 0) {
            tableRows += `<tr class="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                <td class="py-2 px-3 text-sm font-medium text-gray-800">${esc(provName)}</td>
                <td class="py-2 px-3 text-sm text-gray-600">-</td>
                <td class="py-2 px-3 text-sm text-gray-600">-</td>
                <td class="py-2 px-3 text-sm text-right font-medium text-gray-800">${formatCurrency(subtotal)}</td>
            </tr>`;
        } else {
            for (let i = 0; i < services.length; i++) {
                const svc = services[i];
                const svcDate = svc.date || '-';
                const svcDesc = svc.description || '';
                const cptCode = svc.cpt_code ? ` (CPT: ${esc(svc.cpt_code)})` : '';
                const svcAmount = Number(svc.amount) || 0;
                const citation = svc.citation || '';
                tableRows += `<tr class="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td class="py-2 px-3 text-sm ${i === 0 ? 'font-medium text-gray-800' : 'text-gray-400'}">${i === 0 ? esc(provName) : ''}</td>
                    <td class="py-2 px-3 text-sm text-gray-600">${esc(svcDate)}</td>
                    <td class="py-2 px-3 text-sm text-gray-700">${esc(svcDesc)}${cptCode} ${citation ? renderCitation(citation) : ''}</td>
                    <td class="py-2 px-3 text-sm text-right font-mono text-gray-800">${formatCurrency(svcAmount)}</td>
                </tr>`;
            }
        }
        // Subtotal row per provider
        if (services.length > 1) {
            tableRows += `<tr class="border-b-2 border-gray-200 bg-gray-50">
                <td colspan="3" class="py-1.5 px-3 text-xs font-semibold text-gray-500 text-right uppercase">Subtotal - ${esc(provName)}</td>
                <td class="py-1.5 px-3 text-sm text-right font-bold text-gray-700">${formatCurrency(subtotal)}</td>
            </tr>`;
        }
    }

    // Grand total rows
    let totalsHtml = '';
    if (totalPast > 0) {
        totalsHtml += `<tr class="bg-slate-50">
            <td colspan="3" class="py-2 px-3 text-sm font-semibold text-gray-700 text-right">Total Past Medical</td>
            <td class="py-2 px-3 text-sm text-right font-bold text-gray-800">${formatCurrency(totalPast)}</td>
        </tr>`;
    }
    if (totalFuture > 0) {
        totalsHtml += `<tr class="bg-amber-50">
            <td colspan="3" class="py-2 px-3 text-sm font-semibold text-amber-800 text-right">Future Medical Estimate</td>
            <td class="py-2 px-3 text-sm text-right font-bold text-amber-900">${formatCurrency(totalFuture)}</td>
        </tr>`;
        if (futureBasis) {
            totalsHtml += `<tr class="bg-amber-50">
                <td colspan="4" class="py-1 px-3 text-xs text-amber-700 text-right italic">${esc(futureBasis)}</td>
            </tr>`;
        }
    }
    if (totalCombined > 0) {
        totalsHtml += `<tr class="bg-green-50 border-t-2 border-green-300">
            <td colspan="3" class="py-2.5 px-3 text-sm font-bold text-green-800 text-right uppercase">Total Combined</td>
            <td class="py-2.5 px-3 text-right font-bold text-lg text-green-900">${formatCurrency(totalCombined)}</td>
        </tr>`;
    }

    const notesHtml = notes ? `<p class="text-xs text-gray-500 mt-2 italic">${esc(notes)}</p>` : '';

    const html = `
        <div class="bg-green-50 rounded-lg p-4 border border-green-200">
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center space-x-2">
                    <svg class="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span class="text-sm font-bold text-green-800">Billing Details</span>
                </div>
                <button onclick="downloadBillingCSV()" class="inline-flex items-center px-3 py-1.5 text-xs font-medium text-green-700 bg-white border border-green-300 rounded-lg hover:bg-green-100 transition-colors no-print">
                    <svg class="w-3.5 h-3.5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Download Billing Summary
                </button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead><tr class="border-b-2 border-green-300 text-xs text-green-800 uppercase tracking-wide">
                        <th class="text-left py-2 px-3">Provider</th>
                        <th class="text-left py-2 px-3">Date</th>
                        <th class="text-left py-2 px-3">Service / Description</th>
                        <th class="text-right py-2 px-3">Amount</th>
                    </tr></thead>
                    <tbody>${tableRows}${totalsHtml}</tbody>
                </table>
            </div>
            ${notesHtml}
        </div>`;

    return html;
}

function downloadBillingCSV() {
    if (!currentSummaryData) return;
    const billing = currentSummaryData.summary?.billing_data;
    if (!billing) { showToast('No billing data available', 'warning'); return; }

    const rows = [['Provider', 'Date', 'Service/Description', 'CPT Code', 'Amount', 'Citation']];
    for (const prov of (billing.providers || [])) {
        const provName = prov.provider_name || 'Unknown';
        const services = prov.services || [];
        if (services.length === 0) {
            rows.push([provName, '', '', '', prov.subtotal || 0, '']);
        } else {
            for (const svc of services) {
                rows.push([provName, svc.date || '', svc.description || '', svc.cpt_code || '', svc.amount || 0, svc.citation || '']);
            }
        }
        rows.push([`Subtotal - ${provName}`, '', '', '', prov.subtotal || 0, '']);
    }
    rows.push([]);
    rows.push(['Total Past Medical', '', '', '', billing.total_past_medical || 0, '']);
    if (billing.total_future_medical_estimate) {
        rows.push(['Future Medical Estimate', '', '', '', billing.total_future_medical_estimate, billing.future_care_basis || '']);
    }
    rows.push(['TOTAL COMBINED', '', '', '', billing.total_combined || 0, '']);
    if (billing.notes) rows.push(['Notes', billing.notes, '', '', '', '']);

    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    downloadBlob(new Blob([csv], { type: 'text/csv' }), `billing_summary_${currentSummaryData.run_id || 'export'}.csv`);
    showToast('Billing CSV exported', 'success');
}

function renderConfidence(conf) {
    if (conf === undefined || conf === null) return '';
    const pct = (Number(conf) * 100).toFixed(0);
    const cls = conf >= 0.8 ? 'bg-green-100 text-green-700' : conf >= 0.6 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700';
    return `<span class="${cls} text-xs font-mono px-1.5 py-0.5 rounded">${pct}%</span>`;
}

function renderCitation(cit) {
    if (!cit) return '';
    const escaped = esc(cit);
    const runId = currentSummaryData ? esc(currentSummaryData.run_id || '') : '';
    return `<span class="text-xs text-blue-700 font-mono bg-blue-50 px-1.5 py-0.5 rounded cursor-pointer hover:bg-blue-200 hover:text-blue-700 transition-colors underline decoration-dotted" title="Click to view source: ${escaped}" onclick="openSourcePage('${runId}', '${escaped.replace(/'/g, "\\'")}')">${escaped}</span>`;
}

// ── PDF Source Viewer ──────────────────────────────────────────────────────

function extractPageFromCitation(citation) {
    if (!citation) return null;
    // Match patterns like "sec_001:p3", "p3", "Page 3", "page 3", ":p12", "pg 5", "pg5"
    let match = citation.match(/:p(\d+)/i);
    if (match) return parseInt(match[1], 10);
    match = citation.match(/\bpage\s*(\d+)/i);
    if (match) return parseInt(match[1], 10);
    match = citation.match(/\bpg\s*(\d+)/i);
    if (match) return parseInt(match[1], 10);
    match = citation.match(/\bp(\d+)\b/i);
    if (match) return parseInt(match[1], 10);
    return null;
}

async function openSourcePage(runId, citation) {
    if (!runId || !currentSummaryData) {
        showToast('No summary data available', 'info');
        return;
    }

    const pageNum = extractPageFromCitation(citation);

    // Find the source document ID from the database via the run_id
    try {
        const res = await authFetch(`${API}/api/files?run_id=${encodeURIComponent(runId)}&limit=10`);
        if (!res.ok) {
            showToast('Could not find source document', 'error');
            return;
        }
        const data = await res.json();
        const files = data.files || data;

        // Find the original source doc (not the summary JSON)
        const sourceDoc = Array.isArray(files)
            ? files.find(f => f.category !== 'summary' && f.extension !== '.json')
            : null;

        if (!sourceDoc) {
            showToast('Source document not found in database', 'info');
            return;
        }

        const ext = (sourceDoc.extension || '').toLowerCase();
        const isPdf = ext === '.pdf';
        const modal = $('pdf-viewer-modal');
        const frame = $('pdf-viewer-frame');
        const fallback = $('pdf-viewer-fallback');
        const title = $('pdf-viewer-title');

        title.textContent = `Source: ${sourceDoc.filename || 'Document'}${pageNum ? ` - Page ${pageNum}` : ''}${citation ? ` (${citation})` : ''}`;

        if (isPdf) {
            const pageFragment = pageNum ? `#page=${pageNum}` : '';
            frame.src = `${API}/api/files/${sourceDoc.id}/view${pageFragment}`;
            frame.classList.remove('hidden');
            fallback.classList.add('hidden');
        } else if (['.html', '.htm', '.txt', '.png', '.jpg', '.jpeg'].includes(ext)) {
            frame.src = `${API}/api/files/${sourceDoc.id}/view`;
            frame.classList.remove('hidden');
            fallback.classList.add('hidden');
        } else {
            frame.classList.add('hidden');
            fallback.classList.remove('hidden');
            fallback.classList.add('flex');
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');

        // Close on backdrop click
        modal.onclick = function(e) {
            if (e.target === modal) closePdfViewer();
        };

        // Close on Escape key
        document.addEventListener('keydown', _pdfViewerEscHandler);

    } catch (err) {
        showToast(`Error opening source: ${err.message}`, 'error');
    }
}

function _pdfViewerEscHandler(e) {
    if (e.key === 'Escape') closePdfViewer();
}

function closePdfViewer() {
    const modal = $('pdf-viewer-modal');
    const frame = $('pdf-viewer-frame');
    const fallback = $('pdf-viewer-fallback');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    frame.src = '';
    frame.classList.remove('hidden');
    fallback.classList.add('hidden');
    fallback.classList.remove('flex');
    document.removeEventListener('keydown', _pdfViewerEscHandler);
}

const SECTION_MAP = {
    'chief complaint': 'section-chief-complaint',
    'active diagnoses': 'section-diagnoses',
    'diagnoses': 'section-diagnoses',
    'medications': 'section-medications',
    'key findings': 'section-findings',
    'findings': 'section-findings',
    'master chronology': 'section-chronology',
    'chronology': 'section-chronology',
    'timeline': 'section-chronology',
    'smoking gun quotes': 'section-smoking-gun',
    'smoking gun': 'section-smoking-gun',
    'contradictions': 'section-contradictions',
    'discovery deficiencies': 'section-discovery-gaps',
    'discovery gaps': 'section-discovery-gaps',
    'missing records': 'section-discovery-gaps',
    'cheat sheet': 'section-cheat-sheet',
    'litigation cheat sheet': 'section-cheat-sheet',
    'pi core': 'section-pi-core',
    'treatment gaps': 'section-pi-core',
    'pre-existing': 'section-pi-core',
    'tbi': 'section-tbi',
    'spinal': 'section-spinal',
    'soft tissue': 'section-soft-tissue',
    'pain management': 'section-pain-mgmt',
    'low confidence': 'section-low-confidence',
    'billing': 'section-billing',
    'medical bills': 'section-billing',
    'bills': 'section-billing',
    'alerts': 'section-alerts',
    'case alerts': 'section-alerts',
    'risk factors': 'section-alerts',
};

function renderTextWithCitations(text) {
    if (!text) return '';
    return esc(text).replace(
        /\[see:\s*([^\]]+)\]/gi,
        (match, name) => {
            const sectionId = SECTION_MAP[name.trim().toLowerCase()];
            if (!sectionId) return match;
            return `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700 cursor-pointer hover:bg-blue-200 transition-colors" onclick="scrollToSection('${sectionId}')">${esc(name.trim())} ↓</span>`;
        }
    );
}

// ── Export Functions ─────────────────────────────────────────────────────────

$('btn-export-json').addEventListener('click', () => {
    if (!currentSummaryData) return;
    const blob = new Blob([JSON.stringify(currentSummaryData, null, 2)], { type: 'application/json' });
    downloadBlob(blob, `summary_${currentSummaryData.run_id || 'export'}.json`);
    showToast('JSON exported', 'success');
});

$('btn-export-csv').addEventListener('click', () => {
    if (!currentSummaryData) return;
    const summary = currentSummaryData.summary?.summary || {};
    const rows = [['Category', 'Item', 'Confidence', 'Citation']];
    if (summary.chief_complaint) rows.push(['Chief Complaint', summary.chief_complaint.text || '', summary.chief_complaint.confidence || '', summary.chief_complaint.citation || '']);
    (summary.active_diagnoses || []).forEach(d => rows.push(['Diagnosis', d.diagnosis || '', d.confidence || '', d.citation || '']));
    (summary.medications || []).forEach(m => rows.push(['Medication', `${m.name || ''} ${m.dosage || ''}`, m.confidence || '', m.citation || '']));
    (summary.key_findings || []).forEach(f => rows.push(['Finding', f.finding || '', f.confidence || '', f.citation || '']));
    (summary.chronological_events || []).forEach(e => rows.push(['Event', `${e.date || ''}: ${e.event || ''}`, e.confidence || '', e.citation || '']));
    // BLUF fields
    const blufExport = currentSummaryData.summary?.bluf;
    if (blufExport) {
        rows.push(['BLUF - Diagnosis', blufExport.primary_diagnosis || '', '', '']);
        rows.push(['BLUF - Proof', blufExport.objective_proof || '', '', '']);
        rows.push(['BLUF - Outlook', blufExport.future_outlook || '', '', '']);
    }
    // Litigation Cheat Sheet
    const csExport = currentSummaryData.summary?.litigation_cheat_sheet;
    if (csExport) {
        (csExport.wins || []).forEach(w => rows.push(['Win', w.leverage || '', '', w.source_ref || '']));
        (csExport.risks || []).forEach(r => rows.push(['Risk', r.target || '', '', r.source_ref || '']));
    }
    // Alerts
    const alertsExport = currentSummaryData.summary?.alerts || [];
    alertsExport.forEach(a => rows.push([`Alert (${a.severity || ''})`, `${a.title || ''}: ${a.description || ''}`, a.type || '', a.citation || '']));
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    downloadBlob(new Blob([csv], { type: 'text/csv' }), `summary_${currentSummaryData.run_id || 'export'}.csv`);
    showToast('CSV exported', 'success');
});

$('btn-print').addEventListener('click', () => window.print());

function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
}

// ── Logging ─────────────────────────────────────────────────────────────────

function logMessage(msg, type = 'info') {
    const p = document.createElement('p');
    const ts = new Date().toLocaleTimeString();
    const colors = { error: 'text-red-400', success: 'text-green-400', info: 'text-slate-300', system: 'text-blue-300' };
    p.className = `py-0.5 ${colors[type] || colors.info}`;
    // Safe: timestamp is generated, msg comes from our code (not user input in log context)
    p.innerHTML = `<span class="text-slate-500">[${ts}]</span> ${msg}`;
    liveLog.appendChild(p);
    liveLog.scrollTop = liveLog.scrollHeight;
}

function resetPipelineStages() {
    ['ingestion', 'privacy', 'summarizer', 'auditor'].forEach((name, i) => {
        const el = $(`ps-${name}`);
        const icon = el?.querySelector('.stage-icon');
        if (icon) { icon.className = 'stage-icon pending'; icon.textContent = i + 1; }
        el?.classList.remove('active');
        const conn = $(`connector-${i + 1}`);
        if (conn) conn.className = 'flex-1 h-0.5 bg-gray-200 mx-1';
    });
    const etaEl = $('pipeline-eta');
    if (etaEl) etaEl.classList.add('hidden');
    // Reset thorough progress
    const thoroughEl = $('thorough-progress');
    if (thoroughEl) thoroughEl.classList.add('hidden');
    const prepStats = $('preprocess-stats');
    if (prepStats) prepStats.classList.add('hidden');
    const chunkProg = $('chunk-progress');
    if (chunkProg) chunkProg.classList.add('hidden');
}

function resetButtons() {
    btnSummarize.disabled = selectedFiles.length === 0;
    btnText.textContent = 'Upload & Summarize';
    btnSpinner.classList.add('hidden');
    $('file-queue-progress')?.classList.add('hidden');
    // Re-show mode toggle if multiple files still selected
    const toggle = $('processing-mode-toggle');
    if (toggle) {
        if (selectedFiles.length > 1) toggle.classList.remove('hidden');
        else toggle.classList.add('hidden');
    }
}

// ── Pipeline Activity (all runs) ────────────────────────────────────────────

let pipelineListPoll = null;
let pipelineTabActive = false;

async function loadPipelineRuns() {
    try {
        const res = await authFetch(`${API}/api/pipeline`);
        if (!res.ok) return;
        const data = await res.json();
        const runs = data.runs || [];
        renderPipelineRuns(runs);

        // Fast-poll (4s) while any run is still "running"
        const hasRunning = runs.some(r => r.status === 'running');
        if (hasRunning && !pipelineListPoll) {
            pipelineListPoll = setInterval(loadPipelineRuns, 4000);
        } else if (!hasRunning && pipelineListPoll) {
            clearInterval(pipelineListPoll);
            pipelineListPoll = null;
        }
    } catch { /* ignore */ }
}

// Background poll — refresh pipeline list every 15s when pipeline tab is visible
setInterval(() => {
    if (pipelineTabActive && !pipelineListPoll) loadPipelineRuns();
}, 15000);

function renderPipelineRuns(runs) {
    const container = $('pipeline-runs-list');
    if (!runs.length) {
        container.innerHTML = '<p class="text-sm text-gray-500">No pipeline runs yet. Upload a document to start processing.</p>';
        $('pipeline-run-count').textContent = '';
        return;
    }
    $('pipeline-run-count').textContent = `(${runs.length} total)`;

    const stageIcons = { completed: '\u2705', running: '\u23f3', failed: '\u274c' };
    const statusColors = { running: 'bg-blue-100 text-blue-700', completed: 'bg-green-100 text-green-700', failed: 'bg-red-100 text-red-700' };

    container.innerHTML = runs.slice(0, 15).map(r => {
        const stagesHtml = ['ingestion','privacy','summarizer','auditor'].map(s => {
            const st = r.stages?.[s];
            const stStatus = st?.status || st;  // handle both object and legacy string format
            return stStatus ? `<span title="${esc(s)}: ${esc(stStatus)}">${stageIcons[stStatus] || '\u2B1C'}</span>` : '<span title="pending">\u2B1C</span>';
        }).join(' ');
        const time = r.started_at ? new Date(r.started_at).toLocaleString() : '';
        const badge = statusColors[r.status] || 'bg-gray-100 text-gray-600';
        const displayLabel = r.case_ref ? esc(r.case_ref) : (r.source_file ? esc(r.source_file) : esc(r.run_id));
        const runLabel = esc(r.run_id);
        const clickAction = r.status === 'completed' ? `viewSummary('${esc(r.run_id)}')` : (r.status === 'failed' ? '' : `watchPipeline('${esc(r.run_id)}')`);
        // Mode badge
        const modeBadge = r.mode === 'thorough' ? '<span class="px-1 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-700">THOROUGH</span>' : '';
        // Error tooltip for failed pipelines
        const errorTitle = r.status === 'failed' && r.error ? ` title="${esc(r.error)}"` : '';
        // Chunk progress for thorough running pipelines
        let chunkHtml = '';
        if (r.mode === 'thorough' && r.status === 'running' && r.chunks?.details) {
            const cd = r.chunks.details;
            chunkHtml = `<span class="text-purple-500 font-medium whitespace-nowrap">Chunk ${cd.completed||0}/${cd.total||0}</span>`;
        }
        // ETA for running pipelines
        let etaHtml = '';
        if (r.status === 'running') {
            const eta = estimatePipelineETA(r);
            if (eta !== null) etaHtml = `<span class="text-blue-700 font-medium whitespace-nowrap">${formatETA(eta)}</span>`;
        }
        // Duration for completed pipelines
        let durationHtml = '';
        if (r.status === 'completed' && r.started_at && r.completed_at) {
            const dur = Math.round((new Date(r.completed_at) - new Date(r.started_at)) / 1000);
            durationHtml = `<span class="text-gray-400 whitespace-nowrap">${dur < 60 ? dur + 's' : Math.floor(dur/60) + 'm ' + (dur%60) + 's'}</span>`;
        }
        return `<div class="flex items-center justify-between py-1.5 px-2 hover:bg-slate-50 rounded ${clickAction ? 'cursor-pointer' : ''} text-xs border-b border-gray-50"${clickAction ? ` onclick="${clickAction}"` : ''}${errorTitle}>
            <div class="flex items-center space-x-2 flex-1 min-w-0">
                <span class="truncate font-mono text-gray-600" title="${runLabel}">${displayLabel.length > 35 ? displayLabel.slice(0, 35) + '...' : displayLabel}</span>
                ${modeBadge}
                <span class="whitespace-nowrap">${stagesHtml}</span>
            </div>
            <div class="flex items-center space-x-2 ml-2">
                ${chunkHtml}${etaHtml}${durationHtml}
                <span class="text-gray-400 whitespace-nowrap">${time}</span>
                <span class="px-1.5 py-0.5 rounded text-[10px] font-bold ${badge}">${esc(r.status)}</span>
            </div>
        </div>`;
    }).join('');
}

function watchPipeline(runId) {
    switchTab('results');
    currentRunId = runId;
    resultsPlaceholder.classList.add('hidden');
    summaryView.classList.add('hidden');
    processingView.classList.remove('hidden');
    processingHeader.textContent = `Processing: ${runId}`;
    liveLog.innerHTML = '';
    resetPipelineStages();
    $('code-display').innerHTML = getPipelineCodeHTML();
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = setInterval(() => pollPipelineStatus(runId), 3000);
    // Immediate first poll
    pollPipelineStatus(runId);
}
window.watchPipeline = watchPipeline;

// ── Tabs ────────────────────────────────────────────────────────────────────

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ── Past Summaries (paginated API) ──────────────────────────────────────────

async function loadSummariesList() {
    const container = $('summaries-list');
    try {
        const res = await authFetch(`${API}/api/summaries`);
        const data = await res.json();
        allSummaries = data.summaries || data;  // Support both paginated and flat
        renderSummariesList(allSummaries);
    } catch (err) {
        container.innerHTML = '';
        const p = document.createElement('p');
        p.className = 'text-sm text-red-500';
        p.textContent = `Error: ${err.message}`;
        container.appendChild(p);
    }
}

function renderSummariesList(summaries) {
    const container = $('summaries-list');
    const clearBtn = $('btn-clear-summaries');
    if (!summaries.length) {
        container.innerHTML = '<p class="text-sm text-gray-500">No summaries yet. Upload a document to get started.</p>';
        if (clearBtn) clearBtn.classList.add('hidden');
        return;
    }
    if (clearBtn) clearBtn.classList.remove('hidden');
    container.innerHTML = summaries.map(s => {
        const safeName = esc(s.source_file || s.run_id);
        const safeRunId = esc(s.run_id);
        const safeStatus = esc(s.compliance_status || '?');
        return `
        <div class="border rounded-lg p-4 hover:bg-slate-50 transition-colors slide-up group" id="summary-row-${safeRunId}">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3 cursor-pointer flex-1" onclick="viewSummary('${safeRunId}')">
                    <svg class="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <div>
                        <p class="font-medium text-sm">${safeName}</p>
                        <p class="text-xs text-gray-400">${s.processed_at ? new Date(s.processed_at).toLocaleString() : ''}</p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="px-2.5 py-1 rounded-full text-xs font-bold ${
                        s.compliance_status === 'PASS' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }">${safeStatus}</span>
                    <button onclick="event.stopPropagation(); deleteSummary('${safeRunId}', '${safeName}')" class="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-all" title="Delete summary">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                </div>
            </div>
        </div>`;
    }).join('');
}

async function deleteSummary(runId, name) {
    if (!confirm(`Delete summary "${name}"?\n\nThis cannot be undone.`)) return;
    try {
        const res = await authFetch(`${API}/api/summaries/${runId}`, { method: 'DELETE', headers: authHeaders() });
        if (!res.ok) throw new Error('Delete failed');
        const row = $(`summary-row-${runId}`);
        if (row) {
            row.style.transition = 'opacity 0.3s, transform 0.3s';
            row.style.opacity = '0';
            row.style.transform = 'translateX(20px)';
            setTimeout(() => row.remove(), 300);
        }
        allSummaries = allSummaries.filter(s => s.run_id !== runId);
        if (!allSummaries.length) {
            setTimeout(() => renderSummariesList([]), 350);
        }
    } catch (err) {
        alert('Failed to delete summary: ' + err.message);
    }
}

async function clearAllSummaries() {
    if (!confirm(`Delete ALL ${allSummaries.length} summaries?\n\nThis cannot be undone.`)) return;
    let failed = 0;
    for (const s of [...allSummaries]) {
        try {
            const res = await authFetch(`${API}/api/summaries/${s.run_id}`, { method: 'DELETE', headers: authHeaders() });
            if (!res.ok) failed++;
        } catch { failed++; }
    }
    if (failed) alert(`${failed} summary(ies) failed to delete.`);
    allSummaries = [];
    renderSummariesList([]);
}

$('summaries-search')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    const filtered = allSummaries.filter(s =>
        (s.source_file || '').toLowerCase().includes(q) || (s.run_id || '').toLowerCase().includes(q)
    );
    renderSummariesList(filtered);
});

async function viewSummary(runId) {
    document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('tab-active'); b.classList.add('text-gray-500'); });
    document.querySelector('[data-tab="results"]').classList.add('tab-active');
    document.querySelector('[data-tab="results"]').classList.remove('text-gray-500');
    document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
    $('tab-results').classList.remove('hidden');
    resultsPlaceholder.classList.add('hidden');
    processingView.classList.add('hidden');
    summaryView.classList.remove('hidden');
    exportButtons.classList.remove('hidden');
    try {
        const res = await authFetch(`${API}/api/summaries/${runId}`);
        const data = await res.json();
        currentSummaryData = data;
        renderSummary(data);
    } catch (err) {
        $('summary-content').innerHTML = '<p class="text-red-500">Error loading summary</p>';
    }
}

// ── Audit Trail (paginated API) ─────────────────────────────────────────────

async function loadAuditTrail() {
    const container = $('audit-list');
    try {
        const res = await authFetch(`${API}/api/audit`);
        const data = await res.json();
        allAuditEntries = data.entries || data;
        renderAuditList(allAuditEntries);
    } catch (err) {
        container.innerHTML = '';
        const p = document.createElement('p');
        p.className = 'text-sm text-red-500';
        p.textContent = `Error: ${err.message}`;
        container.appendChild(p);
    }
}

function renderAuditList(entries) {
    const container = $('audit-list');
    $('audit-count').textContent = `${entries.length} entries`;
    if (!entries.length) { container.innerHTML = '<p class="text-sm text-gray-500">No audit entries yet.</p>'; return; }

    const actionColors = {
        file_uploaded_manual: 'bg-blue-100 text-blue-700',
        file_uploaded_secure: 'bg-blue-100 text-blue-700',
        contact_added_ui: 'bg-green-100 text-green-700',
        contacts_batch_import: 'bg-purple-100 text-purple-700',
        summary_viewed: 'bg-slate-100 text-slate-700',
        audit_accessed: 'bg-gray-100 text-gray-600',
        upload_token_invalid: 'bg-red-100 text-red-700',
    };

    container.innerHTML = entries.slice(0, 100).map(e => `
        <div class="flex items-start space-x-3 py-2 border-b border-gray-50 last:border-0 hover:bg-slate-50 rounded px-1 transition-colors">
            <span class="text-gray-400 whitespace-nowrap text-xs">${e.timestamp ? new Date(e.timestamp).toLocaleString() : ''}</span>
            <span class="px-2 py-0.5 rounded text-xs whitespace-nowrap ${actionColors[e.action] || 'bg-slate-100 text-slate-700'}">${esc(e.action || '')}</span>
            <span class="text-gray-600 text-xs">${esc(e.details || '')}</span>
            ${e.user ? `<span class="text-gray-400 text-xs ml-auto">${esc(e.user)}</span>` : ''}
        </div>`).join('');
}

$('audit-search')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    const filtered = allAuditEntries.filter(entry =>
        (entry.action || '').toLowerCase().includes(q) || (entry.details || '').toLowerCase().includes(q)
    );
    renderAuditList(filtered);
});

// ── Contact Detail Modal (XSS-safe) ────────────────────────────────────────

async function showContactDetail(contactId) {
    try {
        const res = await authFetch(`${API}/api/contacts/${contactId}`);
        if (!res.ok) return;
        const contact = await res.json();

        const statusColors = {
            new: 'bg-blue-100 text-blue-800', contacted: 'bg-yellow-100 text-yellow-800',
            awaiting: 'bg-orange-100 text-orange-800', received: 'bg-green-100 text-green-800',
            failed: 'bg-red-100 text-red-800',
        };

        const modal = $('contact-modal');
        modal.className = 'modal-backdrop';
        modal.innerHTML = `
            <div class="modal-content p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-bold">${esc(contact.contact_name)}</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </div>
                <div class="grid grid-cols-2 gap-3 text-sm mb-4">
                    <div><span class="text-gray-500">Email:</span> ${esc(contact.contact_email)}</div>
                    <div><span class="text-gray-500">Type:</span> ${esc(contact.contact_type)}</div>
                    <div><span class="text-gray-500">Organization:</span> ${esc(contact.organization || '-')}</div>
                    <div><span class="text-gray-500">Case Ref:</span> ${esc(contact.patient_case_ref || '-')}</div>
                    <div><span class="text-gray-500">Status:</span> <span class="px-2 py-0.5 rounded text-xs font-bold ${statusColors[contact.status] || 'bg-gray-100'}">${esc(contact.status)}</span></div>
                    <div><span class="text-gray-500">Priority:</span> ${esc(contact.priority || 'normal')}</div>
                    <div><span class="text-gray-500">Record Type:</span> ${esc(contact.record_type_needed || '-')}</div>
                    <div><span class="text-gray-500">Follow-ups:</span> ${Number(contact.follow_up_count) || 0}</div>
                </div>
                ${contact.upload_token ? `<div class="mb-4 p-3 bg-slate-50 rounded-lg"><span class="text-xs text-gray-500">Upload Link:</span><br><span class="text-xs font-mono text-blue-800 break-all">${esc(location.origin)}/api/secure-upload/${esc(contact.upload_token)}</span></div>` : ''}
                ${contact.emails?.length ? `
                    <h4 class="font-bold text-sm mb-2">Email History</h4>
                    <div class="space-y-2 max-h-48 overflow-y-auto">
                        ${contact.emails.map(e => `
                            <div class="text-xs p-2 rounded ${e.direction === 'outbound' ? 'bg-blue-50' : 'bg-green-50'}">
                                <div class="flex justify-between"><span class="font-medium">${esc(e.direction)}</span><span class="text-gray-400">${e.timestamp ? new Date(e.timestamp).toLocaleString() : ''}</span></div>
                                <div class="text-gray-600 mt-1">${esc(e.subject || '-')}</div>
                            </div>`).join('')}
                    </div>` : '<p class="text-xs text-gray-400">No emails sent yet.</p>'}
            </div>`;
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    } catch (err) {
        showToast('Could not load contact details', 'error');
    }
}

function closeModal() {
    $('contact-modal').className = 'hidden';
    $('contact-modal').innerHTML = '';
}

// ── Dashboard (paginated contacts API) ──────────────────────────────────────

async function refreshDashboard() {
    try {
        const res = await authFetch(`${API}/api/status`);
        if (res.status === 401) return;
        const data = await res.json();
        $('stat-summaries').textContent = data.summaries_completed || 0;
        $('stat-incoming').textContent = data.files_incoming || 0;
        $('stat-contacts').textContent = data.contacts?.total || 0;
        $('stat-received').textContent = data.contacts?.received || 0;
    } catch { /* silently fail */ }

    try {
        const res = await authFetch(`${API}/api/contacts?per_page=25`);
        if (!res.ok) return;
        const data = await res.json();
        const contacts = data.contacts || data;
        const container = $('contacts-list');

        if (!contacts.length) {
            container.innerHTML = '<p class="text-sm text-gray-500">No contacts yet. Click "+ Add" or import from Excel.</p>';
            return;
        }

        const statusColors = {
            new: 'bg-blue-100 text-blue-800', contacted: 'bg-yellow-100 text-yellow-800',
            awaiting: 'bg-orange-100 text-orange-800', received: 'bg-green-100 text-green-800',
            failed: 'bg-red-100 text-red-800',
        };

        container.innerHTML = contacts.map(c => `
            <div class="contact-row flex items-center justify-between py-2 px-2 border-b border-gray-50 rounded" onclick="showContactDetail(${Number(c.id)})">
                <div class="min-w-0 flex-1">
                    <p class="text-sm font-medium truncate">${esc(c.contact_name)}</p>
                    <p class="text-xs text-gray-400 truncate">${esc(c.organization || '')} ${c.patient_case_ref ? '| ' + esc(c.patient_case_ref) : ''}</p>
                </div>
                <span class="px-2 py-0.5 rounded-full text-xs font-medium ml-2 ${statusColors[c.status] || 'bg-gray-100'}">${esc(c.status)}</span>
            </div>`).join('');
    } catch { /* silently fail */ }
}

// ── Add Contact Form ────────────────────────────────────────────────────────

const addContactPanel = $('add-contact-panel');
const addContactForm = $('add-contact-form');
const btnToggleAdd = $('btn-toggle-add-contact');
const btnCancelAdd = $('btn-cancel-add');

btnToggleAdd?.addEventListener('click', () => {
    addContactPanel.classList.toggle('hidden');
    // Also hide batch panel if open
    $('batch-upload-panel')?.classList.add('hidden');
    if (!addContactPanel.classList.contains('hidden')) {
        addContactForm.querySelector('[name="contact_name"]').focus();
    }
});

btnCancelAdd?.addEventListener('click', () => {
    addContactPanel.classList.add('hidden');
    addContactForm.reset();
});

addContactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btnAdd = $('btn-add-contact');
    const btnAddText = $('btn-add-text');
    const btnAddSpinner = $('btn-add-spinner');

    btnAdd.disabled = true;
    btnAddText.textContent = 'Adding...';
    btnAddSpinner.classList.remove('hidden');

    const formData = new FormData(addContactForm);
    const payload = {};
    formData.forEach((value, key) => { payload[key] = value; });

    try {
        const res = await authFetch(`${API}/api/contacts`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify(payload),
        });
        const data = await res.json();

        if (res.ok) {
            showToast(`Contact "${esc(data.contact_name)}" added. Retrieval bot will email them on next cycle.`, 'success', 6000);
            addContactForm.reset();
            addContactPanel.classList.add('hidden');
            refreshDashboard();
            if (data.upload_link) {
                setTimeout(() => showToast(`Secure upload link generated`, 'info', 5000), 1000);
            }
        } else {
            const errMsg = data.details ? data.details.join(', ') : (data.error || 'Failed to add contact');
            showToast(errMsg, 'error', 6000);
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    } finally {
        btnAdd.disabled = false;
        btnAddText.textContent = 'Add Contact';
        btnAddSpinner.classList.add('hidden');
    }
});

// ── Batch Contact Import ────────────────────────────────────────────────────

const batchPanel = $('batch-upload-panel');
const batchDropZone = $('batch-drop-zone');
const batchFileInput = $('batch-file-input');
const btnToggleBatch = $('btn-toggle-batch');

btnToggleBatch?.addEventListener('click', () => {
    batchPanel?.classList.toggle('hidden');
    addContactPanel?.classList.add('hidden');
});

batchDropZone?.addEventListener('click', () => batchFileInput?.click());
batchDropZone?.addEventListener('dragover', (e) => { e.preventDefault(); batchDropZone.classList.add('drag-over'); });
batchDropZone?.addEventListener('dragleave', () => batchDropZone?.classList.remove('drag-over'));
batchDropZone?.addEventListener('drop', (e) => {
    e.preventDefault();
    batchDropZone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) handleBatchFile(e.dataTransfer.files[0]);
});
batchFileInput?.addEventListener('change', (e) => { if (e.target.files.length) handleBatchFile(e.target.files[0]); });

async function handleBatchFile(file) {
    if (!file.name.match(/\.xlsx?$/i)) {
        showToast('Only Excel files (.xlsx) are accepted', 'error');
        return;
    }

    const btnBatch = $('btn-batch-upload');
    const batchStatus = $('batch-status');
    if (btnBatch) { btnBatch.disabled = true; btnBatch.textContent = 'Importing...'; }
    if (batchStatus) batchStatus.innerHTML = '<p class="text-sm text-gray-500">Uploading and processing...</p>';

    try {
        const formData = new FormData();
        formData.append('file', file);
        const res = await authFetch(`${API}/api/contacts/batch`, {
            method: 'POST',
            headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {},
            body: formData,
        });
        const data = await res.json();

        if (res.ok) {
            const r = data.results;
            const msg = `Imported ${r.imported} contacts, ${r.skipped} skipped, ${r.errors.length} errors`;
            showToast(msg, r.errors.length ? 'warning' : 'success', 8000);

            if (batchStatus) {
                batchStatus.innerHTML = `
                    <div class="bg-green-50 border border-green-200 rounded-lg p-3 text-sm">
                        <p class="font-medium text-green-800">${esc(msg)}</p>
                        ${r.errors.length ? `<ul class="mt-2 text-xs text-red-600 space-y-1">${r.errors.map(e => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
                    </div>`;
            }
            refreshDashboard();
        } else {
            showToast(data.error || 'Batch import failed', 'error');
            if (batchStatus) {
                batchStatus.innerHTML = `<p class="text-sm text-red-500">${esc(data.error || 'Import failed')}</p>`;
            }
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
        if (batchStatus) batchStatus.innerHTML = `<p class="text-sm text-red-500">${esc(err.message)}</p>`;
    } finally {
        if (btnBatch) { btnBatch.disabled = false; btnBatch.textContent = 'Import'; }
    }
}

// ── Logout ──────────────────────────────────────────────────────────────────

$('btn-logout')?.addEventListener('click', async () => {
    try {
        await authFetch(`${API}/logout`, { method: 'POST', headers: authHeaders() });
    } catch { /* ignore */ }
    window.location.href = '/login';
});

// ── Keyboard Shortcuts ──────────────────────────────────────────────────────

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeModal();
        addContactPanel?.classList.add('hidden');
        batchPanel?.classList.add('hidden');
    }
    if (e.ctrlKey && e.key === 'u') { e.preventDefault(); fileInput.click(); }
});

// ── Dashboard Drill-Down ─────────────────────────────────────────────────────

function drillDown(type) {
    if (type === 'summaries') {
        switchTab('summaries');
    } else if (type === 'incoming') {
        $('files-status-filter').value = 'pending';
        switchTab('files');
    } else if (type === 'contacts') {
        const section = $('contacts-list');
        if (section) section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else if (type === 'received') {
        showFilteredContacts('received');
    }
}
window.drillDown = drillDown;

function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('tab-active'); b.classList.add('text-gray-500'); });
    const btn = document.querySelector(`[data-tab="${tabName}"]`);
    if (btn) { btn.classList.add('tab-active'); btn.classList.remove('text-gray-500'); }
    document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
    const tab = $(`tab-${tabName}`);
    if (tab) tab.classList.remove('hidden');
    pipelineTabActive = (tabName === 'pipeline');
    if (tabName === 'pipeline') loadPipelineRuns();
    if (tabName === 'summaries') loadSummariesList();
    if (tabName === 'audit') loadAuditTrail();
    if (tabName === 'files') { loadCasesList(); loadFilesList(); }
    if (tabName === 'settings') { loadEmailSettings(); loadLlmSettings(); loadFeedbackStats(); }
}

async function showIncomingFiles() {
    try {
        const res = await authFetch(`${API}/api/incoming`);
        const data = await res.json();
        const files = data.files || [];

        const modal = $('contact-modal');
        modal.className = 'modal-backdrop';
        const sizeStr = (bytes) => bytes > 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${(bytes / 1024).toFixed(0)} KB`;
        modal.innerHTML = `
            <div class="modal-content p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-bold">Incoming Files (${files.length})</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </div>
                ${files.length === 0 ? '<p class="text-sm text-gray-500">No incoming files.</p>' :
                `<div class="space-y-2 max-h-96 overflow-y-auto">
                    ${files.map(f => `
                        <div class="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg">
                            <div class="flex items-center space-x-2 min-w-0">
                                <span class="px-1.5 py-0.5 rounded text-xs font-mono bg-blue-100 text-blue-700">${esc(f.extension)}</span>
                                <span class="text-sm truncate">${esc(f.name)}</span>
                            </div>
                            <div class="flex items-center space-x-3 text-xs text-gray-400 shrink-0">
                                <span>${sizeStr(f.size)}</span>
                                <span>${f.modified ? new Date(f.modified).toLocaleDateString() : ''}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>`}
            </div>`;
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    } catch (err) {
        showToast('Could not load incoming files', 'error');
    }
}

async function showFilteredContacts(status) {
    try {
        const res = await authFetch(`${API}/api/contacts?status=${status}&per_page=100`);
        const data = await res.json();
        const contacts = data.contacts || data;

        const modal = $('contact-modal');
        modal.className = 'modal-backdrop';
        const statusColors = {
            new: 'bg-blue-100 text-blue-800', contacted: 'bg-yellow-100 text-yellow-800',
            awaiting: 'bg-orange-100 text-orange-800', received: 'bg-green-100 text-green-800',
            failed: 'bg-red-100 text-red-800',
        };
        modal.innerHTML = `
            <div class="modal-content p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-bold">Contacts: ${esc(status)} (${contacts.length})</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </div>
                ${contacts.length === 0 ? `<p class="text-sm text-gray-500">No contacts with status "${esc(status)}".</p>` :
                `<div class="space-y-2 max-h-96 overflow-y-auto">
                    ${contacts.map(c => `
                        <div class="flex items-center justify-between py-2 px-3 hover:bg-slate-50 rounded-lg cursor-pointer" onclick="closeModal(); showContactDetail(${Number(c.id)})">
                            <div class="min-w-0">
                                <p class="text-sm font-medium truncate">${esc(c.contact_name)}</p>
                                <p class="text-xs text-gray-400">${esc(c.organization || '')} ${c.patient_case_ref ? '| ' + esc(c.patient_case_ref) : ''}</p>
                            </div>
                            <span class="px-2 py-0.5 rounded-full text-xs font-medium ml-2 ${statusColors[c.status] || 'bg-gray-100'}">${esc(c.status)}</span>
                        </div>
                    `).join('')}
                </div>`}
            </div>`;
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    } catch (err) {
        showToast('Could not load contacts', 'error');
    }
}

// ── Chat with Summaries ─────────────────────────────────────────────────────

let chatHistory = [];

$('btn-send-chat')?.addEventListener('click', sendChatMessage);
$('chat-input')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
});
$('btn-clear-chat')?.addEventListener('click', () => {
    chatHistory = [];
    const msgs = $('chat-messages');
    msgs.innerHTML = '<div class="chat-msg assistant">Hello! I have access to all medical record summaries in the system. Ask me anything about patient records, diagnoses, medications, or trends across documents.</div>';
});

async function sendChatMessage() {
    const input = $('chat-input');
    const btn = $('btn-send-chat');
    const message = input.value.trim();
    if (!message) return;

    const msgs = $('chat-messages');

    // Add user message
    const userDiv = document.createElement('div');
    userDiv.className = 'chat-msg user';
    userDiv.textContent = message;
    msgs.appendChild(userDiv);

    chatHistory.push({ role: 'user', content: message });
    input.value = '';
    btn.disabled = true;

    // Add typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'chat-msg assistant';
    typingDiv.id = 'chat-typing';
    typingDiv.innerHTML = '<div class="chat-typing"><span></span><span></span><span></span></div>';
    msgs.appendChild(typingDiv);
    msgs.scrollTop = msgs.scrollHeight;

    try {
        const res = await authFetch(`${API}/api/chat`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ message, history: chatHistory }),
        });
        const data = await res.json();

        typingDiv.remove();

        if (res.ok) {
            const reply = data.reply || 'No response.';
            const assistantDiv = document.createElement('div');
            assistantDiv.className = 'chat-msg assistant';
            assistantDiv.innerHTML = formatChatReply(reply);
            msgs.appendChild(assistantDiv);
            chatHistory.push({ role: 'assistant', content: reply });
        } else {
            const errDiv = document.createElement('div');
            errDiv.className = 'chat-msg assistant';
            errDiv.innerHTML = `<span class="text-red-500">${esc(data.error || 'Error getting response')}</span>`;
            msgs.appendChild(errDiv);
        }
    } catch (err) {
        typingDiv.remove();
        const errDiv = document.createElement('div');
        errDiv.className = 'chat-msg assistant';
        errDiv.innerHTML = `<span class="text-red-500">Connection error: ${esc(err.message)}</span>`;
        msgs.appendChild(errDiv);
    } finally {
        btn.disabled = false;
        msgs.scrollTop = msgs.scrollHeight;
        input.focus();
    }
}

function formatChatReply(text) {
    // Basic markdown-ish rendering: code blocks, bold, lists
    let html = esc(text);
    // Code blocks
    html = html.replace(/```([\s\S]*?)```/g, '<pre>$1</pre>');
    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-200 px-1 rounded text-xs">$1</code>');
    // Bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    return html;
}

// ── Summary Feedback (RLHF) ────────────────────────────────────────────────

function renderFeedbackButtons(runId) {
    return `
        <div class="border-t mt-4 pt-4" id="feedback-section-${esc(runId)}">
            <div class="flex items-center justify-between">
                <p class="text-sm font-medium text-gray-600">Rate this summary:</p>
                <div class="flex items-center space-x-2">
                    <button class="rating-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-red-50 text-red-600 hover:bg-red-100" onclick="rateSummary('${esc(runId)}', 'poor', this)">Poor</button>
                    <button class="rating-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-600 hover:bg-blue-100" onclick="rateSummary('${esc(runId)}', 'good', this)">Good</button>
                    <button class="rating-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-green-50 text-green-600 hover:bg-green-100" onclick="rateSummary('${esc(runId)}', 'excellent', this)">Excellent</button>
                </div>
            </div>
            <div class="mt-2 hidden" id="feedback-text-${esc(runId)}">
                <textarea id="feedback-input-${esc(runId)}" rows="2" placeholder="Optional: What could be improved?" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-700 outline-none resize-none"></textarea>
                <button class="mt-1 px-3 py-1.5 rounded-lg bg-blue-900 text-white text-xs font-medium hover:bg-blue-900" onclick="submitFeedback('${esc(runId)}')">Submit Feedback</button>
            </div>
        </div>`;
}

let currentFeedbackRating = null;

async function rateSummary(runId, rating, btnEl) {
    currentFeedbackRating = rating;
    // Highlight selected button
    const section = $(`feedback-section-${runId}`);
    if (section) {
        section.querySelectorAll('.rating-btn').forEach(b => b.classList.remove('selected'));
        btnEl.classList.add('selected');
        $(`feedback-text-${runId}`)?.classList.remove('hidden');
    }
}
window.rateSummary = rateSummary;

async function submitFeedback(runId) {
    if (!currentFeedbackRating) return;
    const feedbackText = ($(`feedback-input-${runId}`)?.value || '').trim();

    try {
        const res = await authFetch(`${API}/api/summaries/${runId}/feedback`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ rating: currentFeedbackRating, feedback_text: feedbackText }),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(data.message || 'Feedback submitted!', 'success');
            const section = $(`feedback-section-${runId}`);
            if (section) section.innerHTML = `<p class="text-sm text-green-600 text-center py-2">Thank you for your ${currentFeedbackRating} rating!</p>`;
            currentFeedbackRating = null;
        } else {
            showToast(data.error || 'Failed to submit feedback', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}
window.submitFeedback = submitFeedback;

// ── Email Settings ──────────────────────────────────────────────────────────

async function loadEmailSettings() {
    try {
        const res = await authFetch(`${API}/api/settings/email`);
        const data = await res.json();
        const form = $('email-settings-form');
        if (!form) return;

        const fields = ['smtp_host', 'smtp_port', 'smtp_username', 'smtp_password',
                        'imap_host', 'imap_port', 'imap_username', 'imap_password',
                        'sender_name', 'sender_organization', 'sender_phone'];
        fields.forEach(f => {
            const input = form.querySelector(`[name="${f}"]`);
            if (input && data[f] !== undefined) input.value = data[f];
        });
        const enabledCb = form.querySelector('[name="enabled"]');
        if (enabledCb) enabledCb.checked = !!data.enabled;
    } catch { /* silently fail */ }
}

$('email-settings-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = $('email-settings-form');
    const formData = new FormData(form);
    const payload = {};
    formData.forEach((v, k) => { payload[k] = v; });
    payload.enabled = form.querySelector('[name="enabled"]')?.checked || false;

    try {
        const res = await authFetch(`${API}/api/settings/email`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify(payload),
        });
        const data = await res.json();
        showToast(data.message || 'Settings saved', res.ok ? 'success' : 'error');
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
});

$('btn-test-email')?.addEventListener('click', async () => {
    const form = $('email-settings-form');
    const formData = new FormData(form);
    const payload = {};
    formData.forEach((v, k) => { payload[k] = v; });

    const btn = $('btn-test-email');
    btn.textContent = 'Testing...';
    btn.disabled = true;

    try {
        const res = await authFetch(`${API}/api/settings/email/test`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify(payload),
        });
        const data = await res.json();

        const resultsDiv = $('email-test-results');
        resultsDiv.classList.remove('hidden');
        resultsDiv.innerHTML = `
            <div class="border rounded-lg p-4 space-y-2 mt-3">
                <div class="flex items-center space-x-2">
                    <span class="w-2 h-2 rounded-full ${data.smtp?.status === 'ok' ? 'bg-green-400' : data.smtp?.status === 'error' ? 'bg-red-400' : 'bg-gray-400'}"></span>
                    <span class="text-sm font-medium">SMTP:</span>
                    <span class="text-sm ${data.smtp?.status === 'ok' ? 'text-green-600' : 'text-red-600'}">${esc(data.smtp?.message || 'N/A')}</span>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="w-2 h-2 rounded-full ${data.imap?.status === 'ok' ? 'bg-green-400' : data.imap?.status === 'error' ? 'bg-red-400' : 'bg-gray-400'}"></span>
                    <span class="text-sm font-medium">IMAP:</span>
                    <span class="text-sm ${data.imap?.status === 'ok' ? 'text-green-600' : 'text-red-600'}">${esc(data.imap?.message || 'N/A')}</span>
                </div>
            </div>`;
    } catch (err) {
        showToast(`Test failed: ${err.message}`, 'error');
    } finally {
        btn.textContent = 'Test Connection';
        btn.disabled = false;
    }
});

async function loadFeedbackStats() {
    try {
        const res = await authFetch(`${API}/api/feedback/stats`);
        const data = await res.json();
        $('fb-poor').textContent = data.stats?.poor || 0;
        $('fb-good').textContent = data.stats?.good || 0;
        $('fb-excellent').textContent = data.stats?.excellent || 0;

        const recentDiv = $('recent-feedback');
        if (recentDiv && data.recent?.length) {
            const ratingColors = { poor: 'text-red-600 bg-red-50', good: 'text-blue-600 bg-blue-50', excellent: 'text-green-600 bg-green-50' };
            recentDiv.innerHTML = '<h4 class="text-sm font-bold text-gray-700 mb-2">Recent Feedback</h4>' +
                data.recent.slice(0, 10).map(r => `
                    <div class="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg text-sm">
                        <div class="flex items-center space-x-2">
                            <span class="px-2 py-0.5 rounded text-xs font-bold ${ratingColors[r.rating] || ''}">${esc(r.rating)}</span>
                            <span class="text-gray-600 text-xs">${esc(r.run_id?.substring(0, 20) || '')}</span>
                        </div>
                        <span class="text-gray-400 text-xs">${r.created_at ? new Date(r.created_at).toLocaleDateString() : ''}</span>
                    </div>
                `).join('');
        }
    } catch { /* silently fail */ }
}

// ── LLM Backend Settings ────────────────────────────────────────────────────

async function loadLlmSettings() {
    try {
        const res = await authFetch(`${API}/api/settings/llm`);
        const data = await res.json();

        // Set radio buttons
        const radios = document.querySelectorAll('[name="llm_backend"]');
        radios.forEach(r => {
            r.checked = r.value === data.backend;
            const card = r.closest('label');
            if (card) {
                card.classList.toggle('border-blue-700', r.checked);
                card.classList.toggle('bg-blue-50', r.checked);
            }
        });

        // Show/hide Claude model section
        const claudeSection = $('claude-model-section');
        if (claudeSection) {
            claudeSection.classList.toggle('hidden', data.backend !== 'claude');
        }

        // Set Claude model radio
        if (data.claude?.model) {
            const modelRadios = document.querySelectorAll('[name="claude_model"]');
            modelRadios.forEach(r => { r.checked = r.value === data.claude.model; });
        }

        // Availability indicators
        const ollamaAvail = $('ollama-avail');
        if (ollamaAvail) {
            ollamaAvail.innerHTML = data.ollama?.available
                ? '<span class="text-green-600">Connected</span>'
                : '<span class="text-red-500">Not running</span>';
        }
        const claudeAvail = $('claude-avail');
        if (claudeAvail) {
            claudeAvail.innerHTML = data.claude?.available
                ? '<span class="text-green-600">API key configured</span>'
                : '<span class="text-red-500">No API key</span>';
        }
    } catch { /* silently fail */ }
}

// Radio button change — toggle card styling and model section
document.querySelectorAll('[name="llm_backend"]').forEach(radio => {
    radio.addEventListener('change', () => {
        document.querySelectorAll('[name="llm_backend"]').forEach(r => {
            const card = r.closest('label');
            if (card) {
                card.classList.toggle('border-blue-700', r.checked);
                card.classList.toggle('bg-blue-50', r.checked);
            }
        });
        const claudeSection = $('claude-model-section');
        if (claudeSection) {
            claudeSection.classList.toggle('hidden', radio.value !== 'claude' || !radio.checked);
        }
    });
});

$('btn-save-llm')?.addEventListener('click', async () => {
    const backend = document.querySelector('[name="llm_backend"]:checked')?.value;
    const claudeModel = document.querySelector('[name="claude_model"]:checked')?.value;

    if (!backend) { showToast('Select a backend', 'warning'); return; }

    const btn = $('btn-save-llm');
    btn.textContent = 'Saving...';
    btn.disabled = true;

    try {
        const res = await authFetch(`${API}/api/settings/llm`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ backend, claude_model: claudeModel }),
        });
        const data = await res.json();
        showToast(data.message || (res.ok ? 'Settings saved' : data.error), res.ok ? 'success' : 'error');
        if (res.ok) checkSystemHealth();  // refresh header indicator
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    } finally {
        btn.textContent = 'Save LLM Settings';
        btn.disabled = false;
    }
});

// ── Files Tab ───────────────────────────────────────────────────────────────

const FILE_STATUS_COLORS = {
    pending: 'bg-blue-100 text-blue-800',
    processing: 'bg-yellow-100 text-yellow-800',
    completed: 'bg-green-100 text-green-800',
    failed: 'bg-red-100 text-red-800',
};

function fileSizeStr(bytes) {
    if (!bytes) return '0 B';
    if (bytes > 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
    if (bytes > 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${bytes} B`;
}

async function loadFilesList() {
    const container = $('files-list');
    const statusFilter = $('files-status-filter')?.value || '';
    const categoryFilter = $('files-category-filter')?.value || '';
    const search = $('files-search')?.value || '';

    try {
        let url = `${API}/api/files?page=${filesPage}&per_page=100`;
        if (statusFilter) url += `&status=${encodeURIComponent(statusFilter)}`;
        if (categoryFilter) url += `&category=${encodeURIComponent(categoryFilter)}`;
        if (search) url += `&q=${encodeURIComponent(search)}`;

        const res = await authFetch(url);
        const data = await res.json();
        const files = data.files || [];

        if (!files.length) {
            container.innerHTML = '<p class="text-sm text-gray-500 text-center py-8">No files found. Upload documents or click "Sync Files" to scan existing vault files.</p>';
            $('files-count').textContent = '';
            $('files-pagination').innerHTML = '';
            return;
        }

        $('files-count').textContent = `${data.pagination.total} file(s)`;
        renderFilesList(files);
        renderFilesPagination(data.pagination);
    } catch (err) {
        container.innerHTML = '<p class="text-sm text-red-500">Failed to load files.</p>';
    }
}

function renderFileRow(f) {
    const statusColor = FILE_STATUS_COLORS[f.status] || 'bg-gray-100 text-gray-800';
    const catLabel = f.category && f.category !== 'uncategorized' ? f.category.replace(/_/g, ' ') : '';
    const checked = selectedFileIds.has(f.id) ? 'checked' : '';
    const viewSummaryBtn = f.status === 'completed' && f.run_id
        ? `<button class="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200 transition-colors whitespace-nowrap"
            onclick="event.stopPropagation(); viewSummary('${esc(f.run_id)}')" title="View summary for this file">View Summary</button>`
        : '';
    return `
    <div class="flex items-center justify-between py-2.5 px-4 bg-white rounded-lg hover:bg-slate-50 transition-colors border border-gray-100"
         data-doc-id="${f.id}">
        <div class="flex items-center space-x-3 min-w-0 flex-1">
            <input type="checkbox" class="file-select-cb w-4 h-4 rounded border-gray-300 text-blue-800 focus:ring-blue-700 cursor-pointer shrink-0"
                data-doc-id="${f.id}" ${checked}
                onclick="event.stopPropagation(); toggleFileSelect(${f.id}, this.checked)">
            <span class="px-1.5 py-0.5 rounded text-xs font-mono bg-blue-100 text-blue-700 shrink-0 cursor-pointer"
                onclick="showFileDetail(${Number(f.id)})">
                ${esc(f.extension || '?')}
            </span>
            <div class="min-w-0 cursor-pointer" onclick="showFileDetail(${Number(f.id)})">
                <p class="text-sm font-medium truncate">${esc(f.filename)}</p>
                <p class="text-xs text-gray-400 truncate">
                    ${catLabel ? esc(catLabel) : ''}
                    ${f.contact_name ? (catLabel ? ' &middot; ' : '') + esc(f.contact_name) : ''}
                    ${f.upload_source ? ' &middot; ' + esc(f.upload_source) : ''}
                </p>
            </div>
        </div>
        <div class="flex items-center space-x-3 shrink-0 ml-2">
            ${viewSummaryBtn}
            <span class="text-xs text-gray-400 hidden sm:inline">${fileSizeStr(f.file_size)}</span>
            <span class="text-xs text-gray-400 hidden md:inline">${f.created_at ? new Date(f.created_at).toLocaleDateString() : ''}</span>
            <span class="px-2 py-0.5 rounded-full text-xs font-medium ${statusColor} cursor-pointer" onclick="showFileDetail(${Number(f.id)})">
                ${esc(f.status)}
            </span>
        </div>
    </div>`;
}

function renderFilesList(files) {
    const container = $('files-list');

    // Group files by case_ref
    const grouped = {};
    for (const f of files) {
        const key = f.case_ref || '__uncategorized__';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(f);
    }

    // Sort groups: named cases first (alphabetically), uncategorized last
    const keys = Object.keys(grouped).sort((a, b) => {
        if (a === '__uncategorized__') return 1;
        if (b === '__uncategorized__') return -1;
        return a.localeCompare(b);
    });

    let html = '';
    for (const key of keys) {
        const caseFiles = grouped[key];
        const isUncategorized = key === '__uncategorized__';
        const caseLabel = isUncategorized ? 'Unfiled Documents' : key;
        const groupDocIds = caseFiles.map(f => f.id);
        const allChecked = groupDocIds.every(id => selectedFileIds.has(id));

        // Count statuses for case summary
        const counts = { pending: 0, processing: 0, completed: 0, failed: 0 };
        caseFiles.forEach(f => { if (counts[f.status] !== undefined) counts[f.status]++; });

        const statusPills = [];
        if (counts.completed) statusPills.push(`<span class="px-1.5 py-0.5 rounded-full text-xs bg-green-100 text-green-700">${counts.completed} done</span>`);
        if (counts.pending) statusPills.push(`<span class="px-1.5 py-0.5 rounded-full text-xs bg-blue-100 text-blue-700">${counts.pending} pending</span>`);
        if (counts.processing) statusPills.push(`<span class="px-1.5 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-700">${counts.processing} processing</span>`);
        if (counts.failed) statusPills.push(`<span class="px-1.5 py-0.5 rounded-full text-xs bg-red-100 text-red-700">${counts.failed} failed</span>`);

        const renameBtn = isUncategorized ? '' :
            `<button class="ml-1 text-gray-400 hover:text-blue-800 transition-colors" title="Rename case"
                onclick="event.stopPropagation(); startCaseRename(this, '${esc(key).replace(/'/g, "\\'")}', [${groupDocIds.join(',')}])">
                <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
            </button>`;

        // View Summary button for case row
        const completedFile = caseFiles.find(f => f.status === 'completed' && f.run_id);
        const caseViewSummaryBtn = completedFile
            ? `<button class="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200 transition-colors whitespace-nowrap"
                onclick="event.stopPropagation(); viewSummary('${esc(completedFile.run_id)}')" title="View summary for this case">View Summary</button>`
            : '';

        html += `
        <details class="mb-3 border rounded-lg overflow-hidden slide-up" open>
            <summary class="flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 cursor-pointer select-none">
                <div class="flex items-center space-x-2">
                    <input type="checkbox" class="group-select-cb w-4 h-4 rounded border-gray-300 text-blue-800 focus:ring-blue-700 cursor-pointer"
                        ${allChecked && caseFiles.length ? 'checked' : ''}
                        onclick="event.stopPropagation(); toggleGroupSelect([${groupDocIds.join(',')}], this.checked)">
                    <svg class="w-4 h-4 ${isUncategorized ? 'text-gray-400' : 'text-blue-700'}" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                    </svg>
                    <span class="case-label text-sm font-semibold ${isUncategorized ? 'text-gray-500 italic' : 'text-gray-800'}">${esc(caseLabel)}</span>
                    ${renameBtn}
                    <span class="text-xs text-gray-400">(${caseFiles.length} file${caseFiles.length !== 1 ? 's' : ''})</span>
                </div>
                <div class="flex items-center space-x-1.5">
                    ${caseViewSummaryBtn}
                    ${isUncategorized ? `<button class="px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700 hover:bg-amber-200 transition-colors"
                        onclick="event.stopPropagation(); autoDetectCases()">Auto-detect</button>` : ''}
                    <button class="px-2 py-0.5 rounded text-xs font-medium bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                        onclick="event.stopPropagation(); deleteCaseFiles('${esc(caseLabel).replace(/'/g, "\\'")}', [${groupDocIds.join(',')}])"
                        title="Delete all files in this group">Delete All</button>
                    ${statusPills.join('')}
                </div>
            </summary>
            <div class="space-y-1 p-2" ${isUncategorized ? 'id="unfiled-files-list"' : ''}>
                ${caseFiles.map(f => renderFileRow(f)).join('')}
            </div>
        </details>`;
    }

    container.innerHTML = html;
    updateBulkBar();
}

/* ---- File selection helpers ---- */
function toggleFileSelect(docId, checked) {
    if (checked) selectedFileIds.add(docId);
    else selectedFileIds.delete(docId);
    updateBulkBar();
}

function toggleGroupSelect(docIds, checked) {
    for (const id of docIds) {
        if (checked) selectedFileIds.add(id);
        else selectedFileIds.delete(id);
    }
    // sync individual checkboxes
    for (const id of docIds) {
        const cb = document.querySelector(`.file-select-cb[data-doc-id="${id}"]`);
        if (cb) cb.checked = checked;
    }
    updateBulkBar();
}

function clearFileSelection() {
    selectedFileIds.clear();
    document.querySelectorAll('.file-select-cb, .group-select-cb').forEach(cb => cb.checked = false);
    updateBulkBar();
}

async function loadCasesList() {
    try {
        const res = await authFetch(`${API}/api/cases`);
        const data = await res.json();
        cachedCases = data.cases || [];
    } catch { cachedCases = []; }
}

function updateBulkBar() {
    let bar = $('bulk-action-bar');
    if (!bar) {
        bar = document.createElement('div');
        bar.id = 'bulk-action-bar';
        bar.className = 'fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg px-6 py-3 flex items-center justify-between z-50 transition-transform';
        bar.style.transform = 'translateY(100%)';
        document.body.appendChild(bar);
    }

    if (selectedFileIds.size === 0) {
        bar.style.transform = 'translateY(100%)';
        return;
    }

    const caseOptions = cachedCases.map(c =>
        `<option value="${esc(c.name)}">${esc(c.name)} (${c.file_count})</option>`
    ).join('');

    bar.innerHTML = `
        <div class="flex items-center space-x-3">
            <span class="text-sm font-semibold text-blue-700">${selectedFileIds.size} file${selectedFileIds.size !== 1 ? 's' : ''} selected</span>
            <select id="bulk-case-select" class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-700"
                onchange="if(this.value==='__new__') document.getElementById('bulk-case-new').classList.remove('hidden');">
                <option value="">Assign to case...</option>
                ${caseOptions}
                <option value="__new__">+ New case...</option>
            </select>
            <input id="bulk-case-new" type="text" placeholder="New case name" class="hidden px-3 py-1.5 text-sm border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-700" style="width:180px">
        </div>
        <div class="flex items-center space-x-2">
            <button onclick="applyBulkCase()" class="px-4 py-1.5 rounded-lg bg-blue-900 text-white text-sm font-medium hover:bg-blue-900 transition-colors">Apply</button>
            <button onclick="bulkDeleteFiles()" class="px-4 py-1.5 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600 transition-colors">Delete Selected</button>
            <button onclick="clearFileSelection()" class="px-4 py-1.5 rounded-lg border border-gray-300 text-gray-600 text-sm hover:bg-gray-50 transition-colors">Clear</button>
        </div>`;
    bar.style.transform = 'translateY(0)';
}

async function applyBulkCase() {
    const sel = $('bulk-case-select');
    const newInput = $('bulk-case-new');
    let caseRef = sel?.value || '';
    if (caseRef === '__new__') caseRef = (newInput?.value || '').trim();
    if (!caseRef) { showToast('Please select or enter a case name', 'error'); return; }

    const docIds = Array.from(selectedFileIds);
    try {
        const res = await authFetch(`${API}/api/files/bulk-update`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ doc_ids: docIds, case_ref: caseRef }),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(`${data.updated} file(s) assigned to ${caseRef}`, 'success');
            selectedFileIds.clear();
            loadCasesList();
            loadFilesList();
        } else {
            showToast(data.error || 'Bulk update failed', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

async function bulkDeleteFiles() {
    const count = selectedFileIds.size;
    if (!count) return;
    if (!confirm(`Permanently delete ${count} file${count !== 1 ? 's' : ''}? This action cannot be undone.`)) return;

    const docIds = Array.from(selectedFileIds);
    try {
        const res = await authFetch(`${API}/api/files/bulk-delete`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ doc_ids: docIds }),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(`${data.deleted} file(s) deleted`, 'success');
            selectedFileIds.clear();
            loadCasesList();
            loadFilesList();
            refreshDashboard();
        } else {
            showToast(data.error || 'Bulk delete failed', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

async function deleteCaseFiles(caseLabel, docIds) {
    const count = docIds.length;
    if (!confirm(`Permanently delete all ${count} file${count !== 1 ? 's' : ''} in "${caseLabel}"? This action cannot be undone.`)) return;

    try {
        const res = await authFetch(`${API}/api/files/bulk-delete`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ doc_ids: docIds }),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(`Case "${caseLabel}" deleted (${data.deleted} files)`, 'success');
            selectedFileIds.clear();
            loadCasesList();
            loadFilesList();
            refreshDashboard();
        } else {
            showToast(data.error || 'Case delete failed', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

function startCaseRename(btn, currentName, docIds) {
    const summary = btn.closest('summary');
    const label = summary.querySelector('.case-label');
    const origText = label.textContent;
    label.outerHTML = `
        <span class="case-rename-wrap inline-flex items-center space-x-1">
            <input type="text" class="case-rename-input px-2 py-0.5 text-sm border border-blue-700 rounded outline-none focus:ring-2 focus:ring-blue-700" value="${esc(currentName)}" style="width:200px">
            <button class="text-green-600 hover:text-green-800" onclick="event.stopPropagation(); finishCaseRename([${docIds.join(',')}], this)">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            </button>
            <button class="text-red-500 hover:text-red-700" onclick="event.stopPropagation(); cancelCaseRename(this, '${esc(origText).replace(/'/g, "\\'")}')">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </span>`;
    const inp = summary.querySelector('.case-rename-input');
    inp.focus();
    inp.select();
    inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.stopPropagation(); finishCaseRename(docIds, inp.nextElementSibling); }
        if (e.key === 'Escape') { e.stopPropagation(); cancelCaseRename(inp.nextElementSibling.nextElementSibling, origText); }
    });
    inp.addEventListener('click', (e) => e.stopPropagation());
}

async function finishCaseRename(docIds, btn) {
    const wrap = btn.closest('.case-rename-wrap');
    const newName = wrap.querySelector('.case-rename-input').value.trim();
    if (!newName) { showToast('Case name cannot be empty', 'error'); return; }
    try {
        const res = await authFetch(`${API}/api/files/bulk-update`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ doc_ids: docIds, case_ref: newName }),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(`Case renamed to "${newName}"`, 'success');
            loadCasesList();
            loadFilesList();
        } else {
            showToast(data.error || 'Rename failed', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

function cancelCaseRename(btn, origText) {
    const wrap = btn.closest('.case-rename-wrap');
    wrap.outerHTML = `<span class="case-label text-sm font-semibold text-gray-800">${esc(origText)}</span>`;
}

async function autoDetectCases() {
    const container = $('unfiled-files-list');
    if (!container) return;
    const rows = container.querySelectorAll('[data-doc-id]');
    if (!rows.length) { showToast('No unfiled files to detect', 'info'); return; }

    showToast('Detecting cases...', 'info');
    let found = 0;

    for (const row of rows) {
        const docId = parseInt(row.dataset.docId);
        const nameEl = row.querySelector('.text-sm.font-medium');
        const filename = nameEl?.textContent?.trim();
        if (!filename) continue;

        try {
            const res = await authFetch(`${API}/api/files/suggest-case`, {
                method: 'POST',
                headers: authHeaders(),
                body: JSON.stringify({ filename, doc_id: docId }),
            });
            const data = await res.json();
            if (data.suggestion) {
                found++;
                const badge = document.createElement('div');
                badge.className = 'flex items-center space-x-2 mt-1 ml-10';
                const confColor = data.confidence === 'high' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700';
                badge.innerHTML = `
                    <span class="text-xs ${confColor} px-1.5 py-0.5 rounded">${esc(data.confidence)}</span>
                    <span class="text-xs text-gray-600">Looks like <strong>${esc(data.suggestion)}</strong></span>
                    <button class="text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors"
                        onclick="acceptCaseSuggestion(${docId}, '${esc(data.suggestion).replace(/'/g, "\\'")}', this)">Accept</button>
                    <button class="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors"
                        onclick="this.closest('.flex').remove()">Dismiss</button>`;
                row.after(badge);
            }
        } catch { /* skip */ }
    }
    showToast(found ? `Found ${found} suggestion(s)` : 'No matches found', found ? 'success' : 'info');
}

async function acceptCaseSuggestion(docId, caseRef, btn) {
    try {
        const res = await authFetch(`${API}/api/files/${docId}`, {
            method: 'PATCH',
            headers: authHeaders(),
            body: JSON.stringify({ case_ref: caseRef }),
        });
        if (res.ok) {
            showToast(`Assigned to ${caseRef}`, 'success');
            btn.closest('.flex').remove();
            loadCasesList();
            loadFilesList();
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

function renderFilesPagination(pg) {
    const container = $('files-pagination');
    if (!pg || pg.pages <= 1) { container.innerHTML = ''; return; }
    container.innerHTML = `
        <button ${pg.page <= 1 ? 'disabled' : ''}
            class="px-3 py-1.5 text-sm border rounded ${pg.page <= 1 ? 'text-gray-300 cursor-default' : 'text-gray-600 hover:bg-gray-50 cursor-pointer'}"
            onclick="goToFilesPage(${pg.page - 1})">Previous</button>
        <span class="text-sm text-gray-500">Page ${pg.page} of ${pg.pages}</span>
        <button ${pg.page >= pg.pages ? 'disabled' : ''}
            class="px-3 py-1.5 text-sm border rounded ${pg.page >= pg.pages ? 'text-gray-300 cursor-default' : 'text-gray-600 hover:bg-gray-50 cursor-pointer'}"
            onclick="goToFilesPage(${pg.page + 1})">Next</button>`;
}

async function showFileDetail(docId) {
    try {
        const res = await authFetch(`${API}/api/files/${docId}`);
        if (!res.ok) { showToast('File not found', 'error'); return; }
        const f = await res.json();

        const modal = $('contact-modal');
        modal.className = 'modal-backdrop';

        const categories = ['uncategorized','clinical_notes','lab_results','imaging','discharge','billing','referral','legal','correspondence'];
        const catOptions = categories.map(c =>
            `<option value="${c}" ${f.category === c ? 'selected' : ''}>${c.replace(/_/g, ' ')}</option>`
        ).join('');

        modal.innerHTML = `
            <div class="modal-content p-6" style="max-width: 600px;">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-bold truncate mr-4">${esc(f.filename)}</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 text-2xl shrink-0">&times;</button>
                </div>
                <div class="grid grid-cols-2 gap-3 mb-4 text-sm">
                    <div><span class="text-gray-500">Status:</span> <span class="font-medium px-2 py-0.5 rounded-full text-xs ${FILE_STATUS_COLORS[f.status] || ''}">${esc(f.status)}</span></div>
                    <div><span class="text-gray-500">Location:</span> <span class="font-medium">${esc(f.vault_zone)}</span></div>
                    <div><span class="text-gray-500">Size:</span> <span class="font-medium">${fileSizeStr(f.file_size)}</span></div>
                    <div><span class="text-gray-500">Type:</span> <span class="font-medium">${esc(f.extension)}</span></div>
                    <div><span class="text-gray-500">Uploaded:</span> <span class="font-medium">${f.created_at ? new Date(f.created_at).toLocaleString() : '-'}</span></div>
                    <div><span class="text-gray-500">Processed:</span> <span class="font-medium">${f.processed_at ? new Date(f.processed_at).toLocaleString() : '-'}</span></div>
                    <div><span class="text-gray-500">Source:</span> <span class="font-medium">${esc(f.upload_source)}</span></div>
                    <div><span class="text-gray-500">On disk:</span> <span class="font-medium ${f.file_exists ? 'text-green-600' : 'text-red-500'}">${f.file_exists ? 'Yes' : 'Missing'}</span></div>
                    ${f.file_hash ? `<div class="col-span-2"><span class="text-gray-500">SHA-256:</span> <span class="font-mono text-xs">${esc(f.file_hash.substring(0, 24))}...</span></div>` : ''}
                    ${f.run_id ? `<div class="col-span-2"><span class="text-gray-500">Run ID:</span> <span class="font-mono text-xs">${esc(f.run_id)}</span></div>` : ''}
                </div>
                <div class="space-y-3 border-t pt-4 mb-4">
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Case Reference</label>
                        <input id="file-case-ref" type="text" value="${esc(f.case_ref || '')}"
                            class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-700"
                            placeholder="e.g. CASE-2024-001">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Category</label>
                        <select id="file-category" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-700">
                            ${catOptions}
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                        <textarea id="file-notes" rows="2" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg outline-none resize-none focus:ring-2 focus:ring-blue-700"
                            placeholder="Additional notes...">${esc(f.notes || '')}</textarea>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <button onclick="saveFileMetadata(${f.id})" class="px-4 py-2 rounded-lg bg-blue-900 text-white text-sm hover:bg-blue-900 transition-colors">Save Changes</button>
                    ${f.file_exists ? `<a href="${API}/api/files/${f.id}/download" class="px-4 py-2 rounded-lg border border-gray-300 text-gray-600 text-sm hover:bg-gray-50 inline-flex items-center transition-colors">Download</a>` : ''}
                    ${f.status === 'failed' || f.status === 'pending' ? `<button onclick="reprocessFile(${f.id})" class="px-4 py-2 rounded-lg bg-amber-500 text-white text-sm hover:bg-amber-600 transition-colors">Re-process</button>` : ''}
                    ${f.status === 'completed' && f.run_id ? `<button onclick="closeModal(); viewSummary('${esc(f.run_id)}')" class="px-4 py-2 rounded-lg bg-green-600 text-white text-sm hover:bg-green-700 transition-colors">View Summary</button>` : ''}
                    <button onclick="deleteFile(${f.id})" class="px-4 py-2 rounded-lg bg-red-500 text-white text-sm hover:bg-red-600 transition-colors">Delete</button>
                </div>
            </div>`;
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    } catch (err) {
        showToast('Could not load file details', 'error');
    }
}

async function saveFileMetadata(docId) {
    const payload = {
        case_ref: $('file-case-ref')?.value || '',
        category: $('file-category')?.value || 'uncategorized',
        notes: $('file-notes')?.value || '',
    };
    try {
        const res = await authFetch(`${API}/api/files/${docId}`, {
            method: 'PATCH',
            headers: authHeaders(),
            body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (res.ok) {
            showToast('File metadata updated', 'success');
            closeModal();
            loadFilesList();
        } else {
            showToast(data.error || 'Failed to update', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

async function reprocessFile(docId) {
    if (!confirm('Re-trigger summarization pipeline for this file?')) return;
    try {
        const res = await authFetch(`${API}/api/files/${docId}/reprocess`, {
            method: 'POST',
            headers: authHeaders(),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(`Pipeline started: ${data.run_id}`, 'info');
            closeModal();
            loadFilesList();
        } else {
            showToast(data.error || 'Failed to start pipeline', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

async function deleteFile(docId) {
    if (!confirm('Permanently delete this file? This action cannot be undone.')) return;
    try {
        const res = await authFetch(`${API}/api/files/${docId}`, {
            method: 'DELETE',
            headers: authHeaders(),
        });
        const data = await res.json();
        if (res.ok) {
            showToast('File deleted', 'success');
            closeModal();
            loadFilesList();
            refreshDashboard();
        } else {
            showToast(data.error || 'Failed to delete', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    }
}

async function syncFiles() {
    const btn = $('btn-sync-files');
    btn.textContent = 'Syncing...';
    btn.disabled = true;
    try {
        const res = await authFetch(`${API}/api/files/sync`, {
            method: 'POST',
            headers: authHeaders(),
        });
        const data = await res.json();
        if (res.ok) {
            showToast(data.message || `Synced ${data.registered} files`, 'success');
            loadFilesList();
        } else {
            showToast(data.error || 'Sync failed', 'error');
        }
    } catch (err) {
        showToast(`Error: ${err.message}`, 'error');
    } finally {
        btn.textContent = 'Sync Files';
        btn.disabled = false;
    }
}

// Files tab event listeners
$('files-status-filter')?.addEventListener('change', () => { filesPage = 1; loadFilesList(); });
$('files-category-filter')?.addEventListener('change', () => { filesPage = 1; loadFilesList(); });
$('files-search')?.addEventListener('input', () => {
    clearTimeout(filesSearchTimeout);
    filesSearchTimeout = setTimeout(() => { filesPage = 1; loadFilesList(); }, 300);
});
$('btn-sync-files')?.addEventListener('click', syncFiles);

// Expose to window for onclick handlers
window.showFileDetail = showFileDetail;
window.saveFileMetadata = saveFileMetadata;
window.reprocessFile = reprocessFile;
window.deleteFile = deleteFile;
window.bulkDeleteFiles = bulkDeleteFiles;
window.deleteCaseFiles = deleteCaseFiles;
window.syncFiles = syncFiles;
window.loadPipelineRuns = loadPipelineRuns;
window.openSourcePage = openSourcePage;
window.closePdfViewer = closePdfViewer;

// ── Demo Case Loader ────────────────────────────────────────────────────────

async function loadDemoCase() {
    try {
        showToast('Loading demo case files...', 'info');
        const res = await authFetch(`${API}/api/demo-case/load`, {
            method: 'POST',
            headers: authHeaders(),
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Failed to load demo case');
        }
        const data = await res.json();
        // Set the case ref input
        const caseInput = $('case-ref-input');
        if (caseInput) caseInput.value = data.case_ref || 'DEMO-Martinez-MVA-2024';

        // Show the files in the file list
        const fileListEl = $('file-list');
        if (fileListEl && data.files) {
            fileListEl.innerHTML = data.files.map(f =>
                `<div class="flex items-center justify-between py-1 px-2 bg-emerald-50 rounded text-xs"><span class="text-gray-700">${esc(f.filename)}</span><span class="text-emerald-600 font-medium">Ready</span></div>`
            ).join('');
        }

        showToast(`Demo loaded: ${data.files?.length || 0} files. Starting summarization...`, 'success', 4000);

        // Auto-trigger summarization — demo files are already in vault,
        // so we call /api/summarize directly with the server-side file paths
        if (data.file_paths && data.file_paths.length > 0) {
            // Switch to processing view
            resultsPlaceholder.classList.add('hidden');
            summaryView.classList.add('hidden');
            processingView.classList.remove('hidden');
            liveLog.innerHTML = '';
            resetPipelineStages();
            $('code-display').innerHTML = getPipelineCodeHTML();

            const sumRes = await authFetch(`${API}/api/summarize`, {
                method: 'POST',
                headers: authHeaders(),
                body: JSON.stringify({
                    file_paths: data.file_paths,
                    case_ref: data.case_ref || 'DEMO-Martinez-MVA-2024',
                    mode: speedMode || 'auto',
                }),
            });
            const sumData = await sumRes.json();
            if (sumRes.ok && sumData.run_id) {
                currentRunId = sumData.run_id;
                logMessage(`Pipeline started for demo case (${data.files.length} files, mode: ${sumData.mode})`);
                watchPipeline(sumData.run_id);
            } else {
                showToast(`Pipeline start failed: ${sumData.error || 'Unknown error'}`, 'error');
            }
        }
    } catch (err) {
        showToast('Demo load failed: ' + err.message, 'error');
    }
}
window.loadDemoCase = loadDemoCase;

// ── Negligence Detection ────────────────────────────────────────────────────

async function runNegligenceAnalysis() {
    if (!currentSummaryData) { showToast('No summary loaded', 'warning'); return; }

    const btn = $('btn-negligence');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="flex items-center"><svg class="w-4 h-4 mr-1.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg>Scanning...</span>';

    try {
        const res = await authFetch(`${API}/api/negligence/analyze`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ run_id: currentSummaryData.run_id })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Analysis failed');
        }
        const result = await res.json();
        renderNegligenceCard(result);
        showToast(`Negligence scan complete: ${result.finding_count || 0} findings`, 'success');
    } catch (err) {
        showToast(`Negligence scan failed: ${err.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}
window.runNegligenceAnalysis = runNegligenceAnalysis;

function renderNegligenceCard(data) {
    const existing = document.getElementById('negligence-card');
    if (existing) existing.remove();

    const findings = data.findings || [];
    if (findings.length === 0) {
        showToast('No significant standard-of-care issues detected', 'info');
        return;
    }

    const riskColors = { critical: 'red', high: 'red', medium: 'yellow', low: 'green' };
    const riskColor = riskColors[data.overall_risk] || 'gray';
    const sevIcons = { high: '\u{1F534}', medium: '\u{1F7E1}', low: '\u{1F7E2}' };

    const findingsHtml = findings.map(f => {
        const sev = f.severity || 'medium';
        const icon = sevIcons[sev] || '\u26AA';
        return `<div class="p-3 bg-white rounded-lg border border-gray-200 mb-2">
            <div class="flex items-start justify-between">
                <div class="flex-1">
                    <p class="text-sm font-semibold text-gray-800">${icon} ${esc(f.title)}</p>
                    <p class="text-xs text-gray-600 mt-1">${esc(f.description)}</p>
                    ${f.recommendation ? `<p class="text-xs text-blue-700 mt-1 font-medium">Action: ${esc(f.recommendation)}</p>` : ''}
                </div>
                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-${sev === 'high' ? 'red' : sev === 'medium' ? 'yellow' : 'green'}-100 text-${sev === 'high' ? 'red' : sev === 'medium' ? 'yellow' : 'green'}-800 shrink-0 ml-2">${esc(sev)}</span>
            </div>
        </div>`;
    }).join('');

    const card = document.createElement('div');
    card.id = 'negligence-card';
    card.className = 'mb-4 p-5 bg-gradient-to-r from-red-50 to-rose-50 rounded-xl border-2 border-red-300 shadow-lg';
    card.innerHTML = `
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-bold text-red-900 uppercase tracking-wide flex items-center">
                <svg class="w-5 h-5 mr-2 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
                Standard of Care Analysis
            </h3>
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-${riskColor}-100 text-${riskColor}-800">Risk: ${esc(data.overall_risk || 'unknown')}</span>
        </div>
        <div class="grid grid-cols-3 gap-2 mb-3 text-center text-xs">
            <div class="p-2 bg-red-100 rounded-lg"><span class="font-bold text-red-700">${data.severity_summary?.high || 0}</span> High</div>
            <div class="p-2 bg-yellow-100 rounded-lg"><span class="font-bold text-yellow-700">${data.severity_summary?.medium || 0}</span> Medium</div>
            <div class="p-2 bg-green-100 rounded-lg"><span class="font-bold text-green-700">${data.severity_summary?.low || 0}</span> Low</div>
        </div>
        <div class="space-y-2">${findingsHtml}</div>
    `;

    const analysisPanel = $('subtab-analysis');
    if (analysisPanel) {
        const emptyState = $('analysis-empty');
        if (emptyState) emptyState.remove();
        analysisPanel.appendChild(card);
    }
    toolResults.negligence = data;
    updateInsightsStrip();
    updateSubTabBadges();
    switchSubTab('analysis');
}

// ── Auto-Task Generation ────────────────────────────────────────────────────

async function generateCaseTasks() {
    if (!currentSummaryData) { showToast('No summary loaded', 'warning'); return; }

    const btn = $('btn-auto-tasks');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="flex items-center"><svg class="w-4 h-4 mr-1.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg>Generating...</span>';

    try {
        const res = await authFetch(`${API}/api/tasks/generate`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ run_id: currentSummaryData.run_id })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Task generation failed');
        }
        const result = await res.json();
        renderAutoTasks(result);
        showToast(`Generated ${result.task_count || 0} action items`, 'success');
    } catch (err) {
        showToast(`Task generation failed: ${err.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}
window.generateCaseTasks = generateCaseTasks;

function renderAutoTasks(data) {
    const existing = document.getElementById('auto-tasks-card');
    if (existing) existing.remove();

    const tasks = data.tasks || [];
    if (tasks.length === 0) {
        showToast('No action items generated', 'info');
        return;
    }

    const categoryIcons = {
        deposition: '\u{1f4cb}', records_request: '\u{1f4c1}', follow_up: '\u{1f4de}',
        investigation: '\u{1f50d}', documentation: '\u{1f4dd}', expert_review: '\u{1f468}\u200d\u2695\ufe0f', discovery: '\u2696\ufe0f'
    };
    const priorityColors = {
        1: 'red', 2: 'orange', 3: 'yellow', 4: 'blue', 5: 'gray'
    };
    const priorityLabels = {
        1: 'Critical', 2: 'High', 3: 'Medium', 4: 'Low', 5: 'Routine'
    };

    const tasksHtml = tasks.map(t => {
        const icon = categoryIcons[t.category] || '\u{1f4cc}';
        const pColor = priorityColors[t.priority] || 'gray';
        const pLabel = priorityLabels[t.priority] || 'Routine';
        const assignee = t.assignee_type === 'attorney' ? '\u{1f454} Attorney' : '\u{1f4ce} Paralegal';
        return `<div class="flex items-start p-3 bg-white rounded-lg border border-gray-200 mb-2">
            <input type="checkbox" class="mt-1 mr-3 rounded border-gray-300 text-amber-600 focus:ring-amber-500 shrink-0">
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                    <span>${icon}</span>
                    <p class="text-sm font-semibold text-gray-800 truncate">${esc(t.title)}</p>
                </div>
                <p class="text-xs text-gray-600">${esc(t.description)}</p>
                <div class="flex items-center gap-3 mt-1.5">
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-${pColor}-100 text-${pColor}-700">${pLabel}</span>
                    <span class="text-[10px] text-gray-500">${assignee}</span>
                </div>
            </div>
        </div>`;
    }).join('');

    const card = document.createElement('div');
    card.id = 'auto-tasks-card';
    card.className = 'mb-4 p-5 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border-2 border-amber-300 shadow-lg';
    card.innerHTML = `
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-bold text-amber-900 uppercase tracking-wide flex items-center">
                <svg class="w-5 h-5 mr-2 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                Action Items (${tasks.length})
            </h3>
            <button onclick="exportAutoTasks()" class="px-3 py-1 text-xs font-medium text-amber-700 bg-white border border-amber-300 rounded-lg hover:bg-amber-100 transition-colors">Export CSV</button>
        </div>
        <div class="grid grid-cols-4 gap-2 mb-3 text-center text-xs">
            <div class="p-1.5 bg-red-100 rounded"><span class="font-bold text-red-700">${data.priority_breakdown?.critical || 0}</span> Critical</div>
            <div class="p-1.5 bg-orange-100 rounded"><span class="font-bold text-orange-700">${data.priority_breakdown?.high || 0}</span> High</div>
            <div class="p-1.5 bg-yellow-100 rounded"><span class="font-bold text-yellow-700">${data.priority_breakdown?.medium || 0}</span> Medium</div>
            <div class="p-1.5 bg-blue-100 rounded"><span class="font-bold text-blue-700">${(data.priority_breakdown?.low || 0) + (data.priority_breakdown?.routine || 0)}</span> Other</div>
        </div>
        <div class="max-h-80 overflow-y-auto space-y-1">${tasksHtml}</div>
    `;

    const actionsPanel = $('subtab-actions');
    if (actionsPanel) {
        const emptyState = $('actions-empty');
        if (emptyState) emptyState.remove();
        actionsPanel.insertBefore(card, actionsPanel.firstChild);
    }
    toolResults.tasks = data;
    updateInsightsStrip();
    updateSubTabBadges();
    switchSubTab('actions');
}

function exportAutoTasks() {
    const card = document.getElementById('auto-tasks-card');
    if (!card) return;
    // Simple CSV export of visible tasks
    const rows = [['#', 'Priority', 'Category', 'Task', 'Description', 'Assignee']];
    const taskItems = card.querySelectorAll('.flex.items-start.p-3');
    taskItems.forEach((item, i) => {
        const title = item.querySelector('.font-semibold')?.textContent || '';
        const desc = item.querySelector('.text-gray-600')?.textContent || '';
        const priority = item.querySelector('[class*="font-bold"]')?.textContent || '';
        const assignee = item.querySelectorAll('.text-gray-500')?.[0]?.textContent || '';
        rows.push([i + 1, priority, '', title, desc, assignee]);
    });
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `case_tasks_${currentSummaryData?.run_id || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Tasks exported to CSV', 'success');
}
window.exportAutoTasks = exportAutoTasks;

// ── Injury Visualization ────────────────────────────────────────────────────

async function showInjuryDiagram() {
    if (!currentSummaryData) { showToast('No summary loaded', 'warning'); return; }

    const btn = $('btn-injury-diagram');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="flex items-center"><svg class="w-4 h-4 mr-1.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg>Loading...</span>';

    try {
        const res = await authFetch(`${API}/api/injury-diagram/${currentSummaryData.run_id}`);
        if (!res.ok) throw new Error('Failed to load diagram');
        const data = await res.json();

        if (data.injury_count === 0) {
            showToast('No injury regions mapped from diagnoses', 'info');
            return;
        }

        renderInjuryDiagram(data);
        showToast(`${data.injury_count} injury regions mapped`, 'success');
    } catch (err) {
        showToast('Injury diagram failed: ' + err.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}
window.showInjuryDiagram = showInjuryDiagram;

function renderInjuryDiagram(data) {
    const existing = document.getElementById('injury-diagram-card');
    if (existing) existing.remove();

    const card = document.createElement('div');
    card.id = 'injury-diagram-card';
    card.className = 'mb-4 p-5 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border-2 border-blue-300 shadow-lg';
    card.innerHTML = `
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-bold text-blue-900 uppercase tracking-wide flex items-center">
                <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                Injury Diagram (${data.injury_count} regions)
            </h3>
            <div class="flex items-center space-x-2">
                <span class="text-xs text-gray-500">${data.regions_affected?.join(', ') || ''}</span>
                <button onclick="downloadInjurySVG()" class="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" title="Download SVG">Download SVG</button>
            </div>
        </div>
        <div class="flex justify-center bg-white rounded-lg p-4 border border-blue-100">
            ${data.svg}
        </div>
        ${data.saved_path ? '<p class="mt-2 text-xs text-gray-400">Saved to: ' + esc(data.saved_path) + '</p>' : ''}
    `;

    const analysisPanel = $('subtab-analysis');
    if (analysisPanel) {
        const emptyState = $('analysis-empty');
        if (emptyState) emptyState.remove();
        analysisPanel.appendChild(card);
    }
    toolResults.injuryMap = data;
    updateInsightsStrip();
    updateSubTabBadges();
    switchSubTab('analysis');
}

function downloadInjurySVG() {
    const card = document.getElementById('injury-diagram-card');
    if (!card) return;
    const svgEl = card.querySelector('svg');
    if (!svgEl) { showToast('No SVG to download', 'warning'); return; }
    const svgData = new XMLSerializer().serializeToString(svgEl);
    const blob = new Blob([svgData], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `injury_diagram_${currentSummaryData?.run_id || 'export'}.svg`;
    a.click();
    URL.revokeObjectURL(url);
}
window.downloadInjurySVG = downloadInjurySVG;

// ── Case Valuation ──────────────────────────────────────────────────────────

async function runCaseValuation() {
    if (!currentSummaryData) {
        showToast('No summary loaded', 'warning');
        return;
    }

    const btn = $('btn-case-valuation');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="flex items-center"><svg class="w-4 h-4 mr-1.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg>Analyzing...</span>';

    try {
        const res = await authFetch(`${API}/api/valuation/estimate`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({
                run_id: currentSummaryData.run_id,
                options: {
                    state: $('demand-state')?.value || 'default',
                    case_type: $('demand-case-type')?.value || 'mva',
                }
            })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Valuation failed');
        }

        const result = await res.json();
        renderValuationCard(result);
        showToast('Case valuation complete', 'success');

    } catch (err) {
        showToast(`Valuation failed: ${err.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}
window.runCaseValuation = runCaseValuation;

function renderValuationCard(val) {
    // Remove existing card if present
    const existing = document.getElementById('valuation-card');
    if (existing) existing.remove();

    const severity = val.severity || 'unknown';
    const sevColors = {
        minor: 'yellow', moderate: 'blue', serious: 'orange', severe: 'red', catastrophic: 'red'
    };
    const sevColor = sevColors[severity] || 'gray';
    const confPct = Math.round((val.confidence || 0) * 100);
    const confColor = confPct >= 70 ? 'green' : confPct >= 50 ? 'yellow' : 'red';

    const strengthItems = (val.factors_strengthening || []).map(f =>
        `<li class="flex items-start"><span class="text-green-500 mr-1.5 mt-0.5 shrink-0">&#9650;</span><span>${esc(f)}</span></li>`
    ).join('');
    const weakItems = (val.factors_weakening || []).map(f =>
        `<li class="flex items-start"><span class="text-red-500 mr-1.5 mt-0.5 shrink-0">&#9660;</span><span>${esc(f)}</span></li>`
    ).join('');

    const card = document.createElement('div');
    card.id = 'valuation-card';
    card.className = 'mb-4 p-5 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border-2 border-purple-300 shadow-lg';
    card.innerHTML = `
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-bold text-purple-900 uppercase tracking-wide flex items-center">
                <svg class="w-5 h-5 mr-2 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Predicted Settlement Value
            </h3>
            <div class="flex items-center space-x-2">
                <span class="px-2 py-0.5 rounded-full text-xs font-bold bg-${sevColor}-100 text-${sevColor}-800">${esc(severity)}</span>
                <span class="px-2 py-0.5 rounded-full text-xs font-bold bg-${confColor}-100 text-${confColor}-800">${confPct}% confidence</span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-4 mb-4">
            <div class="text-center p-3 bg-white rounded-lg border border-purple-100">
                <p class="text-[10px] font-bold uppercase text-gray-500">Low</p>
                <p class="text-lg font-bold text-gray-600">${formatCurrency(val.low || 0)}</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg border-2 border-purple-300 shadow-sm">
                <p class="text-[10px] font-bold uppercase text-purple-700">Estimated</p>
                <p class="text-2xl font-bold text-purple-700">${formatCurrency(val.mid || 0)}</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg border border-purple-100">
                <p class="text-[10px] font-bold uppercase text-gray-500">High</p>
                <p class="text-lg font-bold text-gray-600">${formatCurrency(val.high || 0)}</p>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-3 mb-4 text-xs text-center text-gray-600">
            <div><span class="font-semibold">Medical Specials:</span> ${formatCurrency(val.billing_total || 0)}</div>
            <div><span class="font-semibold">Treatment:</span> ${val.treatment_months || 0} months</div>
            <div><span class="font-semibold">Providers:</span> ${val.provider_count || 0}</div>
        </div>
        ${val.reasoning ? `<p class="text-sm text-gray-700 mb-3 italic">${esc(val.reasoning)}</p>` : ''}
        ${(strengthItems || weakItems) ? `
        <div class="grid grid-cols-2 gap-4 text-xs">
            ${strengthItems ? `<div><p class="font-bold text-green-700 mb-1">Strengthening Factors</p><ul class="space-y-1 text-gray-700">${strengthItems}</ul></div>` : ''}
            ${weakItems ? `<div><p class="font-bold text-red-700 mb-1">Weakening Factors</p><ul class="space-y-1 text-gray-700">${weakItems}</ul></div>` : ''}
        </div>` : ''}
        ${val.comparable_basis ? `<p class="text-xs text-gray-500 mt-3 border-t border-purple-100 pt-2">${esc(val.comparable_basis)}</p>` : ''}
    `;

    const analysisPanel = $('subtab-analysis');
    if (analysisPanel) {
        const emptyState = $('analysis-empty');
        if (emptyState) emptyState.remove();
        analysisPanel.insertBefore(card, analysisPanel.firstChild);
    }
    toolResults.valuation = val;
    updateInsightsStrip();
    updateSubTabBadges();
    switchSubTab('analysis');
}

// ── Demand Package Generator ────────────────────────────────────────────────

function showDemandModal() {
    const modal = $('demand-modal');
    if (modal) {
        modal.classList.remove('hidden');
        $('demand-results')?.classList.add('hidden');
        loadDemandStates();
        _autoPopulateDemandForm();
    }
}
window.showDemandModal = showDemandModal;

function _autoPopulateDemandForm() {
    if (!currentSummaryData) return;
    const summary = currentSummaryData.summary?.summary || currentSummaryData.summary || {};

    // Auto-populate plaintiff name from patient demographics
    const demographics = summary.patient_demographics || summary.demographics || {};
    const patientName = demographics.name || demographics.patient_name || '';
    if (patientName) {
        const el = $('demand-plaintiff');
        if (el && !el.value) el.value = patientName;
    }

    // Auto-populate incident date
    const events = summary.chronological_events || [];
    if (events.length > 0) {
        const firstEvent = events[0];
        const dateStr = typeof firstEvent === 'object' ? (firstEvent.date || firstEvent.event_date || '') : '';
        if (dateStr) {
            const el = $('demand-incident-date');
            if (el && !el.value) el.value = dateStr;
        }
    }

    // Auto-detect case type from diagnoses/events
    const allText = JSON.stringify(summary).toLowerCase();
    const caseTypeEl = $('demand-case-type');
    if (caseTypeEl && caseTypeEl.value === 'mva') {
        if (allText.includes('motor vehicle') || allText.includes('mva') || allText.includes('car accident') || allText.includes('collision')) {
            caseTypeEl.value = 'mva';
        } else if (allText.includes('slip') || allText.includes('fall') || allText.includes('premises')) {
            caseTypeEl.value = 'slip_fall';
        } else if (allText.includes('malpractice') || allText.includes('surgical error') || allText.includes('misdiagnos')) {
            caseTypeEl.value = 'med_mal';
        } else if (allText.includes('workers') || allText.includes('workplace') || allText.includes('on the job')) {
            caseTypeEl.value = 'workers_comp';
        } else if (allText.includes('dog') || allText.includes('bite') || allText.includes('animal')) {
            caseTypeEl.value = 'dog_bite';
        }
    }
}

function closeDemandModal() {
    const modal = $('demand-modal');
    if (modal) modal.classList.add('hidden');
}
window.closeDemandModal = closeDemandModal;

async function loadDemandStates() {
    try {
        const res = await authFetch(`${API}/api/demand/case-types`);
        if (!res.ok) return;
        const data = await res.json();
        const stateSelect = $('demand-state');
        if (stateSelect && data.states) {
            stateSelect.innerHTML = '<option value="default">General (No State-Specific)</option>';
            data.states.forEach(s => {
                const code = typeof s === 'object' ? s.code : s;
                const name = typeof s === 'object' ? s.name : s.toUpperCase();
                if (code !== 'default') {
                    const opt = document.createElement('option');
                    opt.value = code;
                    opt.textContent = name;
                    stateSelect.appendChild(opt);
                }
            });
        }
        // Also update case types if available
        const caseTypeSelect = $('demand-case-type');
        if (caseTypeSelect && data.case_types) {
            caseTypeSelect.innerHTML = '';
            data.case_types.forEach(ct => {
                const opt = document.createElement('option');
                opt.value = typeof ct === 'object' ? ct.id : ct;
                opt.textContent = typeof ct === 'object' ? ct.name : ct;
                caseTypeSelect.appendChild(opt);
            });
        }
    } catch { /* ignore */ }
}

async function generateDemandPackage() {
    if (!currentSummaryData) {
        showToast('No summary loaded', 'warning');
        return;
    }

    const btn = $('btn-generate-demand');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="flex items-center justify-center"><svg class="w-4 h-4 mr-1.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg>Generating...</span>';

    try {
        const options = {
            case_type: $('demand-case-type')?.value || 'mva',
            state: $('demand-state')?.value || 'default',
            plaintiff_name: $('demand-plaintiff')?.value || '[PLAINTIFF]',
            incident_date: $('demand-incident-date')?.value || '[DATE]',
            multiplier: parseFloat($('demand-multiplier')?.value || '3.0'),
            response_days: parseInt($('demand-deadline')?.value || '30'),
        };

        const autoCalc = $('demand-auto-calc')?.checked;
        const manualAmount = $('demand-amount')?.value?.trim();
        if (!autoCalc && manualAmount) {
            options.demand_amount = parseFloat(manualAmount.replace(/[$,]/g, ''));
        }

        const res = await authFetch(`${API}/api/demand/generate`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({
                run_id: currentSummaryData.run_id,
                options
            })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Generation failed');
        }

        const result = await res.json();

        // Show results
        const resultsDiv = $('demand-results');
        const totalEl = $('demand-total');
        const linksDiv = $('demand-download-links');

        if (totalEl) {
            totalEl.textContent = formatCurrency(result.demand_amount || 0);
        }

        if (linksDiv) {
            linksDiv.innerHTML = '';
            (result.files || []).forEach(f => {
                const link = document.createElement('a');
                link.href = `${API}/api/demand/${currentSummaryData.run_id}/download/${f.filename}`;
                link.className = 'flex items-center justify-between p-3 bg-white rounded-lg border border-emerald-200 hover:border-emerald-400 transition-colors';
                const icon = f.filename.endsWith('.docx') ? '📄' : '📊';
                link.innerHTML = `<span class="text-sm font-medium text-gray-700">${icon} ${esc(f.label)}</span><span class="text-xs text-emerald-600 font-semibold">Download</span>`;
                link.download = f.filename;
                linksDiv.appendChild(link);
            });
        }

        if (resultsDiv) resultsDiv.classList.remove('hidden');
        showToast('Demand package generated successfully', 'success');

        // Track for insights strip and add status card to Actions tab
        toolResults.demand = result;
        updateInsightsStrip();
        updateSubTabBadges();
        renderDemandStatusCard(result);

    } catch (err) {
        showToast(`Demand generation failed: ${err.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}
window.generateDemandPackage = generateDemandPackage;

// ── Licensing ──────────────────────────────────────────────────────────────

async function loadLicenseStatus() {
    try {
        const res = await authFetch(`${API}/api/license/status`);
        if (!res.ok) return;
        const data = await res.json();
        renderLicenseStatus(data);
        // Show demo banner if applicable
        if (data.is_demo) {
            const banner = $('demo-banner');
            if (banner) {
                banner.classList.remove('hidden');
                const daysEl = $('demo-days-left');
                const casesEl = $('demo-cases-left');
                if (daysEl) daysEl.textContent = data.demo_days_remaining ?? '?';
                if (casesEl) casesEl.textContent = data.trial_remaining ?? '0';
                if (data.demo_expired) {
                    banner.className = 'bg-red-50 border-b border-red-200 px-4 py-2 text-center text-sm';
                    const txt = $('demo-banner-text');
                    if (txt) txt.innerHTML = '<span class="text-red-700 font-semibold">Your demo has expired. Purchase a license to continue.</span>';
                }
            }
        }
    } catch { /* ignore */ }
}

function renderLicenseStatus(data) {
    const container = $('license-status');
    if (!container) return;

    const tier = data.tier || 'trial';
    const tierColors = { trial: 'yellow', core: 'blue', pro: 'emerald' };
    const tierLabels = { trial: 'Free Trial', core: 'Core', pro: 'Pro' };
    const color = tierColors[tier] || 'gray';
    const label = tierLabels[tier] || tier;

    let html = `<span class="px-3 py-1 rounded-full text-xs font-bold bg-${color}-100 text-${color}-800">${esc(label)}</span>`;

    if (tier === 'trial') {
        const used = data.trial_cases_used || 0;
        const remaining = data.trial_remaining || 0;
        html += `<p class="text-sm text-gray-600 mt-2">${used} of 3 free cases used (${remaining} remaining)</p>`;
        html += `<div class="w-full bg-gray-200 rounded-full h-2 mt-1"><div class="bg-yellow-500 h-2 rounded-full" style="width:${Math.min(100, (used/3)*100)}%"></div></div>`;
    } else {
        html += `<p class="text-sm text-gray-600 mt-2">Activated: ${data.activated_at ? new Date(data.activated_at).toLocaleDateString() : 'N/A'}</p>`;
    }

    container.innerHTML = html;

    // Show/hide key input
    const keySection = $('license-key-section');
    if (keySection) {
        keySection.classList.toggle('hidden', tier !== 'trial');
    }

    // Update header tier badge
    const headerBadge = $('license-tier-badge');
    if (headerBadge) {
        headerBadge.textContent = label;
        headerBadge.classList.remove('hidden');
    }
}

async function activateLicense() {
    const keyInput = $('license-key-input');
    if (!keyInput) return;
    const key = keyInput.value.trim();
    if (!key) { showToast('Please enter a license key', 'warning'); return; }

    try {
        const res = await authFetch(`${API}/api/license/activate`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ key })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`License activated! Tier: ${data.tier.toUpperCase()}`, 'success');
            loadLicenseStatus();
        } else {
            showToast(data.error || 'Invalid license key', 'error');
        }
    } catch (err) {
        showToast('Activation failed: ' + err.message, 'error');
    }
}
window.activateLicense = activateLicense;

// ── Sub-Tab Navigation (within Results view) ────────────────────────────────

function switchSubTab(tabName) {
    activeSubTab = tabName;
    document.querySelectorAll('.sub-tab-btn').forEach(b => {
        b.classList.remove('sub-tab-active');
        b.classList.add('text-gray-400');
    });
    const btn = document.querySelector(`[data-subtab="${tabName}"]`);
    if (btn) {
        btn.classList.add('sub-tab-active');
        btn.classList.remove('text-gray-400');
    }
    document.querySelectorAll('.sub-tab-panel').forEach(p => p.classList.add('hidden'));
    const panel = $(`subtab-${tabName}`);
    if (panel) panel.classList.remove('hidden');
}

document.querySelectorAll('.sub-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchSubTab(btn.dataset.subtab));
});

function getAnalysisEmptyState() {
    return `<div id="analysis-empty" class="flex flex-col items-center justify-center py-16 text-center">
        <svg class="w-16 h-16 text-gray-200 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="0.75" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        <h4 class="text-sm font-semibold text-gray-500">No Analysis Results Yet</h4>
        <p class="text-xs text-gray-400 mt-1 max-w-xs">Run Negligence Scan, Case Valuation, or Injury Map using the buttons above.</p>
    </div>`;
}

function getActionsEmptyState() {
    return `<div id="actions-empty" class="flex flex-col items-center justify-center py-16 text-center">
        <svg class="w-16 h-16 text-gray-200 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="0.75" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
        <h4 class="text-sm font-semibold text-gray-500">No Action Items Yet</h4>
        <p class="text-xs text-gray-400 mt-1 max-w-xs">Generate tasks or demand packages using the buttons above.</p>
    </div>`;
}

function updateInsightsStrip() {
    const strip = $('insights-strip');
    if (!strip) return;

    const chips = [];

    if (toolResults.valuation) {
        const v = toolResults.valuation;
        chips.push({ label: 'Valuation', value: `${formatCurrency(v.low || 0)}\u2013${formatCurrency(v.high || 0)}`, tab: 'analysis' });
    }
    if (toolResults.negligence) {
        const n = toolResults.negligence;
        const count = n.finding_count || n.findings?.length || 0;
        chips.push({ label: 'Negligence', value: `${count} finding${count !== 1 ? 's' : ''}`, tab: 'analysis' });
    }
    if (toolResults.injuryMap) {
        chips.push({ label: 'Injuries', value: `${toolResults.injuryMap.injury_count || 0} regions`, tab: 'analysis' });
    }
    if (toolResults.tasks) {
        const t = toolResults.tasks;
        const count = t.task_count || t.tasks?.length || 0;
        chips.push({ label: 'Tasks', value: `${count} item${count !== 1 ? 's' : ''}`, tab: 'actions' });
    }
    if (toolResults.demand) {
        chips.push({ label: 'Demand', value: formatCurrency(toolResults.demand.demand_amount || 0), tab: 'actions' });
    }

    if (chips.length === 0) {
        strip.classList.add('hidden');
        return;
    }

    strip.classList.remove('hidden');
    strip.innerHTML = chips.map(c =>
        `<button class="insight-chip" onclick="switchSubTab('${c.tab}')">
            <span class="chip-label">${c.label}:</span>
            <span class="chip-value">${c.value}</span>
        </button>`
    ).join('');
}

function updateSubTabBadges() {
    const analysisCount = [toolResults.valuation, toolResults.negligence, toolResults.injuryMap].filter(Boolean).length;
    const analysisBadge = $('badge-analysis');
    if (analysisBadge) {
        if (analysisCount > 0) {
            analysisBadge.textContent = analysisCount;
            analysisBadge.classList.remove('hidden');
        } else {
            analysisBadge.classList.add('hidden');
        }
    }

    const actionsCount = [toolResults.tasks, toolResults.demand].filter(Boolean).length;
    const actionsBadge = $('badge-actions');
    if (actionsBadge) {
        if (actionsCount > 0) {
            actionsBadge.textContent = actionsCount;
            actionsBadge.classList.remove('hidden');
        } else {
            actionsBadge.classList.add('hidden');
        }
    }
}

function renderDemandStatusCard(result) {
    const existing = document.getElementById('demand-status-card');
    if (existing) existing.remove();

    const card = document.createElement('div');
    card.id = 'demand-status-card';
    card.className = 'p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border-2 border-emerald-300 shadow-lg';
    const files = (result.files || []).map(f => {
        const icon = f.filename.endsWith('.docx') ? '\u{1f4c4}' : '\u{1f4ca}';
        return `<a href="${API}/api/demand/${currentSummaryData.run_id}/download/${f.filename}" download="${f.filename}"
            class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-emerald-200 hover:border-emerald-400 text-xs font-medium text-gray-700 transition-colors">
            ${icon} ${esc(f.label)}</a>`;
    }).join('');
    card.innerHTML = `
        <div class="flex items-center justify-between mb-2">
            <h3 class="text-sm font-bold text-emerald-900 uppercase tracking-wide flex items-center">
                <svg class="w-5 h-5 mr-2 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Demand Package Ready
            </h3>
            <span class="text-lg font-bold text-emerald-700">${formatCurrency(result.demand_amount || 0)}</span>
        </div>
        <div class="flex flex-wrap gap-2">${files}</div>`;

    const actionsPanel = $('subtab-actions');
    if (actionsPanel) {
        const emptyState = $('actions-empty');
        if (emptyState) emptyState.remove();
        actionsPanel.appendChild(card);
    }
}

window.switchSubTab = switchSubTab;

// ── Deposition Summary Module ────────────────────────────────────────────────

let _depoFile = null;
let _depoResult = null;

// File input handler
document.addEventListener('DOMContentLoaded', () => {
    const depoInput = document.getElementById('depo-file-input');
    if (depoInput) {
        depoInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                _depoFile = e.target.files[0];
                const opts = document.getElementById('depo-options');
                const fname = document.getElementById('depo-file-name');
                if (opts) opts.classList.remove('hidden');
                if (fname) fname.textContent = `Selected: ${_depoFile.name} (${((_depoFile.size / 1024) | 0)} KB)`;
            }
        });
    }
    // Drag and drop on depo zone
    const dropZone = document.getElementById('depo-drop-zone');
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('border-blue-500', 'bg-blue-50'); });
        dropZone.addEventListener('dragleave', () => { dropZone.classList.remove('border-blue-500', 'bg-blue-50'); });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-500', 'bg-blue-50');
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                _depoFile = e.dataTransfer.files[0];
                const opts = document.getElementById('depo-options');
                const fname = document.getElementById('depo-file-name');
                if (opts) opts.classList.remove('hidden');
                if (fname) fname.textContent = `Selected: ${_depoFile.name} (${((_depoFile.size / 1024) | 0)} KB)`;
            }
        });
    }
});

async function analyzeDeposition() {
    if (!_depoFile) return alert('Please select a deposition transcript file first.');

    const progress = document.getElementById('depo-progress');
    const results = document.getElementById('depo-results');
    const btn = document.getElementById('btn-analyze-depo');
    if (progress) progress.classList.remove('hidden');
    if (results) results.classList.add('hidden');
    if (btn) btn.disabled = true;

    const formData = new FormData();
    formData.append('file', _depoFile);
    formData.append('deponent_name', (document.getElementById('depo-name') || {}).value || '');
    formData.append('deponent_role', (document.getElementById('depo-role') || {}).value || 'witness');
    formData.append('case_ref', (document.getElementById('depo-case-ref') || {}).value || '');
    formData.append('focus_areas', (document.getElementById('depo-focus') || {}).value || '');

    try {
        const resp = await fetch('/api/deposition/upload', {
            method: 'POST',
            headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {},
            body: formData,
        });
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || 'Analysis failed');

        _depoResult = data.result;
        renderDepositionResults(data.result);
        loadDepositionList();
    } catch (err) {
        alert('Deposition analysis failed: ' + err.message);
    } finally {
        if (progress) progress.classList.add('hidden');
        if (btn) btn.disabled = false;
    }
}

function renderDepositionResults(r) {
    const results = document.getElementById('depo-results');
    if (!results) return;
    results.classList.remove('hidden');

    // Narrative
    const narrative = document.getElementById('depo-narrative');
    if (narrative) narrative.textContent = r.summary_narrative || 'No narrative available.';

    // Stats
    setText('depo-stat-testimony', (r.key_testimony || []).length);
    setText('depo-stat-admissions', (r.admissions || []).length);
    setText('depo-stat-contradictions', (r.contradictions || []).length);
    setText('depo-stat-impeach', (r.impeachment_opportunities || []).length);
    setText('depo-stat-medical', (r.medical_statements || []).length);

    // Key Testimony
    renderDepoSection('depo-key-testimony', 'Key Testimony', r.key_testimony || [], (item) => `
        <div class="mb-3 pb-3 border-b border-gray-100 last:border-0">
            <div class="flex items-start justify-between">
                <p class="text-sm font-semibold text-gray-800">${esc(item.topic || '')}</p>
                <span class="text-xs px-2 py-0.5 rounded-full ${item.favorability === 'favorable' ? 'bg-green-100 text-green-700' : item.favorability === 'unfavorable' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}">${esc(item.favorability || 'neutral')}</span>
            </div>
            <blockquote class="text-sm text-gray-600 italic my-1 pl-3 border-l-2 border-blue-200">"${esc(item.statement || '')}"</blockquote>
            <p class="text-xs text-gray-500">${esc(item.significance || '')}</p>
            ${item.citation ? `<span class="text-xs text-blue-600 font-mono">${esc(item.citation)}</span>` : ''}
        </div>`);

    // Admissions
    renderDepoSection('depo-admissions', 'Admissions', r.admissions || [], (item) => `
        <div class="mb-3 pb-3 border-b border-gray-100 last:border-0">
            <blockquote class="text-sm text-gray-700 italic pl-3 border-l-2 border-green-300">"${esc(item.statement || '')}"</blockquote>
            <p class="text-xs text-gray-500 mt-1">${esc(item.litigation_value || '')}</p>
            ${item.citation ? `<span class="text-xs text-blue-600 font-mono">${esc(item.citation)}</span>` : ''}
        </div>`);

    // Contradictions
    renderDepoSection('depo-contradictions', 'Contradictions', r.contradictions || [], (item) => `
        <div class="mb-3 pb-3 border-b border-gray-100 last:border-0">
            <div class="grid grid-cols-2 gap-2 mb-1">
                <div class="text-xs bg-red-50 p-2 rounded"><span class="font-bold">Statement 1:</span> ${esc(item.statement_1 || '')} <span class="text-blue-600 font-mono">${esc(item.citation_1 || '')}</span></div>
                <div class="text-xs bg-red-50 p-2 rounded"><span class="font-bold">Statement 2:</span> ${esc(item.statement_2 || '')} <span class="text-blue-600 font-mono">${esc(item.citation_2 || '')}</span></div>
            </div>
            <p class="text-xs text-gray-500"><span class="font-semibold">${esc(item.type || '')}</span> — ${esc(item.significance || '')}</p>
        </div>`);

    // Impeachment
    renderDepoSection('depo-impeachment', 'Impeachment Opportunities', r.impeachment_opportunities || [], (item) => `
        <div class="mb-3 pb-3 border-b border-gray-100 last:border-0">
            <p class="text-sm font-semibold text-amber-800">${esc(item.area || '')}</p>
            <p class="text-xs text-gray-600 mt-1">${esc(item.basis || '')}</p>
            <p class="text-xs text-gray-500 mt-1"><span class="font-semibold">Approach:</span> ${esc(item.suggested_approach || '')}</p>
            ${item.citation ? `<span class="text-xs text-blue-600 font-mono">${esc(item.citation)}</span>` : ''}
        </div>`);

    // Medical Statements
    renderDepoSection('depo-medical', 'Medical Statements', r.medical_statements || [], (item) => `
        <div class="mb-3 pb-3 border-b border-gray-100 last:border-0">
            <p class="text-sm font-semibold text-purple-800">${esc(item.topic || '')}</p>
            <p class="text-xs text-gray-600 mt-1">${esc(item.testimony || '')}</p>
            ${item.accuracy_note ? `<p class="text-xs text-amber-600 mt-1">Note: ${esc(item.accuracy_note)}</p>` : ''}
            ${item.citation ? `<span class="text-xs text-blue-600 font-mono">${esc(item.citation)}</span>` : ''}
        </div>`);

    // Timeline
    renderDepoSection('depo-timeline', 'Timeline from Testimony', r.timeline || [], (item) => `
        <div class="flex items-start mb-2">
            <span class="text-xs font-mono bg-gray-100 px-2 py-1 rounded mr-3 whitespace-nowrap">${esc(item.date || 'N/A')}</span>
            <p class="text-xs text-gray-700">${esc(item.event || '')} <span class="text-blue-600 font-mono">${esc(item.citation || '')}</span></p>
        </div>`);

    // Credibility
    const credEl = document.getElementById('depo-credibility');
    if (credEl && r.credibility_assessment) {
        const ca = r.credibility_assessment;
        const color = ca.overall === 'strong' ? 'green' : ca.overall === 'weak' ? 'red' : 'amber';
        credEl.innerHTML = `
            <h4 class="text-sm font-bold text-gray-700 mb-2">Credibility Assessment</h4>
            <div class="flex items-center mb-2"><span class="px-3 py-1 rounded-full text-xs font-bold bg-${color}-100 text-${color}-700">${esc(ca.overall || 'unknown').toUpperCase()}</span></div>
            <p class="text-xs text-gray-600 mb-2">${esc(ca.notes || '')}</p>
            ${(ca.indicators || []).map(i => `<div class="flex items-center text-xs mb-1"><span class="mr-2 ${i.type === 'positive' ? 'text-green-600' : 'text-red-600'}">${i.type === 'positive' ? '+' : '-'}</span>${esc(i.observation || '')}</div>`).join('')}`;
    }

    // Follow-up
    renderDepoSection('depo-follow-up', 'Follow-Up Needed', r.follow_up_needed || [], (item) => `
        <div class="mb-2 pb-2 border-b border-gray-100 last:border-0">
            <p class="text-sm font-semibold text-gray-700">${esc(item.topic || '')}</p>
            <p class="text-xs text-gray-500">${esc(item.reason || '')}</p>
            <p class="text-xs text-blue-700 mt-1">Action: ${esc(item.suggested_action || '')}</p>
        </div>`);
}

function renderDepoSection(id, title, items, renderItem) {
    const el = document.getElementById(id);
    if (!el) return;
    if (!items.length) { el.classList.add('hidden'); return; }
    el.classList.remove('hidden');
    el.innerHTML = `<h4 class="text-sm font-bold text-gray-700 mb-2">${title} (${items.length})</h4>${items.map(renderItem).join('')}`;
}

function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
}

function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

async function loadDepositionList() {
    try {
        const resp = await fetch('/api/deposition/list', { headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {} });
        const data = await resp.json();
        const list = document.getElementById('depo-list');
        if (!list) return;
        const depos = data.depositions || [];
        if (!depos.length) { list.innerHTML = '<p class="text-sm text-gray-400">No depositions analyzed yet.</p>'; return; }
        list.innerHTML = depos.map(d => `
            <div class="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer" onclick="loadDeposition('${esc(d.run_id)}')">
                <div>
                    <p class="text-sm font-medium text-gray-800">${esc(d.deponent || 'Unknown')} <span class="text-xs text-gray-400">(${esc(d.role || 'witness')})</span></p>
                    <p class="text-xs text-gray-400">${d.pages} pages | ${d.key_testimony_count} key findings | ${d.contradictions_count} contradictions | ${d.admissions_count} admissions</p>
                </div>
                <span class="text-xs text-gray-400">${d.analyzed_at ? new Date(d.analyzed_at).toLocaleDateString() : ''}</span>
            </div>`).join('');
    } catch (err) { console.error('Failed to load depositions:', err); }
}

async function loadDeposition(runId) {
    try {
        const resp = await fetch(`/api/deposition/${runId}`, { headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {} });
        const data = await resp.json();
        _depoResult = data;
        renderDepositionResults(data);
    } catch (err) { alert('Failed to load deposition: ' + err.message); }
}

function exportDepoJSON() {
    if (!_depoResult) return alert('No deposition data to export.');
    const blob = new Blob([JSON.stringify(_depoResult, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deposition_analysis_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

// ── Case Management Integrations ─────────────────────────────────────────────

async function loadIntegrations() {
    try {
        const resp = await fetch('/api/integrations/list', { headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {} });
        const data = await resp.json();
        const list = document.getElementById('integrations-list');
        if (!list) return;
        const platforms = data.platforms || [];
        list.innerHTML = platforms.map(p => `
            <div class="border rounded-lg p-4 ${p.enabled ? 'border-green-200 bg-green-50' : ''}">
                <div class="flex items-center justify-between mb-2">
                    <div>
                        <h4 class="text-sm font-bold text-gray-800">${esc(p.name)}</h4>
                        <p class="text-xs text-gray-500">${esc(p.description)}</p>
                    </div>
                    <div class="flex items-center space-x-2">
                        ${p.enabled ? `<span class="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 font-medium">Connected</span>
                            <button onclick="testIntegration('${p.id}')" class="text-xs px-2 py-1 border rounded text-gray-500 hover:bg-gray-50">Test</button>
                            <button onclick="disableIntegration('${p.id}')" class="text-xs px-2 py-1 border rounded text-red-500 hover:bg-red-50">Disable</button>`
                            : `<button onclick="showIntegrationConfig('${p.id}')" class="text-xs px-3 py-1.5 bg-blue-900 text-white rounded hover:bg-blue-800">Configure</button>`}
                    </div>
                </div>
                ${p.enabled && p.push_count ? `<p class="text-xs text-gray-400">${p.push_count} pushes | Last: ${p.last_push ? new Date(p.last_push).toLocaleDateString() : 'Never'}</p>` : ''}
                <div id="integration-config-${p.id}" class="hidden mt-3 border-t pt-3">
                    ${p.config_fields.map(f => `
                        <div class="settings-field mb-2">
                            <label>${esc(f.label)}${f.required ? ' *' : ''}</label>
                            <input type="${f.type === 'password' ? 'password' : 'text'}" id="int-${p.id}-${f.key}" placeholder="${esc(f.placeholder || f.default || '')}" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg">
                        </div>`).join('')}
                    <div class="flex justify-end space-x-2 mt-2">
                        <button onclick="document.getElementById('integration-config-${p.id}').classList.add('hidden')" class="text-xs px-3 py-1.5 border rounded text-gray-500 hover:bg-gray-50">Cancel</button>
                        <button onclick="saveIntegration('${p.id}')" class="text-xs px-3 py-1.5 bg-blue-900 text-white rounded hover:bg-blue-800">Save & Enable</button>
                    </div>
                </div>
            </div>`).join('');
    } catch (err) { console.error('Failed to load integrations:', err); }
}

function showIntegrationConfig(platformId) {
    const el = document.getElementById(`integration-config-${platformId}`);
    if (el) el.classList.toggle('hidden');
}

async function saveIntegration(platformId) {
    const fields = document.querySelectorAll(`[id^="int-${platformId}-"]`);
    const settings = {};
    fields.forEach(f => {
        const key = f.id.replace(`int-${platformId}-`, '');
        if (f.value) settings[key] = f.value;
    });

    try {
        const resp = await fetch('/api/integrations/configure', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}) },
            body: JSON.stringify({ platform_id: platformId, settings }),
        });
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || 'Configuration failed');
        loadIntegrations();
    } catch (err) { alert('Configuration failed: ' + err.message); }
}

async function testIntegration(platformId) {
    try {
        const resp = await fetch('/api/integrations/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}) },
            body: JSON.stringify({ platform_id: platformId }),
        });
        const data = await resp.json();
        alert(data.ok ? 'Connection successful!' : `Connection failed: ${data.error || 'Unknown error'}`);
    } catch (err) { alert('Test failed: ' + err.message); }
}

async function disableIntegration(platformId) {
    if (!confirm('Disable this integration?')) return;
    try {
        await fetch('/api/integrations/disable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}) },
            body: JSON.stringify({ platform_id: platformId }),
        });
        loadIntegrations();
    } catch (err) { alert('Failed to disable: ' + err.message); }
}

// ── Missing Window Exports ───────────────────────────────────────────────────
// Functions used in onclick handlers must be on window scope

window.viewSummary = viewSummary;
window.showContactDetail = showContactDetail;
window.closeModal = closeModal;
window.deleteSummary = deleteSummary;
window.clearAllSummaries = clearAllSummaries;
window.scrollToSection = scrollToSection;
window.downloadBillingCSV = downloadBillingCSV;
window.toggleFileSelect = toggleFileSelect;
window.toggleGroupSelect = toggleGroupSelect;
window.clearFileSelection = clearFileSelection;
window.applyBulkCase = applyBulkCase;
window.startCaseRename = startCaseRename;
window.finishCaseRename = finishCaseRename;
window.cancelCaseRename = cancelCaseRename;
window.autoDetectCases = autoDetectCases;
window.acceptCaseSuggestion = acceptCaseSuggestion;
window.loadFilesList = loadFilesList;
window.goToFilesPage = function(page) { filesPage = page; loadFilesList(); };
window.analyzeDeposition = analyzeDeposition;
window.loadDepositionList = loadDepositionList;
window.loadDeposition = loadDeposition;
window.exportDepoJSON = exportDepoJSON;
window.loadIntegrations = loadIntegrations;
window.showIntegrationConfig = showIntegrationConfig;
window.saveIntegration = saveIntegration;
window.testIntegration = testIntegration;
window.disableIntegration = disableIntegration;

// ── Init ────────────────────────────────────────────────────────────────────

fetchCsrfToken();
checkSystemHealth();
refreshDashboard();
loadPipelineRuns();   // Pre-load pipeline data so it's ready when tab is opened
loadLicenseStatus();  // Load license state for settings tab
loadIntegrations();   // Load integrations config for settings tab
setInterval(refreshDashboard, 30000);
setInterval(checkSystemHealth, 60000);
