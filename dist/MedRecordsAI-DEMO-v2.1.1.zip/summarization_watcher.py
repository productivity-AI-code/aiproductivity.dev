"""
summarization_watcher.py -- Monitors vault/incoming/ for new medical records
and triggers the 4-agent summarization pipeline with JSON validation gates.

Pipeline: Ingestion → Privacy → Summarizer → Auditor
Each stage outputs validated JSON. Schema validation gates prevent malformed
data from reaching the next stage.

Usage:
  python summarization_watcher.py             # Run continuously (PM2)
  python summarization_watcher.py --once      # Single scan and exit
  python summarization_watcher.py --dry-run   # Report without processing
"""

import argparse
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import yaml

from pipeline_schemas import (
    extract_json_from_response,
    validate_ingestion_output,
    validate_privacy_output,
    validate_summary_output,
    validate_audit_output,
    build_stage_prompt,
    INGESTION_SCHEMA_EXAMPLE,
    PRIVACY_SCHEMA_EXAMPLE,
    SUMMARY_SCHEMA_EXAMPLE,
    AUDIT_SCHEMA_EXAMPLE,
)

BASE_DIR = Path(__file__).parent
INCOMING_DIR = BASE_DIR / "vault" / "incoming"
PROCESSING_DIR = BASE_DIR / "vault" / "processing"
PROCESSED_DIR = BASE_DIR / "vault" / "processed"
SUMMARIES_DIR = BASE_DIR / "vault" / "summaries"
AUDIT_DIR = BASE_DIR / "vault" / "audit"
LEDGER_FILE = BASE_DIR / "vault" / "processed_files.json"
PIPELINE_STATUS_DIR = BASE_DIR / "vault" / "pipeline_status"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("summarization_watcher")

# Pipeline stage definitions
PIPELINE_STAGES = [
    {
        "name": "ingestion",
        "agent": "ingestion",
        "task": "Parse this medical document into structured JSON for litigation support analysis. Extract all sections, classify each section by type (e.g., encounter notes, labs, imaging, vitals, discharge). Preserve clinical detail — attorneys need exact findings, dates, and provider names. Output ONLY valid JSON matching the schema.",
        "validator": validate_ingestion_output,
        "schema_example": INGESTION_SCHEMA_EXAMPLE,
    },
    {
        "name": "privacy",
        "agent": "privacy",
        "task": "De-identify this medical record for HIPAA-compliant litigation review. Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens. Count every redaction. Output ONLY valid JSON matching the schema.",
        "validator": validate_privacy_output,
        "schema_example": PRIVACY_SCHEMA_EXAMPLE,
    },
    {
        "name": "summarizer",
        "agent": "summarizer",
        "task": "Produce a litigation-ready clinical summary of this de-identified medical record. This system is used by personal injury attorneys to analyze patient medical records. Every claim must cite its source section. Build a master chronology of all clinical events. Identify smoking-gun quotes, contradictions, discovery deficiencies, and timeline gaps. Include confidence scores. Additionally, extract ALL billing and cost information found in the records into a 'billing_data' object. For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. Calculate subtotals per provider, total past medical costs, and any future medical cost estimates with the basis for those estimates. If no billing data is found, output billing_data with an empty providers array and totals of 0.\n\nALERTS & GAP DETECTION (REQUIRED):\nYou MUST also generate an 'alerts' array at the top level of your JSON output. These alerts serve as proactive intelligence for the attorney — flagging risks, gaps, and strategic vulnerabilities that could impact case value BEFORE opposing counsel finds them.\n\nGenerate between 3 and 10 alerts per case. Each alert must be one of these types:\n  - treatment_gap: Periods where expected treatment was absent (e.g., no PT visits for 30+ days)\n  - missing_provider: Referenced providers whose records are not in the file\n  - pre_existing: Pre-existing conditions that defense will use to argue causation\n  - inconsistency: Contradictions between records, statements, or clinical findings\n  - compliance_issue: Missed appointments, non-compliance with treatment plans, AMA discharges\n  - prior_injury: Prior injuries to the same body region that weaken causation arguments\n  - medication_change: Significant medication changes (escalation, new narcotics, discontinuation)\n\nEach alert object MUST have these fields:\n  - type: one of the types listed above\n  - severity: 'high' | 'medium' | 'low'\n  - title: concise title (e.g., '45-Day Physical Therapy Gap')\n  - description: detailed explanation of the alert and its litigation significance\n  - impact_estimate: how this may affect settlement value or case strategy\n  - recommended_action: specific next step for the attorney or paralegal\n  - citation: section reference (e.g., 'sec_003:p7')\n  - date_range: relevant date range if applicable (e.g., '04/15/2024 - 05/30/2024'), or null\n\nPrioritize HIGH severity alerts for issues that directly threaten case value. Think like opposing counsel: what weaknesses would THEY exploit?\n\nOutput ONLY valid JSON matching the schema.",
        "validator": validate_summary_output,
        "schema_example": SUMMARY_SCHEMA_EXAMPLE,
    },
    {
        "name": "auditor",
        "agent": "auditor",
        "task": "Create a HIPAA compliance audit entry for this pipeline run. Reference files ONLY by SHA-256 hash. Include NO PHI. Determine compliance status. Output ONLY valid JSON matching the schema.",
        "validator": validate_audit_output,
        "schema_example": AUDIT_SCHEMA_EXAMPLE,
    },
]


# ── Configuration ────────────────────────────────────────────────────────────

def load_config():
    config_path = BASE_DIR / "config.yaml"
    if not config_path.exists():
        logger.warning("config.yaml not found, using defaults")
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


# ── File Ledger ──────────────────────────────────────────────────────────────

def load_ledger():
    if LEDGER_FILE.exists():
        with open(LEDGER_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_ledger(ledger):
    tmp = LEDGER_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(ledger, f, indent=2)
    tmp.replace(LEDGER_FILE)


# ── File Hashing ─────────────────────────────────────────────────────────────

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ── Pipeline Status Tracking ─────────────────────────────────────────────────

def update_pipeline_status(run_id, stage, status, details=None, source_file=None, case_ref=None):
    """Write pipeline status for UI polling."""
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f"{run_id}.json"

    if status_file.exists():
        with open(status_file, encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {
            "run_id": run_id,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "status": "running",
            "stages": {},
        }

    if source_file and "source_file" not in data:
        data["source_file"] = source_file
    if case_ref and "case_ref" not in data:
        data["case_ref"] = case_ref

    data["stages"][stage] = {
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "details": details,
    }

    if status == "failed":
        data["status"] = "failed"
    elif stage == "auditor" and status == "completed":
        data["status"] = "completed"
        data["completed_at"] = datetime.now(timezone.utc).isoformat()

    with open(status_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ── Agent Dispatch ───────────────────────────────────────────────────────────

def dispatch_agent(agent_name, task, context_json, config, combined=False):
    """
    Dispatch a task to an agent via dispatch.py and return the parsed output.
    Task is written to a temp file to avoid Windows command-line length limits.
    Note: context_json is NOT passed separately because build_stage_prompt()
    already embeds the full input data in the task string. Passing it twice
    would double the prompt size and cause Claude API timeouts on large cases.
    If combined=True, uses the higher combined_timeout/combined_max_tokens config.
    """
    # Write task to a temp file within the project (dispatch.py requires this)
    tmp_dir = BASE_DIR / "vault" / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    task_file = tmp_dir / f"task_{agent_name}_{ts}.txt"

    try:
        task_file.write_text(task, encoding="utf-8")
    except Exception as e:
        logger.error("Failed to write temp files for %s: %s", agent_name, e)
        return None

    cmd = [
        sys.executable, str(BASE_DIR / "dispatch.py"),
        "--agent", agent_name,
        "--task-file", str(task_file),
    ]

    logger.info("Dispatching to %s...", agent_name)

    try:
        backend = config.get("llm_backend", "ollama")
        if backend == "claude":
            cfg_timeout = config.get("claude", {}).get("combined_timeout" if combined else "timeout", 180)
            timeout = cfg_timeout + 120  # buffer for subprocess overhead
        else:
            timeout = config.get("ollama", {}).get("timeout", 900) + 60

        # On Windows, hide the subprocess console window
        kwargs = {}
        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = 0  # SW_HIDE
            kwargs["startupinfo"] = startupinfo
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW

        env = os.environ.copy()
        if combined:
            env["COMBINED_PIPELINE"] = "1"

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(BASE_DIR),
            env=env,
            **kwargs,
        )

        if result.returncode != 0:
            stderr_msg = result.stderr[-500:] if result.stderr else "no stderr"
            stdout_tail = result.stdout[-500:] if result.stdout else "no stdout"
            logger.error("Agent %s failed (rc=%d): %s", agent_name, result.returncode, stderr_msg)
            if stdout_tail and stdout_tail != "no stdout":
                logger.error("Agent %s stdout: %s", agent_name, stdout_tail)
            return None

        # Find the task output file from dispatch output
        output_path = None
        for line in result.stdout.split("\n"):
            if "Output saved to:" in line:
                output_path = line.split("Output saved to:")[-1].strip()
                break

        if output_path and Path(output_path).exists():
            raw_output = Path(output_path).read_text(encoding="utf-8")
            return raw_output
        else:
            logger.error("Agent %s completed but output file not found", agent_name)
            return None

    except subprocess.TimeoutExpired:
        logger.error("Agent %s timed out", agent_name)
        return None
    except Exception as e:
        logger.error("Agent %s dispatch error: %s", agent_name, e)
        return None
    finally:
        # Clean up temp file
        try:
            task_file.unlink(missing_ok=True)
        except Exception:
            pass


# ── Document Status Sync ─────────────────────────────────────────────────────

def _update_document_status(file_path, **kwargs):
    """Update the documents table for a file being processed.
    Matches by original_path or current_path."""
    try:
        from db import transaction as db_transaction
        file_str = str(file_path)
        sets = []
        params = []
        for key, val in kwargs.items():
            sets.append(f"{key} = ?")
            params.append(val)
        if not sets:
            return
        sets.append("updated_at = ?")
        params.append(datetime.now(timezone.utc).isoformat())
        params.extend([file_str, file_str])
        with db_transaction() as conn:
            conn.execute(
                f"UPDATE documents SET {', '.join(sets)} WHERE original_path = ? OR current_path = ?",
                params,
            )
    except Exception as e:
        logger.debug("Document status sync skipped: %s", e)


def _register_summary_document(summary_file, run_id, source_file_path):
    """Insert the summary JSON as a document row under the same case_ref as its source file."""
    try:
        from db import transaction as db_transaction
        source_str = str(source_file_path)
        with db_transaction() as conn:
            # Look up the source document's case_ref
            row = conn.execute(
                "SELECT case_ref FROM documents WHERE original_path = ? OR current_path = ?",
                (source_str, source_str),
            ).fetchone()
            case_ref = row["case_ref"] if row else None

            # Avoid duplicates on reprocess
            existing = conn.execute(
                "SELECT id FROM documents WHERE run_id = ? AND category = 'summary'",
                (run_id,),
            ).fetchone()
            if existing:
                logger.debug("Summary document already registered for run %s", run_id)
                return

            now = datetime.now(timezone.utc).isoformat()
            summary_path = str(summary_file)
            conn.execute(
                """INSERT INTO documents
                   (filename, original_path, current_path, file_size, extension,
                    vault_zone, status, case_ref, category, run_id,
                    upload_source, created_at, updated_at, processed_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    f"{run_id}_summary.json",
                    summary_path, summary_path,
                    summary_file.stat().st_size if summary_file.exists() else 0,
                    ".json",
                    "processed", "completed",
                    case_ref, "summary", run_id,
                    "api", now, now, now,
                ),
            )
    except Exception as e:
        logger.debug("Summary document registration skipped: %s", e)


def _read_file_content(file_path):
    """Read file content as text, with special handling for PDF, image, and Excel files.
    Returns a tuple of (text_content, page_map). page_map is a list of dicts for PDFs,
    or None for other file types."""
    ext = file_path.suffix.lower()
    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(str(file_path))
            pages = []
            page_map = []
            running_char = 0
            for i, page in enumerate(doc, 1):
                text = page.get_text().strip()
                if text:
                    header = f"--- Page {i} ---\n"
                    page_text = header + text
                    start_char = running_char
                    end_char = running_char + len(page_text)
                    page_map.append({
                        "page": i,
                        "start_char": start_char,
                        "end_char": end_char,
                        "text_preview": text[:100],
                    })
                    pages.append(page_text)
                    running_char = end_char + 2  # account for "\n\n" join separator
            doc.close()
            return (
                "\n\n".join(pages) if pages else "(PDF contained no extractable text)",
                page_map if page_map else None,
            )
        except ImportError:
            logger.warning("PyMuPDF not installed; cannot extract PDF text")
            return "(PDF file — install PyMuPDF to extract content)", None
        except Exception as e:
            logger.warning("PDF extraction failed for %s: %s", file_path.name, e)
            return f"(PDF extraction error: {e})", None
    elif ext in (".png", ".jpg", ".jpeg", ".tiff", ".tif"):
        return f"(Image file: {file_path.name} — requires Vision API for text extraction)", None
    elif ext in (".dcm", ".dicom"):
        return f"(DICOM file: {file_path.name} — medical imaging file)", None
    elif ext == ".xlsx":
        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
            parts = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = []
                for row in ws.iter_rows(values_only=True):
                    rows.append("\t".join(str(c) if c is not None else "" for c in row))
                if rows:
                    parts.append(f"--- Sheet: {sheet_name} ---\n" + "\n".join(rows))
            wb.close()
            return ("\n\n".join(parts) if parts else "(empty workbook)"), None
        except ImportError:
            logger.warning("openpyxl not installed; cannot read .xlsx files")
            return "(Excel .xlsx file — install openpyxl to extract content)", None
    elif ext == ".xls":
        try:
            import xlrd
            wb = xlrd.open_workbook(str(file_path))
            parts = []
            for sheet in wb.sheets():
                rows = []
                for rx in range(sheet.nrows):
                    rows.append("\t".join(str(sheet.cell_value(rx, cx)) for cx in range(sheet.ncols)))
                if rows:
                    parts.append(f"--- Sheet: {sheet.name} ---\n" + "\n".join(rows))
            return ("\n\n".join(parts) if parts else "(empty workbook)"), None
        except ImportError:
            logger.warning("xlrd not installed; cannot read .xls files")
            return "(Excel .xls file — install xlrd to extract content)", None
    else:
        try:
            return file_path.read_text(encoding="utf-8", errors="replace"), None
        except Exception:
            with open(file_path, "rb") as f:
                return f.read().decode("utf-8", errors="replace"), None


# ── Pipeline Runner ──────────────────────────────────────────────────────────

def run_pipeline(file_path, config, run_id=None, dry_run=False):
    """
    Run the 4-stage summarization pipeline on a single file.
    Each stage outputs JSON validated by schema gates.
    Returns the summary JSON or None on failure.
    """
    file_path = Path(file_path)
    file_hash = file_sha256(file_path)
    if not run_id:
        run_id = f"pipeline_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{file_hash[:8]}"

    logger.info("Pipeline %s starting for: %s", run_id, file_path.name)

    # Update document status to processing
    _update_document_status(file_path, status="processing", vault_zone="processing", run_id=run_id)

    # Move to processing directory
    processing_path = PROCESSING_DIR / f"{run_id}_{file_path.name}"
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)

    if not dry_run:
        shutil.copy2(file_path, processing_path)

    # Read raw file content for ingestion stage
    raw_content, source_page_map = _read_file_content(file_path)

    # Initial input for ingestion: raw text + metadata
    pipeline_input = {
        "source_file": file_path.name,
        "file_hash_sha256": file_hash,
        "raw_content": raw_content[:200000],  # Raised limit for PDF extraction
        "file_size_bytes": file_path.stat().st_size,
    }

    stage_outputs = {}
    current_input = pipeline_input

    # Load RLHF feedback to enhance summarizer prompt
    feedback_context = _load_rlhf_feedback()

    for stage in PIPELINE_STAGES:
        stage_name = stage["name"]
        logger.info("  Stage: %s", stage_name)

        if dry_run:
            logger.info("  [DRY RUN] Would dispatch to %s", stage["agent"])
            update_pipeline_status(run_id, stage_name, "skipped", "dry run")
            continue

        update_pipeline_status(run_id, stage_name, "running",
                               source_file=file_path.name)

        # Build the prompt with JSON schema enforcement
        task_with_schema = stage["task"] + "\n\n" + build_stage_prompt(
            stage_name, current_input, stage["schema_example"]
        )

        # Inject RLHF feedback context for the summarizer stage
        if stage_name == "summarizer" and feedback_context:
            task_with_schema += "\n\n" + feedback_context

        # Dispatch to agent
        raw_output = dispatch_agent(stage["agent"], task_with_schema, current_input, config)

        if not raw_output:
            logger.error("  Stage %s: No output from agent", stage_name)
            update_pipeline_status(run_id, stage_name, "failed", "No output from agent")
            _move_to_failed(processing_path, run_id)
            return None

        # Extract JSON from LLM response
        try:
            parsed_output = extract_json_from_response(raw_output)
        except ValueError as e:
            logger.error("  Stage %s: Invalid JSON: %s", stage_name, e)

            # Retry once with correction prompt
            logger.info("  Retrying %s with JSON correction prompt...", stage_name)
            retry_task = (
                f"Your previous output was not valid JSON. Error: {e}\n"
                f"Please output ONLY a valid JSON object matching the schema. "
                f"No markdown, no explanation."
            )
            retry_output = dispatch_agent(stage["agent"], retry_task, current_input, config)
            if retry_output:
                try:
                    parsed_output = extract_json_from_response(retry_output)
                except ValueError as e2:
                    logger.error("  Stage %s: Retry also failed: %s", stage_name, e2)
                    update_pipeline_status(run_id, stage_name, "failed", f"Invalid JSON after retry: {e2}")
                    _move_to_failed(processing_path, run_id)
                    return None
            else:
                update_pipeline_status(run_id, stage_name, "failed", f"Invalid JSON: {e}")
                _move_to_failed(processing_path, run_id)
                return None

        # Validate output against schema
        validation_errors = stage["validator"](parsed_output)
        if validation_errors:
            # Log warnings but don't block for non-critical errors
            critical = [e for e in validation_errors if "CRITICAL" in e]
            warnings = [e for e in validation_errors if "CRITICAL" not in e]

            if warnings:
                logger.warning("  Stage %s validation warnings: %s", stage_name, warnings)

            if critical:
                logger.error("  Stage %s CRITICAL validation errors: %s", stage_name, critical)
                update_pipeline_status(run_id, stage_name, "failed", f"Validation: {critical}")
                _move_to_failed(processing_path, run_id)
                return None

        stage_outputs[stage_name] = parsed_output
        current_input = parsed_output
        update_pipeline_status(run_id, stage_name, "completed")
        logger.info("  Stage %s: PASSED", stage_name)

    if dry_run:
        return None

    # Save summary
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f"{run_id}_summary.json"
    summary_data = {
        "run_id": run_id,
        "source_file": file_path.name,
        "source_file_hash": file_hash,
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "ingestion": stage_outputs.get("ingestion"),
        "privacy": stage_outputs.get("privacy"),
        "summary": stage_outputs.get("summarizer"),
        "audit": stage_outputs.get("auditor"),
    }
    if source_page_map:
        summary_data["source_pages"] = source_page_map
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2)
    logger.info("Summary saved: %s", summary_file)

    # Save audit entry
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f"{run_id}_audit.json"
    audit_entry = stage_outputs.get("auditor", {})
    with open(audit_file, "w", encoding="utf-8") as f:
        json.dump(audit_entry, f, indent=2)

    # Move file to processed
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    processed_path = PROCESSED_DIR / f"{run_id}_{file_path.name}"
    if processing_path.exists():
        shutil.move(str(processing_path), str(processed_path))

    # Update document status to completed
    _update_document_status(
        file_path, status="completed", vault_zone="processed",
        current_path=str(processed_path),
        summary_file=f"{run_id}_summary.json",
        processed_at=datetime.now(timezone.utc).isoformat(),
    )

    # Register the summary file as a case document
    _register_summary_document(summary_file, run_id, file_path)

    return summary_data


def run_pipeline_thorough(file_paths, config, run_id=None, case_ref=None, mode="thorough"):
    """
    Thorough processing pipeline for large/complex cases.
    Preprocesses → chunks → per-chunk pipeline → merge → audit.

    Designed for 500+ page cases with duplicates and handwritten notes.
    """
    from document_preprocessor import preprocess_case, PreprocessingResult

    file_paths = [Path(p) for p in file_paths]
    if not run_id:
        run_id = f"thorough_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"

    logger.info("Thorough pipeline %s starting for %d files (case_ref=%s, mode=%s)",
                run_id, len(file_paths), case_ref, mode)

    modes_cfg = config.get("processing_modes", {}).get("thorough", {})

    # Mark all files as processing
    for fp in file_paths:
        _update_document_status(fp, status="processing", vault_zone="processing", run_id=run_id)

    # Copy files to processing directory
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)
    processing_paths = []
    for fp in file_paths:
        dest = PROCESSING_DIR / f"{run_id}_{fp.name}"
        shutil.copy2(fp, dest)
        processing_paths.append(dest)

    # ── Phase 1: Preprocessing ──────────────────────────────────────────────
    logger.info("Phase 1: Preprocessing...")
    _update_thorough_status(run_id, "preprocessing", "running")

    try:
        preprocess_result = preprocess_case(
            file_paths, config, mode=mode, transcribe=True
        )
    except Exception as e:
        logger.error("Preprocessing failed: %s", e)
        _update_thorough_status(run_id, "preprocessing", "failed", str(e))
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None

    _update_thorough_status(run_id, "preprocessing", "completed", {
        "total_pages": preprocess_result.total_pages,
        "unique_pages": preprocess_result.unique_pages,
        "duplicate_pages": preprocess_result.duplicate_pages,
        "blank_pages": preprocess_result.blank_pages,
        "noise_pages": preprocess_result.noise_pages,
        "handwritten_pages": preprocess_result.handwritten_pages,
        "clinical_pages": preprocess_result.clinical_pages,
        "chunks": len(preprocess_result.chunks),
        "dedup_stats": preprocess_result.dedup_stats,
    })

    chunks = preprocess_result.chunks
    if not chunks:
        logger.warning("No processable content found after preprocessing")
        _update_thorough_status(run_id, "preprocessing", "failed", "No processable content")
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None

    logger.info("Preprocessing complete: %d chunks from %d unique pages (of %d total)",
                len(chunks), preprocess_result.unique_pages, preprocess_result.total_pages)

    # ── Phase 2: Per-Chunk Pipeline ─────────────────────────────────────────
    logger.info("Phase 2: Per-chunk processing (%d chunks)...", len(chunks))
    chunk_summaries = []
    chunk_contexts = []  # Running context for continuity between chunks
    feedback_context = _load_rlhf_feedback()

    for i, chunk in enumerate(chunks):
        chunk_id = chunk["chunk_id"]
        chunk_num = i + 1
        total_chunks = len(chunks)

        logger.info("  Processing chunk %d/%d (%d pages)...", chunk_num, total_chunks, chunk["page_count"])
        _update_thorough_status(run_id, "chunks", "running", {
            "total": total_chunks,
            "completed": i,
            "current": chunk_num,
            "failed": 0,
        })

        # Build context header for continuity
        context_header = _build_chunk_context(chunk_num, total_chunks, chunk_contexts)

        # Run 3-stage pipeline per chunk: ingestion → privacy → summarizer
        chunk_result = _run_chunk_pipeline(
            chunk, chunk_num, total_chunks, context_header,
            config, run_id, feedback_context, modes_cfg,
        )

        if chunk_result:
            chunk_summaries.append(chunk_result)
            # Extract key info for context continuity
            chunk_contexts.append(_extract_chunk_context(chunk_result, chunk_num))
            logger.info("  Chunk %d/%d: PASSED", chunk_num, total_chunks)
        else:
            logger.warning("  Chunk %d/%d: FAILED (continuing with remaining chunks)", chunk_num, total_chunks)

    _update_thorough_status(run_id, "chunks", "completed", {
        "total": len(chunks),
        "completed": len(chunk_summaries),
        "failed": len(chunks) - len(chunk_summaries),
    })

    if not chunk_summaries:
        logger.error("All chunks failed — aborting pipeline")
        _update_thorough_status(run_id, "merge", "failed", "No chunk summaries to merge")
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None

    # ── Phase 3: Merge ──────────────────────────────────────────────────────
    logger.info("Phase 3: Merging %d chunk summaries...", len(chunk_summaries))
    _update_thorough_status(run_id, "merge", "running")

    merged_summary = _merge_chunk_summaries(chunk_summaries, config, run_id, case_ref, modes_cfg)

    if not merged_summary:
        logger.error("Merge failed")
        _update_thorough_status(run_id, "merge", "failed", "Merge stage failed")
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None

    _update_thorough_status(run_id, "merge", "completed")
    logger.info("Phase 3: Merge PASSED")

    # ── Phase 4: Audit ──────────────────────────────────────────────────────
    logger.info("Phase 4: Audit...")
    update_pipeline_status(run_id, "auditor", "running")

    combined_hashes = [file_sha256(fp) for fp in file_paths]
    combined_hash = hashlib.sha256("|".join(combined_hashes).encode()).hexdigest()

    audit_input = {
        "pipeline_run_id": run_id,
        "source_file_hash": combined_hash,
        "stages_completed": ["preprocessing", "ingestion", "privacy", "summarizer", "merge"],
        "mode": "thorough",
        "total_pages": preprocess_result.total_pages,
        "unique_pages": preprocess_result.unique_pages,
        "chunks_processed": len(chunk_summaries),
        "phi_summary": merged_summary.get("privacy", {}).get("phi_summary", {}),
        "verification": merged_summary.get("summary", {}).get("verification", merged_summary.get("verification", {})),
    }

    audit_task = (
        f"Create a HIPAA compliance audit entry for this THOROUGH pipeline run. "
        f"This was a large case ({preprocess_result.total_pages} pages, {len(chunks)} chunks). "
        f"Reference files ONLY by SHA-256 hash. Include NO PHI. "
        f"Output ONLY valid JSON matching the schema."
    )
    audit_prompt = audit_task + "\n\n" + build_stage_prompt("auditor", audit_input, AUDIT_SCHEMA_EXAMPLE)
    raw_audit = dispatch_agent("auditor", audit_prompt, audit_input, config)

    audit_output = None
    if raw_audit:
        try:
            audit_output = extract_json_from_response(raw_audit)
            validation_errors = validate_audit_output(audit_output)
            critical = [e for e in (validation_errors or []) if "CRITICAL" in e]
            if critical:
                logger.warning("Audit validation critical errors: %s", critical)
        except ValueError as e:
            logger.warning("Audit JSON parse failed: %s", e)

    update_pipeline_status(run_id, "auditor", "completed")

    # ── Build source page maps for PDF files ─────────────────────────────────
    thorough_page_maps = {}
    for fp in file_paths:
        _, file_page_map = _read_file_content(fp)
        if file_page_map:
            thorough_page_maps[fp.name] = file_page_map

    # ── Save Results ────────────────────────────────────────────────────────
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f"{run_id}_summary.json"

    summary_data = {
        "run_id": run_id,
        "mode": "thorough",
        "source_file": f"CASE: {case_ref or run_id} ({len(file_paths)} files, {preprocess_result.total_pages} pages)",
        "source_files": [fp.name for fp in file_paths],
        "case_ref": case_ref,
        "source_file_hash": combined_hash,
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "preprocessing": {
            "total_pages": preprocess_result.total_pages,
            "unique_pages": preprocess_result.unique_pages,
            "duplicate_pages": preprocess_result.duplicate_pages,
            "blank_pages": preprocess_result.blank_pages,
            "handwritten_pages": preprocess_result.handwritten_pages,
            "chunks_processed": len(chunk_summaries),
            "chunks_total": len(chunks),
            "dedup_stats": preprocess_result.dedup_stats,
        },
        "ingestion": merged_summary.get("ingestion"),
        "privacy": merged_summary.get("privacy"),
        "summary": merged_summary.get("summary"),
        "audit": audit_output,
    }
    if thorough_page_maps:
        summary_data["source_pages"] = thorough_page_maps

    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2)
    logger.info("Thorough summary saved: %s", summary_file)

    # Save audit entry
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f"{run_id}_audit.json"
    with open(audit_file, "w", encoding="utf-8") as f:
        json.dump(audit_output or {}, f, indent=2)

    # Move files to processed
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for i, fp in enumerate(file_paths):
        processed_path = PROCESSED_DIR / f"{run_id}_{fp.name}"
        pp = processing_paths[i]
        if pp.exists():
            shutil.move(str(pp), str(processed_path))
        _update_document_status(
            fp, status="completed", vault_zone="processed",
            current_path=str(processed_path),
            summary_file=f"{run_id}_summary.json",
            processed_at=datetime.now(timezone.utc).isoformat(),
        )

    _register_summary_document(summary_file, run_id, file_paths[0])

    # Final status update
    _update_thorough_status(run_id, "pipeline", "completed")

    logger.info("Thorough pipeline %s complete: %d pages → %d chunks → merged summary",
                run_id, preprocess_result.total_pages, len(chunk_summaries))

    return summary_data


# ── Thorough Pipeline Helpers ───────────────────────────────────────────────

def _update_thorough_status(run_id, phase, status, details=None):
    """Write extended pipeline status for thorough mode UI polling."""
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f"{run_id}.json"

    if status_file.exists():
        with open(status_file, encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {
            "run_id": run_id,
            "mode": "thorough",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "status": "running",
            "stages": {},
        }

    data[phase] = {
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "details": details,
    }

    if status == "failed" and phase != "chunks":
        data["status"] = "failed"
    elif phase == "pipeline" and status == "completed":
        data["status"] = "completed"
        data["completed_at"] = datetime.now(timezone.utc).isoformat()

    with open(status_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _build_chunk_context(chunk_num, total_chunks, previous_contexts):
    """Build a context header for chunk continuity."""
    if chunk_num == 1:
        return f"You are processing CHUNK 1 of {total_chunks}. This is the first chunk."

    # Summarize what we've seen so far
    all_dates = []
    all_diagnoses = []
    summaries = []
    for ctx in previous_contexts:
        all_dates.extend(ctx.get("dates", []))
        all_diagnoses.extend(ctx.get("diagnoses", []))
        if ctx.get("summary"):
            summaries.append(ctx["summary"])

    header = f"You are processing CHUNK {chunk_num} of {total_chunks}.\n\n"
    header += "PRIOR CHUNKS CONTEXT (do NOT repeat this information, focus on NEW data in this chunk):\n"

    if all_dates:
        header += f"- Encounter dates seen so far: {', '.join(sorted(set(all_dates))[:20])}\n"
    if all_diagnoses:
        header += f"- Diagnoses seen so far: {', '.join(sorted(set(all_diagnoses))[:15])}\n"
    if summaries:
        combined = " | ".join(summaries[-3:])  # Last 3 chunk summaries
        if len(combined) > 500:
            combined = combined[:500] + "..."
        header += f"- Recent chunk summaries: {combined}\n"

    return header


def _extract_chunk_context(chunk_result, chunk_num):
    """Extract key context from a processed chunk for continuity."""
    context = {"chunk": chunk_num, "dates": [], "diagnoses": [], "summary": ""}

    summary = chunk_result.get("summary", {})
    if isinstance(summary, dict):
        s = summary.get("summary", {})
        if isinstance(s, dict):
            # Extract dates from chronology
            for event in s.get("master_chronology", s.get("chronological_events", [])):
                if isinstance(event, dict) and "date" in event:
                    context["dates"].append(str(event["date"]))

            # Extract diagnoses
            for diag in s.get("active_diagnoses", []):
                if isinstance(diag, dict):
                    d = diag.get("diagnosis", diag.get("text", ""))
                    if d:
                        context["diagnoses"].append(str(d))

            # Brief summary
            cc = s.get("chief_complaint", {})
            if isinstance(cc, dict):
                context["summary"] = str(cc.get("text", ""))[:200]

    return context


def _run_chunk_pipeline(chunk, chunk_num, total_chunks, context_header,
                         config, run_id, feedback_context, modes_cfg):
    """Run ingestion → privacy → summarizer on a single chunk."""

    chunk_text = chunk["text"]
    source_files = chunk["source_files"]

    # Stage 1: Ingestion
    ingestion_input = {
        "source_file": f"Chunk {chunk_num}/{total_chunks} ({', '.join(source_files)})",
        "file_hash_sha256": hashlib.sha256(chunk_text.encode()).hexdigest(),
        "raw_content": chunk_text[:200000],  # Higher limit for thorough mode
        "file_size_bytes": len(chunk_text),
        "chunk_info": {
            "chunk_number": chunk_num,
            "total_chunks": total_chunks,
            "page_count": chunk["page_count"],
        },
    }

    ingestion_task = (
        f"{context_header}\n\n"
        f"Parse this CHUNK of medical documents into structured JSON. "
        f"This is chunk {chunk_num} of {total_chunks} from a large case. "
        f"Extract all sections, classify by type. Output ONLY valid JSON matching the schema."
    )
    ingestion_prompt = ingestion_task + "\n\n" + build_stage_prompt(
        "ingestion", ingestion_input, INGESTION_SCHEMA_EXAMPLE
    )

    raw_ingestion = dispatch_agent("ingestion", ingestion_prompt, ingestion_input, config)
    if not raw_ingestion:
        logger.error("  Chunk %d ingestion: No output", chunk_num)
        return None

    try:
        ingestion_output = extract_json_from_response(raw_ingestion)
    except ValueError as e:
        logger.error("  Chunk %d ingestion: Invalid JSON: %s", chunk_num, e)
        return None

    # Stage 2: Privacy
    privacy_task = (
        f"De-identify this medical record chunk ({chunk_num}/{total_chunks}). "
        f"Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens. "
        f"Output ONLY valid JSON matching the schema."
    )
    privacy_prompt = privacy_task + "\n\n" + build_stage_prompt(
        "privacy", ingestion_output, PRIVACY_SCHEMA_EXAMPLE
    )

    raw_privacy = dispatch_agent("privacy", privacy_prompt, ingestion_output, config)
    if not raw_privacy:
        logger.error("  Chunk %d privacy: No output", chunk_num)
        return None

    try:
        privacy_output = extract_json_from_response(raw_privacy)
    except ValueError as e:
        logger.error("  Chunk %d privacy: Invalid JSON: %s", chunk_num, e)
        return None

    # Stage 3: Summarizer
    summarizer_task = (
        f"{context_header}\n\n"
        f"Produce a litigation-ready clinical summary of this de-identified chunk "
        f"({chunk_num}/{total_chunks}). Summarize THIS CHUNK ONLY. "
        f"Do NOT repeat information from prior chunks listed in the context header. "
        f"Focus on NEW encounters, findings, medications, and diagnoses in this chunk. "
        f"Every claim must cite its source section. Include confidence scores. "
        f"Additionally, extract ANY billing and cost information found in this chunk into a 'billing_data' object. "
        f"For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. "
        f"If no billing data is found in this chunk, output billing_data with an empty providers array and totals of 0. "
        f"Also generate an 'alerts' array flagging any treatment gaps, missing providers, pre-existing conditions, "
        f"inconsistencies, compliance issues, prior injuries, or medication changes found in THIS chunk. "
        f"Each alert needs: type, severity (high|medium|low), title, description, impact_estimate, "
        f"recommended_action, citation, and date_range (or null). "
        f"Output ONLY valid JSON matching the schema."
    )
    summarizer_prompt = summarizer_task + "\n\n" + build_stage_prompt(
        "summarizer", privacy_output, SUMMARY_SCHEMA_EXAMPLE
    )

    if feedback_context:
        summarizer_prompt += "\n\n" + feedback_context

    raw_summary = dispatch_agent("summarizer", summarizer_prompt, privacy_output, config)
    if not raw_summary:
        logger.error("  Chunk %d summarizer: No output", chunk_num)
        return None

    try:
        summary_output = extract_json_from_response(raw_summary)
    except ValueError as e:
        logger.error("  Chunk %d summarizer: Invalid JSON: %s", chunk_num, e)
        return None

    return {
        "chunk_id": chunk["chunk_id"],
        "chunk_num": chunk_num,
        "ingestion": ingestion_output,
        "privacy": privacy_output,
        "summary": summary_output,
    }


def _merge_chunk_summaries(chunk_summaries, config, run_id, case_ref, modes_cfg):
    """Merge all chunk summaries into a unified case summary."""

    merge_model = modes_cfg.get("merge_model", "claude-sonnet-4-6")
    merge_max_tokens = modes_cfg.get("merge_max_tokens", 32768)

    # Collect all chunk summaries for merging
    chunk_summary_texts = []
    all_ingestion_sections = []
    all_privacy_sections = []
    total_phi = {"total_identifiers_found": 0, "total_redacted": 0, "by_type": {}, "redaction_complete": True}

    for cs in chunk_summaries:
        chunk_num = cs["chunk_num"]

        # Collect ingestion sections
        ing = cs.get("ingestion", {})
        if isinstance(ing.get("sections"), list):
            for sec in ing["sections"]:
                sec["_chunk"] = chunk_num
                all_ingestion_sections.append(sec)

        # Collect privacy sections and aggregate PHI stats
        priv = cs.get("privacy", {})
        if isinstance(priv.get("sections"), list):
            for sec in priv["sections"]:
                sec["_chunk"] = chunk_num
                all_privacy_sections.append(sec)
        phi = priv.get("phi_summary", {})
        total_phi["total_identifiers_found"] += phi.get("total_identifiers_found", 0)
        total_phi["total_redacted"] += phi.get("total_redacted", 0)
        for ptype, count in phi.get("by_type", {}).items():
            total_phi["by_type"][ptype] = total_phi["by_type"].get(ptype, 0) + count

        # Collect summary text for merge prompt
        summ = cs.get("summary", {})
        chunk_summary_texts.append(json.dumps(summ, indent=2))

    # Build merge prompt
    merge_input = "\n\n---\n\n".join(
        f"### CHUNK {cs['chunk_num']} SUMMARY\n{text}"
        for cs, text in zip(chunk_summaries, chunk_summary_texts)
    )

    merge_task = (
        f"You are merging {len(chunk_summaries)} chunk summaries from a large medical case "
        f"({case_ref or run_id}) into ONE unified summary.\n\n"
        f"INSTRUCTIONS:\n"
        f"1. Combine all master_chronology entries into one unified timeline, sorted by date, deduplicated\n"
        f"2. Consolidate active_diagnoses — remove duplicates, keep highest confidence\n"
        f"3. Consolidate medications — remove duplicates, note dosage changes over time\n"
        f"4. Merge key_findings — deduplicate, keep all unique findings\n"
        f"5. Merge smoking_gun_quotes — keep all unique quotes\n"
        f"6. Merge contradictions_flagged — include cross-chunk contradictions\n"
        f"7. Merge timeline_gaps — include gaps between chunks\n"
        f"8. Merge discovery_deficiencies — deduplicate\n"
        f"9. Merge alerts — combine all chunk alerts, deduplicate, and add any NEW cross-chunk alerts "
        f"(e.g., treatment gaps spanning chunks, cross-chunk inconsistencies). Keep 3-10 total alerts.\n"
        f"10. Write a unified executive_strategy, bluf, litigation_cheat_sheet, and trial_strategy_note\n"
        f"11. Update verification stats for the merged summary\n\n"
        f"CONSTRAINTS:\n"
        f"- Use ONLY data from the chunk summaries below. Do NOT invent or hallucinate.\n"
        f"- Preserve all citations in their original format\n"
        f"- When deduplicating, keep the entry with highest confidence\n\n"
        f"Output ONLY valid JSON matching the schema.\n\n"
        f"## CHUNK SUMMARIES TO MERGE\n\n{merge_input}"
    )

    merge_prompt = merge_task + "\n\n" + build_stage_prompt(
        "summarizer", {"merge_mode": True, "chunks_count": len(chunk_summaries)},
        SUMMARY_SCHEMA_EXAMPLE,
    )

    raw_merged = dispatch_agent("summarizer", merge_prompt, {"merge": True}, config, combined=True)

    if not raw_merged:
        logger.error("Merge stage: No output")
        return None

    try:
        merged_output = extract_json_from_response(raw_merged)
    except ValueError as e:
        logger.error("Merge stage: Invalid JSON: %s", e)
        return None

    # Assemble final merged result
    return {
        "ingestion": {
            "sections": all_ingestion_sections,
            "document_type": "multi_chunk_case",
            "total_chunks": len(chunk_summaries),
        },
        "privacy": {
            "sections": all_privacy_sections,
            "phi_summary": total_phi,
        },
        "summary": merged_output,
    }


def _move_to_failed(processing_path, run_id):
    """Move a failed file to processing/failed/."""
    failed_dir = PROCESSING_DIR / "failed"
    failed_dir.mkdir(parents=True, exist_ok=True)
    dest = failed_dir / processing_path.name
    if processing_path.exists():
        shutil.move(str(processing_path), str(dest))
    # Update document status to failed — match by path first, then by run_id
    _update_document_status(processing_path, status="failed", vault_zone="failed",
                            current_path=str(dest))
    # Also update by run_id for combined pipelines where the processing path
    # has a run_id prefix and won't match the original_path stored in the DB
    if run_id:
        try:
            from db import transaction as db_transaction
            now = datetime.now(timezone.utc).isoformat()
            with db_transaction() as conn:
                conn.execute(
                    "UPDATE documents SET status = 'failed', vault_zone = 'failed', "
                    "updated_at = ? WHERE run_id = ? AND status = 'processing'",
                    (now, run_id),
                )
        except Exception as e:
            logger.debug("Failed to update documents by run_id %s: %s", run_id, e)


# ── Combined Multi-File Pipeline ─────────────────────────────────────────────

def run_pipeline_combined(file_paths, config, run_id=None, case_ref=None, dry_run=False):
    """
    Run the 4-stage summarization pipeline on multiple files combined into one case.
    Concatenates file contents and processes them as a single record set.
    """
    if not file_paths:
        return None

    file_paths = [Path(p) for p in file_paths]

    if not run_id:
        run_id = f"case_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}" if hasattr(uuid, 'uuid4') else f"case_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"

    logger.info("Combined pipeline %s starting for %d files (case_ref=%s)", run_id, len(file_paths), case_ref)

    # Mark all files as processing
    for fp in file_paths:
        _update_document_status(fp, status="processing", vault_zone="processing", run_id=run_id)

    # Copy all files to processing directory
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)
    processing_paths = []
    for fp in file_paths:
        dest = PROCESSING_DIR / f"{run_id}_{fp.name}"
        if not dry_run:
            shutil.copy2(fp, dest)
        processing_paths.append(dest)

    # Read and concatenate all file contents
    combined_parts = []
    combined_hashes = []
    combined_page_maps = {}
    total_size = 0
    for fp in file_paths:
        file_hash = file_sha256(fp)
        combined_hashes.append(file_hash)
        total_size += fp.stat().st_size
        content, file_page_map = _read_file_content(fp)
        if file_page_map:
            combined_page_maps[fp.name] = file_page_map
        # Tag each file's content with its filename for the LLM
        combined_parts.append(f"===== FILE: {fp.name} =====\n{content}")

    combined_content = "\n\n".join(combined_parts)
    combined_hash = hashlib.sha256("|".join(combined_hashes).encode()).hexdigest()

    # Build pipeline input with combined content
    pipeline_input = {
        "source_file": f"CASE: {case_ref or run_id} ({len(file_paths)} files)",
        "file_hash_sha256": combined_hash,
        "raw_content": combined_content[:400000],  # Higher limit for multi-file
        "file_size_bytes": total_size,
        "file_count": len(file_paths),
        "case_ref": case_ref,
        "source_files": [fp.name for fp in file_paths],
    }

    stage_outputs = {}
    current_input = pipeline_input

    feedback_context = _load_rlhf_feedback()

    # Multi-file-aware task descriptions override single-file defaults
    combined_tasks = {
        "ingestion": (
            "Parse these medical documents into structured JSON. "
            "This is a MULTI-FILE CASE containing {n} files from the same patient case. "
            "Extract all sections from ALL files, classify each section by type, "
            "and tag each section with the source filename. "
            "Output ONLY valid JSON matching the schema."
        ).format(n=len(file_paths)),
        "privacy": (
            "De-identify these medical records. This is a MULTI-FILE CASE with {n} source files. "
            "Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens across ALL sections. "
            "Count every redaction. Output ONLY valid JSON matching the schema."
        ).format(n=len(file_paths)),
        "summarizer": (
            "Produce a unified clinical summary for this patient case combining {n} medical records. "
            "This is the PRIMARY USE CASE: a litigation support team has uploaded multiple records "
            "(e.g., ER reports, imaging, PT notes, discharge summaries, lab results) for ONE patient. "
            "You MUST cross-reference findings across all files to build a complete picture. "
            "Every claim must cite its source section. Include confidence scores. "
            "Detect contradictions BETWEEN files and timeline gaps. "
            "The master_chronology must weave events from ALL files into one unified timeline. "
            "Additionally, extract ALL billing and cost information found across all records into a 'billing_data' object. "
            "For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. "
            "Calculate subtotals per provider, total past medical costs, and any future medical cost estimates with the basis for those estimates. "
            "If no billing data is found, output billing_data with an empty providers array and totals of 0. "
            "\n\nALERTS & GAP DETECTION (REQUIRED):\n"
            "You MUST also generate an 'alerts' array at the top level of your JSON output. "
            "These alerts serve as proactive intelligence for the attorney — flagging risks, gaps, "
            "and strategic vulnerabilities that could impact case value BEFORE opposing counsel finds them. "
            "Generate between 3 and 10 alerts per case. Each alert must be one of these types: "
            "treatment_gap, missing_provider, pre_existing, inconsistency, compliance_issue, prior_injury, medication_change. "
            "Each alert object MUST have: type, severity (high|medium|low), title, description, "
            "impact_estimate, recommended_action, citation, and date_range (or null). "
            "Prioritize HIGH severity alerts for issues that directly threaten case value. "
            "Think like opposing counsel: what weaknesses would THEY exploit? "
            "Output ONLY valid JSON matching the schema."
        ).format(n=len(file_paths)),
        "auditor": (
            "Create a HIPAA compliance audit entry for this multi-file pipeline run covering {n} source files. "
            "Reference files ONLY by SHA-256 hash. Include NO PHI. "
            "Determine compliance status. Output ONLY valid JSON matching the schema."
        ).format(n=len(file_paths)),
    }

    for stage in PIPELINE_STAGES:
        stage_name = stage["name"]
        logger.info("  Stage: %s", stage_name)

        if dry_run:
            logger.info("  [DRY RUN] Would dispatch to %s", stage["agent"])
            update_pipeline_status(run_id, stage_name, "skipped", "dry run")
            continue

        update_pipeline_status(run_id, stage_name, "running",
                               case_ref=case_ref,
                               source_file=f"{len(file_paths)} files")

        # Use multi-file-aware task description
        stage_task = combined_tasks.get(stage_name, stage["task"])
        task_with_schema = stage_task + "\n\n" + build_stage_prompt(
            stage_name, current_input, stage["schema_example"]
        )

        if stage_name == "summarizer" and feedback_context:
            task_with_schema += "\n\n" + feedback_context

        raw_output = dispatch_agent(stage["agent"], task_with_schema, current_input, config, combined=True)

        if not raw_output:
            logger.error("  Stage %s: No output from agent", stage_name)
            update_pipeline_status(run_id, stage_name, "failed", "No output from agent")
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None

        try:
            parsed_output = extract_json_from_response(raw_output)
        except ValueError as e:
            logger.error("  Stage %s: Invalid JSON: %s", stage_name, e)
            logger.info("  Retrying %s with JSON correction prompt...", stage_name)
            retry_task = (
                f"Your previous output was not valid JSON. Error: {e}\n"
                f"Please output ONLY a valid JSON object matching the schema. "
                f"No markdown, no explanation."
            )
            retry_output = dispatch_agent(stage["agent"], retry_task, current_input, config)
            if retry_output:
                try:
                    parsed_output = extract_json_from_response(retry_output)
                except ValueError as e2:
                    logger.error("  Stage %s: Retry also failed: %s", stage_name, e2)
                    update_pipeline_status(run_id, stage_name, "failed", f"Invalid JSON after retry: {e2}")
                    for pp in processing_paths:
                        _move_to_failed(pp, run_id)
                    return None
            else:
                update_pipeline_status(run_id, stage_name, "failed", f"Invalid JSON: {e}")
                for pp in processing_paths:
                    _move_to_failed(pp, run_id)
                return None

        validation_errors = stage["validator"](parsed_output)
        if validation_errors:
            critical = [e for e in validation_errors if "CRITICAL" in e]
            warnings = [e for e in validation_errors if "CRITICAL" not in e]
            if warnings:
                logger.warning("  Stage %s validation warnings: %s", stage_name, warnings)
            if critical:
                logger.error("  Stage %s CRITICAL validation errors: %s", stage_name, critical)
                update_pipeline_status(run_id, stage_name, "failed", f"Validation: {critical}")
                for pp in processing_paths:
                    _move_to_failed(pp, run_id)
                return None

        stage_outputs[stage_name] = parsed_output
        current_input = parsed_output
        update_pipeline_status(run_id, stage_name, "completed")
        logger.info("  Stage %s: PASSED", stage_name)

    if dry_run:
        return None

    # Save combined summary
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f"{run_id}_summary.json"
    summary_data = {
        "run_id": run_id,
        "source_file": f"CASE: {case_ref or run_id} ({len(file_paths)} files)",
        "source_files": [fp.name for fp in file_paths],
        "case_ref": case_ref,
        "source_file_hash": combined_hash,
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "ingestion": stage_outputs.get("ingestion"),
        "privacy": stage_outputs.get("privacy"),
        "summary": stage_outputs.get("summarizer"),
        "audit": stage_outputs.get("auditor"),
    }
    if combined_page_maps:
        summary_data["source_pages"] = combined_page_maps
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2)
    logger.info("Combined summary saved: %s", summary_file)

    # Save audit entry
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f"{run_id}_audit.json"
    audit_entry = stage_outputs.get("auditor", {})
    with open(audit_file, "w", encoding="utf-8") as f:
        json.dump(audit_entry, f, indent=2)

    # Move all files to processed
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for i, fp in enumerate(file_paths):
        processed_path = PROCESSED_DIR / f"{run_id}_{fp.name}"
        pp = processing_paths[i]
        if pp.exists():
            shutil.move(str(pp), str(processed_path))
        _update_document_status(
            fp, status="completed", vault_zone="processed",
            current_path=str(processed_path),
            summary_file=f"{run_id}_summary.json",
            processed_at=datetime.now(timezone.utc).isoformat(),
        )

    # Register the summary under the case_ref
    _register_summary_document(summary_file, run_id, file_paths[0])

    return summary_data


# ── RLHF Feedback Loader ─────────────────────────────────────────────────────

def _load_rlhf_feedback():
    """Load recent feedback to inject into summarizer prompts for reinforcement learning."""
    try:
        from db import get_db
        conn = get_db()
        try:
            # Get recent feedback with text
            rows = conn.execute(
                """SELECT sf.run_id, sf.rating, sf.feedback_text
                   FROM summary_feedback sf
                   WHERE sf.feedback_text IS NOT NULL AND sf.feedback_text != ''
                   ORDER BY sf.created_at DESC LIMIT 10"""
            ).fetchall()

            # Get aggregate stats
            stats = conn.execute(
                "SELECT rating, COUNT(*) as cnt FROM summary_feedback GROUP BY rating"
            ).fetchall()
        finally:
            conn.close()

        if not rows and not stats:
            return ""

        stat_map = {r["rating"]: r["cnt"] for r in stats}
        total = sum(stat_map.values())

        parts = ["## QUALITY FEEDBACK FROM HUMAN REVIEWERS"]
        parts.append(f"Total reviews: {total} (Poor: {stat_map.get('poor', 0)}, Good: {stat_map.get('good', 0)}, Excellent: {stat_map.get('excellent', 0)})")

        if stat_map.get("poor", 0) > 0:
            parts.append("\nCommon issues from POOR ratings (AVOID these):")
            for r in rows:
                if r["rating"] == "poor" and r["feedback_text"]:
                    parts.append(f"  - {r['feedback_text'][:200]}")

        if stat_map.get("excellent", 0) > 0:
            parts.append("\nQualities from EXCELLENT ratings (DO more of this):")
            for r in rows:
                if r["rating"] == "excellent" and r["feedback_text"]:
                    parts.append(f"  - {r['feedback_text'][:200]}")

        parts.append("\nUse this feedback to improve your summary quality.")
        return "\n".join(parts)

    except Exception as e:
        logger.warning("Could not load RLHF feedback: %s", e)
        return ""


# ── Scanner ──────────────────────────────────────────────────────────────────

def scan_incoming(config):
    """List unprocessed files in vault/incoming/."""
    supported = set(config.get("summarization", {}).get("supported_extensions", [".pdf"]))
    ledger = load_ledger()

    files = []
    if not INCOMING_DIR.exists():
        return files

    for path in INCOMING_DIR.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in supported:
            continue
        # Skip already processed files (by path string)
        if str(path) in ledger:
            continue
        files.append(path)

    return sorted(files, key=lambda p: p.stat().st_mtime)


def _get_case_ref_for_file(file_path):
    """Look up the case_ref for a file from the documents table."""
    try:
        from db import get_db
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT case_ref FROM documents WHERE (original_path = ? OR current_path = ?) AND case_ref IS NOT NULL",
                (str(file_path), str(file_path)),
            ).fetchone()
            return row["case_ref"] if row else None
        finally:
            conn.close()
    except Exception:
        return None


def run_scan(config, dry_run=False):
    """Single scan cycle: find new files, process each through pipeline.

    Files sharing the same case_ref are grouped and processed together via
    the combined pipeline. Files without a case_ref are processed individually.
    """
    files = scan_incoming(config)
    if not files:
        logger.info("No new files to process.")
        return

    logger.info("Found %d new file(s) to process.", len(files))
    ledger = load_ledger()

    # Group files by case_ref (None = individual processing)
    case_groups = {}
    solo_files = []
    for file_path in files:
        case_ref = _get_case_ref_for_file(file_path)
        if case_ref:
            case_groups.setdefault(case_ref, []).append(file_path)
        else:
            solo_files.append(file_path)

    # Process grouped case files together
    for case_ref, group_files in case_groups.items():
        logger.info("Processing case '%s' with %d file(s)...", case_ref, len(group_files))
        try:
            if len(group_files) == 1:
                result = run_pipeline(group_files[0], config, dry_run=dry_run)
            else:
                result = run_pipeline_combined(group_files, config, case_ref=case_ref, dry_run=dry_run)
            if result:
                for fp in group_files:
                    ledger[str(fp)] = {
                        "run_id": result["run_id"],
                        "processed_at": result["processed_at"],
                        "summary_file": f"{result['run_id']}_summary.json",
                        "case_ref": case_ref,
                    }
                save_ledger(ledger)
                logger.info("Case '%s' processed: %s", case_ref, result["run_id"])
            elif dry_run:
                logger.info("[DRY RUN] Would process case '%s'", case_ref)
            else:
                logger.error("Pipeline failed for case '%s'", case_ref)
                for fp in group_files:
                    ledger[str(fp)] = {
                        "status": "failed",
                        "failed_at": datetime.now(timezone.utc).isoformat(),
                        "case_ref": case_ref,
                    }
                save_ledger(ledger)
        except Exception as e:
            logger.error("Error processing case '%s': %s", case_ref, e)

    # Process individual files without case_ref
    for file_path in solo_files:
        try:
            result = run_pipeline(file_path, config, dry_run=dry_run)
            if result:
                ledger[str(file_path)] = {
                    "run_id": result["run_id"],
                    "processed_at": result["processed_at"],
                    "summary_file": f"{result['run_id']}_summary.json",
                }
                save_ledger(ledger)
                logger.info("Processed: %s → %s", file_path.name, result["run_id"])
            elif dry_run:
                logger.info("[DRY RUN] Would process: %s", file_path.name)
            else:
                logger.error("Pipeline failed for: %s", file_path.name)
                ledger[str(file_path)] = {
                    "status": "failed",
                    "failed_at": datetime.now(timezone.utc).isoformat(),
                }
                save_ledger(ledger)
        except Exception as e:
            logger.error("Error processing %s: %s", file_path.name, e)


def run_loop(config, dry_run=False):
    """Main daemon loop."""
    interval = config.get("summarization", {}).get("scan_interval_seconds", 1800)
    logger.info("Summarization watcher started. Scan interval: %ds", interval)

    while True:
        try:
            run_scan(config, dry_run=dry_run)
        except Exception as e:
            logger.error("Scan error: %s", e)
        time.sleep(interval)


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Summarization Watcher Daemon")
    parser.add_argument("--once", action="store_true", help="Single scan and exit")
    parser.add_argument("--dry-run", action="store_true", help="Report without processing")
    args = parser.parse_args()

    config = load_config()

    # Ensure directories exist
    for d in [INCOMING_DIR, PROCESSING_DIR, PROCESSED_DIR, SUMMARIES_DIR, AUDIT_DIR]:
        d.mkdir(parents=True, exist_ok=True)

    if args.once:
        run_scan(config, dry_run=args.dry_run)
    else:
        run_loop(config, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
