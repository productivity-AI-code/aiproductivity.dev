import base64
import hashlib
import hmac as _hmac
import json
import logging
import platform
import sys
import zlib
from pathlib import Path
logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).parent
_KDF_SALT = b'MedRecAI-state-v1-2024'
_KDF_ITERATIONS = 100000
_TAG_LEN = 32

def derive_machine_key() -> bytes:
    components = [platform.node().encode('utf-8'), str(BASE_DIR.resolve()).encode('utf-8'), f'{sys.version_info.major}.{sys.version_info.minor}'.encode('utf-8')]
    raw = b'|'.join(components)
    return hashlib.pbkdf2_hmac('sha256', raw, _KDF_SALT, _KDF_ITERATIONS)

def seal_state(state: dict, key: bytes) -> bytes:
    payload = json.dumps(state, sort_keys=True).encode('utf-8')
    compressed = zlib.compress(payload, 9)
    tag = _hmac.new(key, compressed, hashlib.sha256).digest()
    return base64.b64encode(tag + compressed)

def unseal_state(blob: bytes, key: bytes) -> dict | None:
    try:
        raw = base64.b64decode(blob)
    except Exception:
        return None
    if len(raw) < _TAG_LEN + 1:
        return None
    stored_tag = raw[:_TAG_LEN]
    compressed = raw[_TAG_LEN:]
    expected_tag = _hmac.new(key, compressed, hashlib.sha256).digest()
    if not _hmac.compare_digest(stored_tag, expected_tag):
        logger.warning('License state HMAC verification failed — possible tampering')
        return None
    try:
        payload = zlib.decompress(compressed)
        return json.loads(payload.decode('utf-8'))
    except (zlib.error, json.JSONDecodeError, UnicodeDecodeError):
        return None