from pathlib import Path
from flask import request, jsonify, g
DEMO_MARKER = Path(__file__).parent / '.demo_build'

def is_demo() -> bool:
    return DEMO_MARKER.exists()

def init_demo_guard(app):
    if not is_demo():
        return
    app.logger.info('Demo build detected — enabling demo guard (14-day expiration)')

    @app.before_request
    def _check_demo_expiration():
        exempt = ('/health', '/static/', '/api/license/', '/login', '/logout', '/api/csrf-token')
        if any((request.path.startswith(p) for p in exempt)):
            return None
        from licensing import check_demo_expiration
        status = check_demo_expiration()
        reason = status.get('reason')
        if status['expired']:
            if reason in ('clock_rollback', 'install_date_invalid'):
                msg = 'Demo validation failed. System clock inconsistency detected. Purchase a license to continue.'
            elif reason == 'marker_tampered':
                msg = 'Demo validation failed. Application files have been modified. Purchase a license to continue.'
            else:
                msg = 'Your 14-day demo has expired. Purchase a license to continue using MedRecords AI.'
            if request.path.startswith('/api/'):
                return (jsonify({'error': 'Demo expired', 'message': msg, 'upgrade_url': 'https://aiproductivity.dev/#pricing', 'expired': True}), 403)
            g.demo_expired = True
        try:
            from integrity import is_critically_tampered
            if is_critically_tampered():
                g.force_watermark = True
        except ImportError:
            pass
        g.demo_days_remaining = status.get('days_remaining', 0)
        g.is_demo = True

    @app.after_request
    def _add_demo_header(response):
        if getattr(g, 'is_demo', False):
            response.headers['X-Demo-Version'] = 'true'
            response.headers['X-Demo-Days-Remaining'] = str(getattr(g, 'demo_days_remaining', 0))
            if getattr(g, 'force_watermark', False):
                response.headers['X-Integrity-Warning'] = 'true'
        return response