
import os
import json
import logging
from pathlib import Path
from security_vault import Vault

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger("encrypt_vault")

BASE_DIR = Path(__file__).parent
VAULT_ROOT = BASE_DIR / "vault"

def migrate_vault():
    """Crawl the vault and encrypt any unencrypted JSON/PDF/Log files."""
    logger.info(f"Starting vault migration at {VAULT_ROOT}")
    
    # We target summaries, audit logs, and status files
    targets = [
        VAULT_ROOT / "summaries",
        VAULT_ROOT / "audit",
        VAULT_ROOT / "pipeline_status"
    ]
    
    count = 0
    for target in targets:
        if not target.exists():
            continue
            
        logger.info(f"Scanning {target.name}...")
        for p in target.rglob("*"):
            if p.is_file() and p.suffix in (".json", ".pdf", ".txt", ".log"):
                # Skip already encrypted files
                if Vault.is_encrypted(p):
                    continue
                
                # Skip system files we want to keep plain
                if p.name in ("processed_files.json", "pipeline_stats.json", ".vault_key"):
                    continue
                
                try:
                    Vault.encrypt_file(p)
                    count += 1
                    if count % 10 == 0:
                        logger.info(f"Encrypted {count} files...")
                except Exception as e:
                    logger.error(f"Failed to encrypt {p.name}: {e}")

    logger.info(f"Migration complete. {count} files secured with AES-256.")

if __name__ == "__main__":
    migrate_vault()
