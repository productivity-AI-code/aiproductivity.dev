
import os
import base64
import logging
from pathlib import Path
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.fernet import Fernet

logger = logging.getLogger("security_vault")

# Path to the local master key seed (unique per installation)
KEY_FILE = Path(__file__).parent / "vault" / ".vault_key"

class Vault:
    _fernet = None

    @classmethod
    def _get_fernet(cls):
        if cls._fernet:
            return cls._fernet
        
        # Ensure vault dir exists
        KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        if not KEY_FILE.exists():
            logger.info("Generating new vault master key...")
            # Use a random seed + machine name for uniqueness
            import socket
            import uuid
            seed = os.urandom(32) + socket.gethostname().encode() + str(uuid.getnode()).encode()
            
            # Use PBKDF2 to derive a strong key
            salt = os.urandom(16)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(seed))
            
            # Store salt + key (obfuscated)
            with open(KEY_FILE, "wb") as f:
                f.write(salt + b"||" + key)
        
        with open(KEY_FILE, "rb") as f:
            data = f.read()
            salt, key = data.split(b"||")
            cls._fernet = Fernet(key)
            
        return cls._fernet

    @classmethod
    def encrypt(cls, data):
        """Encrypt bytes or string data."""
        if isinstance(data, str):
            data = data.encode("utf-8")
        f = cls._get_fernet()
        return f.encrypt(data)

    @classmethod
    def decrypt(cls, token):
        """Decrypt data back to bytes."""
        f = cls._get_fernet()
        return f.decrypt(token)

    @classmethod
    def encrypt_file(cls, source_path, dest_path=None):
        """Encrypt a file on disk."""
        source_path = Path(source_path)
        if not dest_path:
            dest_path = source_path
        
        with open(source_path, "rb") as f:
            raw_data = f.read()
        
        encrypted_data = cls.encrypt(raw_data)
        
        with open(dest_path, "wb") as f:
            f.write(encrypted_data)
        
        logger.debug(f"Encrypted file: {source_path.name}")

    @classmethod
    def decrypt_file(cls, source_path):
        """Decrypt an encrypted file from disk and return bytes."""
        with open(source_path, "rb") as f:
            encrypted_data = f.read()
        return cls.decrypt(encrypted_data)

    @classmethod
    def is_encrypted(cls, path):
        """Basic check if a file is a Fernet token."""
        try:
            with open(path, "rb") as f:
                header = f.read(1)
                # Fernet tokens start with 0x80 (version 128)
                return header == b'\x80'
        except:
            return False
