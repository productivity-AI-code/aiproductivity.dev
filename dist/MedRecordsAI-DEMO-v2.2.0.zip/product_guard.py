import hashlib
import hmac as _hmac
import json
import logging
from pathlib import Path
from flask import request, jsonify, g, redirect, render_template_string
logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).parent
BUILD_INFO_PATH = BASE_DIR / '.build_info'
DEMO_MARKER_PATH = BASE_DIR / '.demo_build'
_BUILD_INFO_SIGN_KEY = b'MRA-BUILD-INFO-2024-SIGN'

def _load_build_info() -> dict | None:
    if not BUILD_INFO_PATH.exists():
        return None
    try:
        raw = json.loads(BUILD_INFO_PATH.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return None
    stored_sig = raw.pop('_signature', None)
    if not stored_sig:
        logger.warning('Build info missing signature')
        return None
    check_payload = json.dumps(raw, sort_keys=True)
    expected_sig = _hmac.new(_BUILD_INFO_SIGN_KEY, check_payload.encode(), hashlib.sha256).hexdigest()
    if not _hmac.compare_digest(stored_sig, expected_sig):
        logger.warning('Build info signature mismatch — tampered')
        return None
    return raw
_build_info_cache = None
_build_info_loaded = False

def get_build_info() -> dict | None:
    global _build_info_cache, _build_info_loaded
    if not _build_info_loaded:
        _build_info_cache = _load_build_info()
        _build_info_loaded = True
    return _build_info_cache

def is_product_build() -> bool:
    return get_build_info() is not None or DEMO_MARKER_PATH.exists()

def get_build_type() -> str:
    info = get_build_info()
    if info is not None:
        return info.get('build_type', 'dev')
    if DEMO_MARKER_PATH.exists():
        return 'demo'
    return 'dev'

def init_product_guard(app):
    build_type = get_build_type()
    if build_type == 'dev':
        app.logger.info('Dev environment — product guard disabled')
        return
    if build_type == 'demo':
        try:
            from demo_guard import init_demo_guard
            init_demo_guard(app)
        except ImportError:
            app.logger.warning('Demo build detected but demo_guard.py not found')
        return
    app.logger.info('Product build detected (%s) — enabling license enforcement', build_type)
    EXEMPT_PATHS = ('/health', '/static/', '/api/license/', '/api/csrf-token', '/login', '/logout', '/activate')

    @app.before_request
    def _check_product_license():
        if any((request.path.startswith(p) for p in EXEMPT_PATHS)):
            return None
        from licensing import get_license_state
        state = get_license_state()
        tier = state.get('tier', 'trial')
        license_key = state.get('license_key')
        if license_key and tier in ('core', 'pro'):
            g.product_tier = tier
            g.build_type = build_type
            try:
                from integrity import is_critically_tampered
                if is_critically_tampered():
                    g.force_watermark = True
            except ImportError:
                pass
            return None
        if request.path.startswith('/api/'):
            return (jsonify({'error': 'License activation required', 'message': f'This {build_type.title()} build requires a valid license key. Please activate your license at /activate or via POST /api/license/activate with your key.', 'activation_url': '/activate', 'upgrade_url': 'https://aiproductivity.dev/pricing'}), 403)
        return redirect('/activate')

    @app.after_request
    def _add_product_headers(response):
        tier = getattr(g, 'product_tier', None)
        if tier:
            response.headers['X-Product-Tier'] = tier
            response.headers['X-Build-Type'] = getattr(g, 'build_type', 'unknown')
            if getattr(g, 'force_watermark', False):
                response.headers['X-Integrity-Warning'] = 'true'
        return response

    @app.route('/activate')
    def activation_page():
        return render_template_string(_ACTIVATION_HTML, build_type=build_type.title())
_ACTIVATION_HTML = '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>MedRecords AI - License Activation</title>\n  <style>\n    * { box-sizing: border-box; margin: 0; padding: 0; }\n    body {\n      font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif;\n      background: #0f172a; color: #e2e8f0;\n      display: flex; justify-content: center; align-items: center;\n      min-height: 100vh; padding: 20px;\n    }\n    .card {\n      background: #1e293b; border-radius: 12px; padding: 40px;\n      max-width: 480px; width: 100%; box-shadow: 0 4px 24px rgba(0,0,0,0.3);\n    }\n    h1 { font-size: 1.5rem; margin-bottom: 8px; color: #00d4aa; }\n    h2 { font-size: 1.1rem; margin-bottom: 16px; font-weight: 400; color: #94a3b8; }\n    .info { color: #64748b; font-size: 0.85rem; margin-bottom: 24px; }\n    input {\n      width: 100%; padding: 14px; margin-bottom: 12px;\n      border: 1px solid #334155; border-radius: 8px;\n      background: #0f172a; color: #e2e8f0; font-size: 1rem;\n      font-family: monospace; letter-spacing: 1px;\n    }\n    input:focus { outline: none; border-color: #00d4aa; }\n    button {\n      width: 100%; padding: 14px; background: #00d4aa; color: #0f172a;\n      border: none; border-radius: 8px; font-size: 1rem;\n      font-weight: 600; cursor: pointer; transition: background 0.2s;\n    }\n    button:hover { background: #00b894; }\n    button:disabled { background: #334155; color: #64748b; cursor: not-allowed; }\n    .error { color: #f87171; margin-top: 12px; font-size: 0.9rem; }\n    .success { color: #00d4aa; margin-top: 12px; font-size: 0.9rem; }\n    .links { margin-top: 24px; text-align: center; }\n    .links a { color: #00d4aa; text-decoration: none; font-size: 0.85rem; }\n    .links a:hover { text-decoration: underline; }\n  </style>\n</head>\n<body>\n  <div class="card">\n    <h1>MedRecords AI</h1>\n    <h2>{{ build_type }} License Activation</h2>\n    <p class="info">Enter your license key to activate this installation.</p>\n    <form id="activateForm">\n      <input type="text" id="licenseKey"\n             placeholder="MRA-XXXXX-XXXXX-XXXXX-XXXXX"\n             autocomplete="off" spellcheck="false" required>\n      <button type="submit" id="submitBtn">Activate License</button>\n    </form>\n    <div id="message"></div>\n    <div class="links">\n      <a href="https://aiproductivity.dev/pricing" target="_blank">Purchase a license</a>\n    </div>\n  </div>\n  <script>\n    const form = document.getElementById(\'activateForm\');\n    const msg = document.getElementById(\'message\');\n    const btn = document.getElementById(\'submitBtn\');\n\n    form.addEventListener(\'submit\', async (e) => {\n      e.preventDefault();\n      const key = document.getElementById(\'licenseKey\').value.trim();\n      if (!key) return;\n\n      btn.disabled = true;\n      btn.textContent = \'Activating...\';\n      msg.className = \'\';\n      msg.textContent = \'\';\n\n      try {\n        const csrfResp = await fetch(\'/api/csrf-token\');\n        const csrf = await csrfResp.json();\n\n        const resp = await fetch(\'/api/license/activate\', {\n          method: \'POST\',\n          headers: {\n            \'Content-Type\': \'application/json\',\n            \'X-CSRF-Token\': csrf.token\n          },\n          body: JSON.stringify({ key }),\n        });\n        const data = await resp.json();\n\n        if (data.success) {\n          msg.className = \'success\';\n          msg.textContent = \'License activated! Redirecting...\';\n          setTimeout(() => { window.location.href = \'/\'; }, 1500);\n        } else {\n          msg.className = \'error\';\n          msg.textContent = data.error || \'Invalid license key. Please check and try again.\';\n          btn.disabled = false;\n          btn.textContent = \'Activate License\';\n        }\n      } catch (err) {\n        msg.className = \'error\';\n        msg.textContent = \'Connection error. Please try again.\';\n        btn.disabled = false;\n        btn.textContent = \'Activate License\';\n      }\n    });\n  </script>\n</body>\n</html>\n'