import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
logger = logging.getLogger('deposition_summarizer')
BASE_DIR = Path(__file__).parent
VAULT_DEPOSITIONS = BASE_DIR / 'vault' / 'depositions'

def summarize_deposition(transcript_text, config=None, options=None):
    config = config or {}
    options = options or {}
    parsed = _parse_transcript(transcript_text)
    result = _llm_deposition_analysis(parsed, config, options)
    result['deponent'] = {'name': options.get('deponent_name', parsed.get('deponent_name', 'Unknown')), 'role': options.get('deponent_role', 'witness')}
    result['transcript_stats'] = {'total_pages': parsed.get('total_pages', 0), 'total_lines': parsed.get('total_lines', 0), 'word_count': len(transcript_text.split()), 'analyzed_at': datetime.now(timezone.utc).isoformat()}
    return result

def _parse_transcript(text):
    result = {'deponent_name': 'Unknown', 'total_pages': 0, 'total_lines': 0, 'pages': [], 'raw_text': text}
    name_patterns = ['DEPOSITION\\s+OF\\s+([A-Z][A-Za-z\\s,\\.]+?)(?:\\n|,)', 'Deposition\\s+of\\s+([A-Z][A-Za-z\\s,\\.]+?)(?:\\n|,)', 'EXAMINATION\\s+OF\\s+([A-Z][A-Za-z\\s,\\.]+?)(?:\\n|,)', 'WITNESS:\\s*([A-Z][A-Za-z\\s,\\.]+?)(?:\\n|$)']
    for pattern in name_patterns:
        match = re.search(pattern, text[:2000])
        if match:
            result['deponent_name'] = match.group(1).strip()
            break
    page_pattern = re.compile('(?:^|\\n)\\s*(?:PAGE\\s+)?(\\d{1,4})\\s*\\n((?:\\s*\\d{1,2}\\s+.+\\n?)+)', re.MULTILINE | re.IGNORECASE)
    pages = {}
    for match in page_pattern.finditer(text):
        page_num = int(match.group(1))
        page_content = match.group(2)
        lines = {}
        for line_match in re.finditer('^\\s*(\\d{1,2})\\s+(.+)$', page_content, re.MULTILINE):
            line_num = int(line_match.group(1))
            line_text = line_match.group(2).strip()
            lines[line_num] = line_text
        if lines:
            pages[page_num] = lines
    if pages:
        result['total_pages'] = max(pages.keys())
        result['total_lines'] = sum((len(v) for v in pages.values()))
        result['pages'] = pages
    else:
        all_lines = text.split('\n')
        result['total_lines'] = len(all_lines)
        result['total_pages'] = max(1, len(all_lines) // 25)
    return result

def _llm_deposition_analysis(parsed, config, options):
    from dispatch import call_claude
    deponent_name = options.get('deponent_name', parsed.get('deponent_name', 'the deponent'))
    deponent_role = options.get('deponent_role', 'witness')
    focus_areas = options.get('focus_areas', [])
    focus_text = ''
    if focus_areas:
        focus_text = f'\n\nFOCUS AREAS (pay special attention to):\n' + '\n'.join((f'- {a}' for a in focus_areas))
    transcript = parsed['raw_text']
    if len(transcript) > 80000:
        transcript = transcript[:80000] + '\n\n[TRANSCRIPT TRUNCATED - remaining pages not shown]'
    prompt = f"""You are an expert litigation paralegal analyzing a deposition transcript. Your analysis will be used by personal injury attorneys to prepare for trial.\n\nDEPONENT: {deponent_name}\nDEPONENT ROLE: {deponent_role}{focus_text}\n\nTRANSCRIPT:\n{transcript}\n\nAnalyze this deposition transcript and produce a comprehensive JSON report. Include page and line citations where possible (format: "p.XX:L.YY" or "p.XX:LL.YY-ZZ").\n\nOutput ONLY valid JSON with this structure:\n{{\n    "summary_narrative": "A 2-3 paragraph executive summary of the deposition — who was deposed, key themes, most important takeaways for trial strategy",\n\n    "key_testimony": [\n        {{\n            "topic": "Brief topic label",\n            "statement": "Exact or near-exact quote from testimony",\n            "significance": "Why this matters for the case",\n            "citation": "p.XX:L.YY",\n            "favorability": "favorable|unfavorable|neutral"\n        }}\n    ],\n\n    "admissions": [\n        {{\n            "statement": "What was admitted",\n            "context": "Q&A context around the admission",\n            "litigation_value": "How this admission helps the case",\n            "citation": "p.XX:L.YY"\n        }}\n    ],\n\n    "contradictions": [\n        {{\n            "statement_1": "First contradicting statement",\n            "statement_2": "Second contradicting statement or known fact it contradicts",\n            "type": "internal|vs_medical_records|vs_prior_statement|vs_other_witness",\n            "significance": "Why this contradiction matters",\n            "citation_1": "p.XX:L.YY",\n            "citation_2": "p.XX:L.YY or 'Medical Record: [description]'"\n        }}\n    ],\n\n    "medical_statements": [\n        {{\n            "topic": "Medical topic discussed",\n            "testimony": "What was said about medical treatment/condition",\n            "accuracy_note": "Whether this aligns with typical medical records or raises concerns",\n            "citation": "p.XX:L.YY"\n        }}\n    ],\n\n    "impeachment_opportunities": [\n        {{\n            "area": "Topic area for potential impeachment",\n            "basis": "Why this testimony could be impeached",\n            "suggested_approach": "How to approach impeachment at trial",\n            "citation": "p.XX:L.YY"\n        }}\n    ],\n\n    "timeline": [\n        {{\n            "date": "Date mentioned or approximate timeframe",\n            "event": "What happened according to testimony",\n            "citation": "p.XX:L.YY"\n        }}\n    ],\n\n    "credibility_assessment": {{\n        "overall": "strong|moderate|weak",\n        "indicators": [\n            {{\n                "type": "positive|negative",\n                "observation": "Specific credibility indicator observed",\n                "citation": "p.XX:L.YY"\n            }}\n        ],\n        "notes": "Overall assessment of witness credibility and reliability"\n    }},\n\n    "objections_noted": [\n        {{\n            "type": "Type of objection (form, foundation, relevance, etc.)",\n            "context": "What was being asked when objection was raised",\n            "ruling": "sustained|overruled|taken_under_advisement|none",\n            "citation": "p.XX:L.YY"\n        }}\n    ],\n\n    "follow_up_needed": [\n        {{\n            "topic": "Area requiring follow-up",\n            "reason": "Why follow-up is needed",\n            "suggested_action": "Specific next step"\n        }}\n    ]\n}}\n\nBe thorough and precise. Every citation must reference actual content from the transcript. Prioritize findings by litigation value — the most impactful items first in each category."""
    try:
        raw = call_claude(prompt, config)
        if not raw:
            raise ValueError('Empty response from LLM')
        from pipeline_schemas import extract_json_from_response
        result = extract_json_from_response(raw)
        defaults = {'summary_narrative': 'Deposition analysis could not be completed.', 'key_testimony': [], 'admissions': [], 'contradictions': [], 'medical_statements': [], 'impeachment_opportunities': [], 'timeline': [], 'credibility_assessment': {'overall': 'moderate', 'indicators': [], 'notes': ''}, 'objections_noted': [], 'follow_up_needed': []}
        for key, default in defaults.items():
            if key not in result:
                result[key] = default
        return result
    except Exception as e:
        logger.error('LLM deposition analysis failed: %s', e)
        return {'summary_narrative': f'Automated analysis failed: {str(e)}. Manual review required.', 'key_testimony': [], 'admissions': [], 'contradictions': [], 'medical_statements': [], 'impeachment_opportunities': [], 'timeline': [], 'credibility_assessment': {'overall': 'unknown', 'indicators': [], 'notes': str(e)}, 'objections_noted': [], 'follow_up_needed': [], 'error': str(e)}

def save_deposition_summary(run_id, result):
    VAULT_DEPOSITIONS.mkdir(parents=True, exist_ok=True)
    output_path = VAULT_DEPOSITIONS / f'{run_id}_deposition.json'
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    return str(output_path)

def list_deposition_summaries():
    if not VAULT_DEPOSITIONS.exists():
        return []
    summaries = []
    for f in sorted(VAULT_DEPOSITIONS.glob('*_deposition.json'), reverse=True):
        try:
            with open(f, encoding='utf-8') as fh:
                data = json.load(fh)
            summaries.append({'run_id': f.stem.replace('_deposition', ''), 'deponent': data.get('deponent', {}).get('name', 'Unknown'), 'role': data.get('deponent', {}).get('role', 'witness'), 'analyzed_at': data.get('transcript_stats', {}).get('analyzed_at', ''), 'pages': data.get('transcript_stats', {}).get('total_pages', 0), 'key_testimony_count': len(data.get('key_testimony', [])), 'contradictions_count': len(data.get('contradictions', [])), 'admissions_count': len(data.get('admissions', []))})
        except Exception:
            continue
    return summaries