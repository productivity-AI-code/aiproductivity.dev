import base64
import hashlib
import hmac
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).parent
LICENSE_STATE_PATH = BASE_DIR / 'vault' / '.license_state.bin'
_LEGACY_STATE_PATH = BASE_DIR / 'vault' / '.license_state.json'
HMAC_SECRET = os.getenv('LICENSE_HMAC_SECRET', 'MEDRECORDS_LK_2024_s3cr3t_k3y').encode('utf-8')
FREE_TRIAL_LIMIT = 3
DEMO_EXPIRY_DAYS = 14
KEY_PREFIX = 'MRA'
PRO_ONLY_FEATURES = {'demand_package', 'case_valuation', 'billing_extractor', 'negligence_detection', 'task_generation', 'injury_visualization'}
VALID_TIERS = {'core', 'pro'}

def _ensure_vault():
    LICENSE_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)

def _default_state():
    return {'trial_cases_used': 0, 'license_key': None, 'tier': 'trial', 'activated_at': None, 'install_date': None, 'is_demo': False}

def _locked_state():
    s = _default_state()
    s['trial_cases_used'] = FREE_TRIAL_LIMIT
    s['tier'] = 'trial'
    return s

def _get_crypto():
    try:
        from license_crypto import derive_machine_key, seal_state, unseal_state
        return (derive_machine_key, seal_state, unseal_state)
    except ImportError:
        return (None, None, None)

def _read_state() -> dict:
    default = _default_state()
    derive_key, _, unseal = _get_crypto()
    if not LICENSE_STATE_PATH.exists() and _LEGACY_STATE_PATH.exists():
        try:
            with open(_LEGACY_STATE_PATH, 'r', encoding='utf-8') as f:
                legacy_data = json.load(f)
            for k, v in default.items():
                legacy_data.setdefault(k, v)
            _write_state(legacy_data)
            _LEGACY_STATE_PATH.unlink(missing_ok=True)
            logger.info('Migrated license state to encrypted format')
            return legacy_data
        except (json.JSONDecodeError, OSError):
            pass
    if not LICENSE_STATE_PATH.exists():
        installed = (BASE_DIR / '.installed').exists()
        is_demo = (BASE_DIR / '.demo_build').exists()
        if installed and is_demo:
            logger.warning('License state missing after install — locking trial')
            return _locked_state()
        return default
    try:
        blob = LICENSE_STATE_PATH.read_bytes()
    except OSError:
        return default
    if derive_key and unseal:
        key = derive_key()
        data = unseal(blob, key)
        if data is not None:
            for k, v in default.items():
                data.setdefault(k, v)
            return data
        logger.warning('License state tamper detected — returning locked state')
        return _locked_state()
    try:
        data = json.loads(blob.decode('utf-8'))
        for k, v in default.items():
            data.setdefault(k, v)
        return data
    except (json.JSONDecodeError, UnicodeDecodeError):
        return default

def _write_state(state: dict):
    _ensure_vault()
    state['_last_write'] = datetime.now(timezone.utc).isoformat()
    derive_key, seal, _ = _get_crypto()
    if derive_key and seal:
        key = derive_key()
        blob = seal(state, key)
        LICENSE_STATE_PATH.write_bytes(blob)
    else:
        with open(LICENSE_STATE_PATH, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)

def _hmac_sign(payload: str) -> str:
    sig = hmac.new(HMAC_SECRET, payload.encode('utf-8'), hashlib.sha256).hexdigest()
    return sig[:10].upper()

def _encode_segment(data: str) -> str:
    encoded = base64.b32encode(data.encode('utf-8')).decode('ascii').rstrip('=')
    return encoded.upper()

def _decode_segment(segment: str) -> str:
    padded = segment + '=' * ((8 - len(segment) % 8) % 8)
    try:
        return base64.b32decode(padded.upper()).decode('utf-8')
    except Exception:
        return ''

def validate_license_key(key: str) -> dict:
    if not key or not isinstance(key, str):
        return {'valid': False}
    key = key.strip().upper()
    pattern = '^MRA-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})$'
    match = re.match(pattern, key)
    if not match:
        return {'valid': False}
    seg1, seg2, tier_seg, sig_seg = match.groups()
    email_hash = seg1 + seg2
    tier_raw = _decode_segment(tier_seg.rstrip('X'))
    if tier_raw not in VALID_TIERS:
        for t in VALID_TIERS:
            t_encoded = _encode_segment(t)[:5].ljust(5, 'X')
            if t_encoded == tier_seg:
                tier_raw = t
                break
        if tier_raw not in VALID_TIERS:
            return {'valid': False}
    payload_check = f'hash:{email_hash}|{tier_raw}'
    expected_sig = _hmac_sign(payload_check)[:5]
    if sig_seg != expected_sig:
        alt_payload = f'{seg1}{seg2}{tier_seg}'
        alt_sig = _hmac_sign(alt_payload)[:5]
        if sig_seg != alt_sig:
            return {'valid': False}
    return {'valid': True, 'tier': tier_raw, 'email_hash': email_hash}

def register_demo():
    state = _read_state()
    state['is_demo'] = True
    state['tier'] = 'trial'
    state['install_date'] = datetime.now(timezone.utc).isoformat()
    _write_state(state)
    logger.info('Demo registered — 14-day trial started')

def get_license_state() -> dict:
    return _read_state()

def increment_trial_usage():
    state = _read_state()
    state['trial_cases_used'] = state.get('trial_cases_used', 0) + 1
    _write_state(state)

def activate_license(key: str) -> dict:
    result = validate_license_key(key)
    if not result.get('valid'):
        return {'valid': False}
    state = _read_state()
    state['license_key'] = key.strip().upper()
    state['tier'] = result['tier']
    state['activated_at'] = datetime.now(timezone.utc).isoformat()
    _write_state(state)
    return {'valid': True, 'tier': result['tier']}

def is_feature_allowed(feature_name: str) -> bool:
    state = _read_state()
    tier = state.get('tier', 'trial')
    if feature_name in PRO_ONLY_FEATURES:
        return tier == 'pro'
    return True

def get_watermark_text(force: bool=False) -> str | None:
    if force:
        return '--- INTEGRITY WARNING ---\nApplication files have been modified.\nThis output may not be reliable. Reinstall or purchase a license.\n--- INTEGRITY WARNING ---'
    state = _read_state()
    tier = state.get('tier', 'trial')
    if tier in ('core', 'pro'):
        return None
    used = state.get('trial_cases_used', 0)
    if used >= FREE_TRIAL_LIMIT:
        return '--- TRIAL VERSION ---\nThis output was generated with MedRecords AI Free Trial.\nPurchase a license at https://aiproductivity.dev/pricing to remove this watermark.\n--- TRIAL VERSION ---'
    return None

def get_trial_remaining() -> int:
    state = _read_state()
    tier = state.get('tier', 'trial')
    if tier in ('core', 'pro'):
        return 0
    used = state.get('trial_cases_used', 0)
    return max(0, FREE_TRIAL_LIMIT - used)

def is_demo_build() -> bool:
    return (BASE_DIR / '.demo_build').exists()

def is_product_build() -> bool:
    return (BASE_DIR / '.build_info').exists() or is_demo_build()

def verify_build_info() -> dict | None:
    build_info_path = BASE_DIR / '.build_info'
    if not build_info_path.exists():
        return None
    try:
        raw = json.loads(build_info_path.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return None
    stored_sig = raw.pop('_signature', None)
    if not stored_sig:
        logger.warning('Build info missing signature — tampered')
        return None
    check_payload = json.dumps(raw, sort_keys=True)
    expected_sig = hmac.new(b'MRA-BUILD-INFO-2024-SIGN', check_payload.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(stored_sig, expected_sig):
        logger.warning('Build info signature mismatch — tampered')
        return None
    return raw

def record_install_date():
    state = _read_state()
    if not state.get('install_date'):
        state['install_date'] = datetime.now(timezone.utc).isoformat()
        state['is_demo'] = True
        _write_state(state)

def _verify_demo_marker() -> dict | None:
    marker_path = BASE_DIR / '.demo_build'
    if not marker_path.exists():
        return None
    try:
        raw = json.loads(marker_path.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return None
    stored_sig = raw.pop('_signature', None)
    if not stored_sig:
        logger.warning('Demo marker missing signature — tampered')
        return None
    check_payload = json.dumps(raw, sort_keys=True)
    expected_sig = hmac.new(b'MRA-DEMO-MARKER-2024-SIGN', check_payload.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(stored_sig, expected_sig):
        logger.warning('Demo marker signature mismatch — tampered')
        return None
    return raw

def check_demo_expiration() -> dict:
    now = datetime.now(timezone.utc)
    state = _read_state()
    last_write = state.get('_last_write')
    if last_write:
        try:
            lw_dt = datetime.fromisoformat(last_write)
            if now < lw_dt - __import__('datetime').timedelta(minutes=5):
                logger.warning('System clock rolled back — locking demo')
                return {'expired': True, 'days_remaining': 0, 'install_date': state.get('install_date'), 'reason': 'clock_rollback'}
        except (ValueError, TypeError):
            pass
    marker = _verify_demo_marker()
    if marker is None:
        bi = verify_build_info()
        if bi and bi.get('build_type') == 'demo':
            marker = bi
    if marker is not None:
        built_at_str = marker.get('built_at')
        if built_at_str:
            try:
                built_at = datetime.fromisoformat(built_at_str)
                if now < built_at:
                    logger.warning('System clock before build date — locking demo')
                    return {'expired': True, 'days_remaining': 0, 'install_date': state.get('install_date'), 'reason': 'clock_rollback'}
                install_str = state.get('install_date')
                if install_str:
                    install_dt = datetime.fromisoformat(install_str)
                    if install_dt < built_at - __import__('datetime').timedelta(hours=1):
                        logger.warning('Install date before build date — locking demo')
                        return {'expired': True, 'days_remaining': 0, 'install_date': install_str, 'reason': 'install_date_invalid'}
            except (ValueError, TypeError):
                pass
        expiry_days = marker.get('expiry_days', DEMO_EXPIRY_DAYS)
    elif (BASE_DIR / '.demo_build').exists():
        return {'expired': True, 'days_remaining': 0, 'install_date': state.get('install_date'), 'reason': 'marker_tampered'}
    else:
        expiry_days = DEMO_EXPIRY_DAYS
    install_str = state.get('install_date')
    if not install_str:
        return {'expired': False, 'days_remaining': expiry_days, 'install_date': None, 'reason': None}
    install_date = datetime.fromisoformat(install_str)
    elapsed = (now - install_date).days
    remaining = max(0, expiry_days - elapsed)
    return {'expired': remaining <= 0, 'days_remaining': remaining, 'install_date': install_str, 'reason': 'time_expired' if remaining <= 0 else None}