"""
db.py -- Unified database schema and connection management for MedRecords AI.

Single source of truth for the tracking database schema. Replaces duplicated
schema definitions across medical_app.py, retrieval_bot.py, and setup_medical.py.

Features:
- WAL mode for concurrent read/write
- Automatic schema migration
- Transaction context manager
- Connection pooling via thread-local storage

Usage:
    from db import get_db, init_db, transaction

    # Read
    conn = get_db()
    rows = conn.execute("SELECT * FROM contacts").fetchall()
    conn.close()

    # Write with transaction
    with transaction() as conn:
        conn.execute("INSERT INTO contacts (...) VALUES (...)", (...))
"""

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

BASE_DIR = Path(__file__).parent
TRACKING_DB = BASE_DIR / "tracking.db"

# Thread-local storage for connections
_local = threading.local()

# Schema version for migrations
SCHEMA_VERSION = 4

SCHEMA_SQL = """
-- Contacts table: tracks all record request contacts
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    contact_type TEXT DEFAULT 'custodian'
        CHECK(contact_type IN ('custodian', 'counsel', 'patient', 'provider')),
    organization TEXT,
    patient_case_ref TEXT,
    record_type_needed TEXT,
    date_added TEXT NOT NULL,
    status TEXT DEFAULT 'new'
        CHECK(status IN ('new', 'contacted', 'awaiting', 'received', 'failed', 'cancelled')),
    last_contact_date TEXT,
    thread_id TEXT,
    upload_token TEXT UNIQUE,
    notes TEXT,
    priority TEXT DEFAULT 'normal'
        CHECK(priority IN ('normal', 'high', 'urgent')),
    follow_up_count INTEGER DEFAULT 0,
    excel_row INTEGER,
    source TEXT DEFAULT 'manual'
        CHECK(source IN ('manual', 'excel', 'ui', 'api')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Email log: tracks all inbound/outbound emails per contact
CREATE TABLE IF NOT EXISTS email_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    direction TEXT NOT NULL CHECK(direction IN ('inbound', 'outbound')),
    subject TEXT,
    message_id TEXT,
    in_reply_to TEXT,
    timestamp TEXT DEFAULT (datetime('now')),
    status TEXT DEFAULT 'sent'
        CHECK(status IN ('sent', 'delivered', 'failed', 'bounced', 'received')),
    error_message TEXT,
    has_attachments INTEGER DEFAULT 0,
    attachment_paths TEXT,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);

-- Access log: tracks who accessed what data (HIPAA requirement)
CREATE TABLE IF NOT EXISTS access_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT DEFAULT (datetime('now')),
    username TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    ip_address TEXT,
    details TEXT
);

-- Summary feedback for RLHF
CREATE TABLE IF NOT EXISTS summary_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    rating TEXT NOT NULL CHECK(rating IN ('poor', 'good', 'excellent')),
    feedback_text TEXT,
    username TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Case valuation outcome tracking for RL calibration
CREATE TABLE IF NOT EXISTS valuation_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    predicted_low INTEGER,
    predicted_mid INTEGER,
    predicted_high INTEGER,
    predicted_severity TEXT,
    actual_settlement INTEGER,
    actual_verdict INTEGER,
    outcome_type TEXT CHECK(outcome_type IN ('settled', 'verdict', 'dismissed', 'pending')),
    attorney_accuracy_rating TEXT CHECK(attorney_accuracy_rating IN ('too_low', 'accurate', 'too_high')),
    attorney_notes TEXT,
    jurisdiction TEXT,
    case_type TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Demand package feedback for RL
CREATE TABLE IF NOT EXISTS demand_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    rating TEXT CHECK(rating IN ('poor', 'good', 'excellent')),
    sections_edited TEXT,
    edit_severity TEXT CHECK(edit_severity IN ('minor_tweaks', 'significant_rewrites', 'unusable')),
    tone_feedback TEXT CHECK(tone_feedback IN ('too_aggressive', 'appropriate', 'too_conservative')),
    legal_accuracy INTEGER CHECK(legal_accuracy BETWEEN 1 AND 5),
    feedback_text TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Negligence detection feedback for RL
CREATE TABLE IF NOT EXISTS negligence_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    finding_title TEXT,
    finding_accepted INTEGER CHECK(finding_accepted IN (0, 1)),
    severity_correct INTEGER CHECK(severity_correct IN (0, 1)),
    corrected_severity TEXT,
    attorney_notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Few-shot exemplar bank for prompt enhancement
CREATE TABLE IF NOT EXISTS exemplar_bank (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    feature TEXT NOT NULL CHECK(feature IN ('valuation', 'demand', 'negligence')),
    input_hash TEXT NOT NULL,
    input_summary TEXT NOT NULL,
    output TEXT NOT NULL,
    quality_score REAL,
    severity TEXT,
    case_type TEXT,
    jurisdiction TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Adaptive system parameters (calibrated from feedback data)
CREATE TABLE IF NOT EXISTS system_parameters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    param_category TEXT NOT NULL,
    param_key TEXT NOT NULL,
    param_value TEXT NOT NULL,
    source TEXT DEFAULT 'manual',
    sample_count INTEGER DEFAULT 0,
    calibrated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(param_category, param_key)
);

-- Email configuration
CREATE TABLE IF NOT EXISTS email_config (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    smtp_host TEXT,
    smtp_port INTEGER DEFAULT 587,
    smtp_username TEXT,
    smtp_password_encrypted TEXT,
    imap_host TEXT,
    imap_port INTEGER DEFAULT 993,
    imap_username TEXT,
    imap_password_encrypted TEXT,
    sender_name TEXT,
    sender_organization TEXT,
    sender_phone TEXT,
    enabled INTEGER DEFAULT 0,
    updated_at TEXT DEFAULT (datetime('now')),
    updated_by TEXT
);

-- Documents table: tracks all files through the vault lifecycle
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    original_path TEXT NOT NULL,
    current_path TEXT,
    file_hash TEXT,
    file_size INTEGER,
    extension TEXT,
    vault_zone TEXT DEFAULT 'incoming'
        CHECK(vault_zone IN ('incoming', 'processing', 'processed', 'failed')),
    status TEXT DEFAULT 'pending'
        CHECK(status IN ('pending', 'processing', 'completed', 'failed')),
    case_ref TEXT,
    category TEXT DEFAULT 'uncategorized',
    contact_id INTEGER,
    run_id TEXT,
    summary_file TEXT,
    notes TEXT,
    uploaded_by TEXT,
    upload_source TEXT DEFAULT 'manual'
        CHECK(upload_source IN ('manual', 'secure_upload', 'email', 'api', 'demo')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    processed_at TEXT,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);

-- Schema version tracking for migrations
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT DEFAULT (datetime('now'))
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_contacts_status ON contacts(status);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(contact_email);
CREATE INDEX IF NOT EXISTS idx_contacts_upload_token ON contacts(upload_token);
CREATE INDEX IF NOT EXISTS idx_contacts_case_ref ON contacts(patient_case_ref);
CREATE INDEX IF NOT EXISTS idx_email_log_contact ON email_log(contact_id);
CREATE INDEX IF NOT EXISTS idx_access_log_timestamp ON access_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_access_log_username ON access_log(username);
CREATE INDEX IF NOT EXISTS idx_summary_feedback_run_id ON summary_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_valuation_outcomes_run_id ON valuation_outcomes(run_id);
CREATE INDEX IF NOT EXISTS idx_valuation_outcomes_severity ON valuation_outcomes(predicted_severity);
CREATE INDEX IF NOT EXISTS idx_demand_feedback_run_id ON demand_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_negligence_feedback_run_id ON negligence_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_exemplar_bank_feature ON exemplar_bank(feature);
CREATE INDEX IF NOT EXISTS idx_exemplar_bank_lookup ON exemplar_bank(feature, severity, case_type);
CREATE INDEX IF NOT EXISTS idx_system_parameters_lookup ON system_parameters(param_category, param_key);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_case_ref ON documents(case_ref);
CREATE INDEX IF NOT EXISTS idx_documents_contact_id ON documents(contact_id);
CREATE INDEX IF NOT EXISTS idx_documents_vault_zone ON documents(vault_zone);
CREATE INDEX IF NOT EXISTS idx_documents_hash ON documents(file_hash);
"""


def _create_connection(db_path: str = None) -> sqlite3.Connection:
    """Create a new database connection with production settings."""
    path = db_path or str(TRACKING_DB)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row

    # Enable WAL mode for concurrent reads during writes
    conn.execute("PRAGMA journal_mode=WAL")
    # Enable foreign key enforcement
    conn.execute("PRAGMA foreign_keys=ON")
    # Faster sync (safe with WAL mode)
    conn.execute("PRAGMA synchronous=NORMAL")
    # Larger cache for better read performance
    conn.execute("PRAGMA cache_size=-8000")  # 8MB

    return conn


def get_db(db_path: str = None) -> sqlite3.Connection:
    """Get a database connection. Creates new one per call for thread safety."""
    return _create_connection(db_path)


@contextmanager
def transaction(db_path: str = None):
    """
    Context manager for database transactions.
    Auto-commits on success, rolls back on exception.

    Usage:
        with transaction() as conn:
            conn.execute("INSERT INTO ...", (...))
            conn.execute("UPDATE ...", (...))
    """
    conn = _create_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _migrate_schema(conn):
    """Apply schema migrations for columns added after initial release."""
    # Contacts table migrations
    contacts_cols = {row[1] for row in conn.execute("PRAGMA table_info(contacts)").fetchall()}

    contacts_migrations = [
        ("source", "ALTER TABLE contacts ADD COLUMN source TEXT DEFAULT 'manual'"),
        ("excel_row", "ALTER TABLE contacts ADD COLUMN excel_row INTEGER"),
    ]

    for col_name, sql in contacts_migrations:
        if col_name not in contacts_cols:
            conn.execute(sql)

    # Email_log table migrations
    email_log_cols = {row[1] for row in conn.execute("PRAGMA table_info(email_log)").fetchall()}

    email_log_migrations = [
        ("has_attachments", "ALTER TABLE email_log ADD COLUMN has_attachments INTEGER DEFAULT 0"),
        ("attachment_paths", "ALTER TABLE email_log ADD COLUMN attachment_paths TEXT"),
    ]

    for col_name, sql in email_log_migrations:
        if col_name not in email_log_cols:
            conn.execute(sql)

    conn.commit()


def init_db(db_path: str = None):
    """
    Initialize the database schema. Safe to call multiple times
    (uses CREATE TABLE IF NOT EXISTS).
    """
    conn = _create_connection(db_path)
    try:
        conn.executescript(SCHEMA_SQL)

        # Apply migrations for existing databases
        _migrate_schema(conn)

        # Record schema version
        current = conn.execute(
            "SELECT MAX(version) FROM schema_version"
        ).fetchone()[0]

        if current is None or current < SCHEMA_VERSION:
            conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (?)",
                (SCHEMA_VERSION,),
            )
            conn.commit()
    finally:
        conn.close()


def log_access(username: str, action: str, resource_type: str,
               resource_id: str = None, ip_address: str = None,
               details: str = None, db_path: str = None):
    """
    Log a data access event for HIPAA compliance.
    Non-blocking: silently fails if database is unavailable.
    """
    try:
        with transaction(db_path) as conn:
            conn.execute(
                """INSERT INTO access_log
                   (username, action, resource_type, resource_id, ip_address, details)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (username, action, resource_type, resource_id, ip_address, details),
            )
    except Exception:
        pass  # Access logging should never break the main flow


def get_schema_version(db_path: str = None) -> int:
    """Get the current schema version."""
    try:
        conn = _create_connection(db_path)
        version = conn.execute(
            "SELECT MAX(version) FROM schema_version"
        ).fetchone()[0]
        conn.close()
        return version or 0
    except Exception:
        return 0
