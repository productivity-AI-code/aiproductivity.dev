"""
demo_guard.py -- Demo expiration and feature enforcement for MedRecords AI.

When running as a demo build (detected by .demo_build marker file), enforces:
  - 14-day time limit from install date
  - Pro features blocked (modules not shipped + is_feature_allowed checks)
  - Demo banner info in API responses
"""

from pathlib import Path
from flask import request, jsonify, g

DEMO_MARKER = Path(__file__).parent / ".demo_build"


def is_demo() -> bool:
    """Check if this is a demo build."""
    return DEMO_MARKER.exists()


def init_demo_guard(app):
    """Register demo guard middleware with the Flask app. No-op if not a demo build."""
    if not is_demo():
        return

    app.logger.info("Demo build detected — enabling demo guard (14-day expiration)")

    @app.before_request
    def _check_demo_expiration():
        # Allow health check, static files, license, and login endpoints
        exempt = ("/health", "/static/", "/api/license/", "/login", "/logout", "/api/csrf-token")
        if any(request.path.startswith(p) for p in exempt):
            return None

        from licensing import check_demo_expiration
        status = check_demo_expiration()

        if status["expired"]:
            if request.path.startswith("/api/"):
                return jsonify({
                    "error": "Demo expired",
                    "message": "Your 14-day demo has expired. Purchase a license to continue using MedRecords AI.",
                    "upgrade_url": "https://aiproductivity.dev/pricing",
                    "expired": True,
                }), 403
            # For HTML requests, still allow page load but the JS will handle the expired state
            g.demo_expired = True

        g.demo_days_remaining = status.get("days_remaining", 0)
        g.is_demo = True

    @app.after_request
    def _add_demo_header(response):
        if getattr(g, 'is_demo', False):
            response.headers["X-Demo-Version"] = "true"
            response.headers["X-Demo-Days-Remaining"] = str(getattr(g, 'demo_days_remaining', 0))
        return response
