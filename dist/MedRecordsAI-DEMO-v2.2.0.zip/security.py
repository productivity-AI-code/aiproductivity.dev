import functools
import hashlib
import hmac
import html
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import datetime, timezone
from flask import Flask, request, session, jsonify, redirect, url_for, make_response, g
DEFAULT_ADMIN_USER = 'admin'

def _get_password_hash(password: str) -> str:
    salt = os.getenv('AUTH_SALT', 'medrecords-default-salt')
    return hashlib.sha256(f'{salt}:{password}'.encode()).hexdigest()

class RateLimiter:

    def __init__(self):
        self._buckets = defaultdict(lambda: {'tokens': 0, 'last_refill': 0.0})

    def is_allowed(self, key: str, max_tokens: int, refill_rate: float) -> bool:
        now = time.time()
        bucket = self._buckets[key]
        elapsed = now - bucket['last_refill']
        bucket['tokens'] = min(max_tokens, bucket['tokens'] + elapsed * refill_rate)
        bucket['last_refill'] = now
        if bucket['tokens'] >= 1:
            bucket['tokens'] -= 1
            return True
        return False

    def cleanup(self, max_age_seconds: int=3600):
        now = time.time()
        stale = [k for k, v in self._buckets.items() if now - v['last_refill'] > max_age_seconds]
        for k in stale:
            del self._buckets[k]
_limiter = RateLimiter()
_last_cleanup = time.time()

def rate_limit(requests_per_minute: int=30, burst: int=None):
    burst = burst or requests_per_minute
    refill_rate = requests_per_minute / 60.0

    def decorator(f):

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            global _last_cleanup
            client_ip = request.remote_addr or 'unknown'
            key = f'{f.__name__}:{client_ip}'
            if not _limiter.is_allowed(key, burst, refill_rate):
                return (jsonify({'error': 'Rate limit exceeded. Please try again later.'}), 429)
            now = time.time()
            if now - _last_cleanup > 600:
                _limiter.cleanup()
                _last_cleanup = now
            return f(*args, **kwargs)
        return wrapper
    return decorator

def _generate_csrf_token() -> str:
    token = secrets.token_hex(32)
    session['_csrf_token'] = token
    return token

def get_csrf_token() -> str:
    if '_csrf_token' not in session:
        return _generate_csrf_token()
    return session['_csrf_token']

def _validate_csrf():
    if request.method in ('GET', 'HEAD', 'OPTIONS'):
        return
    if request.path in ('/login', '/logout'):
        return
    if request.path.startswith('/api/secure-upload/'):
        return
    if request.headers.get('X-API-Key'):
        return
    token = request.headers.get('X-CSRF-Token') or request.form.get('_csrf_token') or (request.get_json(silent=True) or {}).get('_csrf_token')
    expected = session.get('_csrf_token')
    if not token or not expected or (not hmac.compare_digest(token, expected)):
        return (jsonify({'error': 'CSRF validation failed'}), 403)

def require_auth(f):

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('authenticated'):
            g.auth_user = session.get('username', 'session_user')
            return f(*args, **kwargs)
        api_key = request.headers.get('X-API-Key')
        expected_key = os.getenv('API_KEY')
        if api_key and expected_key and hmac.compare_digest(api_key, expected_key):
            g.auth_user = 'api_key_user'
            return f(*args, **kwargs)
        if request.path.startswith('/api/'):
            return (jsonify({'error': 'Authentication required'}), 401)
        return redirect('/login')
    return wrapper

def _check_credentials(username: str, password: str) -> bool:
    expected_user = os.getenv('AUTH_USERNAME', DEFAULT_ADMIN_USER)
    expected_hash = os.getenv('AUTH_PASSWORD_HASH')
    if not expected_hash:
        expected_password = os.getenv('AUTH_PASSWORD', '')
        if not expected_password:
            return False
        expected_hash = _get_password_hash(expected_password)
    provided_hash = _get_password_hash(password)
    return hmac.compare_digest(username, expected_user) and hmac.compare_digest(provided_hash, expected_hash)

def _add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    csp = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self' http://localhost:11434; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    response.headers['Content-Security-Policy'] = csp
    if request.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
        response.headers['Pragma'] = 'no-cache'
    return response
EMAIL_RE = re.compile('^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$')
MAX_FIELD_LENGTHS = {'contact_name': 200, 'contact_email': 254, 'organization': 300, 'patient_case_ref': 100, 'record_type_needed': 100, 'notes': 2000, 'priority': 20, 'contact_type': 50}

def validate_contact_input(data: dict) -> list:
    errors = []
    if not data:
        return ['Request body is required']
    name = data.get('contact_name', '').strip()
    email = data.get('contact_email', '').strip()
    if not name:
        errors.append('contact_name is required')
    if not email:
        errors.append('contact_email is required')
    elif not EMAIL_RE.match(email):
        errors.append('contact_email is not a valid email address')
    for field, max_len in MAX_FIELD_LENGTHS.items():
        value = data.get(field, '')
        if isinstance(value, str) and len(value) > max_len:
            errors.append(f'{field} exceeds maximum length of {max_len} characters')
    valid_types = {'custodian', 'counsel', 'patient', 'provider'}
    if data.get('contact_type') and data['contact_type'] not in valid_types:
        errors.append(f"contact_type must be one of: {', '.join(valid_types)}")
    valid_priorities = {'normal', 'high', 'urgent'}
    if data.get('priority') and data['priority'] not in valid_priorities:
        errors.append(f"priority must be one of: {', '.join(valid_priorities)}")
    return errors

def sanitize_string(value: str, max_length: int=500) -> str:
    if not isinstance(value, str):
        return ''
    return html.escape(value.strip()[:max_length])

def validate_startup_config(app, config: dict, logger) -> list:
    warnings = []
    errors = []
    secret = app.secret_key
    if not secret or secret in ('dev-secret-change-me', 'change-this'):
        errors.append('CRITICAL: Flask secret key is not set or uses default value. Set FLASK_SECRET_KEY environment variable.')
    auth_password = os.getenv('AUTH_PASSWORD', '')
    auth_hash = os.getenv('AUTH_PASSWORD_HASH', '')
    if not auth_password and (not auth_hash):
        warnings.append('WARNING: No AUTH_PASSWORD or AUTH_PASSWORD_HASH set. Login will be disabled. Set AUTH_PASSWORD in .env for production.')
    api_key = os.getenv('API_KEY', '')
    if not api_key:
        warnings.append('WARNING: No API_KEY set. API key authentication is disabled.')
    smtp_host = os.getenv('SMTP_HOST', '')
    if smtp_host and smtp_host in ('smtp.example.com', ''):
        warnings.append('WARNING: SMTP_HOST is not configured. Email retrieval bot will not function.')
    ollama_cfg = config.get('ollama', {})
    if not ollama_cfg.get('endpoint'):
        warnings.append('WARNING: Ollama endpoint not configured in config.yaml')
    for w in warnings:
        logger.warning(w)
    for e in errors:
        logger.error(e)
    return warnings + errors

def sign_audit_entry(entry: dict) -> str:
    key = os.getenv('AUDIT_HMAC_KEY', os.getenv('FLASK_SECRET_KEY', ''))
    if not key:
        key = 'unsigned-audit-entry'
    canonical = {k: v for k, v in sorted(entry.items()) if k != 'hmac_signature'}
    import json
    payload = json.dumps(canonical, sort_keys=True, default=str)
    return hmac.new(key.encode(), payload.encode(), hashlib.sha256).hexdigest()

def verify_audit_signature(entry: dict) -> bool:
    stored_sig = entry.get('hmac_signature')
    if not stored_sig:
        return False
    expected_sig = sign_audit_entry(entry)
    return hmac.compare_digest(stored_sig, expected_sig)

def init_security(app: Flask):
    secret = os.getenv('FLASK_SECRET_KEY', '')
    if secret:
        app.secret_key = secret
    elif not app.secret_key:
        app.secret_key = secrets.token_hex(32)
        app.logger.warning("No FLASK_SECRET_KEY set. Generated ephemeral key (sessions won't survive restart). Set FLASK_SECRET_KEY in .env for production.")
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_COOKIE_SECURE'] = os.getenv('FLASK_ENV') == 'production'
    app.config['PERMANENT_SESSION_LIFETIME'] = 28800

    @app.before_request
    def csrf_check():
        result = _validate_csrf()
        if result:
            return result

    @app.context_processor
    def inject_csrf():
        return {'csrf_token': get_csrf_token}
    app.after_request(_add_security_headers)

    @app.route('/api/csrf-token')
    def csrf_token_endpoint():
        return jsonify({'csrf_token': get_csrf_token()})