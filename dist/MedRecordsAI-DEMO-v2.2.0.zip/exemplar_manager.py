"""
exemplar_manager.py -- Few-shot exemplar bank for RL-enhanced prompt generation.

Stores high-quality input/output pairs from attorney-validated results.
Retrieves similar exemplars to inject as few-shot examples into LLM prompts,
improving output consistency without model fine-tuning.

Memory-efficient: Uses SQLite for storage, simple attribute matching for
retrieval (no vector embeddings required).

Usage:
    from exemplar_manager import store_exemplar, get_exemplars, build_exemplar_prompt

    # Store a validated exemplar
    store_exemplar("valuation", input_data, output_data, quality_score=0.95,
                   severity="serious", case_type="mva", jurisdiction="CA")

    # Retrieve similar exemplars for prompt injection
    exemplars = get_exemplars("valuation", severity="serious", case_type="mva", limit=3)

    # Build prompt block from exemplars
    prompt_block = build_exemplar_prompt("valuation", exemplars)
"""

import hashlib
import json
import logging
from datetime import datetime

logger = logging.getLogger("exemplar_manager")


def _get_db():
    """Get a database connection."""
    from db import get_db
    return get_db()


def _input_hash(input_data):
    """Generate a hash of the input data for deduplication."""
    text = json.dumps(input_data, sort_keys=True, default=str)
    return hashlib.sha256(text.encode()).hexdigest()[:32]


def store_exemplar(feature, input_data, output_data, quality_score=1.0,
                   severity=None, case_type=None, jurisdiction=None):
    """
    Store a high-quality input/output pair as a few-shot exemplar.

    Args:
        feature: "valuation", "demand", or "negligence"
        input_data: dict of case data that was input to the feature
        output_data: dict of the output that was produced
        quality_score: 0.0-1.0 quality rating (from attorney feedback)
        severity: injury severity tier (for matching)
        case_type: case type (e.g., "mva", "slip_fall")
        jurisdiction: state code (e.g., "CA", "TX")

    Returns:
        int: exemplar ID, or None if duplicate/error
    """
    if feature not in ("valuation", "demand", "negligence"):
        logger.warning("Invalid feature for exemplar: %s", feature)
        return None

    ih = _input_hash(input_data)

    conn = _get_db()
    try:
        # Check for duplicate
        existing = conn.execute(
            "SELECT id FROM exemplar_bank WHERE feature = ? AND input_hash = ?",
            (feature, ih),
        ).fetchone()

        if existing:
            # Update quality score if new one is higher
            conn.execute(
                """UPDATE exemplar_bank SET quality_score = MAX(quality_score, ?),
                   output = ? WHERE id = ?""",
                (quality_score, json.dumps(output_data, default=str), existing["id"]),
            )
            conn.commit()
            logger.info("Updated exemplar %d quality to %.2f", existing["id"], quality_score)
            return existing["id"]

        cursor = conn.execute(
            """INSERT INTO exemplar_bank
               (feature, input_hash, input_summary, output, quality_score,
                severity, case_type, jurisdiction)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (feature, ih,
             json.dumps(input_data, default=str),
             json.dumps(output_data, default=str),
             quality_score,
             severity, case_type, jurisdiction),
        )
        conn.commit()
        eid = cursor.lastrowid
        logger.info("Stored new %s exemplar #%d (severity=%s, type=%s, jurisdiction=%s)",
                     feature, eid, severity, case_type, jurisdiction)
        return eid

    except Exception as e:
        logger.error("Failed to store exemplar: %s", e)
        return None
    finally:
        conn.close()


def get_exemplars(feature, severity=None, case_type=None, jurisdiction=None,
                  limit=3, min_quality=0.7):
    """
    Retrieve the most relevant exemplars for a given feature and case profile.

    Matching priority:
    1. Exact match on severity + case_type + jurisdiction
    2. Match on severity + case_type (any jurisdiction)
    3. Match on severity only
    4. Any exemplar for this feature (highest quality first)

    Args:
        feature: "valuation", "demand", or "negligence"
        severity: injury severity tier to match
        case_type: case type to match
        jurisdiction: state code to match
        limit: max exemplars to return
        min_quality: minimum quality score threshold

    Returns:
        list of dicts with keys: input_summary, output, quality_score, severity, case_type, jurisdiction
    """
    conn = _get_db()
    try:
        results = []

        # Tier 1: Exact match
        if severity and case_type and jurisdiction:
            rows = conn.execute(
                """SELECT * FROM exemplar_bank
                   WHERE feature = ? AND severity = ? AND case_type = ? AND jurisdiction = ?
                   AND quality_score >= ?
                   ORDER BY quality_score DESC LIMIT ?""",
                (feature, severity, case_type, jurisdiction, min_quality, limit),
            ).fetchall()
            results.extend(dict(r) for r in rows)

        # Tier 2: severity + case_type
        if len(results) < limit and severity and case_type:
            existing_ids = {r["id"] for r in results}
            rows = conn.execute(
                """SELECT * FROM exemplar_bank
                   WHERE feature = ? AND severity = ? AND case_type = ?
                   AND quality_score >= ?
                   ORDER BY quality_score DESC LIMIT ?""",
                (feature, severity, case_type, min_quality, limit),
            ).fetchall()
            for r in rows:
                if dict(r)["id"] not in existing_ids and len(results) < limit:
                    results.append(dict(r))

        # Tier 3: severity only
        if len(results) < limit and severity:
            existing_ids = {r["id"] for r in results}
            rows = conn.execute(
                """SELECT * FROM exemplar_bank
                   WHERE feature = ? AND severity = ?
                   AND quality_score >= ?
                   ORDER BY quality_score DESC LIMIT ?""",
                (feature, severity, min_quality, limit),
            ).fetchall()
            for r in rows:
                if dict(r)["id"] not in existing_ids and len(results) < limit:
                    results.append(dict(r))

        # Tier 4: any exemplar for this feature
        if len(results) < limit:
            existing_ids = {r["id"] for r in results}
            rows = conn.execute(
                """SELECT * FROM exemplar_bank
                   WHERE feature = ? AND quality_score >= ?
                   ORDER BY quality_score DESC LIMIT ?""",
                (feature, min_quality, limit),
            ).fetchall()
            for r in rows:
                if dict(r)["id"] not in existing_ids and len(results) < limit:
                    results.append(dict(r))

        return results

    except Exception as e:
        logger.error("Failed to retrieve exemplars: %s", e)
        return []
    finally:
        conn.close()


def build_exemplar_prompt(feature, exemplars):
    """
    Build a prompt block from exemplars for injection into LLM calls.

    Args:
        feature: "valuation", "demand", or "negligence"
        exemplars: list of exemplar dicts from get_exemplars()

    Returns:
        str: prompt block to inject, or empty string if no exemplars
    """
    if not exemplars:
        return ""

    feature_labels = {
        "valuation": "CASE VALUATION",
        "demand": "DEMAND PACKAGE",
        "negligence": "NEGLIGENCE DETECTION",
    }
    label = feature_labels.get(feature, feature.upper())

    parts = [f"## REFERENCE EXAMPLES — HIGH-QUALITY {label} OUTPUTS"]
    parts.append(f"The following {len(exemplars)} example(s) were rated highly by attorneys. "
                 "Use them as reference for style, detail level, and reasoning quality.\n")

    for i, ex in enumerate(exemplars, 1):
        try:
            input_data = json.loads(ex["input_summary"]) if isinstance(ex["input_summary"], str) else ex["input_summary"]
            output_data = json.loads(ex["output"]) if isinstance(ex["output"], str) else ex["output"]
        except (json.JSONDecodeError, TypeError):
            continue

        parts.append(f"### Example {i} (Quality: {ex.get('quality_score', 'N/A')}, "
                     f"Severity: {ex.get('severity', 'N/A')}, Type: {ex.get('case_type', 'N/A')})")

        # Summarize input (keep it brief to save tokens)
        if feature == "valuation":
            input_summary = _summarize_valuation_input(input_data)
            output_summary = _summarize_valuation_output(output_data)
        elif feature == "demand":
            input_summary = _summarize_demand_input(input_data)
            output_summary = _summarize_demand_output(output_data)
        elif feature == "negligence":
            input_summary = _summarize_negligence_input(input_data)
            output_summary = _summarize_negligence_output(output_data)
        else:
            input_summary = json.dumps(input_data, indent=2)[:500]
            output_summary = json.dumps(output_data, indent=2)[:500]

        parts.append(f"**Input Context**: {input_summary}")
        parts.append(f"**Output**: {output_summary}\n")

    parts.append("Use these examples as guidance for quality and format. "
                 "Adapt to the current case specifics.\n")

    return "\n".join(parts)


def _summarize_valuation_input(data):
    """Create a brief summary of valuation input for the prompt."""
    summary = data.get("summary", data)
    diagnoses = summary.get("active_diagnoses", [])
    dx_text = ", ".join(
        (d.get("diagnosis", str(d)) if isinstance(d, dict) else str(d))
        for d in diagnoses[:3]
    )
    billing = summary.get("billing_data", {})
    total = billing.get("total_combined", billing.get("total_past_medical", "N/A"))
    return f"Diagnoses: {dx_text or 'N/A'}. Medical specials: ${total}."


def _summarize_valuation_output(data):
    """Create a brief summary of valuation output."""
    return (f"Range: ${data.get('low', 'N/A'):,} - ${data.get('high', 'N/A'):,} "
            f"(mid: ${data.get('mid', 'N/A'):,}). "
            f"Severity: {data.get('severity', 'N/A')}. "
            f"Reasoning: {(data.get('reasoning') or 'N/A')[:200]}")


def _summarize_demand_input(data):
    """Create a brief summary of demand input."""
    summary = data.get("summary", data)
    diagnoses = summary.get("active_diagnoses", [])
    dx_text = ", ".join(
        (d.get("diagnosis", str(d)) if isinstance(d, dict) else str(d))
        for d in diagnoses[:3]
    )
    return f"Case type: {data.get('case_type', 'N/A')}. Diagnoses: {dx_text or 'N/A'}."


def _summarize_demand_output(data):
    """Create a brief summary of demand output."""
    narrative = data.get("narrative", {})
    return (f"Demand amount: ${data.get('demand_amount', 'N/A'):,}. "
            f"Sections: {len(narrative)} narrative sections generated.")


def _summarize_negligence_input(data):
    """Create a brief summary of negligence input."""
    summary = data.get("summary", data)
    diagnoses = summary.get("active_diagnoses", [])
    dx_text = ", ".join(
        (d.get("diagnosis", str(d)) if isinstance(d, dict) else str(d))
        for d in diagnoses[:3]
    )
    return f"Diagnoses: {dx_text or 'N/A'}."


def _summarize_negligence_output(data):
    """Create a brief summary of negligence output."""
    findings = data.get("findings", [])
    if not findings:
        return "No findings."
    titles = [f.get("title", "Unknown") for f in findings[:3]]
    return f"{len(findings)} findings: {'; '.join(titles)}."


def get_exemplar_count(feature=None):
    """Get count of exemplars, optionally filtered by feature."""
    conn = _get_db()
    try:
        if feature:
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM exemplar_bank WHERE feature = ?",
                (feature,),
            ).fetchone()
        else:
            row = conn.execute("SELECT COUNT(*) as cnt FROM exemplar_bank").fetchone()
        return row["cnt"] if row else 0
    except Exception:
        return 0
    finally:
        conn.close()


def prune_exemplars(feature, max_per_feature=50):
    """Remove lowest-quality exemplars if bank exceeds max size."""
    conn = _get_db()
    try:
        count = conn.execute(
            "SELECT COUNT(*) as cnt FROM exemplar_bank WHERE feature = ?",
            (feature,),
        ).fetchone()["cnt"]

        if count <= max_per_feature:
            return 0

        excess = count - max_per_feature
        conn.execute(
            """DELETE FROM exemplar_bank WHERE id IN (
                SELECT id FROM exemplar_bank WHERE feature = ?
                ORDER BY quality_score ASC LIMIT ?)""",
            (feature, excess),
        )
        conn.commit()
        logger.info("Pruned %d low-quality %s exemplars", excess, feature)
        return excess

    except Exception as e:
        logger.error("Failed to prune exemplars: %s", e)
        return 0
    finally:
        conn.close()
