"""
medical_app.py -- Flask backend for Medical Records Retrieval & Summarization UI.

Production-hardened with:
- Session-based authentication + API key support
- CSRF protection on all state-changing endpoints
- Rate limiting on upload/auth endpoints
- Security headers (CSP, X-Frame-Options, etc.)
- Input validation with field length limits
- Pagination on list endpoints
- Structured JSON logging with rotation
- Health check endpoint with dependency verification
- HIPAA access logging
- Startup configuration validation
- Batch contact import from Excel
- HMAC-signed audit trail entries

Usage:
  python medical_app.py                   # Run on configured port
  python medical_app.py --port 8080       # Custom port
"""

import argparse
import hashlib
import io
import json
import logging
import logging.handlers
import os
import re
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import yaml
from dotenv import load_dotenv
from flask import (
    Flask, request, jsonify, send_from_directory, send_file, abort, session, redirect,
    make_response,
)
from werkzeug.utils import secure_filename

load_dotenv()

BASE_DIR = Path(__file__).parent
VAULT_INCOMING = BASE_DIR / "vault" / "incoming"
VAULT_SUMMARIES = BASE_DIR / "vault" / "summaries"
VAULT_AUDIT = BASE_DIR / "vault" / "audit"
PIPELINE_STATUS_DIR = BASE_DIR / "vault" / "pipeline_status"
UI_DIR = BASE_DIR / "ui"

app = Flask(__name__, static_folder=str(UI_DIR), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100MB

ALLOWED_EXTENSIONS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif",
    ".dcm", ".dicom", ".doc", ".docx", ".txt",
    ".csv", ".json", ".xml", ".log",
    ".xlsx", ".xls", ".html", ".htm",
}

# Maximum concurrent pipeline threads
_active_pipelines = threading.Semaphore(3)


# ── Logging Setup ─────────────────────────────────────────────────────────────

def _setup_logging():
    """Configure structured logging with file rotation."""
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(exist_ok=True)

    formatter = logging.Formatter(
        '{"time":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s",'
        '"message":"%(message)s","module":"%(module)s","line":%(lineno)d}'
    )

    # File handler with rotation (10MB per file, keep 5 backups)
    file_handler = logging.handlers.RotatingFileHandler(
        str(log_dir / "medical_app.log"),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    # Error-only file for quick triage
    error_handler = logging.handlers.RotatingFileHandler(
        str(log_dir / "medical_app_errors.log"),
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    error_handler.setFormatter(formatter)
    error_handler.setLevel(logging.ERROR)

    # Console handler (human-readable)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    ))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(error_handler)
    root_logger.addHandler(console_handler)

    return logging.getLogger("medical_app")


logger = _setup_logging()


# ── Config ────────────────────────────────────────────────────────────────────

def load_config():
    config_path = BASE_DIR / "config.yaml"
    if not config_path.exists():
        # Try to copy from example
        example_path = BASE_DIR / "config.yaml.example"
        if example_path.exists():
            import shutil
            shutil.copy2(example_path, config_path)
            logger.info("Created config.yaml from config.yaml.example")
        else:
            logger.warning("config.yaml not found at %s — using defaults", config_path)
            return {}
    try:
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        logger.error("Failed to load config.yaml: %s", e)
        return {}


# ── Database (uses unified db module) ─────────────────────────────────────────

from db import get_db, init_db, transaction, log_access  # noqa: E402


def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


# ── Security Middleware ───────────────────────────────────────────────────────

from security import (  # noqa: E402
    init_security, require_auth, rate_limit,
    validate_contact_input, sanitize_string, get_csrf_token,
    validate_startup_config, sign_audit_entry,
)

init_security(app)

try:
    from stripe_webhook import stripe_bp  # noqa: E402
    app.register_blueprint(stripe_bp)
except Exception as e:
    logger.warning("Stripe webhook disabled: %s", e)

# Product guard: tier-based enforcement (demo/core/pro)
try:
    from product_guard import init_product_guard  # noqa: E402
    init_product_guard(app)
except Exception as e:
    logger.warning("Product guard init failed: %s", e)
    # Fallback: try legacy demo guard directly
    try:
        from demo_guard import init_demo_guard  # noqa: E402
        init_demo_guard(app)
    except Exception as e2:
        logger.warning("Demo guard init also failed: %s", e2)

# File integrity checker (verifies no code tampering since packaging)
try:
    from integrity import verify_integrity, start_background_checker, is_critically_tampered  # noqa: E402
    _tampered = verify_integrity()
    if _tampered:
        logger.warning("Integrity check: %d file(s) modified: %s", len(_tampered), ", ".join(_tampered))
    start_background_checker()
except Exception as e:
    logger.warning("Integrity checker disabled: %s", e)


# ── Stale Pipeline Cleanup ───────────────────────────────────────────────────

def _cleanup_stale_pipelines():
    """Mark any 'running' pipeline status files as 'failed' on startup.
    When the server restarts, background pipeline threads are killed,
    leaving status files stuck at 'running' forever."""
    if not PIPELINE_STATUS_DIR.exists():
        return
    cleaned = 0
    for f in PIPELINE_STATUS_DIR.glob("*.json"):
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
            if data.get("status") == "running":
                data["status"] = "failed"
                data["error"] = "Pipeline interrupted by server restart"
                data["completed_at"] = datetime.now(timezone.utc).isoformat()
                with open(f, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, indent=2)
                cleaned += 1
        except Exception:
            continue
    if cleaned:
        logger.info("Cleaned up %d stale pipeline status files on startup", cleaned)

    # Also sync document statuses: any doc marked 'processing' whose pipeline
    # is actually failed/completed should be updated
    try:
        from db import transaction as db_transaction
        now = datetime.now(timezone.utc).isoformat()
        with db_transaction() as conn:
            stuck = conn.execute(
                "SELECT id, run_id FROM documents WHERE status = 'processing'"
            ).fetchall()
            fixed = 0
            for row in stuck:
                run_id = row["run_id"] if isinstance(row, dict) else row[1]
                doc_id = row["id"] if isinstance(row, dict) else row[0]
                if not run_id:
                    continue
                sf = PIPELINE_STATUS_DIR / f"{run_id}.json"
                if sf.exists():
                    with open(sf, encoding="utf-8") as fh:
                        ps = json.load(fh)
                    pipeline_status = ps.get("status", "unknown")
                    if pipeline_status in ("failed", "completed"):
                        new_status = "failed" if pipeline_status == "failed" else "completed"
                        conn.execute(
                            "UPDATE documents SET status = ?, vault_zone = ?, updated_at = ? WHERE id = ?",
                            (new_status, new_status, now, doc_id),
                        )
                        fixed += 1
            if fixed:
                logger.info("Synced %d stuck document statuses with pipeline results", fixed)
    except Exception as e:
        logger.debug("Document status sync on startup skipped: %s", e)

_cleanup_stale_pipelines()


# ── JSON Error Handlers ──────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(e):
    return jsonify({"error": str(e.description) if hasattr(e, 'description') else "Bad request"}), 400

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(e):
    logger.error("Internal server error: %s", e, exc_info=True)
    return jsonify({"error": "Internal server error"}), 500


# ── Static UI & Auth Routes ──────────────────────────────────────────────────

@app.route("/")
@require_auth
def index():
    return send_from_directory(str(UI_DIR), "index.html")


@app.route("/landing")
def landing_page():
    return send_from_directory(str(UI_DIR), "landing.html")


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(str(UI_DIR), filename)


@app.route("/login", methods=["GET", "POST"])
@rate_limit(requests_per_minute=10, burst=5)
def login():
    if request.method == "GET":
        return send_from_directory(str(UI_DIR), "login.html")

    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    from security import _check_credentials
    if _check_credentials(username, password):
        session["authenticated"] = True
        session["username"] = username
        session.permanent = True
        log_access(username, "login", "session", ip_address=request.remote_addr)
        logger.info("User logged in: %s from %s", username, request.remote_addr)
        return jsonify({"success": True, "redirect": "/"})

    logger.warning("Failed login attempt: user=%s ip=%s", username, request.remote_addr)
    log_access(username or "unknown", "login_failed", "session",
               ip_address=request.remote_addr)
    return jsonify({"error": "Invalid credentials"}), 401


@app.route("/logout", methods=["POST"])
def logout():
    username = session.get("username", "unknown")
    session.clear()
    log_access(username, "logout", "session", ip_address=request.remote_addr)
    return jsonify({"success": True, "redirect": "/login"})


# ── Health Check (unauthenticated for load balancer probes) ──────────────────

@app.route("/health")
def health_check():
    """Health check endpoint for monitoring. Tests all critical dependencies."""
    checks = {}
    healthy = True

    # Database check
    try:
        conn = get_db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = f"error: {e}"
        healthy = False

    # Vault directories check
    for name, path in [
        ("vault_incoming", VAULT_INCOMING),
        ("vault_summaries", VAULT_SUMMARIES),
        ("vault_audit", VAULT_AUDIT),
    ]:
        if path.exists() and os.access(str(path), os.W_OK):
            checks[name] = "ok"
        else:
            checks[name] = "missing or not writable"
            healthy = False

    # Ollama check
    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/tags", method="GET")
        req.add_header("User-Agent", "MedRecords-HealthCheck")
        with urllib.request.urlopen(req, timeout=5) as resp:
            checks["ollama"] = "ok" if resp.status == 200 else f"status {resp.status}"
    except Exception:
        checks["ollama"] = "unreachable"
        # Ollama being down is degraded, not fully unhealthy
        # (system can still serve UI and manage contacts)

    status_code = 200 if healthy else 503
    return jsonify({
        "status": "healthy" if healthy else "unhealthy",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "allowed_extensions": sorted(ALLOWED_EXTENSIONS),
    }), status_code


# ── Contacts API ─────────────────────────────────────────────────────────────

@app.route("/api/contacts")
@require_auth
@rate_limit(requests_per_minute=60)
def list_contacts():
    """List contacts with pagination. Query params: page, per_page, status, q."""
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 100)
    status_filter = request.args.get("status", "")
    search_q = request.args.get("q", "").strip()

    offset = (page - 1) * per_page

    conn = get_db()
    try:
        query = """SELECT id, contact_name, contact_email, contact_type, organization,
                          patient_case_ref, record_type_needed, date_added, status,
                          last_contact_date, priority, follow_up_count, source
                   FROM contacts"""
        params = []
        conditions = []

        if status_filter:
            conditions.append("status = ?")
            params.append(status_filter)
        if search_q:
            conditions.append(
                "(contact_name LIKE ? OR contact_email LIKE ? OR organization LIKE ? OR patient_case_ref LIKE ?)"
            )
            like = f"%{search_q}%"
            params.extend([like, like, like, like])

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # Get total count
        count_query = query.replace(
            "SELECT id, contact_name, contact_email, contact_type, organization,"
            "\n                          patient_case_ref, record_type_needed, date_added, status,"
            "\n                          last_contact_date, priority, follow_up_count, source",
            "SELECT COUNT(*) as total"
        )
        total = conn.execute(count_query, params).fetchone()["total"]

        query += " ORDER BY date_added DESC LIMIT ? OFFSET ?"
        params.extend([per_page, offset])

        rows = conn.execute(query, params).fetchall()
    finally:
        conn.close()

    log_access(
        session.get("username", "api"), "list", "contacts",
        ip_address=request.remote_addr,
        details=f"page={page} per_page={per_page} total={total}",
    )

    return jsonify({
        "contacts": [dict(r) for r in rows],
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


@app.route("/api/contacts/<int:contact_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_contact(contact_id):
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
        if not row:
            abort(404)

        emails = conn.execute(
            "SELECT * FROM email_log WHERE contact_id = ? ORDER BY timestamp DESC",
            (contact_id,),
        ).fetchall()
    finally:
        conn.close()

    log_access(
        session.get("username", "api"), "view", "contact",
        resource_id=str(contact_id), ip_address=request.remote_addr,
    )

    result = dict(row)
    result["emails"] = [dict(e) for e in emails]
    return jsonify(result)


# ── Create Contact ───────────────────────────────────────────────────────────

@app.route("/api/contacts", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def create_contact():
    """Add a new contact from the UI and trigger retrieval automation."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # Input validation
    errors = validate_contact_input(data)
    if errors:
        return jsonify({"error": "Validation failed", "details": errors}), 400

    name = sanitize_string(data["contact_name"], 200)
    email = data["contact_email"].strip().lower()
    contact_type = data.get("contact_type", "custodian")
    organization = sanitize_string(data.get("organization", ""), 300)
    case_ref = sanitize_string(data.get("patient_case_ref", ""), 100)
    record_type = data.get("record_type_needed", "")
    priority = data.get("priority", "normal")
    notes = sanitize_string(data.get("notes", ""), 2000)

    upload_token = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    try:
        with transaction() as conn:
            cursor = conn.execute(
                """INSERT INTO contacts
                   (contact_name, contact_email, contact_type, organization,
                    patient_case_ref, record_type_needed, date_added, status,
                    priority, notes, upload_token, follow_up_count, source, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, 0, 'ui', ?, ?)""",
                (name, email, contact_type, organization, case_ref, record_type,
                 now, priority, notes, upload_token, now, now),
            )
            contact_id = cursor.lastrowid
    except sqlite3.IntegrityError as e:
        logger.warning("Duplicate contact: %s", e)
        return jsonify({"error": "A contact with this upload token already exists"}), 409

    _audit_log("contact_added_ui", contact_id, f"Contact added via UI: {name} ({email})")
    log_access(
        session.get("username", "api"), "create", "contact",
        resource_id=str(contact_id), ip_address=request.remote_addr,
    )
    logger.info("Contact created via UI: %s (%s) id=%d", name, email, contact_id)

    config = load_config()
    port = config.get("web_ui", {}).get("port", 8080)
    base_url = os.getenv("UPLOAD_BASE_URL", f"http://localhost:{port}")
    return jsonify({
        "id": contact_id,
        "contact_name": name,
        "contact_email": email,
        "status": "new",
        "upload_token": upload_token,
        "upload_link": f"{base_url}/api/secure-upload/{upload_token}",
        "message": "Contact created. The retrieval bot will send the initial request email on its next cycle.",
    }), 201


# ── Batch Contact Import (Excel) ────────────────────────────────────────────

@app.route("/api/contacts/batch", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def batch_import_contacts():
    """
    Import contacts from an uploaded Excel file.
    Expected columns: Contact Name | Email | Type | Organization | Case Ref | Record Type | Priority | Notes
    """
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    suffix = Path(file.filename).suffix.lower()
    if suffix not in (".xlsx", ".xls"):
        return jsonify({"error": "Only Excel files (.xlsx, .xls) are accepted"}), 400

    try:
        import openpyxl
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    try:
        wb = openpyxl.load_workbook(io.BytesIO(file.read()), read_only=True, data_only=True)
        ws = wb.active
        if ws is None:
            return jsonify({"error": "Excel file has no active worksheet"}), 400
    except Exception as e:
        return jsonify({"error": f"Cannot read Excel file: {e}"}), 400

    # Parse header row to find column mapping
    headers = []
    for cell in next(ws.iter_rows(min_row=1, max_row=1, values_only=False)):
        val = str(cell.value or "").strip().lower()
        headers.append(val)

    # Map columns by header name (flexible matching)
    col_map = {}
    header_aliases = {
        "contact_name": ["contact name", "name", "contact_name"],
        "contact_email": ["email", "contact email", "contact_email", "email address"],
        "contact_type": ["type", "contact type", "contact_type"],
        "organization": ["organization", "org", "company", "facility"],
        "patient_case_ref": ["case ref", "case reference", "patient_case_ref", "case #", "case"],
        "record_type_needed": ["record type", "record_type_needed", "records needed", "record type needed"],
        "priority": ["priority"],
        "notes": ["notes", "note", "comments"],
    }
    for field, aliases in header_aliases.items():
        for i, h in enumerate(headers):
            if h in aliases:
                col_map[field] = i
                break

    if "contact_name" not in col_map or "contact_email" not in col_map:
        return jsonify({
            "error": "Excel file must have 'Contact Name' and 'Email' columns",
            "found_headers": headers,
        }), 400

    # Process rows
    results = {"imported": 0, "skipped": 0, "errors": []}
    now = datetime.now(timezone.utc).isoformat()
    config = load_config()
    port = config.get("web_ui", {}).get("port", 8080)
    base_url = os.getenv("UPLOAD_BASE_URL", f"http://localhost:{port}")

    row_num = 1  # Start at 1 because row 0 is header
    try:
        with transaction() as conn:
            for row in ws.iter_rows(min_row=2, values_only=True):
                row_num += 1
                if not row or all(v is None for v in row):
                    continue

                # Extract fields
                def cell(field, default=""):
                    idx = col_map.get(field)
                    if idx is not None and idx < len(row) and row[idx] is not None:
                        return str(row[idx]).strip()
                    return default

                name = cell("contact_name")
                email = cell("contact_email")

                if not name or not email:
                    results["skipped"] += 1
                    continue

                # Validate email format
                if not re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", email):
                    results["errors"].append(f"Row {row_num}: Invalid email '{email}'")
                    results["skipped"] += 1
                    continue

                # Check for duplicate (same email + case ref)
                case_ref = cell("patient_case_ref")
                existing = conn.execute(
                    "SELECT id FROM contacts WHERE contact_email = ? AND patient_case_ref = ?",
                    (email.lower(), case_ref),
                ).fetchone()

                if existing:
                    results["skipped"] += 1
                    continue

                upload_token = str(uuid.uuid4())
                contact_type = cell("contact_type", "custodian").lower()
                if contact_type not in ("custodian", "counsel", "patient", "provider"):
                    contact_type = "custodian"

                priority = cell("priority", "normal").lower()
                if priority not in ("normal", "high", "urgent"):
                    priority = "normal"

                conn.execute(
                    """INSERT INTO contacts
                       (contact_name, contact_email, contact_type, organization,
                        patient_case_ref, record_type_needed, date_added, status,
                        priority, notes, upload_token, follow_up_count, source,
                        created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, 0, 'excel', ?, ?)""",
                    (sanitize_string(name, 200), email.lower(), contact_type,
                     sanitize_string(cell("organization"), 300), sanitize_string(case_ref, 100),
                     cell("record_type_needed"), now, priority,
                     sanitize_string(cell("notes"), 2000), upload_token, now, now),
                )
                results["imported"] += 1

    except Exception as e:
        logger.error("Batch import error at row %d: %s", row_num, e)
        return jsonify({
            "error": f"Import failed at row {row_num}: {e}",
            "partial_results": results,
        }), 500
    finally:
        wb.close()

    _audit_log(
        "contacts_batch_import", None,
        f"Batch import: {results['imported']} imported, {results['skipped']} skipped, "
        f"{len(results['errors'])} errors",
    )
    log_access(
        session.get("username", "api"), "batch_import", "contacts",
        ip_address=request.remote_addr,
        details=f"imported={results['imported']} skipped={results['skipped']}",
    )
    logger.info("Batch import: %d imported, %d skipped", results["imported"], results["skipped"])

    return jsonify({
        "message": f"Successfully imported {results['imported']} contacts.",
        "results": results,
    })


# ── Contact Import Template Download ────────────────────────────────────────

@app.route("/api/contacts/template")
@require_auth
def download_contact_template():
    """Generate and serve an Excel template for batch contact import."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        return jsonify({"error": "openpyxl not installed"}), 500

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Contacts Import"

    # Column definitions
    columns = [
        ("Contact Name", 25, "Dr. John Smith"),
        ("Email", 30, "records@hospital.com"),
        ("Type", 18, "medical_provider"),
        ("Organization", 25, "Memorial Hospital"),
        ("Case Ref", 20, "CASE-2024-001"),
        ("Record Type", 22, "medical_records"),
        ("Priority", 12, "high"),
        ("Notes", 35, "Request all records from 2024"),
    ]

    # Header styling
    header_fill = PatternFill(start_color="4F46E5", end_color="4F46E5", fill_type="solid")
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    # Write headers
    for col_idx, (name, width, _) in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width

    # Example row
    example_font = Font(name="Calibri", color="999999", italic=True, size=10)
    for col_idx, (_, _, example) in enumerate(columns, 1):
        cell = ws.cell(row=2, column=col_idx, value=example)
        cell.font = example_font
        cell.border = thin_border

    # Instructions sheet
    instructions = wb.create_sheet("Instructions")
    instructions.column_dimensions["A"].width = 20
    instructions.column_dimensions["B"].width = 60
    instructions_data = [
        ("Column", "Description"),
        ("Contact Name", "Required. Full name of the contact person or department."),
        ("Email", "Required. Email address for correspondence."),
        ("Type", "Contact type: medical_provider, legal, insurance, hospital, pharmacy, imaging_center, employer, client, other"),
        ("Organization", "Optional. Name of the organization or facility."),
        ("Case Ref", "Optional. Patient case reference number (e.g., CASE-2024-001)."),
        ("Record Type", "Optional. Type of records needed: medical_records, billing_records, imaging, lab_results, pharmacy_records, employment_records, insurance_records, other"),
        ("Priority", "Optional. Priority level: low, normal, high, urgent (default: normal)."),
        ("Notes", "Optional. Any special instructions or notes."),
    ]
    for row_idx, (col_a, col_b) in enumerate(instructions_data, 1):
        cell_a = instructions.cell(row=row_idx, column=1, value=col_a)
        cell_b = instructions.cell(row=row_idx, column=2, value=col_b)
        if row_idx == 1:
            cell_a.font = Font(bold=True)
            cell_b.font = Font(bold=True)

    # Serve file
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="contacts_import_template.xlsx",
    )


# ── Manual Upload ────────────────────────────────────────────────────────────

@app.route("/api/upload", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=20, burst=10)
def manual_upload():
    """Upload a medical document from the UI for manual summarization."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": f"File type not allowed. Supported: {', '.join(sorted(ALLOWED_EXTENSIONS))}"}), 400

    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({"error": "Invalid filename"}), 400

    # Optional case reference for grouping multi-file uploads
    case_ref = request.form.get("case_ref", "").strip() or None

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    upload_dir = VAULT_INCOMING / f"manual_{timestamp}"
    upload_dir.mkdir(parents=True, exist_ok=True)

    save_path = upload_dir / filename
    file.save(str(save_path))

    file_hash = hashlib.sha256(save_path.read_bytes()).hexdigest()

    # Register in documents table
    doc_id = None
    try:
        with transaction() as conn:
            cur = conn.execute(
                """INSERT INTO documents
                   (filename, original_path, current_path, file_hash, file_size,
                    extension, vault_zone, status, uploaded_by, upload_source, case_ref)
                   VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', ?, 'manual', ?)""",
                (filename, str(save_path), str(save_path), file_hash,
                 save_path.stat().st_size, save_path.suffix.lower(),
                 session.get("username", "api"), case_ref),
            )
            doc_id = cur.lastrowid
    except Exception as e:
        logger.error("Failed to register document: %s", e)

    # Auto-detect case_ref if none provided
    suggestion = None
    if not case_ref and doc_id:
        try:
            from case_detector import suggest_case_ref as _suggest
            conn2 = get_db()
            try:
                rows = conn2.execute(
                    "SELECT DISTINCT case_ref FROM documents WHERE case_ref IS NOT NULL AND case_ref != ''"
                ).fetchall()
            finally:
                conn2.close()
            existing = [r["case_ref"] for r in rows]
            result = _suggest(filename, existing)
            if result and result["confidence"] in ("high", "medium"):
                case_ref = result["suggestion"]
                suggestion = result
                try:
                    with transaction() as conn3:
                        conn3.execute(
                            "UPDATE documents SET case_ref = ? WHERE id = ?",
                            (case_ref, doc_id),
                        )
                except Exception as e:
                    logger.error("Auto-assign case_ref error: %s", e)
        except Exception as e:
            logger.debug("Case detection skipped: %s", e)

    _audit_log("file_uploaded_manual", None, f"Manual upload: {filename} ({file_hash[:12]}){' case=' + case_ref if case_ref else ''}")
    log_access(
        session.get("username", "api"), "upload", "document",
        resource_id=file_hash[:12], ip_address=request.remote_addr,
        details=f"file={filename}" + (f", case_ref={case_ref}" if case_ref else ""),
    )
    logger.info("Manual upload: %s -> %s (doc_id=%s, case_ref=%s)", filename, save_path, doc_id, case_ref)

    resp = {
        "file_id": f"manual_{timestamp}_{filename}",
        "doc_id": doc_id,
        "file_path": str(save_path),
        "file_hash": file_hash,
        "case_ref": case_ref,
        "message": "File uploaded. Use /api/summarize to trigger processing.",
    }
    if suggestion:
        resp["case_suggestion"] = suggestion
    return jsonify(resp)


# ── Demo Case Loader ──────────────────────────────────────────────────────────

@app.route("/api/demo-case/load", methods=["POST"])
@require_auth
def load_demo_case():
    """Load the included demo case files for first-time demonstration."""
    demo_dir = BASE_DIR / "demo_case"
    if not demo_dir.exists():
        return jsonify({"error": "Demo case not found"}), 404

    demo_files = sorted(
        f for f in demo_dir.iterdir()
        if f.is_file() and f.name != "README.txt" and f.suffix.lower() in ALLOWED_EXTENSIONS
    )
    if not demo_files:
        return jsonify({"error": "No demo files found"}), 404

    case_ref = "DEMO-Martinez-MVA-2024"
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    uploaded = []

    import shutil
    upload_dir = VAULT_INCOMING / f"demo_{timestamp}"
    upload_dir.mkdir(parents=True, exist_ok=True)
    file_paths = []

    for df in demo_files:
        dest = upload_dir / df.name
        shutil.copy2(str(df), str(dest))
        file_hash = hashlib.sha256(dest.read_bytes()).hexdigest()
        file_paths.append(str(dest))

        try:
            with transaction() as conn:
                cur = conn.execute(
                    """INSERT INTO documents
                       (filename, original_path, current_path, file_hash, file_size,
                        extension, vault_zone, status, uploaded_by, upload_source, case_ref)
                       VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', ?, 'manual', ?)""",
                    (df.name, str(dest), str(dest), file_hash,
                     dest.stat().st_size, dest.suffix.lower(),
                     session.get("username", "api"), case_ref),
                )
                uploaded.append({"filename": df.name, "doc_id": cur.lastrowid})
        except Exception as e:
            logger.error("Failed to register demo file %s: %s", df.name, e)

    _audit_log("demo_case_loaded", None, f"Demo case loaded: {len(uploaded)} files")
    return jsonify({
        "message": f"Demo case loaded: {len(uploaded)} files",
        "case_ref": case_ref,
        "files": uploaded,
        "file_paths": file_paths,
    })


# ── Secure Upload (Token-Based, no auth required) ───────────────────────────

@app.route("/api/secure-upload/<token>", methods=["GET", "POST"])
@rate_limit(requests_per_minute=10, burst=5)
def secure_upload(token):
    """Token-authenticated upload endpoint for external contacts."""
    # Validate token format (UUID)
    try:
        uuid.UUID(token)
    except ValueError:
        abort(404)

    conn = get_db()
    try:
        contact = conn.execute(
            "SELECT id, contact_name, patient_case_ref FROM contacts WHERE upload_token = ?",
            (token,),
        ).fetchone()
    finally:
        conn.close()

    if not contact:
        _audit_log("upload_token_invalid", None, f"Invalid token attempt: {token[:8]}...")
        logger.warning("Invalid upload token from %s: %s...", request.remote_addr, token[:8])
        abort(403)

    if request.method == "GET":
        import html as html_mod
        case_ref = html_mod.escape(contact["patient_case_ref"] or "N/A")
        return f"""<!DOCTYPE html>
<html><head><title>Secure Document Upload</title>
<style>body{{font-family:Inter,sans-serif;max-width:600px;margin:40px auto;padding:20px}}
h1{{color:#1f2937}}form{{border:2px dashed #d1d5db;padding:40px;text-align:center;border-radius:8px}}
input[type=file]{{margin:20px 0}}button{{background:#4f46e5;color:#fff;padding:12px 24px;border:none;border-radius:6px;cursor:pointer;font-size:16px}}
button:hover{{background:#4338ca}}</style></head>
<body><h1>Secure Document Upload</h1>
<p>Case: {case_ref}</p>
<form method="POST" enctype="multipart/form-data">
<p>Select your medical records to upload:</p>
<input type="file" name="file" accept=".pdf,.png,.jpg,.jpeg,.tiff,.tif,.dcm,.dicom,.doc,.docx,.txt,.csv,.json,.xml,.log,.xlsx,.xls,.html,.htm" required>
<br><button type="submit">Upload Securely</button>
</form></body></html>"""

    # POST: handle upload
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename or not allowed_file(file.filename):
        return jsonify({"error": "Invalid file type"}), 400

    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({"error": "Invalid filename"}), 400

    contact_dir = VAULT_INCOMING / str(contact["id"])
    contact_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    save_path = contact_dir / f"{timestamp}_{filename}"
    file.save(str(save_path))

    # Update contact status and register document transactionally
    try:
        file_hash = hashlib.sha256(save_path.read_bytes()).hexdigest()
        with transaction() as conn:
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "UPDATE contacts SET status = 'received', last_contact_date = ?, updated_at = ? WHERE id = ?",
                (now, now, contact["id"]),
            )
            conn.execute(
                """INSERT INTO documents
                   (filename, original_path, current_path, file_hash, file_size,
                    extension, vault_zone, status, uploaded_by, upload_source,
                    contact_id, case_ref)
                   VALUES (?, ?, ?, ?, ?, ?, 'incoming', 'pending', 'external', 'secure_upload', ?, ?)""",
                (filename, str(save_path), str(save_path), file_hash,
                 save_path.stat().st_size, save_path.suffix.lower(),
                 contact["id"], contact["patient_case_ref"]),
            )
    except Exception as e:
        logger.error("Failed to update contact/document after upload: %s", e)

    _audit_log("file_uploaded_secure", contact["id"], f"Secure upload: {filename}")
    log_access(
        "external", "secure_upload", "document",
        resource_id=str(contact["id"]), ip_address=request.remote_addr,
        details=f"file={filename}",
    )

    return """<!DOCTYPE html>
<html><head><title>Upload Successful</title>
<style>body{font-family:Inter,sans-serif;max-width:600px;margin:40px auto;padding:20px;text-align:center}
.success{color:#059669;font-size:24px}</style></head>
<body><p class="success">File uploaded successfully!</p>
<p>Your records have been securely received. You may close this window.</p></body></html>"""


# ── On-Demand Summarization ──────────────────────────────────────────────────

@app.route("/api/summarize", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def trigger_summarize():
    """Trigger on-demand summarization for uploaded file(s).

    Accepts either:
      - {"file_path": "..."} — single file
      - {"file_paths": [...], "case_ref": "..."} — combined multi-file case
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # ── Demo case limit enforcement ──────────────────────────────────
    from licensing import is_demo_build, get_trial_remaining
    if is_demo_build() and get_trial_remaining() <= 0:
        return jsonify({
            "error": "Demo case limit reached (3 cases). Purchase a license to process unlimited cases.",
            "upgrade_url": "https://aiproductivity.dev/pricing",
        }), 403

    case_ref = data.get("case_ref", "").strip() or None
    mode = data.get("mode", "auto").strip().lower()
    if mode not in ("auto", "fast", "thorough"):
        mode = "auto"

    # Collect file paths: support both single and multi-file
    raw_paths = data.get("file_paths") or []
    if not raw_paths and "file_path" in data:
        raw_paths = [data["file_path"]]

    if not raw_paths:
        return jsonify({"error": "file_path or file_paths required"}), 400

    # Validate all paths
    resolved_paths = []
    for raw in raw_paths:
        fp = Path(raw)
        try:
            resolved = fp.resolve(strict=False)
            resolved.relative_to(VAULT_INCOMING.resolve())
        except (ValueError, OSError):
            logger.warning("Path traversal attempt: %s from %s", raw, request.remote_addr)
            return jsonify({"error": f"Invalid file path: {Path(raw).name}"}), 400
        if not resolved.exists():
            return jsonify({"error": f"File not found: {Path(raw).name}"}), 404
        if resolved.is_symlink():
            return jsonify({"error": "Symbolic links are not allowed"}), 400
        resolved_paths.append(resolved)

    run_id = f"manual_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"

    # Run pipeline in background thread with concurrency limit
    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Too many pipelines running. Please try again later."}), 429

    if mode == "thorough":
        # Force thorough mode
        t = threading.Thread(
            target=_run_thorough_pipeline_background,
            args=([str(p) for p in resolved_paths], run_id, case_ref, "thorough"),
            daemon=False,
        )
    elif mode == "auto":
        # Auto-detect: preprocess first, then decide
        t = threading.Thread(
            target=_run_auto_pipeline_background,
            args=([str(p) for p in resolved_paths], run_id, case_ref),
            daemon=False,
        )
    elif len(resolved_paths) > 1:
        # Fast mode, multi-file: combined pipeline
        t = threading.Thread(
            target=_run_combined_pipeline_background,
            args=([str(p) for p in resolved_paths], run_id, case_ref),
            daemon=False,
        )
    else:
        # Fast mode, single file
        t = threading.Thread(
            target=_run_pipeline_background,
            args=(str(resolved_paths[0]), run_id),
            daemon=False,
        )
    t.start()

    log_access(
        session.get("username", "api"), "trigger_summarize", "pipeline",
        resource_id=run_id, ip_address=request.remote_addr,
        details=f"files={len(resolved_paths)}, mode={mode}" + (f", case_ref={case_ref}" if case_ref else ""),
    )

    return jsonify({
        "run_id": run_id,
        "status": "started",
        "mode": mode,
        "file_count": len(resolved_paths),
        "case_ref": case_ref,
        "message": "Pipeline started. Poll /api/pipeline/<run_id> for status.",
    })


def _classify_pipeline_error(error_str):
    """Classify a pipeline error for user-friendly reporting."""
    e = error_str.lower()
    if "__error__:" in e:
        parts = error_str.split(":", 2)
        error_type = parts[1] if len(parts) > 1 else "unknown"
        return error_type, parts[2] if len(parts) > 2 else error_str
    if any(kw in e for kw in ("credit balance", "insufficient", "billing", "overloaded",
                                "credit limit", "exceeded your", "funds", "payment required")):
        return "api_credits_exhausted", "Your Anthropic API credit balance is too low. Add credits at console.anthropic.com."
    if "invalid" in e and ("api key" in e or "x-api-key" in e or "authentication" in e):
        return "api_key_invalid", "Your Anthropic API key is invalid."
    if "timeout" in e or "timed out" in e:
        return "api_timeout", "The AI request timed out."
    if "rate limit" in e or "429" in e:
        return "api_rate_limited", "Too many API requests. Wait a minute."
    return "unknown", error_str


def _write_pipeline_failure(run_id, error, mode=None):
    """Write a structured failure status for a pipeline run."""
    error_type, error_msg = _classify_pipeline_error(str(error))
    from summarization_watcher import _get_user_action
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f"{run_id}.json"
    data = {}
    if status_file.exists():
        try:
            data = json.loads(status_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    data.update({
        "run_id": run_id,
        "status": "failed",
        "error": str(error),
        "error_type": error_type,
        "error_message": error_msg,
        "user_action": _get_user_action(error_type),
        "retryable": error_type not in ("api_key_invalid", "api_credits_exhausted"),
        "failed_at": datetime.now(timezone.utc).isoformat(),
    })
    if mode:
        data["mode"] = mode
    try:
        tmp = status_file.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        tmp.replace(status_file)
    except Exception as write_err:
        logger.error("Failed to write pipeline status file: %s", write_err)


def _run_pipeline_background(file_path, run_id):
    """Run the summarization pipeline in a background thread with error handling."""
    try:
        from summarization_watcher import run_pipeline, load_config as load_watcher_config
        config = load_watcher_config()
        run_pipeline(Path(file_path), config, run_id=run_id)
    except Exception as e:
        logger.error("Background pipeline error for %s: %s", run_id, e, exc_info=True)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


def _run_combined_pipeline_background(file_paths, run_id, case_ref):
    """Run the summarization pipeline on multiple files combined into one case."""
    try:
        from summarization_watcher import run_pipeline_combined, load_config as load_watcher_config
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]
        run_pipeline_combined(paths, config, run_id=run_id, case_ref=case_ref)
        # Increment demo trial counter on success
        from licensing import is_demo_build, increment_trial_usage
        if is_demo_build():
            increment_trial_usage()
    except Exception as e:
        logger.error("Combined pipeline error for %s: %s", run_id, e, exc_info=True)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


def _run_thorough_pipeline_background(file_paths, run_id, case_ref, mode="thorough"):
    """Run the thorough pipeline for large/complex cases."""
    try:
        from summarization_watcher import run_pipeline_thorough, load_config as load_watcher_config
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]
        run_pipeline_thorough(paths, config, run_id=run_id, case_ref=case_ref, mode=mode)
        from licensing import is_demo_build, increment_trial_usage
        if is_demo_build():
            increment_trial_usage()
    except Exception as e:
        logger.error("Thorough pipeline error for %s: %s", run_id, e, exc_info=True)
        _write_pipeline_failure(run_id, e, mode="thorough")
    finally:
        _active_pipelines.release()


def _run_auto_pipeline_background(file_paths, run_id, case_ref):
    """Auto-detect mode: run preprocessing, decide fast vs thorough, then execute."""
    try:
        from summarization_watcher import (
            run_pipeline, run_pipeline_combined, run_pipeline_thorough,
            load_config as load_watcher_config,
        )
        from document_preprocessor import preprocess_case, determine_processing_mode
        config = load_watcher_config()
        paths = [Path(p) for p in file_paths]

        # Quick preprocessing to determine mode (no transcription yet)
        preprocess_result = preprocess_case(paths, config, mode="auto", transcribe=False)
        recommended = determine_processing_mode(preprocess_result, "auto")

        logger.info("Auto-detect for %s: %d pages, %d clinical, %d handwritten -> %s",
                     run_id, preprocess_result.total_pages, preprocess_result.clinical_pages,
                     preprocess_result.handwritten_pages, recommended)

        if recommended == "thorough":
            run_pipeline_thorough(paths, config, run_id=run_id, case_ref=case_ref, mode="thorough")
        elif len(paths) > 1:
            run_pipeline_combined(paths, config, run_id=run_id, case_ref=case_ref)
        else:
            run_pipeline(paths[0], config, run_id=run_id)
        # Increment demo trial counter on success
        from licensing import is_demo_build, increment_trial_usage
        if is_demo_build():
            increment_trial_usage()
    except Exception as e:
        logger.error("Auto pipeline error for %s: %s", run_id, e, exc_info=True)
        _write_pipeline_failure(run_id, e)
    finally:
        _active_pipelines.release()


# ── Preprocessing API ────────────────────────────────────────────────────────

@app.route("/api/preprocess", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def preprocess_files():
    """Run preprocessing only — returns dedup stats and recommended mode.

    Useful for UI preview before committing to full pipeline.
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    raw_paths = data.get("file_paths") or []
    if not raw_paths and "file_path" in data:
        raw_paths = [data["file_path"]]

    if not raw_paths:
        return jsonify({"error": "file_path or file_paths required"}), 400

    resolved_paths = []
    for raw in raw_paths:
        fp = Path(raw)
        try:
            resolved = fp.resolve(strict=False)
            resolved.relative_to(VAULT_INCOMING.resolve())
        except (ValueError, OSError):
            return jsonify({"error": f"Invalid file path: {Path(raw).name}"}), 400
        if not resolved.exists():
            return jsonify({"error": f"File not found: {Path(raw).name}"}), 404
        resolved_paths.append(resolved)

    try:
        from document_preprocessor import preprocess_case
        config = load_config()
        result = preprocess_case(resolved_paths, config, mode="auto", transcribe=False)

        return jsonify({
            "total_pages": result.total_pages,
            "unique_pages": result.unique_pages,
            "duplicate_pages": result.duplicate_pages,
            "blank_pages": result.blank_pages,
            "noise_pages": result.noise_pages,
            "handwritten_pages": result.handwritten_pages,
            "clinical_pages": result.clinical_pages,
            "chunks": len(result.chunks),
            "recommended_mode": result.recommended_mode,
            "dedup_stats": result.dedup_stats,
        })
    except Exception as e:
        logger.error("Preprocessing error: %s", e, exc_info=True)
        return jsonify({"error": f"Preprocessing failed: {e}"}), 500


# ── Summaries API ────────────────────────────────────────────────────────────

@app.route("/api/summaries")
@require_auth
@rate_limit(requests_per_minute=60)
def list_summaries():
    """List completed summaries with pagination."""
    if not VAULT_SUMMARIES.exists():
        return jsonify({"summaries": [], "pagination": {"page": 1, "total": 0}})

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 25, type=int), 50)

    all_files = sorted(VAULT_SUMMARIES.glob("*_summary.json"), reverse=True)
    total = len(all_files)
    offset = (page - 1) * per_page
    page_files = all_files[offset:offset + per_page]

    summaries = []
    for f in page_files:
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
            summaries.append({
                "run_id": data.get("run_id", f.stem),
                "source_file": data.get("source_file", ""),
                "processed_at": data.get("processed_at", ""),
                "has_summary": "summary" in data and data["summary"] is not None,
                "compliance_status": (data.get("audit", {}) or {}).get("compliance_status", "unknown"),
            })
        except (json.JSONDecodeError, KeyError):
            continue

    log_access(
        session.get("username", "api"), "list", "summaries",
        ip_address=request.remote_addr,
    )

    return jsonify({
        "summaries": summaries,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


@app.route("/api/summaries/<run_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_summary(run_id):
    """Get a specific summary with full details."""
    # Sanitize run_id to prevent path traversal
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        abort(404)

    with open(summary_file, encoding="utf-8") as f:
        data = json.load(f)

    # ── Demo watermark injection ─────────────────────────────────────
    from licensing import is_demo_build, get_watermark_text
    if is_demo_build():
        watermark = get_watermark_text()
        if watermark:
            data["_trial_watermark"] = watermark

    _audit_log("summary_viewed", None, f"Summary viewed: {safe_id}")
    log_access(
        session.get("username", "api"), "view", "summary",
        resource_id=safe_id, ip_address=request.remote_addr,
    )
    return jsonify(data)


@app.route("/api/summaries/<run_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10)
def delete_summary(run_id):
    """Delete a specific summary and its associated pipeline status."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        abort(404)

    # Delete summary file
    summary_file.unlink()

    # Also delete pipeline status if it exists
    pipeline_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if pipeline_file.exists():
        pipeline_file.unlink()

    # Clear run_id from documents table
    try:
        with transaction() as db:
            db.execute("UPDATE documents SET run_id = NULL, summary_file = NULL WHERE run_id = ?", (safe_id,))
    except Exception:
        pass

    _audit_log("summary_deleted", None, f"Summary deleted: {safe_id}")
    log_access(
        session.get("username", "api"), "delete", "summary",
        resource_id=safe_id, ip_address=request.remote_addr,
    )
    return jsonify({"ok": True, "deleted": safe_id})


# ── Demand Package API ───────────────────────────────────────────────────────

@app.route("/api/demand/generate", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def generate_demand():
    """Generate a demand package from a completed summary."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("demand_package"):
        return jsonify({"error": "Demand Package requires a Pro license. Upgrade at https://aiproductivity.dev/pricing"}), 403

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    run_id = data.get("run_id", "").strip()
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    # Load the summary
    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_file.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    with open(summary_file, encoding="utf-8") as f:
        summary_data = json.load(f)

    # Build options — frontend sends {run_id, options: {...}}
    opts = data.get("options", data)
    options = {
        "case_type": opts.get("case_type", "mva"),
        "state": opts.get("state", "default"),
        "plaintiff_name": opts.get("plaintiff_name", "[PLAINTIFF]"),
        "incident_date": opts.get("incident_date", "[DATE OF INCIDENT]"),
        "multiplier": float(opts.get("multiplier", 3.0)),
        "response_deadline_days": int(opts.get("response_deadline_days", opts.get("response_days", 30))),
    }

    demand_amount = opts.get("demand_amount")
    if demand_amount:
        try:
            options["demand_amount"] = float(demand_amount)
        except (ValueError, TypeError):
            pass

    # Generate
    try:
        with open(BASE_DIR / "config.yaml") as cf:
            config = yaml.safe_load(cf)

        from demand_generator import generate_demand_package
        result = generate_demand_package(summary_data, config, options)

        # Save demand files to vault
        demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
        demand_dir.mkdir(parents=True, exist_ok=True)

        (demand_dir / "demand_package.docx").write_bytes(result["demand_docx"])
        (demand_dir / "billing_summary.xlsx").write_bytes(result["billing_xlsx"])
        (demand_dir / "exhibit_list.docx").write_bytes(result["exhibit_docx"])

        # Save narrative JSON for reference
        with open(demand_dir / "narrative.json", "w", encoding="utf-8") as nf:
            json.dump(result["narrative"], nf, indent=2)

        log_access(
            session.get("username", "api"), "generate_demand", "demand_package",
            resource_id=safe_id, ip_address=request.remote_addr,
            details=f"case_type={options['case_type']}, demand=${result['demand_amount']:,.2f}" if result.get("demand_amount") else "",
        )

        return jsonify({
            "ok": True,
            "run_id": safe_id,
            "demand_amount": result.get("demand_amount"),
            "billing_total": result.get("billing_total"),
            "files": [
                {"filename": "demand_package.docx", "label": "Demand Letter (DOCX)"},
                {"filename": "billing_summary.xlsx", "label": "Billing Summary (XLSX)"},
                {"filename": "exhibit_list.docx", "label": "Exhibit List (DOCX)"},
            ],
            "narrative": result.get("narrative"),
        })

    except Exception as e:
        logger.error("Demand generation failed for %s: %s", safe_id, e, exc_info=True)
        return jsonify({"error": f"Demand generation failed: {str(e)}"}), 500


@app.route("/api/demand/<run_id>/download/<filename>")
@require_auth
def download_demand_file(run_id, filename):
    """Download a demand package file."""
    safe_id = secure_filename(run_id)
    safe_filename = secure_filename(filename)
    if not safe_id or not safe_filename:
        abort(400)

    demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
    file_path = demand_dir / safe_filename
    if not file_path.exists():
        abort(404)

    # Determine MIME type
    mime_types = {
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pdf": "application/pdf",
    }
    ext = Path(safe_filename).suffix.lower()
    mime = mime_types.get(ext, "application/octet-stream")

    return send_file(
        str(file_path),
        mimetype=mime,
        as_attachment=True,
        download_name=safe_filename,
    )


@app.route("/api/demand/case-types")
@require_auth
def get_case_types():
    """Return available case types for demand package generation."""
    from demand_generator import get_case_types as _get_types, get_states as _get_states
    return jsonify({
        "case_types": _get_types(),
        "states": _get_states(),
    })


# ── Case Valuation API ───────────────────────────────────────────────────────

@app.route("/api/valuation/estimate", methods=["POST"])
@require_auth
def estimate_valuation():
    """Estimate settlement value range for a processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("case_valuation"):
        return jsonify({"error": "Case Valuation requires a Pro license. Upgrade at https://aiproductivity.dev/pricing"}), 403

    from case_valuation import estimate_case_value

    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load the summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    try:
        with open(summary_path, encoding="utf-8") as f:
            summary_data = json.load(f)
    except Exception as e:
        return jsonify({"error": f"Failed to load summary: {e}"}), 500

    options = data.get("options", {})
    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = estimate_case_value(summary_data, config, options)
        return jsonify(result)
    except Exception as e:
        logger.exception("Valuation estimation failed")
        return jsonify({"error": str(e)}), 500


# ── Licensing API ─────────────────────────────────────────────────────────────

@app.route("/api/license/status")
@require_auth
def license_status():
    """Return current license state."""
    from licensing import get_license_state, get_trial_remaining, validate_license_key
    state = get_license_state()
    state["trial_remaining"] = get_trial_remaining()
    # Add 'valid' field for API consumers
    if state.get("license_key"):
        validation = validate_license_key(state["license_key"])
        state["valid"] = validation.get("valid", False)
    else:
        state["valid"] = state.get("tier") == "trial"
    # Add build info and demo expiration if applicable
    try:
        from product_guard import get_build_type, get_build_info
        bt = get_build_type()
        if bt != "dev":
            state["build_type"] = bt
            bi = get_build_info()
            if bi:
                state["product_version"] = bi.get("version")
        if bt == "demo":
            from licensing import check_demo_expiration
            demo_status = check_demo_expiration()
            state["is_demo"] = True
            state["demo_days_remaining"] = demo_status["days_remaining"]
            state["demo_expired"] = demo_status["expired"]
    except ImportError:
        # Legacy fallback
        try:
            from demo_guard import is_demo
            if is_demo():
                from licensing import check_demo_expiration
                demo_status = check_demo_expiration()
                state["is_demo"] = True
                state["demo_days_remaining"] = demo_status["days_remaining"]
                state["demo_expired"] = demo_status["expired"]
        except ImportError:
            pass
    return jsonify(state)

@app.route("/api/license/activate", methods=["POST"])
def activate_license_route():
    """Activate a license key. No auth required — users need this to unlock the app."""
    from licensing import activate_license as _activate
    key = request.json.get("key", "").strip()
    result = _activate(key)
    if result.get("valid"):
        return jsonify({"success": True, "tier": result["tier"]})
    return jsonify({"success": False, "error": "Invalid license key"}), 400


# ── Negligence Detection API ─────────────────────────────────────────────────

@app.route("/api/negligence/analyze", methods=["POST"])
@require_auth
def analyze_negligence():
    """Analyze a processed case for standard-of-care deviations."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("negligence_detection"):
        return jsonify({"error": "Negligence Detection requires a Pro license. Upgrade at https://aiproductivity.dev/pricing"}), 403
    from negligence_detector import detect_negligence

    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    try:
        with open(summary_path, encoding="utf-8") as f:
            summary_data = json.load(f)
    except Exception as e:
        return jsonify({"error": f"Failed to load summary: {e}"}), 500

    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = detect_negligence(summary_data, config)
        return jsonify(result)
    except Exception as e:
        logger.exception("Negligence analysis failed")
        return jsonify({"error": str(e)}), 500


# ── Auto-Task Generation API ─────────────────────────────────────────────────

@app.route("/api/tasks/generate", methods=["POST"])
@require_auth
def generate_case_tasks():
    """Generate actionable task list from processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("task_generation"):
        return jsonify({"error": "Auto-Task Generation requires a Pro license. Upgrade at https://aiproductivity.dev/pricing"}), 403
    from task_generator import generate_tasks

    data = request.json or {}
    run_id = data.get("run_id")
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load summary — try both naming conventions
    summary_path = VAULT_SUMMARIES / f"{safe_id}_summary.json"
    if not summary_path.exists():
        summary_path = VAULT_SUMMARIES / f"{safe_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found. Process the case first."}), 404

    try:
        with open(summary_path, encoding="utf-8") as f:
            summary_data = json.load(f)
    except Exception as e:
        return jsonify({"error": f"Failed to load summary: {e}"}), 500

    config_path = BASE_DIR / "config.yaml"
    config = {}
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    try:
        result = generate_tasks(summary_data, config)
        return jsonify(result)
    except Exception as e:
        logger.exception("Task generation failed")
        return jsonify({"error": str(e)}), 500


# ── Injury Visualization API ─────────────────────────────────────────────────

@app.route("/api/injury-diagram/<run_id>")
@require_auth
def get_injury_diagram(run_id):
    """Generate injury body diagram SVG for a processed case."""
    from licensing import is_feature_allowed
    if not is_feature_allowed("injury_visualization"):
        return jsonify({"error": "Injury Visualization requires a Pro license. Upgrade at https://aiproductivity.dev/pricing"}), 403
    from injury_visualizer import generate_injury_svg

    run_id = secure_filename(run_id)
    if not run_id:
        return jsonify({"error": "Invalid run_id"}), 400

    summary_path = VAULT_SUMMARIES / f"{run_id}_summary.json"
    if not summary_path.exists():
        # Fallback: try without _summary suffix
        summary_path = VAULT_SUMMARIES / f"{run_id}.json"
    if not summary_path.exists():
        return jsonify({"error": "Summary not found"}), 404

    try:
        with open(summary_path, encoding="utf-8") as f:
            summary_data = json.load(f)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    result = generate_injury_svg(summary_data)

    # Save SVG to summaries folder alongside the summary JSON
    if result.get("svg"):
        svg_path = VAULT_SUMMARIES / f"{run_id}_injury_diagram.svg"
        try:
            svg_path.write_text(result["svg"], encoding="utf-8")
            result["saved_path"] = str(svg_path)
        except Exception as e:
            logger.warning("Failed to save injury SVG: %s", e)

    if request.args.get("format") == "svg":
        return result["svg"], 200, {"Content-Type": "image/svg+xml"}

    return jsonify(result)


# ── Pipeline Status API ──────────────────────────────────────────────────────

@app.route("/api/pipeline")
@require_auth
@rate_limit(requests_per_minute=30)
def list_pipelines():
    """List all pipeline runs with status, most recent first."""
    if not PIPELINE_STATUS_DIR.exists():
        return jsonify({"runs": []})

    runs = []
    for f in sorted(PIPELINE_STATUS_DIR.glob("*.json"), reverse=True):
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)

                # Auto-fail stale "running" pipelines (no update in 30 min)
                if data.get("status") == "running" and data.get("started_at"):
                    try:
                        started = datetime.fromisoformat(data["started_at"])
                        # Find most recent stage timestamp
                        latest_ts = started
                        for sv in data.get("stages", {}).values():
                            if isinstance(sv, dict) and sv.get("timestamp"):
                                ts = datetime.fromisoformat(sv["timestamp"])
                                if ts > latest_ts:
                                    latest_ts = ts
                        if (datetime.now(timezone.utc) - latest_ts).total_seconds() > 1800:
                            data["status"] = "failed"
                            data["error"] = "Pipeline timed out (no progress for 30 minutes)"
                            data["completed_at"] = datetime.now(timezone.utc).isoformat()
                            with open(f, "w", encoding="utf-8") as fw:
                                json.dump(data, fw, indent=2)
                    except (ValueError, TypeError):
                        pass

                run_data = {
                    "run_id": data.get("run_id", f.stem),
                    "status": data.get("status", "unknown"),
                    "mode": data.get("mode", "fast"),
                    "started_at": data.get("started_at"),
                    "completed_at": data.get("completed_at"),
                    "error": data.get("error"),
                    "source_file": data.get("source_file"),
                    "case_ref": data.get("case_ref"),
                    "stages": {k: {"status": v.get("status"), "timestamp": v.get("timestamp"), "started_at": v.get("started_at"), "duration_seconds": v.get("duration_seconds")} for k, v in data.get("stages", {}).items()},
                }
                # Include thorough-mode data if present
                for key in ("preprocessing", "chunks", "merge"):
                    if key in data:
                        run_data[key] = data[key]
                runs.append(run_data)
        except Exception:
            continue

    return jsonify({"runs": runs[:50]})  # Limit to 50 most recent


@app.route("/api/pipeline-stats")
@require_auth
@rate_limit(requests_per_minute=30)
def pipeline_timing_stats():
    """Return aggregated pipeline timing stats for frontend ETA estimation."""
    stats_file = BASE_DIR / "vault" / "pipeline_stats.json"
    if not stats_file.exists():
        return jsonify({"stage_averages": {}, "records": 0})

    try:
        records = json.loads(stats_file.read_text(encoding="utf-8"))
        if not isinstance(records, list):
            return jsonify({"stage_averages": {}, "records": 0})
    except (json.JSONDecodeError, OSError):
        return jsonify({"stage_averages": {}, "records": 0})

    stage_totals = {}     # {stage: [duration, ...]}
    size_buckets = {}     # {"small": {stage: [dur, ...]}, ...}
    chunk_times = []      # per-chunk averages for thorough mode

    for r in records:
        input_chars = r.get("input_chars", 0)
        bucket = "small" if input_chars < 50000 else ("medium" if input_chars < 200000 else "large")

        for stage, dur in r.get("stage_durations", {}).items():
            stage_totals.setdefault(stage, []).append(dur)
            size_buckets.setdefault(bucket, {}).setdefault(stage, []).append(dur)

        if r.get("mode") == "thorough" and r.get("chunks_total_seconds") and r.get("chunk_count"):
            chunk_times.append(r["chunks_total_seconds"] / r["chunk_count"])

    def avg(lst):
        return round(sum(lst) / len(lst), 1) if lst else None

    return jsonify({
        "records": len(records),
        "stage_averages": {s: avg(durs) for s, durs in stage_totals.items()},
        "size_buckets": {
            bucket: {s: avg(durs) for s, durs in stages.items()}
            for bucket, stages in size_buckets.items()
        },
        "thorough_chunk_avg_seconds": avg(chunk_times),
    })


@app.route("/api/pipeline/<run_id>")
@require_auth
@rate_limit(requests_per_minute=120)  # Polled frequently
def pipeline_status(run_id):
    """Get the status of a pipeline run (for UI polling)."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"run_id": safe_id, "status": "not_found"}), 404

    with open(status_file, encoding="utf-8") as f:
        return jsonify(json.load(f))


@app.route("/api/pipeline/<run_id>/retry", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=3)
def pipeline_retry(run_id):
    """Retry a failed pipeline run. Resumes from checkpoint if available."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    status_file = PIPELINE_STATUS_DIR / f"{safe_id}.json"
    if not status_file.exists():
        return jsonify({"error": "Pipeline run not found"}), 404

    try:
        with open(status_file, encoding="utf-8") as f:
            status_data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return jsonify({"error": "Could not read pipeline status"}), 500

    if status_data.get("status") not in ("failed",):
        return jsonify({"error": f"Cannot retry pipeline with status '{status_data.get('status')}'. Only failed pipelines can be retried."}), 400

    # Check if the error is retryable (e.g., API credits exhausted is NOT retryable)
    if status_data.get("retryable") is False:
        error_type = status_data.get("error_type", "unknown")
        user_action = status_data.get("user_action", "Check your configuration and try again.")
        return jsonify({
            "error": f"This pipeline failure is not retryable ({error_type}).",
            "error_type": error_type,
            "user_action": user_action,
            "retryable": False,
        }), 400

    # Demo limit check
    from licensing import is_demo_build, get_trial_remaining
    if is_demo_build() and get_trial_remaining() <= 0:
        return jsonify({"error": "Demo case limit reached. Purchase a license.", "upgrade_url": "https://aiproductivity.dev/pricing"}), 403

    # Concurrency check
    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Too many pipelines running. Please try again later."}), 429

    # Determine pipeline type and source files from status data
    source_file = status_data.get("source_file", "")
    case_ref = status_data.get("case_ref")
    mode = status_data.get("mode", "fast")

    # Find source files: check processing/failed/ or original incoming paths
    resolved_paths = []
    # Try to find files from the status data
    vault_root = BASE_DIR / "vault"
    for zone in ["incoming", "processing", "processing/failed", "processed"]:
        zone_dir = vault_root / zone
        if not zone_dir.exists():
            continue
        for p in zone_dir.rglob("*"):
            if p.is_file() and safe_id in p.name:
                resolved_paths.append(p)

    # Also check documents table for original paths
    if not resolved_paths:
        try:
            conn = get_db()
            try:
                rows = conn.execute(
                    "SELECT original_path, current_path FROM documents WHERE run_id = ?",
                    (safe_id,)
                ).fetchall()
                for row in rows:
                    for path_col in ("original_path", "current_path"):
                        p = Path(row[path_col]) if row[path_col] else None
                        if p and p.exists() and p.suffix.lower() != ".json":
                            resolved_paths.append(p)
            finally:
                conn.close()
        except Exception:
            pass

    if not resolved_paths:
        _active_pipelines.release()
        return jsonify({"error": "Source files not found for retry. Please re-upload the documents."}), 404

    # Reset status to running
    status_data["status"] = "running"
    status_data["retried_at"] = datetime.now(timezone.utc).isoformat()
    status_data.pop("error_type", None)
    status_data.pop("error_message", None)
    status_data.pop("user_action", None)
    status_data.pop("failed_at", None)
    with open(status_file, "w", encoding="utf-8") as f:
        json.dump(status_data, f, indent=2)

    # Re-launch pipeline (will resume from checkpoint)
    if mode == "thorough":
        t = threading.Thread(
            target=_run_thorough_pipeline_background,
            args=([str(p) for p in resolved_paths], safe_id, case_ref, "thorough"),
            daemon=False,
        )
    elif len(resolved_paths) > 1:
        t = threading.Thread(
            target=_run_combined_pipeline_background,
            args=([str(p) for p in resolved_paths], safe_id, case_ref),
            daemon=False,
        )
    else:
        t = threading.Thread(
            target=_run_pipeline_background,
            args=(str(resolved_paths[0]), safe_id),
            daemon=False,
        )
    t.start()

    logger.info("Pipeline %s retried with %d files", safe_id, len(resolved_paths))

    return jsonify({
        "run_id": safe_id,
        "status": "retrying",
        "file_count": len(resolved_paths),
        "message": "Pipeline retry started. Resuming from last checkpoint.",
    })


# ── Health Check ──────────────────────────────────────────────────────────────

_app_start_time = time.time()


@app.route("/api/health")
def api_health_check():
    """Health check endpoint for PM2/monitoring. No auth required."""
    import os as _os

    db_ok = False
    try:
        conn = get_db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        db_ok = True
    except Exception:
        pass

    api_key_configured = bool(_os.getenv("ANTHROPIC_API_KEY", ""))

    # Count active pipelines (3 - available = active)
    # Semaphore doesn't expose count directly, so try to acquire then release
    active = 0
    acquired = []
    for _ in range(3):
        if _active_pipelines.acquire(blocking=False):
            acquired.append(True)
        else:
            break
    active = 3 - len(acquired)
    for _ in acquired:
        _active_pipelines.release()

    status = "healthy" if db_ok and api_key_configured else "degraded"
    http_code = 200 if status == "healthy" else 503

    return jsonify({
        "status": status,
        "uptime_seconds": int(time.time() - _app_start_time),
        "active_pipelines": active,
        "db_ok": db_ok,
        "api_key_configured": api_key_configured,
    }), http_code


# ── Audit Trail API ──────────────────────────────────────────────────────────

@app.route("/api/audit")
@require_auth
@rate_limit(requests_per_minute=30)
def list_audit():
    """List audit trail entries with pagination."""
    if not VAULT_AUDIT.exists():
        return jsonify({"entries": [], "pagination": {"page": 1, "total": 0}})

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 100)

    all_files = sorted(VAULT_AUDIT.glob("*.json"), reverse=True)
    total = len(all_files)
    offset = (page - 1) * per_page
    page_files = all_files[offset:offset + per_page]

    entries = []
    for f in page_files:
        try:
            with open(f, encoding="utf-8") as fh:
                entries.append(json.load(fh))
        except (json.JSONDecodeError, KeyError):
            continue

    log_access(
        session.get("username", "api"), "list", "audit_trail",
        ip_address=request.remote_addr,
    )

    return jsonify({
        "entries": entries,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": (total + per_page - 1) // per_page if per_page else 1,
        },
    })


# ── System Status API ────────────────────────────────────────────────────────

@app.route("/api/status")
@app.route("/api/dashboard/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def system_status():
    """Overall system status: counts, health checks."""
    summary_count = len(list(VAULT_SUMMARIES.glob("*_summary.json"))) if VAULT_SUMMARIES.exists() else 0
    incoming_count = sum(1 for _ in VAULT_INCOMING.rglob("*") if _.is_file()) if VAULT_INCOMING.exists() else 0
    processing_count = sum(1 for _ in (BASE_DIR / "vault" / "processing").rglob("*") if _.is_file()) if (BASE_DIR / "vault" / "processing").exists() else 0

    contact_counts = {"total": 0, "new": 0, "contacted": 0, "awaiting": 0, "received": 0, "failed": 0}
    try:
        conn = get_db()
        for row in conn.execute("SELECT status, COUNT(*) as cnt FROM contacts GROUP BY status").fetchall():
            status_key = row["status"]
            if status_key in contact_counts:
                contact_counts[status_key] = row["cnt"]
            contact_counts["total"] += row["cnt"]
        conn.close()
    except Exception:
        pass

    return jsonify({
        "summaries_completed": summary_count,
        "files_incoming": incoming_count,
        "files_processing": processing_count,
        "contacts": contact_counts,
        "system": "operational",
    })


# ── Incoming Files API ────────────────────────────────────────────────────────

@app.route("/api/incoming")
@require_auth
@rate_limit(requests_per_minute=60)
def list_incoming():
    """List files in vault/incoming/ for the dashboard drill-down."""
    if not VAULT_INCOMING.exists():
        return jsonify({"files": [], "total": 0})

    files = []
    for p in sorted(VAULT_INCOMING.rglob("*"), key=lambda x: x.stat().st_mtime, reverse=True):
        if not p.is_file():
            continue
        files.append({
            "name": p.name,
            "path": str(p.relative_to(VAULT_INCOMING)),
            "size": p.stat().st_size,
            "modified": datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat(),
            "extension": p.suffix.lower(),
        })

    return jsonify({"files": files[:100], "total": len(files)})


# ── Chat with Summaries API ──────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=20, burst=10)
def chat_with_summaries():
    """Chat endpoint: LLM with context of all existing summaries."""
    data = request.get_json()
    if not data or not data.get("message", "").strip():
        return jsonify({"error": "message is required"}), 400

    user_message = data["message"].strip()[:2000]
    conversation = data.get("history", [])[-10:]  # Last 10 messages

    # Build summary context
    summary_context = _build_summary_context()

    config = load_config()
    backend = config.get("llm_backend", "ollama")

    system_prompt = (
        "You are a medical records assistant with access to the following patient summaries. "
        "Answer questions accurately based on the summaries provided. "
        "Always cite which summary/document your answer comes from. "
        "If the information is not in the summaries, say so clearly. "
        "Never fabricate medical information.\n\n"
        "=== AVAILABLE SUMMARIES ===\n" + summary_context
    )

    messages = [{"role": "system", "content": system_prompt}]
    for msg in conversation:
        if msg.get("role") in ("user", "assistant"):
            messages.append({"role": msg["role"], "content": msg["content"][:2000]})
    messages.append({"role": "user", "content": user_message})

    try:
        if backend == "claude":
            reply, model = _chat_claude(messages, config)
        else:
            reply, model = _chat_ollama(messages, config)
    except Exception as e:
        logger.error("Chat error: %s", e)
        return jsonify({"error": f"LLM unavailable: {e}"}), 503

    log_access(
        session.get("username", "api"), "chat", "summaries",
        ip_address=request.remote_addr,
        details=f"q={user_message[:80]}",
    )

    return jsonify({"reply": reply, "model": model, "backend": backend})


def _chat_ollama(messages, config):
    """Send chat messages to local Ollama."""
    import requests as req_lib
    endpoint = config.get("ollama", {}).get("endpoint", "http://localhost:11434")
    model = config.get("medical_agents", {}).get("summarizer", {}).get("model", "qwen2.5:7b")
    resp = req_lib.post(
        f"{endpoint}/api/chat",
        json={"model": model, "messages": messages, "stream": False},
        timeout=120,
    )
    resp.raise_for_status()
    result = resp.json()
    return result.get("message", {}).get("content", "No response from model."), model


def _chat_claude(messages, config):
    """Send chat messages to Anthropic Claude API."""
    import anthropic
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set")

    claude_cfg = config.get("claude", {})
    model = claude_cfg.get("model", "claude-sonnet-4-6")
    max_tokens = claude_cfg.get("max_tokens", 8192)

    # Separate system from conversation
    system_text = ""
    conversation = []
    for msg in messages:
        if msg["role"] == "system":
            system_text += msg["content"] + "\n"
        else:
            conversation.append({"role": msg["role"], "content": msg["content"]})

    if not conversation or conversation[0]["role"] != "user":
        conversation.insert(0, {"role": "user", "content": "Please proceed."})

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system_text.strip() if system_text.strip() else anthropic.NOT_GIVEN,
        messages=conversation,
        timeout=claude_cfg.get("timeout", 120),
    )
    text = "\n".join(b.text for b in response.content if b.type == "text")
    return text or "No response from model.", model


def _build_summary_context():
    """Build a concise context string from all existing summaries."""
    if not VAULT_SUMMARIES.exists():
        return "No summaries available yet."

    parts = []
    for f in sorted(VAULT_SUMMARIES.glob("*_summary.json"), reverse=True)[:20]:
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
            summary = data.get("summary", {})
            if not summary:
                continue
            s = summary.get("summary", {})
            source = data.get("source_file", f.stem)
            run_id = data.get("run_id", "")
            chief = s.get("chief_complaint", {}).get("text", "N/A")
            diagnoses = ", ".join(d.get("diagnosis", "") for d in s.get("active_diagnoses", []))
            meds = ", ".join(f"{m.get('name','')} {m.get('dosage','')}" for m in s.get("medications", []))
            findings = ", ".join(f.get("finding", "") for f in s.get("key_findings", []))
            raw_gaps = s.get("timeline_gaps", [])
            gap_strs = []
            for g in raw_gaps:
                if isinstance(g, str):
                    gap_strs.append(g)
                elif isinstance(g, dict):
                    gap_strs.append(
                        g.get("gap_description")
                        or g.get("note")
                        or (f"{g.get('gap_start', '')} to {g.get('gap_end', '')}" if g.get("gap_start") else str(g))
                    )
            gaps = "; ".join(gap_strs)
            confidence = s.get("overall_confidence", "N/A")

            parts.append(
                f"--- Document: {source} (ID: {run_id}) ---\n"
                f"Chief Complaint: {chief}\n"
                f"Diagnoses: {diagnoses or 'None listed'}\n"
                f"Medications: {meds or 'None listed'}\n"
                f"Key Findings: {findings or 'None listed'}\n"
                f"Timeline Gaps: {gaps or 'None'}\n"
                f"Confidence: {confidence}\n"
            )
        except (json.JSONDecodeError, KeyError, TypeError, AttributeError):
            continue

    return "\n".join(parts) if parts else "No summaries available yet."


# ── Summary Feedback (RLHF) API ──────────────────────────────────────────────

@app.route("/api/summaries/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_feedback(run_id):
    """Submit quality feedback on a summary for RLHF."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    rating = data.get("rating", "")
    if rating not in ("poor", "good", "excellent"):
        return jsonify({"error": "rating must be poor, good, or excellent"}), 400

    feedback_text = (data.get("feedback_text") or "")[:2000]
    username = session.get("username", "api")

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO summary_feedback (run_id, rating, feedback_text, username)
                   VALUES (?, ?, ?, ?)""",
                (safe_id, rating, feedback_text, username),
            )
    except Exception as e:
        logger.error("Feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("summary_feedback", None, f"Feedback on {safe_id}: {rating}")
    logger.info("Feedback for %s: %s by %s", safe_id, rating, username)

    return jsonify({"success": True, "message": f"Thank you for your {rating} rating."})


@app.route("/api/summaries/<run_id>/feedback")
@require_auth
@rate_limit(requests_per_minute=60)
def get_feedback(run_id):
    """Get all feedback for a summary."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM summary_feedback WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()

    return jsonify({"feedback": [dict(r) for r in rows]})


@app.route("/api/feedback/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def feedback_stats():
    """Aggregate feedback statistics for RLHF insights."""
    conn = get_db()
    try:
        totals = conn.execute(
            "SELECT rating, COUNT(*) as cnt FROM summary_feedback GROUP BY rating"
        ).fetchall()
        recent = conn.execute(
            """SELECT sf.run_id, sf.rating, sf.feedback_text, sf.created_at, sf.username
               FROM summary_feedback sf ORDER BY sf.created_at DESC LIMIT 20"""
        ).fetchall()
    finally:
        conn.close()

    stats = {"poor": 0, "good": 0, "excellent": 0}
    for row in totals:
        stats[row["rating"]] = row["cnt"]

    return jsonify({
        "stats": stats,
        "total": sum(stats.values()),
        "recent": [dict(r) for r in recent],
    })


# ── Case Valuation Outcome Tracking (RL) ─────────────────────────────────────

@app.route("/api/valuations/<run_id>/outcome", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_valuation_outcome(run_id):
    """Submit actual settlement/verdict outcome for valuation calibration."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    accuracy = data.get("attorney_accuracy_rating", "")
    if accuracy and accuracy not in ("too_low", "accurate", "too_high"):
        return jsonify({"error": "attorney_accuracy_rating must be too_low, accurate, or too_high"}), 400

    outcome_type = data.get("outcome_type", "")
    if outcome_type and outcome_type not in ("settled", "verdict", "dismissed", "pending"):
        return jsonify({"error": "outcome_type must be settled, verdict, dismissed, or pending"}), 400

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO valuation_outcomes
                   (run_id, predicted_low, predicted_mid, predicted_high, predicted_severity,
                    actual_settlement, actual_verdict, outcome_type, attorney_accuracy_rating,
                    attorney_notes, jurisdiction, case_type)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (safe_id,
                 data.get("predicted_low"), data.get("predicted_mid"), data.get("predicted_high"),
                 data.get("predicted_severity"),
                 data.get("actual_settlement"), data.get("actual_verdict"),
                 outcome_type or None, accuracy or None,
                 (data.get("attorney_notes") or "")[:2000] or None,
                 data.get("jurisdiction"), data.get("case_type")),
            )
    except Exception as e:
        logger.error("Valuation outcome save error: %s", e)
        return jsonify({"error": "Failed to save outcome"}), 500

    _audit_log("valuation_outcome", None, f"Outcome for {safe_id}: {accuracy or outcome_type}")
    return jsonify({"success": True, "message": "Valuation outcome recorded."})


@app.route("/api/valuations/<run_id>/outcome")
@require_auth
@rate_limit(requests_per_minute=60)
def get_valuation_outcome(run_id):
    """Get outcome data for a valuation."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM valuation_outcomes WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()
    return jsonify({"outcomes": [dict(r) for r in rows]})


# ── Demand Package Feedback (RL) ─────────────────────────────────────────────

@app.route("/api/demand/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_demand_feedback(run_id):
    """Submit quality feedback on a demand package."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    rating = data.get("rating", "")
    if rating and rating not in ("poor", "good", "excellent"):
        return jsonify({"error": "rating must be poor, good, or excellent"}), 400

    tone = data.get("tone_feedback", "")
    if tone and tone not in ("too_aggressive", "appropriate", "too_conservative"):
        return jsonify({"error": "tone_feedback must be too_aggressive, appropriate, or too_conservative"}), 400

    edit_sev = data.get("edit_severity", "")
    if edit_sev and edit_sev not in ("minor_tweaks", "significant_rewrites", "unusable"):
        return jsonify({"error": "edit_severity must be minor_tweaks, significant_rewrites, or unusable"}), 400

    legal_acc = data.get("legal_accuracy")
    if legal_acc is not None:
        try:
            legal_acc = int(legal_acc)
            if not (1 <= legal_acc <= 5):
                return jsonify({"error": "legal_accuracy must be 1-5"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "legal_accuracy must be an integer 1-5"}), 400

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT INTO demand_feedback
                   (run_id, rating, sections_edited, edit_severity, tone_feedback,
                    legal_accuracy, feedback_text)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (safe_id, rating or None,
                 data.get("sections_edited"),
                 edit_sev or None, tone or None,
                 legal_acc,
                 (data.get("feedback_text") or "")[:2000] or None),
            )
    except Exception as e:
        logger.error("Demand feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("demand_feedback", None, f"Demand feedback on {safe_id}: {rating}")
    return jsonify({"success": True, "message": "Demand package feedback recorded."})


# ── Negligence Detection Feedback (RL) ───────────────────────────────────────

@app.route("/api/negligence/<run_id>/feedback", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def submit_negligence_feedback(run_id):
    """Submit accept/reject feedback on individual negligence findings."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    # Support batch submission of multiple findings
    findings = data.get("findings", [data]) if "findings" in data else [data]

    inserted = 0
    try:
        with transaction() as conn:
            for finding in findings:
                title = (finding.get("finding_title") or "")[:500]
                accepted = finding.get("finding_accepted")
                if accepted is not None:
                    accepted = 1 if accepted else 0

                conn.execute(
                    """INSERT INTO negligence_feedback
                       (run_id, finding_title, finding_accepted, severity_correct,
                        corrected_severity, attorney_notes)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (safe_id, title or None, accepted,
                     1 if finding.get("severity_correct") else (0 if finding.get("severity_correct") is not None else None),
                     finding.get("corrected_severity"),
                     (finding.get("attorney_notes") or "")[:2000] or None),
                )
                inserted += 1
    except Exception as e:
        logger.error("Negligence feedback save error: %s", e)
        return jsonify({"error": "Failed to save feedback"}), 500

    _audit_log("negligence_feedback", None, f"Negligence feedback on {safe_id}: {inserted} findings")
    return jsonify({"success": True, "message": f"{inserted} finding(s) feedback recorded."})


@app.route("/api/negligence/<run_id>/feedback")
@require_auth
@rate_limit(requests_per_minute=60)
def get_negligence_feedback(run_id):
    """Get all negligence feedback for a run."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM negligence_feedback WHERE run_id = ? ORDER BY created_at DESC",
            (safe_id,),
        ).fetchall()
    finally:
        conn.close()
    return jsonify({"feedback": [dict(r) for r in rows]})


# ── RL Feedback Statistics ───────────────────────────────────────────────────

@app.route("/api/rl/stats")
@require_auth
@rate_limit(requests_per_minute=60)
def rl_feedback_stats():
    """Aggregate RL feedback statistics across all features."""
    conn = get_db()
    try:
        # Valuation outcomes
        val_stats = conn.execute(
            """SELECT attorney_accuracy_rating as rating, COUNT(*) as cnt
               FROM valuation_outcomes WHERE attorney_accuracy_rating IS NOT NULL
               GROUP BY attorney_accuracy_rating"""
        ).fetchall()

        # Demand feedback
        dem_stats = conn.execute(
            "SELECT rating, COUNT(*) as cnt FROM demand_feedback WHERE rating IS NOT NULL GROUP BY rating"
        ).fetchall()
        dem_tone = conn.execute(
            """SELECT tone_feedback, COUNT(*) as cnt FROM demand_feedback
               WHERE tone_feedback IS NOT NULL GROUP BY tone_feedback"""
        ).fetchall()

        # Negligence feedback
        neg_stats = conn.execute(
            """SELECT
                 SUM(CASE WHEN finding_accepted = 1 THEN 1 ELSE 0 END) as accepted,
                 SUM(CASE WHEN finding_accepted = 0 THEN 1 ELSE 0 END) as rejected,
                 COUNT(*) as total
               FROM negligence_feedback WHERE finding_accepted IS NOT NULL"""
        ).fetchone()

        # Exemplar bank counts
        exemplar_counts = conn.execute(
            "SELECT feature, COUNT(*) as cnt FROM exemplar_bank GROUP BY feature"
        ).fetchall()
    finally:
        conn.close()

    return jsonify({
        "valuation": {
            "accuracy": {r["rating"]: r["cnt"] for r in val_stats},
            "total": sum(r["cnt"] for r in val_stats),
        },
        "demand": {
            "ratings": {r["rating"]: r["cnt"] for r in dem_stats},
            "tone": {r["tone_feedback"]: r["cnt"] for r in dem_tone},
            "total": sum(r["cnt"] for r in dem_stats),
        },
        "negligence": {
            "accepted": neg_stats["accepted"] or 0 if neg_stats else 0,
            "rejected": neg_stats["rejected"] or 0 if neg_stats else 0,
            "total": neg_stats["total"] or 0 if neg_stats else 0,
            "precision": round((neg_stats["accepted"] or 0) / max(1, neg_stats["total"] or 1), 3) if neg_stats else 0,
        },
        "exemplars": {r["feature"]: r["cnt"] for r in exemplar_counts},
    })


# ── Email Settings API ────────────────────────────────────────────────────────

@app.route("/api/settings/email")
@require_auth
@rate_limit(requests_per_minute=30)
def get_email_settings():
    """Get current email configuration (passwords masked)."""
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM email_config WHERE id = 1").fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({
            "configured": False,
            "smtp_host": "", "smtp_port": 587, "smtp_username": "",
            "imap_host": "", "imap_port": 993, "imap_username": "",
            "sender_name": "", "sender_organization": "", "sender_phone": "",
            "enabled": False,
        })

    d = dict(row)
    # Mask passwords in response
    d["smtp_password"] = "********" if d.get("smtp_password_encrypted") else ""
    d["imap_password"] = "********" if d.get("imap_password_encrypted") else ""
    del d["smtp_password_encrypted"]
    del d["imap_password_encrypted"]
    d["configured"] = True
    return jsonify(d)


@app.route("/api/settings/email", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def save_email_settings():
    """Save email configuration."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    smtp_host = (data.get("smtp_host") or "").strip()
    smtp_port = int(data.get("smtp_port", 587))
    smtp_username = (data.get("smtp_username") or "").strip()
    smtp_password = data.get("smtp_password", "")
    imap_host = (data.get("imap_host") or "").strip()
    imap_port = int(data.get("imap_port", 993))
    imap_username = (data.get("imap_username") or "").strip()
    imap_password = data.get("imap_password", "")
    sender_name = sanitize_string(data.get("sender_name", ""), 200)
    sender_org = sanitize_string(data.get("sender_organization", ""), 300)
    sender_phone = sanitize_string(data.get("sender_phone", ""), 50)
    enabled = 1 if data.get("enabled") else 0

    username = session.get("username", "api")
    now = datetime.now(timezone.utc).isoformat()

    # Don't overwrite password if masked value sent back
    conn = get_db()
    try:
        existing = conn.execute("SELECT * FROM email_config WHERE id = 1").fetchone()
    finally:
        conn.close()

    if smtp_password == "********" and existing:
        smtp_password_enc = existing["smtp_password_encrypted"]
    else:
        smtp_password_enc = smtp_password  # In production, encrypt this

    if imap_password == "********" and existing:
        imap_password_enc = existing["imap_password_encrypted"]
    else:
        imap_password_enc = imap_password

    try:
        with transaction() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO email_config
                   (id, smtp_host, smtp_port, smtp_username, smtp_password_encrypted,
                    imap_host, imap_port, imap_username, imap_password_encrypted,
                    sender_name, sender_organization, sender_phone,
                    enabled, updated_at, updated_by)
                   VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (smtp_host, smtp_port, smtp_username, smtp_password_enc,
                 imap_host, imap_port, imap_username, imap_password_enc,
                 sender_name, sender_org, sender_phone,
                 enabled, now, username),
            )
    except Exception as e:
        logger.error("Email config save error: %s", e)
        return jsonify({"error": "Failed to save settings"}), 500

    _audit_log("email_settings_updated", None, f"Email settings updated by {username}")
    logger.info("Email settings updated by %s", username)

    return jsonify({"success": True, "message": "Email settings saved."})


@app.route("/api/settings/email/test", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=3)
def test_email_connection():
    """Test SMTP and IMAP connection."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    results = {"smtp": None, "imap": None}

    # Test SMTP
    smtp_host = (data.get("smtp_host") or "").strip()
    smtp_port = int(data.get("smtp_port", 587))
    smtp_user = (data.get("smtp_username") or "").strip()
    smtp_pass = data.get("smtp_password", "")

    if smtp_pass == "********":
        conn = get_db()
        try:
            row = conn.execute("SELECT smtp_password_encrypted FROM email_config WHERE id = 1").fetchone()
            smtp_pass = row["smtp_password_encrypted"] if row else ""
        finally:
            conn.close()

    if smtp_host:
        try:
            import smtplib
            with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as s:
                s.ehlo()
                s.starttls()
                s.ehlo()
                if smtp_user and smtp_pass:
                    s.login(smtp_user, smtp_pass)
                results["smtp"] = {"status": "ok", "message": "SMTP connection successful"}
        except Exception as e:
            results["smtp"] = {"status": "error", "message": str(e)}
    else:
        results["smtp"] = {"status": "skipped", "message": "No SMTP host configured"}

    # Test IMAP
    imap_host = (data.get("imap_host") or "").strip()
    imap_port = int(data.get("imap_port", 993))
    imap_user = (data.get("imap_username") or "").strip()
    imap_pass = data.get("imap_password", "")

    if imap_pass == "********":
        conn = get_db()
        try:
            row = conn.execute("SELECT imap_password_encrypted FROM email_config WHERE id = 1").fetchone()
            imap_pass = row["imap_password_encrypted"] if row else ""
        finally:
            conn.close()

    if imap_host:
        try:
            import imaplib
            with imaplib.IMAP4_SSL(imap_host, imap_port) as m:
                if imap_user and imap_pass:
                    m.login(imap_user, imap_pass)
                results["imap"] = {"status": "ok", "message": "IMAP connection successful"}
        except Exception as e:
            results["imap"] = {"status": "error", "message": str(e)}
    else:
        results["imap"] = {"status": "skipped", "message": "No IMAP host configured"}

    return jsonify(results)


# ── LLM Backend Settings API ──────────────────────────────────────────────

@app.route("/api/settings/llm")
@require_auth
@rate_limit(requests_per_minute=30)
def get_llm_settings():
    """Get current LLM backend configuration."""
    config = load_config()
    backend = config.get("llm_backend", "ollama")
    claude_cfg = config.get("claude", {})
    ollama_cfg = config.get("ollama", {})

    # Check Claude API key availability
    has_claude_key = bool(os.getenv("ANTHROPIC_API_KEY", ""))

    # Check Ollama availability
    ollama_ok = False
    try:
        import urllib.request
        req = urllib.request.Request(f"{ollama_cfg.get('endpoint', 'http://localhost:11434')}/api/tags")
        req.add_header("User-Agent", "MedRecords")
        with urllib.request.urlopen(req, timeout=3) as resp:
            ollama_ok = resp.status == 200
    except Exception:
        pass

    return jsonify({
        "backend": backend,
        "claude": {
            "model": claude_cfg.get("model", "claude-sonnet-4-6"),
            "max_tokens": claude_cfg.get("max_tokens", 8192),
            "available": has_claude_key,
            "models": ["claude-haiku-4-5-20251001", "claude-sonnet-4-6", "claude-opus-4-6"],
        },
        "ollama": {
            "endpoint": ollama_cfg.get("endpoint", "http://localhost:11434"),
            "available": ollama_ok,
        },
    })


@app.route("/api/settings/llm", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def save_llm_settings():
    """Switch LLM backend and model. Writes to config.yaml."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    new_backend = data.get("backend", "").strip().lower()
    if new_backend not in ("ollama", "claude"):
        return jsonify({"error": "backend must be 'ollama' or 'claude'"}), 400

    # Validate Claude availability
    if new_backend == "claude" and not os.getenv("ANTHROPIC_API_KEY", ""):
        return jsonify({"error": "Cannot switch to Claude: ANTHROPIC_API_KEY not configured"}), 400

    config = load_config()
    config["llm_backend"] = new_backend

    # Update Claude model if provided
    claude_model = data.get("claude_model", "").strip()
    if claude_model and claude_model in ("claude-haiku-4-5-20251001", "claude-sonnet-4-6", "claude-opus-4-6"):
        if "claude" not in config:
            config["claude"] = {}
        config["claude"]["model"] = claude_model

    # Write back to config.yaml
    config_path = BASE_DIR / "config.yaml"
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    except Exception as e:
        logger.error("Failed to save config.yaml: %s", e)
        return jsonify({"error": "Failed to save configuration"}), 500

    _audit_log("llm_backend_changed", None,
               f"LLM backend changed to {new_backend} by {session.get('username', 'api')}")
    logger.info("LLM backend changed to %s (model: %s)", new_backend,
                claude_model or config.get("claude", {}).get("model", "default"))

    return jsonify({
        "success": True,
        "backend": new_backend,
        "message": f"LLM backend switched to {new_backend}. Pipeline will use this on next run.",
    })


# ── File Management API ──────────────────────────────────────────────────────

VALID_CATEGORIES = {
    "uncategorized", "clinical_notes", "lab_results", "imaging",
    "discharge", "billing", "referral", "legal", "correspondence",
    "summary",
}


@app.route("/api/files")
@require_auth
@rate_limit(requests_per_minute=60)
def list_files():
    """List all tracked documents with filters and pagination."""
    page = max(1, request.args.get("page", 1, type=int))
    per_page = min(100, max(1, request.args.get("per_page", 25, type=int)))
    status_filter = request.args.get("status", "").strip()
    category_filter = request.args.get("category", "").strip()
    case_ref_filter = request.args.get("case_ref", "").strip()
    vault_zone_filter = request.args.get("vault_zone", "").strip()
    search_q = request.args.get("q", "").strip()[:200]
    run_id_filter = request.args.get("run_id", "").strip()[:200]

    conditions = []
    params = []

    if status_filter and status_filter in ("pending", "processing", "completed", "failed"):
        conditions.append("d.status = ?")
        params.append(status_filter)
    if category_filter and category_filter in VALID_CATEGORIES:
        conditions.append("d.category = ?")
        params.append(category_filter)
    if case_ref_filter:
        conditions.append("d.case_ref = ?")
        params.append(case_ref_filter)
    if vault_zone_filter and vault_zone_filter in ("incoming", "processing", "processed", "failed"):
        conditions.append("d.vault_zone = ?")
        params.append(vault_zone_filter)
    if run_id_filter:
        conditions.append("d.run_id = ?")
        params.append(run_id_filter)
    if search_q:
        conditions.append("(d.filename LIKE ? OR d.case_ref LIKE ? OR d.notes LIKE ?)")
        like = f"%{search_q}%"
        params.extend([like, like, like])

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    conn = get_db()
    try:
        total = conn.execute(
            f"SELECT COUNT(*) FROM documents d{where}", params
        ).fetchone()[0]

        offset = (page - 1) * per_page
        rows = conn.execute(
            f"""SELECT d.*, c.contact_name
                FROM documents d
                LEFT JOIN contacts c ON d.contact_id = c.id
                {where}
                ORDER BY d.created_at DESC
                LIMIT ? OFFSET ?""",
            params + [per_page, offset],
        ).fetchall()
    finally:
        conn.close()

    files = []
    for r in rows:
        files.append({
            "id": r["id"],
            "filename": r["filename"],
            "extension": r["extension"],
            "file_size": r["file_size"],
            "status": r["status"],
            "vault_zone": r["vault_zone"],
            "case_ref": r["case_ref"],
            "category": r["category"],
            "contact_name": r["contact_name"],
            "contact_id": r["contact_id"],
            "run_id": r["run_id"],
            "upload_source": r["upload_source"],
            "created_at": r["created_at"],
            "processed_at": r["processed_at"],
        })

    log_access(
        session.get("username", "api"), "list_files", "documents",
        ip_address=request.remote_addr, details=f"page={page}",
    )

    return jsonify({
        "files": files,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "pages": max(1, -(-total // per_page)),
        },
    })


@app.route("/api/files/<int:doc_id>")
@require_auth
@rate_limit(requests_per_minute=60)
def get_file_detail(doc_id):
    """Get full details for a specific document."""
    conn = get_db()
    try:
        row = conn.execute(
            """SELECT d.*, c.contact_name
               FROM documents d
               LEFT JOIN contacts c ON d.contact_id = c.id
               WHERE d.id = ?""",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    result = dict(row)
    # Check if file still exists on disk
    current = result.get("current_path") or result.get("original_path")
    result["file_exists"] = bool(current and Path(current).exists())
    # Check if summary exists
    if result.get("run_id"):
        summary_path = VAULT_SUMMARIES / f"{result['run_id']}_summary.json"
        result["has_summary"] = summary_path.exists()
    else:
        result["has_summary"] = False

    log_access(
        session.get("username", "api"), "view_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
    )

    return jsonify(result)


@app.route("/api/files/<int:doc_id>", methods=["PATCH"])
@require_auth
@rate_limit(requests_per_minute=30)
def update_file_metadata(doc_id):
    """Update document metadata (case_ref, category, notes)."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    conn = get_db()
    try:
        existing = conn.execute("SELECT id FROM documents WHERE id = ?", (doc_id,)).fetchone()
    finally:
        conn.close()

    if not existing:
        return jsonify({"error": "Document not found"}), 404

    updates = []
    params = []

    if "case_ref" in data:
        case_ref = (data["case_ref"] or "").strip()[:100]
        updates.append("case_ref = ?")
        params.append(case_ref if case_ref else None)
    if "category" in data:
        category = (data["category"] or "").strip()
        if category and category not in VALID_CATEGORIES:
            return jsonify({"error": f"Invalid category. Valid: {', '.join(sorted(VALID_CATEGORIES))}"}), 400
        updates.append("category = ?")
        params.append(category or "uncategorized")
    if "notes" in data:
        notes = (data["notes"] or "").strip()[:2000]
        updates.append("notes = ?")
        params.append(notes if notes else None)

    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    updates.append("updated_at = ?")
    params.append(datetime.now(timezone.utc).isoformat())
    params.append(doc_id)

    try:
        with transaction() as conn:
            conn.execute(
                f"UPDATE documents SET {', '.join(updates)} WHERE id = ?",
                params,
            )
    except Exception as e:
        logger.error("Document update error: %s", e)
        return jsonify({"error": "Failed to update document"}), 500

    _audit_log("document_updated", None, f"Document {doc_id} metadata updated")
    return jsonify({"success": True, "message": "Document updated."})


@app.route("/api/files/bulk-update", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=20)
def bulk_update_files():
    """Bulk-update case_ref for multiple documents."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    doc_ids = data.get("doc_ids")
    if not doc_ids or not isinstance(doc_ids, list):
        return jsonify({"error": "doc_ids must be a non-empty list"}), 400
    if len(doc_ids) > 500:
        return jsonify({"error": "Maximum 500 documents per request"}), 400
    if not all(isinstance(i, int) for i in doc_ids):
        return jsonify({"error": "doc_ids must be integers"}), 400

    case_ref = (data.get("case_ref") or "").strip()[:100]
    case_ref = case_ref if case_ref else None

    now = datetime.now(timezone.utc).isoformat()
    placeholders = ",".join("?" for _ in doc_ids)

    try:
        with transaction() as conn:
            cur = conn.execute(
                f"UPDATE documents SET case_ref = ?, updated_at = ? WHERE id IN ({placeholders})",
                [case_ref, now] + doc_ids,
            )
            updated = cur.rowcount
    except Exception as e:
        logger.error("Bulk update error: %s", e)
        return jsonify({"error": "Failed to update documents"}), 500

    _audit_log("bulk_update", None, f"Bulk case_ref update: {updated} docs -> {case_ref}")
    return jsonify({"success": True, "updated": updated})


@app.route("/api/files/bulk-delete", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10)
def bulk_delete_files():
    """Bulk-delete multiple documents from disk and database."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    doc_ids = data.get("doc_ids")
    if not doc_ids or not isinstance(doc_ids, list):
        return jsonify({"error": "doc_ids must be a non-empty list"}), 400
    if len(doc_ids) > 500:
        return jsonify({"error": "Maximum 500 documents per request"}), 400
    if not all(isinstance(i, int) for i in doc_ids):
        return jsonify({"error": "doc_ids must be integers"}), 400

    placeholders = ",".join("?" for _ in doc_ids)
    vault_root = (BASE_DIR / "vault").resolve()

    conn = get_db()
    try:
        rows = conn.execute(
            f"SELECT id, filename, current_path, original_path, file_hash FROM documents WHERE id IN ({placeholders})",
            doc_ids,
        ).fetchall()
    finally:
        conn.close()

    disk_deleted = 0
    for row in rows:
        file_path = row["current_path"] or row["original_path"]
        if file_path:
            resolved = Path(file_path).resolve()
            if str(resolved).startswith(str(vault_root)) and resolved.exists() and resolved.is_file():
                try:
                    resolved.unlink()
                    disk_deleted += 1
                except Exception as e:
                    logger.error("Bulk delete file error %s: %s", resolved, e)

    try:
        with transaction() as txn:
            txn.execute(
                f"DELETE FROM documents WHERE id IN ({placeholders})", doc_ids
            )
            db_deleted = txn.execute("SELECT changes()").fetchone()[0]
    except Exception as e:
        logger.error("Bulk delete DB error: %s", e)
        return jsonify({"error": "Failed to delete from database"}), 500

    _audit_log("bulk_delete", None, f"Bulk delete: {db_deleted} docs removed, {disk_deleted} files from disk")
    log_access(
        session.get("username", "api"), "bulk_delete", "document",
        ip_address=request.remote_addr,
        details=f"deleted={db_deleted}, disk={disk_deleted}",
    )

    return jsonify({"success": True, "deleted": db_deleted, "deleted_from_disk": disk_deleted})


@app.route("/api/cases")
@require_auth
@rate_limit(requests_per_minute=60)
def list_cases():
    """List distinct case references with file counts."""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT case_ref, COUNT(*) as file_count "
            "FROM documents WHERE case_ref IS NOT NULL AND case_ref != '' "
            "GROUP BY case_ref ORDER BY case_ref"
        ).fetchall()
    finally:
        conn.close()

    cases = [{"name": r["case_ref"], "file_count": r["file_count"]} for r in rows]
    return jsonify({"cases": cases})


@app.route("/api/files/suggest-case", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=30)
def suggest_case():
    """Suggest a case_ref for a file based on its filename."""
    data = request.get_json()
    if not data or not data.get("filename"):
        return jsonify({"error": "filename required"}), 400

    try:
        from case_detector import suggest_case_ref as _suggest
        conn = get_db()
        try:
            rows = conn.execute(
                "SELECT DISTINCT case_ref FROM documents WHERE case_ref IS NOT NULL AND case_ref != ''"
            ).fetchall()
        finally:
            conn.close()
        existing = [r["case_ref"] for r in rows]
        result = _suggest(data["filename"], existing)
        return jsonify(result or {"suggestion": None})
    except Exception as e:
        logger.error("Case suggestion error: %s", e)
        return jsonify({"suggestion": None})


@app.route("/api/files/<int:doc_id>", methods=["DELETE"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def delete_file(doc_id):
    """Delete a document from disk and database."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, file_hash FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    file_path = row["current_path"] or row["original_path"]
    deleted_from_disk = False

    if file_path:
        resolved = Path(file_path).resolve()
        vault_root = (BASE_DIR / "vault").resolve()
        if not str(resolved).startswith(str(vault_root)):
            return jsonify({"error": "Path traversal denied"}), 403

        if resolved.exists() and resolved.is_file():
            try:
                resolved.unlink()
                deleted_from_disk = True
            except Exception as e:
                logger.error("Failed to delete file %s: %s", resolved, e)

    try:
        with transaction() as conn:
            conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    except Exception as e:
        logger.error("Document delete DB error: %s", e)
        return jsonify({"error": "Failed to delete from database"}), 500

    _audit_log("document_deleted", None,
               f"Document {doc_id} deleted: {row['filename']} (hash={row['file_hash'][:12] if row['file_hash'] else 'N/A'})")
    log_access(
        session.get("username", "api"), "delete_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    return jsonify({
        "success": True,
        "deleted_from_disk": deleted_from_disk,
        "message": "Document deleted.",
    })


@app.route("/api/files/<int:doc_id>/reprocess", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def reprocess_file(doc_id):
    """Re-trigger the summarization pipeline for a document."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, status FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return jsonify({"error": "Document not found"}), 404

    # Find the file on disk
    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = p
            break

    if not file_path:
        return jsonify({"error": "Source file not found on disk"}), 404

    # Path traversal check
    resolved = Path(file_path).resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        return jsonify({"error": "Path traversal denied"}), 403
    if resolved.is_symlink():
        return jsonify({"error": "Symbolic links not allowed"}), 400

    if not _active_pipelines.acquire(blocking=False):
        return jsonify({"error": "Max concurrent pipelines reached. Try again later."}), 429

    run_id = f"reprocess_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"

    # Update document status
    try:
        with transaction() as conn:
            conn.execute(
                "UPDATE documents SET status = 'processing', run_id = ?, updated_at = ? WHERE id = ?",
                (run_id, datetime.now(timezone.utc).isoformat(), doc_id),
            )
    except Exception as e:
        logger.error("Failed to update document for reprocessing: %s", e)
        _active_pipelines.release()
        return jsonify({"error": "Failed to update document status"}), 500

    t = threading.Thread(
        target=_run_pipeline_background,
        args=(str(resolved), run_id),
        daemon=True,
    )
    t.start()

    _audit_log("document_reprocessed", None, f"Document {doc_id} reprocessed as {run_id}")

    return jsonify({
        "success": True,
        "run_id": run_id,
        "message": "Pipeline restarted. Poll /api/pipeline/<run_id> for status.",
    })


@app.route("/api/files/<int:doc_id>/download")
@require_auth
@rate_limit(requests_per_minute=30)
def download_file(doc_id):
    """Download a document file."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        abort(404)

    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = Path(p)
            break

    if not file_path:
        abort(404)

    # Path traversal check
    resolved = file_path.resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        abort(403)

    log_access(
        session.get("username", "api"), "download_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    return send_file(str(resolved), as_attachment=True, download_name=row["filename"])


@app.route("/api/files/<int:doc_id>/view")
@require_auth
@rate_limit(requests_per_minute=30)
def view_file(doc_id):
    """Serve a document file inline for in-browser viewing (PDF viewer, etc.)."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, filename, current_path, original_path, extension FROM documents WHERE id = ?",
            (doc_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        abort(404)

    file_path = None
    for p in [row["current_path"], row["original_path"]]:
        if p and Path(p).exists():
            file_path = Path(p)
            break

    if not file_path:
        abort(404)

    # Path traversal check
    resolved = file_path.resolve()
    vault_root = (BASE_DIR / "vault").resolve()
    if not str(resolved).startswith(str(vault_root)):
        abort(403)

    ext = (row["extension"] or file_path.suffix).lower()
    # Determine MIME type for inline display
    mime_types = {
        ".pdf": "application/pdf",
        ".html": "text/html",
        ".htm": "text/html",
        ".txt": "text/plain",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".tiff": "image/tiff",
        ".tif": "image/tiff",
    }
    mimetype = mime_types.get(ext, "application/octet-stream")

    log_access(
        session.get("username", "api"), "view_file", "document",
        resource_id=str(doc_id), ip_address=request.remote_addr,
        details=f"file={row['filename']}",
    )

    response = make_response(send_file(str(resolved), mimetype=mimetype))
    response.headers["Content-Disposition"] = f"inline; filename=\"{row['filename']}\""
    return response


@app.route("/api/files/sync", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=5, burst=2)
def sync_files():
    """Scan vault directories and register any untracked files into the documents table."""
    vault_root = BASE_DIR / "vault"
    zones = {
        "incoming": vault_root / "incoming",
        "processed": vault_root / "processed",
        "failed": vault_root / "processing" / "failed",
    }

    registered = 0
    conn = get_db()
    try:
        existing_paths = {
            r[0] for r in conn.execute("SELECT original_path FROM documents").fetchall()
        }
    finally:
        conn.close()

    supported = {".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif",
                 ".dcm", ".dicom", ".doc", ".docx", ".txt"}

    for zone_name, zone_dir in zones.items():
        if not zone_dir.exists():
            continue
        for p in zone_dir.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in supported:
                continue
            if str(p) in existing_paths:
                continue

            status = "pending" if zone_name == "incoming" else (
                "completed" if zone_name == "processed" else "failed"
            )

            try:
                file_hash = hashlib.sha256(p.read_bytes()).hexdigest()
                with transaction() as conn:
                    conn.execute(
                        """INSERT INTO documents
                           (filename, original_path, current_path, file_hash, file_size,
                            extension, vault_zone, status, uploaded_by, upload_source)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'system', 'api')""",
                        (p.name, str(p), str(p), file_hash,
                         p.stat().st_size, p.suffix.lower(),
                         zone_name, status),
                    )
                registered += 1
            except Exception as e:
                logger.error("Failed to register file %s: %s", p, e)

    _audit_log("files_synced", None, f"File sync: {registered} new files registered")

    return jsonify({
        "success": True,
        "registered": registered,
        "message": f"Synced {registered} new file(s) into the documents table.",
    })


# ── Audit Helper ─────────────────────────────────────────────────────────────

def _audit_log(action, contact_id, details):
    """Write an HMAC-signed audit entry to vault/audit/."""
    VAULT_AUDIT.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc)
    entry = {
        "timestamp": timestamp.isoformat(),
        "action": action,
        "source": "medical_app",
        "contact_id": contact_id,
        "details": details,
        "user": session.get("username", "system") if session else "system",
        "ip_address": request.remote_addr if request else None,
    }
    # HMAC sign for immutability verification
    entry["hmac_signature"] = sign_audit_entry(entry)

    filename = f"{timestamp.strftime('%Y%m%d-%H%M%S')}_{action}_{uuid.uuid4().hex[:6]}.json"
    try:
        with open(VAULT_AUDIT / filename, "w", encoding="utf-8") as f:
            json.dump(entry, f, indent=2)
    except Exception as e:
        logger.error("Failed to write audit log: %s", e)


# ── Deposition Summary API ────────────────────────────────────────────────────

@app.route("/api/deposition/upload", methods=["POST"])
@require_auth
@rate_limit(requests_per_minute=10, burst=5)
def upload_deposition():
    """Upload and analyze a deposition transcript."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename"}), 400

    ext = Path(file.filename).suffix.lower()
    if ext not in {".pdf", ".txt", ".doc", ".docx"}:
        return jsonify({"error": "Deposition transcripts must be PDF, TXT, DOC, or DOCX"}), 400

    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({"error": "Invalid filename"}), 400

    # Save to vault/depositions/
    depo_dir = BASE_DIR / "vault" / "depositions"
    depo_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_id = f"depo_{timestamp}"
    save_path = depo_dir / f"{run_id}_{filename}"
    file.save(str(save_path))

    # Extract text from the file
    transcript_text = ""
    try:
        if ext == ".txt":
            transcript_text = save_path.read_text(encoding="utf-8", errors="replace")
        elif ext == ".pdf":
            try:
                import fitz
                doc = fitz.open(str(save_path))
                for page in doc:
                    transcript_text += f"\nPAGE {page.number + 1}\n"
                    transcript_text += page.get_text()
                doc.close()
            except ImportError:
                return jsonify({"error": "PDF support requires PyMuPDF. Install with: pip install pymupdf"}), 500
        elif ext in (".doc", ".docx"):
            try:
                from docx import Document as DocxDoc
                doc = DocxDoc(str(save_path))
                transcript_text = "\n".join(p.text for p in doc.paragraphs)
            except ImportError:
                return jsonify({"error": "DOCX support requires python-docx. Install with: pip install python-docx"}), 500
    except Exception as e:
        return jsonify({"error": f"Failed to extract text: {str(e)}"}), 500

    if not transcript_text.strip():
        return jsonify({"error": "No text could be extracted from the file"}), 400

    # Options from form data
    options = {
        "deponent_name": request.form.get("deponent_name", "").strip(),
        "deponent_role": request.form.get("deponent_role", "witness"),
        "case_ref": request.form.get("case_ref", "").strip(),
    }
    focus = request.form.get("focus_areas", "").strip()
    if focus:
        options["focus_areas"] = [a.strip() for a in focus.split(",") if a.strip()]

    # Run analysis
    try:
        config_path = BASE_DIR / "config.yaml"
        config = {}
        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

        from deposition_summarizer import summarize_deposition, save_deposition_summary
        result = summarize_deposition(transcript_text, config, options)
        save_deposition_summary(run_id, result)

        log_access(
            session.get("username", "api"), "deposition_analysis", "deposition",
            resource_id=run_id, ip_address=request.remote_addr,
            details=f"file={filename}, deponent={options.get('deponent_name', 'Unknown')}",
        )

        return jsonify({
            "ok": True,
            "run_id": run_id,
            "result": result,
        })

    except Exception as e:
        logger.exception("Deposition analysis failed")
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500


@app.route("/api/deposition/list")
@require_auth
def list_depositions():
    """List all analyzed depositions."""
    from deposition_summarizer import list_deposition_summaries
    return jsonify({"depositions": list_deposition_summaries()})


@app.route("/api/deposition/<run_id>")
@require_auth
def get_deposition(run_id):
    """Get a specific deposition analysis."""
    safe_id = secure_filename(run_id)
    if not safe_id:
        abort(400)

    depo_file = BASE_DIR / "vault" / "depositions" / f"{safe_id}_deposition.json"
    if not depo_file.exists():
        abort(404)

    with open(depo_file, encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)


# ── Case Management Integrations API ─────────────────────────────────────────

@app.route("/api/integrations/list")
@require_auth
def list_integration_platforms():
    """List all supported integration platforms and their status."""
    from integrations import list_integrations
    return jsonify({"platforms": list_integrations()})


@app.route("/api/integrations/configure", methods=["POST"])
@require_auth
def configure_integration_endpoint():
    """Configure an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    settings = data.get("settings", {})

    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    try:
        from integrations import configure_integration
        result = configure_integration(platform_id, settings)
        log_access(
            session.get("username", "api"), "configure_integration", "integration",
            resource_id=platform_id, ip_address=request.remote_addr,
        )
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.exception("Integration configuration failed")
        return jsonify({"error": str(e)}), 500


@app.route("/api/integrations/disable", methods=["POST"])
@require_auth
def disable_integration_endpoint():
    """Disable an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    from integrations import disable_integration
    return jsonify(disable_integration(platform_id))


@app.route("/api/integrations/test", methods=["POST"])
@require_auth
def test_integration_endpoint():
    """Test connectivity to an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400

    from integrations import test_connection
    return jsonify(test_connection(platform_id))


@app.route("/api/integrations/push", methods=["POST"])
@require_auth
def push_to_integration_endpoint():
    """Push data to an integration platform."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    platform_id = data.get("platform_id", "").strip()
    run_id = data.get("run_id", "").strip()
    data_type = data.get("data_type", "summary")
    case_ref = data.get("case_ref", "").strip() or None

    if not platform_id:
        return jsonify({"error": "platform_id required"}), 400
    if not run_id:
        return jsonify({"error": "run_id required"}), 400

    safe_id = secure_filename(run_id)
    if not safe_id:
        return jsonify({"error": "Invalid run_id"}), 400

    # Load the data based on type
    push_data = None
    if data_type == "summary":
        summary_file = VAULT_SUMMARIES / f"{safe_id}_summary.json"
        if not summary_file.exists():
            summary_file = VAULT_SUMMARIES / f"{safe_id}.json"
        if summary_file.exists():
            with open(summary_file, encoding="utf-8") as f:
                push_data = json.load(f)

    elif data_type == "deposition":
        depo_file = BASE_DIR / "vault" / "depositions" / f"{safe_id}_deposition.json"
        if depo_file.exists():
            with open(depo_file, encoding="utf-8") as f:
                push_data = json.load(f)

    elif data_type == "demand_package":
        demand_dir = VAULT_SUMMARIES / f"{safe_id}_demand"
        narrative_file = demand_dir / "narrative.json"
        if narrative_file.exists():
            with open(narrative_file, encoding="utf-8") as f:
                push_data = json.load(f)

    if push_data is None:
        return jsonify({"error": f"No {data_type} data found for run_id: {run_id}"}), 404

    try:
        from integrations import push_to_integration
        result = push_to_integration(platform_id, push_data, data_type, case_ref)
        log_access(
            session.get("username", "api"), "push_integration", "integration",
            resource_id=f"{platform_id}:{safe_id}", ip_address=request.remote_addr,
            details=f"type={data_type}",
        )
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.exception("Integration push failed")
        return jsonify({"error": f"Push failed: {str(e)}"}), 500


@app.route("/api/integrations/history")
@require_auth
def integration_history():
    """Get integration push history."""
    from integrations import get_push_history
    limit = request.args.get("limit", 50, type=int)
    return jsonify({"history": get_push_history(limit)})


# ── Main ─────────────────────────────────────────────────────────────────────

def _check_port_available(host: str, port: int) -> bool:
    """Check if the port is available before starting Flask."""
    import socket
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, port))
        return True
    except OSError:
        return False


def main():
    parser = argparse.ArgumentParser(description="Medical Records Web UI")
    parser.add_argument("--port", type=int, default=None, help="Port to listen on")
    args = parser.parse_args()

    try:
        # Ensure vault directories exist
        for d in [VAULT_INCOMING, VAULT_SUMMARIES, VAULT_AUDIT, PIPELINE_STATUS_DIR]:
            d.mkdir(parents=True, exist_ok=True)

        config = load_config()
        ui_config = config.get("web_ui", {})

        host = ui_config.get("host", "127.0.0.1")
        port = args.port or ui_config.get("port", 8080)
        max_mb = ui_config.get("max_upload_mb", 100)
        app.config["MAX_CONTENT_LENGTH"] = max_mb * 1024 * 1024

        # Initialize database
        init_db()

        # Check if port is available
        if not _check_port_available(host, port):
            logger.error(
                "Port %d is already in use. Another instance may be running. "
                "Stop it first or use --port to specify a different port.", port
            )
            raise SystemExit(1)

        # Validate startup configuration
        issues = validate_startup_config(app, config, logger)
        critical = [i for i in issues if i.startswith("CRITICAL")]
        if critical:
            logger.error("Startup blocked by %d critical issue(s). Fix and retry.", len(critical))
            for c in critical:
                logger.error("  %s", c)
            raise SystemExit(1)

        logger.info("Medical Records UI starting on http://%s:%d", host, port)
        logger.info("Health check: http://%s:%d/health", host, port)
        app.run(host=host, port=port, debug=False, threaded=True)

    except SystemExit:
        raise
    except Exception as e:
        logger.error("Fatal startup error: %s", e, exc_info=True)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
