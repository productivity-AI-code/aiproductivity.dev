"""
pipeline_schemas.py — JSON schema definitions and validators for the
4-stage HIPAA Medical Summarization Pipeline.

Every pipeline stage receives and emits validated JSON. Schema validation
gates between stages prevent malformed data from reaching the LLM.

Usage:
    from pipeline_schemas import (
        validate_ingestion_output,
        validate_privacy_output,
        validate_summary_output,
        validate_audit_output,
        extract_json_from_response,
    )

    data = extract_json_from_response(raw_llm_output)
    errors = validate_ingestion_output(data)
    if errors:
        raise ValueError(f"Ingestion output invalid: {errors}")
"""

import json
import re
from datetime import datetime


# ── Helpers ──────────────────────────────────────────────────────────────────

def _repair_json_string(text):
    """Apply progressive repairs to malformed JSON strings.
    Returns list of (label, repaired_string) candidates to try parsing."""
    candidates = []

    # 1. Fix "key"> value → "key": value
    repaired = re.sub(r'(\"[a-zA-Z_]+\")>', r'\1:', text)
    if repaired != text:
        candidates.append(("arrow_to_colon", repaired))

    # 2. Remove trailing commas before } or ]
    no_trailing = re.sub(r',\s*([}\]])', r'\1', text)
    if no_trailing != text:
        candidates.append(("trailing_commas", no_trailing))

    # 3. Replace single quotes with double quotes (Python-style dicts)
    if "'" in text and '"' not in text[:50]:
        single_to_double = text.replace("'", '"')
        candidates.append(("single_quotes", single_to_double))

    # 4. Fix unquoted keys: { key: "value" } → { "key": "value" }
    unquoted_fixed = re.sub(r'(?<=[{,])\s*([a-zA-Z_]\w*)\s*:', r' "\1":', text)
    if unquoted_fixed != text:
        candidates.append(("unquoted_keys", unquoted_fixed))

    # 5. Combined: trailing commas + arrow fix
    combined = re.sub(r',\s*([}\]])', r'\1', repaired)
    if combined != text and combined not in [c[1] for c in candidates]:
        candidates.append(("combined_fix", combined))

    return candidates


def extract_json_from_response(raw_text):
    """
    Extract the first valid JSON object or array from LLM output.
    Uses progressive repair strategies to maximize parse success.
    Returns parsed dict/list or raises ValueError.
    """
    if not raw_text or not raw_text.strip():
        raise ValueError("Empty response from LLM")

    text = raw_text.strip()

    # Strategy 1: Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Strategy 2: Strip markdown code fences
    fenced = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
    if fenced:
        fenced_text = fenced.group(1).strip()
        try:
            return json.loads(fenced_text)
        except json.JSONDecodeError:
            # Try repairs on fenced content too
            for label, repaired in _repair_json_string(fenced_text):
                try:
                    return json.loads(repaired)
                except json.JSONDecodeError:
                    continue

    # Strategy 3: Progressive JSON repair on full text
    for label, repaired in _repair_json_string(text):
        try:
            return json.loads(repaired)
        except json.JSONDecodeError:
            continue

    # Strategy 4: Extract balanced { ... } or [ ... ] block
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        start = text.find(start_char)
        if start == -1:
            continue
        depth = 0
        in_string = False
        escape = False
        for i in range(start, len(text)):
            c = text[i]
            if escape:
                escape = False
                continue
            if c == '\\':
                escape = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == start_char:
                depth += 1
            elif c == end_char:
                depth -= 1
                if depth == 0:
                    block = text[start:i + 1]
                    try:
                        return json.loads(block)
                    except json.JSONDecodeError:
                        # Try repairs on the extracted block
                        for label, repaired in _repair_json_string(block):
                            try:
                                return json.loads(repaired)
                            except json.JSONDecodeError:
                                continue
                        break

    # Strategy 5: json.JSONDecoder raw_decode (handles leading text)
    try:
        decoder = json.JSONDecoder()
        # Find the first { or [
        for i, c in enumerate(text):
            if c in ('{', '['):
                obj, _ = decoder.raw_decode(text, i)
                return obj
    except (json.JSONDecodeError, ValueError):
        pass

    raise ValueError("No valid JSON found in LLM response")


def _check_required(data, fields):
    """Check that all required fields exist and are not None."""
    errors = []
    for field in fields:
        if field not in data or data[field] is None:
            errors.append(f"Missing required field: '{field}'")
    return errors


def _check_type(data, field, expected_type, label=None):
    """Check that a field has the expected type."""
    label = label or field
    if field in data and data[field] is not None:
        if not isinstance(data[field], expected_type):
            return [f"'{label}' must be {expected_type.__name__}, got {type(data[field]).__name__}"]
    return []


def _check_enum(data, field, allowed_values, label=None):
    """Check that a field value is one of the allowed values."""
    label = label or field
    if field in data and data[field] is not None:
        if data[field] not in allowed_values:
            return [f"'{label}' must be one of {allowed_values}, got '{data[field]}'"]
    return []


# ── PHI Leak Detection ──────────────────────────────────────────────────────

_PHI_PATTERNS = [
    # HIPAA Safe Harbor: 18 identifier categories
    # 1. SSN
    (r"\b\d{3}-\d{2}-\d{4}\b", "SSN pattern"),
    # 2. Phone/Fax numbers
    (r"\b\d{3}[-.]\d{3}[-.]\d{4}\b", "Phone number pattern"),
    (r"\b\(\d{3}\)\s*\d{3}[-.]\d{4}\b", "Phone number with area code"),
    # 3. Email
    (r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", "Email pattern"),
    # 4. Street addresses
    (r"\b\d{1,5}\s+\w+\s+(Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Blvd|Boulevard|Way|Court|Ct|Circle|Cir|Place|Pl|Terrace|Ter)\b",
     "Street address pattern"),
    # 5. ZIP codes (5+4 format only — bare 5-digit numbers cause too many false positives)
    (r"\b\d{5}-\d{4}\b", "ZIP+4 code pattern"),
    # 6. Medical Record Numbers (common formats)
    (r"\b(MRN|Medical Record|Med Rec|Record #|Acct|Account)\s*[:#]?\s*\d{4,12}\b",
     "MRN/Account number pattern"),
    # 7. NPI (National Provider Identifier - 10 digits)
    (r"\b(NPI|Provider ID)\s*[:#]?\s*\d{10}\b", "NPI pattern"),
    # 8. Health plan beneficiary numbers
    (r"\b(Policy|Member|Subscriber|Insurance|Plan)\s*(#|ID|No|Number)\s*[:#]?\s*[A-Z0-9]{6,20}\b",
     "Health plan number pattern"),
    # 9. License/certificate numbers
    (r"\b(License|DEA|Cert)\s*(#|No|Number)\s*[:#]?\s*[A-Z0-9]{5,15}\b",
     "License/certificate number pattern"),
    # 10. Vehicle identifiers
    (r"\b(VIN|Vehicle)\s*[:#]?\s*[A-HJ-NPR-Z0-9]{17}\b", "VIN pattern"),
    # 11. URLs
    (r"https?://[^\s]{10,}", "URL pattern"),
    # 12. IP addresses
    (r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "IP address pattern"),
    # 13. Dates of birth / specific dates (common medical formats)
    (r"\b(DOB|Date of Birth|Birth Date|Birthdate)\s*[:#]?\s*\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b",
     "Date of birth pattern"),
    # 14. Ages over 89 (HIPAA considers these identifiers)
    (r"\b(age[ds]?\s*[:#]?\s*)(9[0-9]|1[0-9]{2})\b", "Age over 89 pattern"),
    # 15. Names with common prefixes (heuristic)
    (r"\b(Patient|Pt|Mr|Mrs|Ms|Miss|Dr|Prof)\.\s+[A-Z][a-z]{1,20}\s+[A-Z][a-z]{1,20}\b",
     "Potential name with title"),
]


def check_for_phi_leak(text):
    """
    Scan text for potential PHI patterns. Returns list of warnings.
    Used by the audit validator to ensure no PHI leaked into audit entries.
    """
    warnings = []
    if not isinstance(text, str):
        return warnings
    for pattern, label in _PHI_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            warnings.append(f"Potential PHI leak ({label}): {len(matches)} match(es)")
    return warnings


# ── Stage 1: Ingestion Output Validator ──────────────────────────────────────

VALID_DOC_TYPES = [
    "clinical_note", "lab_report", "imaging", "discharge",
    "referral", "prescription", "progress_note", "operative_report",
    "consultation", "pathology", "radiology", "other",
]

VALID_SECTION_TYPES = [
    "demographics", "encounter", "diagnosis", "medications",
    "labs", "notes", "procedures", "vitals", "imaging",
    "history", "assessment", "plan", "allergies", "other",
]

VALID_OCR_QUALITY = ["high", "medium", "low", "uncertain"]


def validate_ingestion_output(data):
    """
    Validate Stage 1 (Ingestion) output JSON.
    Returns list of error strings. Empty list = valid.
    """
    errors = []

    # Required top-level fields
    errors += _check_required(data, [
        "document_id", "source_file", "ingestion_timestamp",
        "document_type", "sections",
    ])
    errors += _check_type(data, "sections", list)
    errors += _check_enum(data, "document_type", VALID_DOC_TYPES)

    if "page_count" in data:
        errors += _check_type(data, "page_count", int)

    # Validate sections array
    sections = data.get("sections", [])
    if not sections:
        errors.append("'sections' array must not be empty")

    section_ids = set()
    for i, sec in enumerate(sections):
        prefix = f"sections[{i}]"
        if not isinstance(sec, dict):
            errors.append(f"{prefix} must be a dict")
            continue

        errors += _check_required(sec, ["section_id", "section_type", "content"])
        errors += _check_enum(sec, "section_type", VALID_SECTION_TYPES, f"{prefix}.section_type")
        errors += _check_type(sec, "content", str, f"{prefix}.content")

        if "confidence" in sec:
            if not isinstance(sec["confidence"], (int, float)):
                errors.append(f"{prefix}.confidence must be a number")
            elif not (0.0 <= sec["confidence"] <= 1.0):
                errors.append(f"{prefix}.confidence must be between 0.0 and 1.0")

        if "ocr_quality" in sec:
            errors += _check_enum(sec, "ocr_quality", VALID_OCR_QUALITY, f"{prefix}.ocr_quality")

        sid = sec.get("section_id")
        if sid:
            if sid in section_ids:
                errors.append(f"{prefix}.section_id '{sid}' is duplicated")
            section_ids.add(sid)

    # Validate metadata if present
    meta = data.get("metadata")
    if meta and isinstance(meta, dict):
        if "encounter_dates" in meta:
            errors += _check_type(meta, "encounter_dates", list, "metadata.encounter_dates")

    return errors


# ── Stage 2: Privacy Output Validator ────────────────────────────────────────

VALID_PHI_TYPES = [
    "NAME", "GEO", "DATE", "PHONE", "FAX", "EMAIL", "SSN", "MRN",
    "PLAN", "ACCOUNT", "LICENSE", "VEHICLE", "DEVICE", "URL", "IP",
    "BIOMETRIC", "PHOTO", "ID",
]


def validate_privacy_output(data):
    """
    Validate Stage 2 (Privacy) output JSON.
    Critical check: total_redacted must equal total_identifiers_found.
    Returns list of error strings. Empty list = valid.
    """
    errors = []

    errors += _check_required(data, [
        "document_id", "privacy_timestamp", "sections", "phi_summary",
    ])
    errors += _check_type(data, "sections", list)

    # Validate sections
    for i, sec in enumerate(data.get("sections", [])):
        prefix = f"sections[{i}]"
        if not isinstance(sec, dict):
            errors.append(f"{prefix} must be a dict")
            continue
        errors += _check_required(sec, ["section_id", "section_type", "content"])

        # Check redactions_applied if present
        redactions = sec.get("redactions_applied", [])
        if not isinstance(redactions, list):
            errors.append(f"{prefix}.redactions_applied must be a list")
        else:
            for j, r in enumerate(redactions):
                if not isinstance(r, dict):
                    errors.append(f"{prefix}.redactions_applied[{j}] must be a dict")
                    continue
                errors += _check_required(r, ["type", "count"])
                errors += _check_enum(r, "type", VALID_PHI_TYPES,
                                      f"{prefix}.redactions_applied[{j}].type")

    # Validate phi_summary
    phi = data.get("phi_summary", {})
    if not isinstance(phi, dict):
        errors.append("'phi_summary' must be a dict")
    else:
        errors += _check_required(phi, [
            "total_identifiers_found", "total_redacted", "redaction_complete",
        ])

        found = phi.get("total_identifiers_found", 0)
        redacted = phi.get("total_redacted", 0)

        if isinstance(found, int) and isinstance(redacted, int):
            if redacted < found:
                errors.append(
                    f"CRITICAL: Incomplete redaction — found {found} PHI identifiers "
                    f"but only redacted {redacted}"
                )

        if phi.get("redaction_complete") is False:
            errors.append("CRITICAL: phi_summary.redaction_complete is False")

        by_type = phi.get("by_type", {})
        if isinstance(by_type, dict):
            for phi_type in by_type:
                if phi_type not in VALID_PHI_TYPES:
                    errors.append(f"Unknown PHI type in by_type: '{phi_type}'")

    return errors


# ── Stage 3: Summary Output Validator ────────────────────────────────────────

def _validate_claim(claim, prefix, valid_section_ids=None):
    """Validate a single summary claim object."""
    errors = []
    if not isinstance(claim, dict):
        errors.append(f"{prefix} must be a dict")
        return errors

    # Every claim must have text and citation
    if "text" not in claim and "event" not in claim and "diagnosis" not in claim \
            and "name" not in claim and "finding" not in claim:
        errors.append(f"{prefix} must have a text/event/diagnosis/name/finding field")

    if "citation" not in claim:
        errors.append(f"{prefix} missing required 'citation' field")
    elif valid_section_ids and isinstance(claim["citation"], str):
        # Validate citation references a real section_id
        cited_section = claim["citation"].split(":")[0]
        if cited_section not in valid_section_ids:
            errors.append(
                f"{prefix}.citation '{claim['citation']}' references unknown "
                f"section '{cited_section}'"
            )

    if "confidence" in claim:
        if not isinstance(claim["confidence"], (int, float)):
            errors.append(f"{prefix}.confidence must be a number")
        elif not (0.0 <= claim["confidence"] <= 1.0):
            errors.append(f"{prefix}.confidence must be between 0.0 and 1.0")

    return errors


def validate_summary_output(data, privacy_output=None):
    """
    Validate Stage 3 (Summarizer) output JSON.
    If privacy_output is provided, cross-validates citation references.
    Returns list of error strings. Empty list = valid.
    """
    errors = []

    errors += _check_required(data, [
        "document_id", "summary_timestamp", "summary", "verification",
    ])

    # Build set of valid section IDs from privacy output
    valid_section_ids = None
    if privacy_output and isinstance(privacy_output.get("sections"), list):
        valid_section_ids = {
            s["section_id"] for s in privacy_output["sections"]
            if isinstance(s, dict) and "section_id" in s
        }

    # Validate bluf if present (optional — backward compatible)
    bluf = data.get("bluf")
    if bluf is not None:
        if not isinstance(bluf, dict):
            errors.append("'bluf' must be a dict")
        else:
            for field in ["primary_diagnosis", "objective_proof", "future_outlook"]:
                if field in bluf and not isinstance(bluf[field], str):
                    errors.append(f"bluf.{field} must be a string")

    # Validate litigation_cheat_sheet if present (optional — backward compatible)
    cheat_sheet = data.get("litigation_cheat_sheet")
    if cheat_sheet is not None:
        if not isinstance(cheat_sheet, dict):
            errors.append("'litigation_cheat_sheet' must be a dict")
        else:
            for array_name in ["wins", "risks"]:
                items = cheat_sheet.get(array_name)
                if items is not None:
                    if not isinstance(items, list):
                        errors.append(f"litigation_cheat_sheet.{array_name} must be a list")
                    else:
                        key_field = "leverage" if array_name == "wins" else "target"
                        for i, item in enumerate(items):
                            prefix = f"litigation_cheat_sheet.{array_name}[{i}]"
                            if not isinstance(item, dict):
                                errors.append(f"{prefix} must be a dict")
                            elif key_field not in item:
                                errors.append(f"{prefix} missing '{key_field}' field")

    # Validate summary object
    summary = data.get("summary", {})
    if not isinstance(summary, dict):
        errors.append("'summary' must be a dict")
    else:
        # Validate chief_complaint
        if "chief_complaint" in summary:
            errors += _validate_claim(
                summary["chief_complaint"], "summary.chief_complaint", valid_section_ids
            )

        # Validate arrays of claims
        for array_name in [
            "chronological_events", "active_diagnoses",
            "medications", "key_findings",
        ]:
            items = summary.get(array_name, [])
            if not isinstance(items, list):
                errors.append(f"summary.{array_name} must be a list")
            else:
                for i, item in enumerate(items):
                    errors += _validate_claim(
                        item, f"summary.{array_name}[{i}]", valid_section_ids
                    )

        # Validate optional arrays
        for array_name in ["contradictions_flagged", "timeline_gaps"]:
            val = summary.get(array_name)
            if val is not None and not isinstance(val, list):
                errors.append(f"summary.{array_name} must be a list")

        # Validate overall_confidence
        oc = summary.get("overall_confidence")
        if oc is not None:
            if not isinstance(oc, (int, float)):
                errors.append("summary.overall_confidence must be a number")
            elif not (0.0 <= oc <= 1.0):
                errors.append("summary.overall_confidence must be between 0.0 and 1.0")

    # Validate billing_data if present (optional — backward compatible)
    billing = data.get("billing_data")
    if billing is not None:
        if not isinstance(billing, dict):
            errors.append("'billing_data' must be a dict")
        else:
            providers = billing.get("providers")
            if providers is not None:
                if not isinstance(providers, list):
                    errors.append("'billing_data.providers' must be a list")
                else:
                    for i, prov in enumerate(providers):
                        prefix = f"billing_data.providers[{i}]"
                        if not isinstance(prov, dict):
                            errors.append(f"{prefix} must be a dict")
                            continue
                        if "provider_name" not in prov:
                            errors.append(f"{prefix} missing 'provider_name'")
                        services = prov.get("services")
                        if services is not None:
                            if not isinstance(services, list):
                                errors.append(f"{prefix}.services must be a list")
                            else:
                                for j, svc in enumerate(services):
                                    svc_prefix = f"{prefix}.services[{j}]"
                                    if not isinstance(svc, dict):
                                        errors.append(f"{svc_prefix} must be a dict")
                                    elif "amount" in svc and not isinstance(svc["amount"], (int, float)):
                                        errors.append(f"{svc_prefix}.amount must be a number")
                        if "subtotal" in prov and not isinstance(prov["subtotal"], (int, float)):
                            errors.append(f"{prefix}.subtotal must be a number")
            for total_field in ["total_past_medical", "total_future_medical_estimate", "total_combined"]:
                if total_field in billing and billing[total_field] is not None:
                    if not isinstance(billing[total_field], (int, float)):
                        errors.append(f"'billing_data.{total_field}' must be a number")

    # Validate alerts if present (optional — backward compatible)
    VALID_ALERT_TYPES = [
        "treatment_gap", "missing_provider", "pre_existing",
        "inconsistency", "compliance_issue", "prior_injury", "medication_change",
    ]
    VALID_ALERT_SEVERITIES = ["high", "medium", "low"]
    alerts = data.get("alerts")
    if alerts is not None:
        if not isinstance(alerts, list):
            errors.append("'alerts' must be a list")
        else:
            for i, alert in enumerate(alerts):
                prefix = f"alerts[{i}]"
                if not isinstance(alert, dict):
                    errors.append(f"{prefix} must be a dict")
                    continue
                # Validate alert type
                alert_type = alert.get("type")
                if alert_type and alert_type not in VALID_ALERT_TYPES:
                    errors.append(
                        f"{prefix}.type '{alert_type}' not in {VALID_ALERT_TYPES}"
                    )
                # Validate severity
                severity = alert.get("severity")
                if severity and severity not in VALID_ALERT_SEVERITIES:
                    errors.append(
                        f"{prefix}.severity '{severity}' not in {VALID_ALERT_SEVERITIES}"
                    )
                # Validate required string fields exist
                for field in ["title", "description"]:
                    if field not in alert or not alert[field]:
                        errors.append(f"{prefix} missing required field '{field}'")

    # Validate verification object
    verif = data.get("verification", {})
    if not isinstance(verif, dict):
        errors.append("'verification' must be a dict")
    else:
        errors += _check_required(verif, [
            "total_claims", "claims_with_citations", "citation_coverage",
        ])

        total = verif.get("total_claims", 0)
        cited = verif.get("claims_with_citations", 0)
        coverage = verif.get("citation_coverage", 0)

        if isinstance(total, int) and isinstance(cited, int) and total > 0:
            if cited < total:
                errors.append(
                    f"Incomplete citations: {cited}/{total} claims have citations"
                )

        if isinstance(coverage, (int, float)) and coverage < 1.0:
            errors.append(
                f"Citation coverage is {coverage:.0%} — must be 100% or flagged REVIEW_NEEDED"
            )

    return errors


# ── Stage 4: Audit Output Validator ──────────────────────────────────────────

def validate_audit_output(data):
    """
    Validate Stage 4 (Auditor) output JSON.
    Critical check: no PHI in the audit entry.
    Returns list of error strings. Empty list = valid.
    """
    errors = []

    errors += _check_required(data, [
        "audit_id", "timestamp", "pipeline_run_id",
        "source_file_hash", "stages_completed", "compliance_status",
    ])
    errors += _check_type(data, "stages_completed", list)
    errors += _check_enum(data, "compliance_status", ["PASS", "REVIEW_NEEDED"])

    # Numeric fields validation
    for field in [
        "phi_identifiers_found", "phi_identifiers_redacted",
        "summary_claims_count",
    ]:
        if field in data and data[field] is not None:
            if not isinstance(data[field], int):
                errors.append(f"'{field}' must be an integer")

    for field in ["citation_coverage", "overall_confidence"]:
        if field in data and data[field] is not None:
            if not isinstance(data[field], (int, float)):
                errors.append(f"'{field}' must be a number")

    # PHI leak check — scan all string values for PHI patterns
    # Downgraded from HARD FAIL to warning: false positives from hashes/numbers
    # were killing valid pipelines. Log warnings but don't halt.
    phi_warnings = []
    _scan_dict_for_phi(data, "", phi_warnings)
    # phi_warnings are surfaced as validation warnings (non-fatal), not errors

    # Anomalies should be a list if present
    if "anomalies" in data:
        errors += _check_type(data, "anomalies", list)

    return errors


def _scan_dict_for_phi(obj, path, warnings):
    """Recursively scan a dict/list for PHI patterns in string values."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            _scan_dict_for_phi(value, f"{path}.{key}" if path else key, warnings)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            _scan_dict_for_phi(item, f"{path}[{i}]", warnings)
    elif isinstance(obj, str):
        for w in check_for_phi_leak(obj):
            warnings.append(f"at '{path}': {w}")


# ── Pipeline Runner Helpers ──────────────────────────────────────────────────

def build_stage_prompt(stage, input_json, schema_example=None):
    """
    Build a structured prompt that instructs the LLM to output valid JSON.
    The input is always a JSON string, and the output must be valid JSON.
    """
    json_input = json.dumps(input_json, indent=2) if isinstance(input_json, dict) else input_json

    prompt = f"## Input Data (JSON)\n```json\n{json_input}\n```\n\n"
    prompt += "## Output Requirements\n"
    prompt += "You MUST respond with ONLY a valid JSON object. No markdown, no explanation, "
    prompt += "no text before or after the JSON. Your entire response must be parseable by "
    prompt += "json.loads().\n\n"

    if schema_example:
        prompt += f"## Expected Output Schema\n```json\n{json.dumps(schema_example, indent=2)}\n```\n"

    return prompt


INGESTION_SCHEMA_EXAMPLE = {
    "document_id": "<sha256_hash>",
    "source_file": "<filename>",
    "ingestion_timestamp": "<ISO-8601>",
    "document_type": "<clinical_note|lab_report|imaging|discharge|referral|other>",
    "page_count": 0,
    "sections": [
        {
            "section_id": "sec_001",
            "section_type": "<demographics|encounter|diagnosis|medications|labs|notes|procedures|other>",
            "heading": "<section heading>",
            "content": "<structured text content>",
            "page_number": 1,
            "confidence": 0.95,
            "ocr_quality": "<high|medium|low|uncertain>",
        }
    ],
    "metadata": {
        "encounter_dates": [],
        "document_date": "<YYYY-MM-DD>",
        "facility_mentioned": False,
        "provider_mentioned": False,
    },
}

PRIVACY_SCHEMA_EXAMPLE = {
    "document_id": "<sha256_hash>",
    "privacy_timestamp": "<ISO-8601>",
    "sections": [
        {
            "section_id": "sec_001",
            "section_type": "<type>",
            "heading": "<heading>",
            "content": "<de-identified content with [REDACTED_*] tokens>",
            "redactions_applied": [
                {"type": "NAME", "count": 1, "positions": [0]},
            ],
        }
    ],
    "phi_summary": {
        "total_identifiers_found": 0,
        "total_redacted": 0,
        "by_type": {},
        "redaction_complete": True,
    },
}

SUMMARY_SCHEMA_EXAMPLE = {
    "document_id": "<sha256_hash>",
    "summary_timestamp": "<ISO-8601>",
    "case_type": "pi_general",
    "specialty_modules_triggered": [],
    "executive_strategy": "This case presents strong objective evidence of radiculopathy [see: Key Findings] supported by consistent treatment trajectory [see: Master Chronology]. The smoking gun documentation [see: Smoking Gun Quotes] and confirmed nerve root compression make this high-value. Recommend subpoenaing missing MRI [see: Discovery Deficiencies] and deposing treating neurologist.",
    "bluf": {
        "primary_diagnosis": "Single most impactful diagnosed condition with objective confirmation",
        "objective_proof": "Specific test/imaging that objectively confirms the diagnosis (e.g., MRI, EMG/NCV, positive Spurling's)",
        "future_outlook": "Surgical candidacy, permanent impairment rating, or long-term prognosis driving case value",
    },
    "litigation_cheat_sheet": {
        "wins": [
            {"leverage": "Favorable evidence or finding the attorney can use offensively", "source_ref": "sec_003:p2"},
        ],
        "risks": [
            {"target": "Defense attack vector or vulnerability the attorney must prepare for", "source_ref": "sec_005:p3"},
        ],
    },
    "summary": {
        "chief_complaint": {"text": "...", "citation": "sec_001:p1", "confidence": 0.9},
        "master_chronology": [
            {"date": "YYYY-MM-DD", "provider": "...", "clinical_finding": "...", "legal_leverage": "...", "citation": "sec_002:p2", "confidence": 0.9}
        ],
        "active_diagnoses": [
            {"diagnosis": "...", "citation": "sec_003:p3", "confidence": 0.9}
        ],
        "medications": [
            {"name": "...", "dosage": "...", "citation": "sec_004:p4", "confidence": 0.9}
        ],
        "key_findings": [
            {"finding": "...", "citation": "sec_005:p5", "confidence": 0.9}
        ],
        "smoking_gun_quotes": [
            {"quote": "...", "significance": "...", "citation": "sec_003:p2"}
        ],
        "contradictions_flagged": [
            {"contradiction": "...", "subjective": "...", "objective": "...", "legal_note": "...", "citations": []}
        ],
        "timeline_gaps": [],
        "discovery_deficiencies": [
            {"missing_item": "...", "evidence": "...", "citation": "sec_004:p3", "urgency": "HIGH|MEDIUM|LOW"}
        ],
        "overall_confidence": 0.9,
    },
    "pi_core_analysis": {
        "mechanism_of_injury": {"description": "...", "clinical_correlation": "...", "physics_match": True, "citation": "sec_001:p1"},
        "treatment_gaps": [{"gap_start": "YYYY-MM-DD", "gap_end": "YYYY-MM-DD", "days": 0, "defense_risk": "...", "neutralization": "...", "citation": "..."}],
        "pre_existing_conditions": [{"condition": "...", "new_vs_aggravation": "new|aggravation", "eggshell_plaintiff_note": "...", "citation": "sec_002:p1"}],
    },
    "specialty_insights": {
        "tbi": None,
        "spinal_orthopedic": None,
        "soft_tissue": None,
        "pain_management": None,
    },
    "billing_data": {
        "providers": [
            {
                "provider_name": "City Hospital ER",
                "dates_of_service": ["03/12/2024"],
                "services": [
                    {
                        "date": "03/12/2024",
                        "description": "Emergency Room Visit",
                        "cpt_code": "99285",
                        "amount": 8450.00,
                        "citation": "sec_002:p1"
                    }
                ],
                "subtotal": 8450.00
            }
        ],
        "total_past_medical": 0.00,
        "total_future_medical_estimate": 0.00,
        "future_care_basis": "",
        "total_combined": 0.00,
        "notes": ""
    },
    "alerts": [
        {
            "type": "treatment_gap|missing_provider|pre_existing|inconsistency|compliance_issue|prior_injury|medication_change",
            "severity": "high|medium|low",
            "title": "45-Day Physical Therapy Gap",
            "description": "No physical therapy visits between 04/15/2024 and 05/30/2024. This 45-day gap in treatment may indicate non-compliance or symptom resolution, which defense counsel will likely argue reduces case value.",
            "impact_estimate": "May reduce settlement value by 15-20%",
            "recommended_action": "Request client explanation for gap. Consider obtaining PT records from this period if treatment occurred elsewhere.",
            "citation": "sec_003:p7",
            "date_range": "04/15/2024 - 05/30/2024"
        }
    ],
    "trial_strategy_note": "Strongest evidence: EMG/NCV confirms objective radiculopathy [see: Key Findings] correlating with clinical complaints [see: Master Chronology]. Failed conservative care strengthens surgical candidacy. Defense gap argument neutralized [see: PI Core]. Recommend deposing treating neurologist and subpoenaing missing lumbar MRI [see: Discovery Deficiencies].",
    "verification": {
        "total_claims": 0,
        "claims_with_citations": 0,
        "citation_coverage": 1.0,
        "low_confidence_claims": 0,
        "needs_verification": 0,
        "contradictions_found": 0,
        "discovery_gaps": 0,
    },
}

AUDIT_SCHEMA_EXAMPLE = {
    "audit_id": "<uuid>",
    "timestamp": "<ISO-8601>",
    "pipeline_run_id": "<task_id>",
    "source_file_hash": "<sha256>",
    "stages_completed": ["ingestion", "privacy", "summarizer", "auditor"],
    "phi_identifiers_found": 0,
    "phi_identifiers_redacted": 0,
    "summary_claims_count": 0,
    "citation_coverage": 1.0,
    "overall_confidence": 0.0,
    "compliance_status": "PASS",
    "anomalies": [],
}
