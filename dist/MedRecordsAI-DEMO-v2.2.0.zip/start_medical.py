"""
start_medical.py -- One-click launcher for the MedRecords AI system.

Starts all three medical services:
  1. Medical Web UI (Flask)       — http://localhost:8080
  2. Summarization Watcher        — monitors vault/incoming/
  3. Retrieval Bot (optional)     — email-based record retrieval

Usage:
  python start_medical.py              # Start all services
  python start_medical.py --ui-only    # Start only the web UI
  python start_medical.py --no-email   # Skip retrieval bot (no email config)
  python start_medical.py --stop       # Stop all running services
  python start_medical.py --status     # Show service status
"""

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent
PID_DIR = BASE_DIR / "logs"
PID_FILE = PID_DIR / "medical_services.json"

SERVICES = {
    "medical-ui": {
        "script": "medical_app.py",
        "label": "Medical Web UI",
        "required": True,
    },
    "summarization-watcher": {
        "script": "summarization_watcher.py",
        "label": "Summarization Watcher",
        "required": True,
    },
    "retrieval-bot": {
        "script": "retrieval_bot.py",
        "label": "Records Retrieval Bot",
        "required": False,
    },
}


def load_pids():
    if PID_FILE.exists():
        try:
            return json.loads(PID_FILE.read_text())
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def save_pids(pids):
    PID_DIR.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(json.dumps(pids, indent=2))


def is_process_running(pid):
    """Check if a process with the given PID is still running."""
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                capture_output=True, text=True,
            )
            return str(pid) in result.stdout
        else:
            os.kill(pid, 0)
            return True
    except (OSError, subprocess.SubprocessError):
        return False


def start_service(name, config):
    """Start a service in the background."""
    script = BASE_DIR / config["script"]
    if not script.exists():
        print(f"  [SKIP] {config['label']}: {config['script']} not found")
        return None

    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{name}.log"
    err_file = log_dir / f"{name}-error.log"

    with open(log_file, "a") as stdout_f, open(err_file, "a") as stderr_f:
        if sys.platform == "win32":
            # Windows: use CREATE_NEW_PROCESS_GROUP
            proc = subprocess.Popen(
                [sys.executable, str(script)],
                cwd=str(BASE_DIR),
                stdout=stdout_f,
                stderr=stderr_f,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
            )
        else:
            proc = subprocess.Popen(
                [sys.executable, str(script)],
                cwd=str(BASE_DIR),
                stdout=stdout_f,
                stderr=stderr_f,
                start_new_session=True,
            )

    print(f"  [START] {config['label']:30s} PID: {proc.pid}")
    return proc.pid


def stop_service(name, pid):
    """Stop a service by PID."""
    if not is_process_running(pid):
        print(f"  [DEAD]  {name:30s} PID {pid} (already stopped)")
        return

    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                         capture_output=True, timeout=10)
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(2)
            if is_process_running(pid):
                os.kill(pid, signal.SIGKILL)
        print(f"  [STOP]  {name:30s} PID {pid}")
    except Exception as e:
        print(f"  [ERROR] {name:30s} Could not stop PID {pid}: {e}")


def check_email_configured():
    """Check if SMTP/IMAP credentials are configured."""
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
    smtp_host = os.getenv("SMTP_HOST", "")
    return smtp_host and "example.com" not in smtp_host


def _get_configured_port() -> int:
    """Read the configured port from config.yaml, defaulting to 8080."""
    try:
        import yaml
        config_path = BASE_DIR / "config.yaml"
        if not config_path.exists():
            config_path = BASE_DIR / "config.yaml.example"
        if config_path.exists():
            with open(config_path) as f:
                cfg = yaml.safe_load(f) or {}
            return cfg.get("web_ui", {}).get("port", 8080)
    except Exception:
        pass
    return 8080


def _kill_zombie_on_port(port: int):
    """Kill any process holding the configured port (Windows only).

    Handles PM2-managed processes by stopping them via `pm2 stop` first
    (plain taskkill doesn't work because PM2 auto-restarts killed processes).
    """
    if sys.platform != "win32":
        return
    try:
        result = subprocess.run(
            ["netstat", "-aon"],
            capture_output=True, text=True, timeout=10,
        )
        for line in result.stdout.splitlines():
            if f":{port}" in line and "LISTENING" in line:
                parts = line.split()
                try:
                    pid = int(parts[-1])
                except (ValueError, IndexError):
                    continue

                # Try PM2 stop first (handles auto-restart problem)
                # Note: pm2 is a .cmd on Windows, needs shell=True
                # Note: text=True breaks on Windows (cp1252 can't decode ANSI),
                #       so we read bytes and decode as utf-8 with errors='replace'
                pm2_stopped = False
                try:
                    pm2_result = subprocess.run(
                        "pm2 jlist",
                        capture_output=True, timeout=10,
                        shell=True,
                    )
                    pm2_out = pm2_result.stdout.decode("utf-8", errors="replace") if pm2_result.stdout else ""
                    if pm2_result.returncode == 0 and pm2_out.strip():
                        import json as _json
                        pm2_procs = _json.loads(pm2_out)
                        for proc in pm2_procs:
                            if proc.get("pid") == pid:
                                pm2_name = proc.get("name", "")
                                print(f"  [WARN] Stopping PM2 process '{pm2_name}' on port {port} (PID {pid})")
                                subprocess.run(
                                    f"pm2 stop {pm2_name}",
                                    capture_output=True, timeout=10,
                                    shell=True,
                                )
                                pm2_stopped = True
                                time.sleep(2)
                                break
                except Exception:
                    pass

                # Fallback: direct kill if not PM2-managed
                if not pm2_stopped:
                    print(f"  [WARN] Killing process on port {port} (PID {pid})")
                    subprocess.run(
                        ["taskkill", "/F", "/PID", str(pid)],
                        capture_output=True, timeout=10,
                    )
                    time.sleep(1)
    except Exception:
        pass


def cmd_start(args):
    """Start services."""
    # Check for existing services
    pids = load_pids()
    running = {name: pid for name, pid in pids.items() if is_process_running(pid)}
    if running:
        print("\nServices already running:")
        for name, pid in running.items():
            label = SERVICES.get(name, {}).get("label", name)
            print(f"  {label:30s} PID: {pid}")
        print("\nUse --stop first, or --status to check.")
        return

    print("\nStarting MedRecords AI...\n")

    # Kill any zombie process holding the port (common on Windows)
    port = _get_configured_port()
    _kill_zombie_on_port(port)

    # Determine which services to start
    try:
        skip_email = args.no_email or not check_email_configured()
    except Exception:
        skip_email = True
    if skip_email and not args.no_email:
        print("  [INFO] Email not configured in .env — skipping retrieval bot")
        print("         (Configure SMTP_*/IMAP_* in .env to enable)\n")

    new_pids = {}
    for name, config in SERVICES.items():
        if args.ui_only and name != "medical-ui":
            continue
        if name == "retrieval-bot" and skip_email:
            continue
        pid = start_service(name, config)
        if pid:
            new_pids[name] = pid

    save_pids(new_pids)

    # Wait a moment and verify
    time.sleep(3)
    print()
    all_ok = True
    ui_ok = True
    for name, pid in new_pids.items():
        label = SERVICES[name]["label"]
        if is_process_running(pid):
            print(f"  [OK]    {label:30s} running (PID {pid})")
        else:
            print(f"  [FAIL]  {label:30s} died immediately — check logs/{name}-error.log")
            all_ok = False
            if name == "medical-ui":
                ui_ok = False

    if not ui_ok:
        print(f"\n  [ERROR] Medical Web UI failed to start.")
        print(f"  Check: {BASE_DIR / 'logs' / 'medical-ui-error.log'}")
        sys.exit(1)

    print(f"\n  MedRecords AI is running!")
    print(f"  Open: http://localhost:{port}")
    print(f"\n  Logs: {BASE_DIR / 'logs'}")
    print(f"  Stop: python start_medical.py --stop")

    # Auto-open browser if requested
    if args.auto_open:
        try:
            import webbrowser
            time.sleep(1)
            webbrowser.open(f"http://localhost:{port}")
            print(f"\n  Browser opened automatically.")
        except Exception:
            pass


def cmd_stop(args):
    """Stop all services."""
    print("\nStopping MedRecords AI...\n")
    pids = load_pids()
    if not pids:
        print("  No services recorded. Nothing to stop.")
        return

    for name, pid in pids.items():
        stop_service(name, pid)

    save_pids({})
    print("\n  All services stopped.")


def cmd_status(args):
    """Show service status."""
    print("\nMedRecords AI - Service Status\n")
    pids = load_pids()

    if not pids:
        print("  No services recorded. Use --start or run: python start_medical.py")
        return

    for name, pid in pids.items():
        label = SERVICES.get(name, {}).get("label", name)
        running = is_process_running(pid)
        status = "\033[92mRUNNING\033[0m" if running else "\033[91mSTOPPED\033[0m"
        print(f"  {label:30s} PID: {pid:6d}  {status}")


def main():
    parser = argparse.ArgumentParser(
        description="MedRecords AI - Service Launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--stop", action="store_true", help="Stop all running services")
    parser.add_argument("--status", action="store_true", help="Show service status")
    parser.add_argument("--ui-only", action="store_true", help="Start only the web UI")
    parser.add_argument("--no-email", action="store_true", help="Skip retrieval bot")
    parser.add_argument("--auto-open", action="store_true", help="Open browser after starting")
    args = parser.parse_args()

    if args.stop:
        cmd_stop(args)
    elif args.status:
        cmd_status(args)
    else:
        cmd_start(args)


if __name__ == "__main__":
    main()
