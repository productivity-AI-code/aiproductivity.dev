"""
licensing.py -- Free trial & license key system for MedRecords AI.

Trial mode: 3 free cases. After that, output is watermarked and user is prompted to purchase.
License keys are HMAC-SHA256 based, validated offline (no server needed).

Tiers:
  - trial: 3 free cases, watermarked output after limit
  - core:  unlimited cases, no watermark
  - pro:   everything in core + demand_package, case_valuation, billing_extractor
"""

import base64
import hashlib
import hmac
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

# ── Constants ────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent
LICENSE_STATE_PATH = BASE_DIR / "vault" / ".license_state.json"
HMAC_SECRET = os.getenv("LICENSE_HMAC_SECRET", "MEDRECORDS_LK_2024_s3cr3t_k3y").encode("utf-8")
FREE_TRIAL_LIMIT = 3
DEMO_EXPIRY_DAYS = 14
KEY_PREFIX = "MRA"

# Features gated behind the "pro" tier (expanded list)
PRO_ONLY_FEATURES = {"demand_package", "case_valuation", "billing_extractor", "negligence_detection", "task_generation", "injury_visualization"}

# Valid tiers that can be encoded into a license key
VALID_TIERS = {"core", "pro"}


# ── License State Persistence ────────────────────────────────────────────────

def _ensure_vault():
    """Make sure the vault directory exists."""
    LICENSE_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)


def _read_state() -> dict:
    """Read the license state file, returning defaults if missing/corrupt."""
    default = {
        "trial_cases_used": 0,
        "license_key": None,
        "tier": "trial",
        "activated_at": None,
        "install_date": None,
        "is_demo": False,
    }
    if not LICENSE_STATE_PATH.exists():
        return default
    try:
        with open(LICENSE_STATE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Merge with defaults to handle missing keys
        for k, v in default.items():
            data.setdefault(k, v)
        return data
    except (json.JSONDecodeError, OSError):
        return default


def _write_state(state: dict):
    """Persist license state to disk."""
    _ensure_vault()
    with open(LICENSE_STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


# ── HMAC Key Generation & Validation ────────────────────────────────────────

def _hmac_sign(payload: str) -> str:
    """Produce a truncated HMAC-SHA256 signature (10 hex chars) for a payload."""
    sig = hmac.new(HMAC_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return sig[:10].upper()


def _encode_segment(data: str) -> str:
    """Base32-encode a short string and strip padding, uppercase."""
    encoded = base64.b32encode(data.encode("utf-8")).decode("ascii").rstrip("=")
    return encoded.upper()


def _decode_segment(segment: str) -> str:
    """Reverse of _encode_segment."""
    # Re-add base32 padding
    padded = segment + "=" * ((8 - len(segment) % 8) % 8)
    try:
        return base64.b32decode(padded.upper()).decode("utf-8")
    except Exception:
        return ""


def validate_license_key(key: str) -> dict:
    """
    Validate a license key.

    Returns:
      {"valid": True, "tier": "pro"|"core", "email_hash": "..."}
    or:
      {"valid": False}
    """
    if not key or not isinstance(key, str):
        return {"valid": False}

    key = key.strip().upper()

    # Check format: MRA-XXXXX-XXXXX-XXXXX-XXXXX
    pattern = r"^MRA-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})$"
    match = re.match(pattern, key)
    if not match:
        return {"valid": False}

    seg1, seg2, tier_seg, sig_seg = match.groups()
    email_hash = seg1 + seg2

    # Decode the tier segment
    tier_raw = _decode_segment(tier_seg.rstrip("X"))
    if tier_raw not in VALID_TIERS:
        # Try direct match for padded encodings
        for t in VALID_TIERS:
            t_encoded = _encode_segment(t)[:5].ljust(5, "X")
            if t_encoded == tier_seg:
                tier_raw = t
                break
        if tier_raw not in VALID_TIERS:
            return {"valid": False}

    # We cannot recover the original email from the hash, so we verify
    # the HMAC by trying known structure. Since we only have the hash,
    # we use an alternative verification: the key must have been generated
    # by our generate function. We verify the HMAC of email_hash + tier.
    payload_check = f"hash:{email_hash}|{tier_raw}"
    # Also check the original HMAC approach -- try with the hash-based payload
    expected_sig = _hmac_sign(payload_check)[:5]

    if sig_seg != expected_sig:
        # The key was generated with the actual email, but we can't verify
        # without knowing the email. So we use a secondary HMAC check:
        # sign(seg1 + seg2 + tier_seg) and check it matches sig_seg
        alt_payload = f"{seg1}{seg2}{tier_seg}"
        alt_sig = _hmac_sign(alt_payload)[:5]
        if sig_seg != alt_sig:
            return {"valid": False}

    return {"valid": True, "tier": tier_raw, "email_hash": email_hash}


def generate_license_key(email: str, tier: str) -> str:
    """
    Generate a license key for a given email and tier.

    Format: MRA-XXXXX-XXXXX-XXXXX-XXXXX
    Structure:
      - Segment 1-2: SHA256(email)[:10] split into two 5-char pieces
      - Segment 3: base32-encoded tier, padded to 5 chars
      - Segment 4: HMAC(seg1+seg2+tier_seg)[:5]

    This function is for internal use (key generation), not shipped to end users.
    """
    if tier not in VALID_TIERS:
        raise ValueError(f"Invalid tier: {tier}. Must be one of {VALID_TIERS}")

    email = email.strip().lower()

    # Create a deterministic short hash of the email (10 chars)
    email_hash = hashlib.sha256(email.encode("utf-8")).hexdigest()[:10].upper()

    # Encode the tier
    tier_encoded = _encode_segment(tier)
    tier_seg = tier_encoded[:5].ljust(5, "X")

    # Split email hash into two 5-char segments
    seg1 = email_hash[:5]
    seg2 = email_hash[5:10]

    # HMAC signature: sign the combination of the other three segments
    alt_payload = f"{seg1}{seg2}{tier_seg}"
    sig = _hmac_sign(alt_payload)
    sig_seg = sig[:5]

    key = f"{KEY_PREFIX}-{seg1}-{seg2}-{tier_seg}-{sig_seg}"
    return key


# ── Public Helper Functions ──────────────────────────────────────────────────

def get_license_state() -> dict:
    """
    Return the current license state.

    Returns dict with keys:
      - trial_cases_used: int
      - license_key: str|None
      - tier: "trial"|"core"|"pro"
      - activated_at: ISO datetime string|None
    """
    return _read_state()


def increment_trial_usage():
    """Bump the trial case counter by 1."""
    state = _read_state()
    state["trial_cases_used"] = state.get("trial_cases_used", 0) + 1
    _write_state(state)


def activate_license(key: str) -> dict:
    """
    Validate and save a license key.

    Returns:
      {"valid": True, "tier": "core"|"pro"} on success
      {"valid": False} on failure
    """
    result = validate_license_key(key)
    if not result.get("valid"):
        return {"valid": False}

    state = _read_state()
    state["license_key"] = key.strip().upper()
    state["tier"] = result["tier"]
    state["activated_at"] = datetime.now(timezone.utc).isoformat()
    _write_state(state)

    return {"valid": True, "tier": result["tier"]}


def is_feature_allowed(feature_name: str) -> bool:
    """
    Check if a feature is allowed under the current license tier.

    Pro-only features: demand_package, case_valuation, billing_extractor
    Core features: everything except pro-only
    Trial: same as core but limited to FREE_TRIAL_LIMIT cases
    """
    state = _read_state()
    tier = state.get("tier", "trial")

    if feature_name in PRO_ONLY_FEATURES:
        return tier == "pro"

    # All other features are available in core and pro
    # Trial users get access to non-pro features (within their case limit)
    return True


def get_watermark_text() -> str | None:
    """
    Return watermark text for trial users, or None for licensed users.

    Watermark is applied after the free trial limit is exceeded.
    """
    state = _read_state()
    tier = state.get("tier", "trial")

    if tier in ("core", "pro"):
        return None

    # Trial user -- watermark only if they've exceeded the limit
    used = state.get("trial_cases_used", 0)
    if used >= FREE_TRIAL_LIMIT:
        return (
            "--- TRIAL VERSION ---\n"
            "This output was generated with MedRecords AI Free Trial.\n"
            "Purchase a license at https://aiproductivity.dev/pricing to remove this watermark.\n"
            "--- TRIAL VERSION ---"
        )
    return None


def get_trial_remaining() -> int:
    """Return the number of free trial cases remaining."""
    state = _read_state()
    tier = state.get("tier", "trial")

    if tier in ("core", "pro"):
        return 0  # Not on trial

    used = state.get("trial_cases_used", 0)
    return max(0, FREE_TRIAL_LIMIT - used)


def is_demo_build() -> bool:
    """Check if this is a demo build by looking for the .demo_build marker file."""
    return (BASE_DIR / ".demo_build").exists()


def record_install_date():
    """Record the demo installation date (called once during first setup)."""
    state = _read_state()
    if not state.get("install_date"):
        state["install_date"] = datetime.now(timezone.utc).isoformat()
        state["is_demo"] = True
        _write_state(state)


def check_demo_expiration() -> dict:
    """Check if the demo has expired.
    Returns {"expired": bool, "days_remaining": int, "install_date": str|None}
    """
    state = _read_state()
    install_str = state.get("install_date")
    if not install_str:
        return {"expired": False, "days_remaining": DEMO_EXPIRY_DAYS, "install_date": None}

    install_date = datetime.fromisoformat(install_str)
    elapsed = (datetime.now(timezone.utc) - install_date).days
    remaining = max(0, DEMO_EXPIRY_DAYS - elapsed)
    return {
        "expired": remaining <= 0,
        "days_remaining": remaining,
        "install_date": install_str,
    }
