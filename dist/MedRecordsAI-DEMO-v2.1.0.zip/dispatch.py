"""
dispatch.py — Routes tasks to local Ollama agents via HTTP API.

Usage:
  python dispatch.py --agent aria --task "Analyze requirements" --context "Client: bakery"
  python dispatch.py --agent forge --task "Build chatbot" --context-file spec.md
  python dispatch.py --status
  python dispatch.py --list
"""

import argparse
import copy
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
import yaml
from dotenv import load_dotenv
from error_tracker import record_error, inject_into_prompt

load_dotenv()

BASE_DIR = Path(__file__).parent


def load_config():
    config_path = BASE_DIR / "config.yaml"
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


def make_task_id(agent_name):
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"{ts}-{agent_name}"


def _tasks_lock_path(config):
    return BASE_DIR / config["paths"]["tasks_db"] + ".lock"


def load_tasks_db(config):
    db_file = BASE_DIR / config["paths"]["tasks_db"]
    if not db_file.exists():
        return {}
    try:
        with open(db_file, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        # Attempt recovery: extract first valid JSON object
        print(f"  WARNING: tasks.json corrupted ({e}), attempting recovery...")
        try:
            import json as _json
            with open(db_file, encoding="utf-8") as f:
                content = f.read()
            decoder = _json.JSONDecoder()
            obj, _ = decoder.raw_decode(content)
            if isinstance(obj, dict):
                # Write back the repaired version
                save_tasks_db(config, obj)
                print(f"  Recovered {len(obj)} tasks from corrupted file.")
                return obj
        except Exception:
            pass
        # Last resort: return empty and back up corrupted file
        backup = db_file.with_suffix(".corrupted.bak")
        import shutil
        shutil.copy2(str(db_file), str(backup))
        print(f"  Could not recover. Backed up to {backup.name}, starting fresh.")
        return {}


def save_tasks_db(config, tasks):
    db_file = BASE_DIR / config["paths"]["tasks_db"]
    lock_file = db_file.with_suffix(".lock")
    tmp_file = db_file.with_suffix(".tmp")
    # Simple file-based locking to prevent concurrent write corruption
    max_wait = 10
    waited = 0
    while lock_file.exists() and waited < max_wait:
        time.sleep(0.1)
        waited += 0.1
    try:
        lock_file.write_text(str(os.getpid()), encoding="utf-8")
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2)
        tmp_file.replace(db_file)
    finally:
        try:
            lock_file.unlink(missing_ok=True)
        except Exception:
            pass


def load_agent_prompt(config, agent_name):
    prompt_file = BASE_DIR / config["paths"]["agents_dir"] / agent_name / "prompt.md"
    if prompt_file.exists():
        return prompt_file.read_text(encoding="utf-8")
    return f"You are {agent_name}, an AI assistant."


# ── Ollama health helpers ─────────────────────────────────────────────────────

def _wait_for_ollama(endpoint, max_wait=120):
    """
    Poll Ollama /api/tags until it responds or max_wait seconds elapse.
    Returns True if healthy, False if unreachable after max_wait seconds.
    """
    url = f"{endpoint}/api/tags"
    elapsed = 0
    interval = 5
    while elapsed < max_wait:
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                if elapsed > 0:
                    print(f"  Ollama is ready (waited {elapsed}s).")
                return True
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            pass
        print(f"  Ollama not ready, retrying in {interval}s... ({elapsed}/{max_wait}s elapsed)")
        time.sleep(interval)
        elapsed += interval
    return False


def _warmup_model(model, endpoint, timeout=60):
    """
    Trigger model loading via /api/pull (no inference) so the model is in memory
    before the real task. Falls back silently if /api/pull is unavailable.
    Non-fatal — never blocks the real task dispatch.
    """
    # Check if model is already loaded — skip warmup if so
    try:
        ps = requests.get(f"{endpoint}/api/ps", timeout=5).json()
        loaded = [m["name"] for m in ps.get("models", [])]
        if model in loaded:
            print(f"  {model} already loaded — skipping warmup.")
            return
    except Exception:
        pass

    # Model not loaded yet: trigger load via /api/show (fast metadata-only call)
    # This causes Ollama to load model weights without starting inference.
    print(f"  Loading {model} into memory...", end=" ", flush=True)
    try:
        r = requests.post(
            f"{endpoint}/api/show",
            json={"name": model},
            timeout=timeout,
        )
        r.raise_for_status()
        print("ready.")
    except Exception as e:
        print(f"warmup skipped ({e}).")


def _trim_context(messages, ratio=0.60):
    """
    Return a copy of messages with the ## Context section of the user turn trimmed to `ratio`.
    Trims only the context portion — never the task description or system prompt.
    """
    trimmed = copy.deepcopy(messages)
    for msg in trimmed:
        if msg["role"] == "user":
            content = msg["content"]
            marker = "\n\n## Context\n"
            if marker in content:
                task_part, context_part = content.split(marker, 1)
                max_len = int(len(context_part) * ratio)
                trimmed_context = context_part[:max_len]
                if max_len < len(context_part):
                    trimmed_context += "\n\n[Context trimmed due to timeout — see staging files for full details]"
                msg["content"] = task_part + marker + trimmed_context
            else:
                max_len = int(len(content) * ratio)
                msg["content"] = content[:max_len] + "\n\n[Content trimmed due to timeout]"
            break
    return trimmed


# ── Core Ollama call ──────────────────────────────────────────────────────────

def call_ollama(model, messages, endpoint, timeout, retries):
    """Call Ollama chat API with smart retry: trims context on timeout."""
    url = f"{endpoint}/api/chat"
    current_messages = messages

    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(
                url,
                json={"model": model, "messages": current_messages, "stream": False},
                timeout=timeout,
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]

        except requests.exceptions.Timeout:
            if attempt == retries:
                raise RuntimeError(f"Ollama timed out after {timeout}s ({retries} attempts)")
            # Smart retry: trim context before next attempt
            original_len = sum(len(m["content"]) for m in current_messages)
            current_messages = _trim_context(current_messages, ratio=0.60)
            trimmed_len = sum(len(m["content"]) for m in current_messages)
            print(f"  Timeout on attempt {attempt}/{retries}. "
                  f"Context trimmed {original_len} -> {trimmed_len} chars. Retrying in 5s...")
            time.sleep(5)

        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {endpoint}. Is Ollama running?"
            )
        except requests.exceptions.RequestException as e:
            if attempt == retries:
                raise RuntimeError(f"Ollama request failed: {e}")
            print(f"  Error on attempt {attempt}/{retries}: {e}, retrying in 5s...")
            time.sleep(5)


# ── Claude API call ───────────────────────────────────────────────────────────

def call_claude(model, messages, config, timeout_override=None, max_tokens_override=None):
    """Call Anthropic Claude API. Messages follow OpenAI-style role format."""
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set in environment")

    claude_cfg = config.get("claude", {})
    max_tokens = max_tokens_override or claude_cfg.get("max_tokens", 16384)
    timeout = timeout_override or claude_cfg.get("timeout", 180)
    retries = claude_cfg.get("retries", 2)

    # Separate system prompt from conversation messages
    system_text = ""
    conversation = []
    for msg in messages:
        if msg["role"] == "system":
            system_text += msg["content"] + "\n"
        else:
            conversation.append({"role": msg["role"], "content": msg["content"]})

    # Ensure conversation starts with a user message (Claude API requirement)
    if not conversation or conversation[0]["role"] != "user":
        conversation.insert(0, {"role": "user", "content": "Please proceed with the task."})

    for attempt in range(1, retries + 1):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system_text.strip() if system_text.strip() else anthropic.NOT_GIVEN,
                messages=conversation,
                timeout=timeout,
            )
            # Extract text from response
            text_parts = []
            for block in response.content:
                if block.type == "text":
                    text_parts.append(block.text)
            return "\n".join(text_parts)

        except Exception as e:
            if attempt == retries:
                raise RuntimeError(f"Claude API failed after {retries} attempts: {e}")
            print(f"  Claude API error on attempt {attempt}/{retries}: {e}, retrying in 3s...")
            time.sleep(3)


# ── Claude Vision API call ───────────────────────────────────────────────────

def call_claude_vision(model, system_prompt, text_prompt, images, config,
                       timeout_override=None, max_tokens_override=None):
    """Call Claude API with multi-modal content (images + text).

    Args:
        model: Claude model ID (e.g. "claude-haiku-4-5-20251001")
        system_prompt: System prompt string
        text_prompt: Text prompt to accompany the images
        images: List of (image_bytes, media_type) tuples.
                media_type: "image/png", "image/jpeg", "image/tiff", "image/webp"
        config: Full config dict
        timeout_override: Optional timeout in seconds
        max_tokens_override: Optional max tokens

    Returns:
        Response text from Claude
    """
    import base64

    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set in environment")

    claude_cfg = config.get("claude", {})
    max_tokens = max_tokens_override or claude_cfg.get("max_tokens", 16384)
    timeout = timeout_override or claude_cfg.get("timeout", 180)
    retries = claude_cfg.get("retries", 2)

    # Build multi-modal content blocks
    content_blocks = []
    for img_bytes, media_type in images:
        content_blocks.append({
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": media_type,
                "data": base64.b64encode(img_bytes).decode("ascii"),
            },
        })
    content_blocks.append({"type": "text", "text": text_prompt})

    conversation = [{"role": "user", "content": content_blocks}]

    for attempt in range(1, retries + 1):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system_prompt if system_prompt else anthropic.NOT_GIVEN,
                messages=conversation,
                timeout=timeout,
            )
            text_parts = []
            for block in response.content:
                if block.type == "text":
                    text_parts.append(block.text)
            return "\n".join(text_parts)

        except Exception as e:
            if attempt == retries:
                raise RuntimeError(f"Claude Vision API failed after {retries} attempts: {e}")
            print(f"  Claude Vision error attempt {attempt}/{retries}: {e}, retrying in 3s...")
            time.sleep(3)


def dispatch(agent_name, task, context, config):
    agents = config["agents"]
    # Also check medical_agents section for pipeline agents
    medical_agents = config.get("medical_agents", {})
    all_agents = {**agents, **medical_agents}
    if agent_name not in all_agents:
        print(f"ERROR: Unknown agent '{agent_name}'. Available: {', '.join(all_agents)}")
        sys.exit(1)

    agent_cfg = all_agents[agent_name]

    # ── Determine LLM backend ────────────────────────────────────────────────
    # Per-agent override > per-section override > global default
    backend = agent_cfg.get("backend") or config.get("llm_backend", "ollama")

    if backend == "claude":
        claude_cfg = config.get("claude", {})
        model = agent_cfg.get("claude_model") or claude_cfg.get("model", "claude-sonnet-4-6")
    else:
        model = agent_cfg["model"]
        endpoint = config["ollama"]["endpoint"]

        # ── Ollama health pre-check ───────────────────────────────────────────
        max_wait = config.get("watchdog", {}).get("ollama_health_max_wait", 120)
        if not _wait_for_ollama(endpoint, max_wait=max_wait):
            print(f"[FATAL] Ollama is not reachable at {endpoint} after {max_wait}s. Aborting.")
            sys.exit(1)

    task_id = make_task_id(agent_name)

    # Prepare staging output directory
    staging_dir = BASE_DIR / config["paths"]["staging"] / task_id
    staging_dir.mkdir(parents=True, exist_ok=True)
    output_file = staging_dir / "output.txt"

    # Build message history — inject lessons from past errors
    system_prompt = inject_into_prompt(agent_name, load_agent_prompt(config, agent_name))
    user_content = f"## Task\n{task}"
    if context:
        user_content += f"\n\n## Context\n{context}"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    # Record task in DB
    tasks = load_tasks_db(config)
    tasks[task_id] = {
        "task_id": task_id,
        "agent": agent_name,
        "model": model,
        "role": agent_cfg["role"],
        "task": task,
        "context": context,
        "status": "queued",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "started_at": None,
        "completed_at": None,
        "output_path": str(output_file),
        "error": None,
    }
    save_tasks_db(config, tasks)

    timeout_display = config.get("claude", {}).get("timeout", 120) if backend == "claude" else config["ollama"]["timeout"]
    print(f"\n[DISPATCHED]")
    print(f"  Task ID : {task_id}")
    print(f"  Agent   : {agent_name} ({agent_cfg['role']})")
    print(f"  Backend : {backend}")
    print(f"  Model   : {model}")
    print(f"  Task    : {task[:80]}")
    print(f"\nRunning... (timeout={timeout_display}s)\n")

    # Update status to running
    tasks[task_id]["status"] = "running"
    tasks[task_id]["started_at"] = datetime.now(timezone.utc).isoformat()
    save_tasks_db(config, tasks)

    try:
        is_combined = os.getenv("COMBINED_PIPELINE") == "1"
        if backend == "claude":
            claude_cfg = config.get("claude", {})
            override_timeout = claude_cfg.get("combined_timeout") if is_combined else None
            override_tokens = claude_cfg.get("combined_max_tokens") if is_combined else None
            output = call_claude(
                model=model,
                messages=messages,
                config=config,
                timeout_override=override_timeout,
                max_tokens_override=override_tokens,
            )
        else:
            output = call_ollama(
                model=model,
                messages=messages,
                endpoint=endpoint,
                timeout=config["ollama"]["timeout"],
                retries=config["ollama"]["retries"],
            )

        output_file.write_text(output, encoding="utf-8")

        tasks = load_tasks_db(config)
        tasks[task_id]["status"] = "completed"
        tasks[task_id]["completed_at"] = datetime.now(timezone.utc).isoformat()
        save_tasks_db(config, tasks)

        print(f"[COMPLETED] Output saved to: {output_file}")
        print(f"\n--- Output Preview ---\n{output[:400]}\n")

    except Exception as e:
        tasks = load_tasks_db(config)
        tasks[task_id]["status"] = "failed"
        tasks[task_id]["error"] = str(e)
        tasks[task_id]["completed_at"] = datetime.now(timezone.utc).isoformat()
        save_tasks_db(config, tasks)
        output_file.write_text(f"ERROR: {e}", encoding="utf-8")
        record_error(task_id, agent_name, str(e), task, model)
        print(f"[FAILED] {e}")
        sys.exit(1)

    return task_id


def show_status(config):
    tasks = load_tasks_db(config)
    if not tasks:
        print("No tasks found.")
        return
    print(f"\n{'Task ID':<30} {'Agent':<8} {'Status':<12} {'Created':<22} {'Task'}")
    print("-" * 100)
    for t in sorted(tasks.values(), key=lambda x: x["created_at"]):
        print(
            f"{t['task_id']:<30} {t['agent']:<8} {t['status']:<12} "
            f"{t['created_at'][:19]:<22} {t['task'][:40]}"
        )
    print()


def list_agents(config):
    print(f"\n{'Agent':<8} {'Role':<25} {'Model'}")
    print("-" * 60)
    for name, cfg in config["agents"].items():
        print(f"{name:<8} {cfg['role']:<25} {cfg['model']}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Dispatch tasks to local Ollama agents.")
    parser.add_argument("--agent", help="Agent name (aria, forge, nova, scout, sage)")
    parser.add_argument("--task", help="Task description")
    parser.add_argument("--task-file", help="Path to a file containing the task description")
    parser.add_argument("--context", default="", help="Additional context or spec text")
    parser.add_argument("--context-file", help="Path to a file containing context")
    parser.add_argument("--status", action="store_true", help="Show all task statuses")
    parser.add_argument("--list", action="store_true", help="List available agents")
    args = parser.parse_args()

    config = load_config()

    if args.list:
        list_agents(config)
        return

    if args.status:
        show_status(config)
        return

    # Load task from --task-file if provided (avoids Windows CLI length limits)
    task = args.task
    if args.task_file:
        tf = Path(args.task_file).resolve()
        try:
            tf.relative_to(BASE_DIR.resolve())
        except ValueError:
            print(f"ERROR: --task-file must be within the project directory ({BASE_DIR})")
            sys.exit(1)
        with open(tf, encoding="utf-8") as f:
            task = f.read()

    if not args.agent or not task:
        parser.print_help()
        sys.exit(1)

    context = args.context
    if args.context_file:
        cf = Path(args.context_file).resolve()
        # Reject paths that escape the project directory
        try:
            cf.relative_to(BASE_DIR.resolve())
        except ValueError:
            print(f"ERROR: --context-file must be within the project directory ({BASE_DIR})")
            sys.exit(1)
        with open(cf, encoding="utf-8") as f:
            context = f.read()

    dispatch(args.agent, task, context, config)


if __name__ == "__main__":
    main()
