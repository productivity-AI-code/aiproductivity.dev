@echo off
setlocal EnableDelayedExpansion
title MedRecords AI
color 0F

echo.
echo  ================================================================
echo    MedRecords AI - Intelligent Document Analysis Platform
echo    HIPAA-Compliant Medical Record Summarization
echo  ================================================================
echo.

:: Check if this is a demo build
if exist "%~dp0.demo_build" (
    echo  ----------------------------------------------------------------
    echo    DEMO VERSION - 14 Day Trial ^| 3 Cases ^| Core Features Only
    echo  ----------------------------------------------------------------
    echo.
)

:: Check if this is a licensed build (Core/Pro)
if exist "%~dp0.build_info" (
    if not exist "%~dp0.demo_build" (
        echo  ----------------------------------------------------------------
        echo    Licensed Build - Activation Required on First Launch
        echo  ----------------------------------------------------------------
        echo.
    )
)

:: ── Auto-Extract: detect if running from inside a ZIP ────────────────
:: When Windows runs a .bat from inside a ZIP, only the .bat itself is
:: extracted to a temp dir. Check for a required file to detect this.
if not exist "%~dp0setup_wizard.py" (
    echo  It looks like you opened this from inside the ZIP file.
    echo  MedRecords AI needs to be extracted first.
    echo.

    :: Try to find the ZIP in Downloads or next to this bat's original location
    set "INSTALL_DIR=%USERPROFILE%\MedRecordsAI"

    echo  Installing to: !INSTALL_DIR!
    echo.

    :: Look for the ZIP in common download locations
    set "ZIP_FOUND="
    for %%D in ("%USERPROFILE%\Downloads" "%USERPROFILE%\Desktop" "%~dp0..") do (
        for %%F in ("%%~D\MedRecordsAI*.zip") do (
            if exist "%%~F" (
                set "ZIP_FOUND=%%~F"
            )
        )
    )

    if not defined ZIP_FOUND (
        echo  [ERROR] Could not find the MedRecords AI ZIP file.
        echo.
        echo  Please extract the ZIP manually:
        echo    1. Right-click the ZIP file
        echo    2. Select "Extract All..."
        echo    3. Choose a folder like: %USERPROFILE%\MedRecordsAI
        echo    4. Run MedRecordsAI.bat from the extracted folder
        echo.
        pause
        exit /b 1
    )

    echo  Found: !ZIP_FOUND!
    echo  Extracting...
    echo.

    :: Use PowerShell to extract (available on all modern Windows)
    powershell -NoProfile -Command "Expand-Archive -LiteralPath '!ZIP_FOUND!' -DestinationPath '!INSTALL_DIR!' -Force" 2>nul

    if %ERRORLEVEL% NEQ 0 (
        echo  [ERROR] Extraction failed. Please extract manually:
        echo    Right-click the ZIP ^> Extract All ^> Choose a folder
        echo.
        pause
        exit /b 1
    )

    echo  [OK] Extracted successfully.
    echo.

    :: Relaunch from the extracted location
    if exist "!INSTALL_DIR!\MedRecordsAI.bat" (
        start "" "!INSTALL_DIR!\MedRecordsAI.bat"
        exit /b 0
    )

    :: Check if ZIP had a top-level folder
    for /d %%D in ("!INSTALL_DIR!\*") do (
        if exist "%%D\MedRecordsAI.bat" (
            start "" "%%D\MedRecordsAI.bat"
            exit /b 0
        )
    )

    echo  [ERROR] Could not find MedRecordsAI.bat in extracted files.
    echo  Please run it manually from: !INSTALL_DIR!
    pause
    exit /b 1
)

:: ── Reset Mode: clean slate for testing first-time flow ──────────────
if /i not "%~1"=="--reset" goto :skip_reset

echo  Resetting for fresh install test...
echo.

:: Stop any running services gracefully
if exist "%~dp0start_medical.py" (
    python "%~dp0start_medical.py" --stop >nul 2>&1
)

:: Kill any zombie process on port 8080
python -c "import subprocess,re; [subprocess.run(['taskkill','/F','/PID',p]) for l in subprocess.run(['netstat','-aon'],capture_output=True,text=True).stdout.splitlines() if ':8080' in l and 'LISTENING' in l for p in [l.split()[-1]] if p.isdigit()]" >nul 2>&1

:: Delete runtime files
del /q "%~dp0.installed" 2>nul
del /q "%~dp0.env" 2>nul
del /q "%~dp0config.yaml" 2>nul
del /q "%~dp0medical_records.db" 2>nul
del /q "%~dp0medical_records.db-shm" 2>nul
del /q "%~dp0medical_records.db-wal" 2>nul

:: Clear vault, logs, staging, pipeline status
if exist "%~dp0vault" rmdir /s /q "%~dp0vault" 2>nul
if exist "%~dp0logs" rmdir /s /q "%~dp0logs" 2>nul
if exist "%~dp0staging" rmdir /s /q "%~dp0staging" 2>nul

echo  [OK] Reset complete. Running first-time setup...
echo.

:skip_reset

:: ── Detect Python ────────────────────────────────────────────────────
set "PYTHON_CMD="

python --version >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    set "PYTHON_CMD=python"
    goto :python_ok
)

py --version >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    set "PYTHON_CMD=py"
    goto :python_ok
)

:: Python not found — if already set up, just show error
if exist "%~dp0.installed" (
    echo  [ERROR] Python not found. Please reinstall Python 3.10+
    echo          from https://python.org
    echo          Make sure "Add Python to PATH" is checked.
    echo.
    pause
    exit /b 1
)

:: First run — offer automatic installation
echo  Python is required but was not found on this system.
echo.
choice /C YN /M "  Install Python automatically"
if !ERRORLEVEL! EQU 2 goto :manual_python

echo.
echo  [1/3] Checking for Windows package manager...

:: Strategy 1: winget (Windows 10 1709+ / Windows 11)
winget --version >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    echo  [2/3] Installing Python via winget ^(this may take a few minutes^)...
    winget install Python.Python.3.12 --accept-package-agreements --accept-source-agreements --scope user
    if !ERRORLEVEL! EQU 0 goto :python_auto_installed
    echo         winget install did not succeed, trying direct download...
)

:: Strategy 2: download installer from python.org
echo  [2/3] Downloading Python from python.org...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe' -OutFile '%TEMP%\python-installer.exe'"

if not exist "%TEMP%\python-installer.exe" (
    echo  [ERROR] Download failed. Check your internet connection.
    goto :manual_python
)

echo         Installing Python ^(this may take a minute^)...
"%TEMP%\python-installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1
del /q "%TEMP%\python-installer.exe" 2>nul

:python_auto_installed
echo  [3/3] Verifying installation...

:: Refresh PATH from registry to pick up newly installed Python
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "PATH=%%B;!PATH!"

:: Also add common Python install locations directly
for %%D in ("%LOCALAPPDATA%\Programs\Python\Python312" "%LOCALAPPDATA%\Programs\Python\Python311" "%LOCALAPPDATA%\Programs\Python\Python310") do (
    if exist "%%~D\python.exe" set "PATH=%%~D;%%~D\Scripts;!PATH!"
)

python --version >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    set "PYTHON_CMD=python"
    echo.
    echo  [OK] Python installed successfully.
    echo.
    goto :python_ok
)

py --version >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    set "PYTHON_CMD=py"
    echo.
    echo  [OK] Python installed successfully.
    echo.
    goto :python_ok
)

echo.
echo  [ERROR] Could not verify Python after installation.
echo          Please close this window, then reopen MedRecordsAI.bat
echo          ^(A fresh window is needed for the new PATH to take effect.^)
echo.
pause
exit /b 1

:manual_python
echo.
echo  Please install Python 3.10+ from https://python.org
echo  Make sure "Add Python to PATH" is checked during install.
echo  Then run MedRecordsAI.bat again.
echo.
pause
exit /b 1

:python_ok
echo  [OK] Python found
echo.

:: ── First Run: Install ────────────────────────────────────────────────
if exist "%~dp0.installed" goto :launch

echo  First-time setup detected. Starting installation...
echo.

:: Install Flask first (needed for setup wizard)
echo  Preparing setup wizard...
!PYTHON_CMD! -m pip install flask -q >nul 2>&1

:: Launch browser-based setup wizard
echo  Opening setup wizard in your browser...
echo  (If it doesn't open automatically, go to http://localhost:9876)
echo.
!PYTHON_CMD! "%~dp0setup_wizard.py"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [INFO] Setup wizard closed. Checking if setup completed...
)

:: Verify setup completed
if not exist "%~dp0.installed" (
    echo.
    echo  [ERROR] Setup was not completed. Please run this file again.
    echo.
    pause
    exit /b 1
)

echo.
echo  [OK] Setup verified.
echo.

:: ── Launch ────────────────────────────────────────────────────────────
:launch
echo  Starting MedRecords AI...
echo.

:: Stop any previously tracked services so start_medical.py won't refuse
if exist "%~dp0logs\medical_services.json" (
    !PYTHON_CMD! "%~dp0start_medical.py" --stop >nul 2>&1
)

!PYTHON_CMD! "%~dp0start_medical.py" --auto-open

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [ERROR] Failed to start. Check the logs folder for details.
    pause
    exit /b 1
)

echo.
echo  Press any key to stop MedRecords AI...
pause >nul

echo.
echo  Stopping services...
!PYTHON_CMD! "%~dp0start_medical.py" --stop
echo  Done.
timeout /t 2 >nul
