"""One-time script to generate the contacts_tracking.xlsx template."""
import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from pathlib import Path

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Contacts"

headers = [
    "Contact Name", "Contact Email", "Contact Type", "Organization",
    "Patient/Case Ref", "Record Type Needed", "Date Added", "Status",
    "Last Contact Date", "Thread ID", "Upload Token", "Notes", "Priority",
]
ws.append(headers)

# Bold headers
for cell in ws[1]:
    cell.font = openpyxl.styles.Font(bold=True)

# Column widths
widths = [20, 30, 15, 25, 20, 30, 15, 15, 15, 30, 36, 30, 10]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

# Dropdown validations
type_dv = DataValidation(type="list", formula1='"custodian,counsel,patient"', allow_blank=True)
type_dv.error = "Must be custodian, counsel, or patient"
ws.add_data_validation(type_dv)
type_dv.add(f"C2:C1000")

status_dv = DataValidation(type="list", formula1='"new,contacted,awaiting,received,failed"', allow_blank=True)
status_dv.error = "Must be new, contacted, awaiting, received, or failed"
ws.add_data_validation(status_dv)
status_dv.add(f"H2:H1000")

priority_dv = DataValidation(type="list", formula1='"low,normal,high,urgent"', allow_blank=True)
ws.add_data_validation(priority_dv)
priority_dv.add(f"M2:M1000")

out = Path(__file__).parent / "templates" / "contacts_tracking.xlsx"
out.parent.mkdir(parents=True, exist_ok=True)
wb.save(out)
print(f"Created {out}")
