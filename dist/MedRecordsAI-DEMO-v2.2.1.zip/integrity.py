import hashlib
import hmac as _hmac
import json
import logging
import threading
import time
from pathlib import Path
logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).parent
MANIFEST_PATH = BASE_DIR / '.integrity_manifest'
_MANIFEST_SIGN_KEY = b'MRA-INTEGRITY-MANIFEST-2024'
CRITICAL_FILES = {'licensing.py', 'license_crypto.py', 'demo_guard.py', 'product_guard.py', 'security.py', 'integrity.py'}
_tampered_files: list[str] = []
_check_lock = threading.Lock()
_checker_started = False

def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                h.update(chunk)
    except OSError:
        return ''
    return h.hexdigest()

def _load_manifest() -> dict | None:
    if not MANIFEST_PATH.exists():
        return None
    try:
        raw = json.loads(MANIFEST_PATH.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return None
    stored_sig = raw.pop('_signature', None)
    if not stored_sig:
        logger.warning('Integrity manifest missing signature')
        return None
    check_payload = json.dumps(raw, sort_keys=True)
    expected_sig = _hmac.new(_MANIFEST_SIGN_KEY, check_payload.encode(), hashlib.sha256).hexdigest()
    if not _hmac.compare_digest(stored_sig, expected_sig):
        logger.warning('Integrity manifest signature mismatch — tampered')
        return None
    return raw

def verify_integrity() -> list[str]:
    global _tampered_files
    manifest = _load_manifest()
    if manifest is None:
        return []
    files = manifest.get('files', {})
    tampered = []
    for rel_path, expected_hash in files.items():
        full_path = BASE_DIR / rel_path
        actual_hash = _hash_file(full_path)
        if actual_hash != expected_hash:
            tampered.append(rel_path)
            logger.warning('Integrity check failed: %s', rel_path)
    with _check_lock:
        _tampered_files = tampered
    return tampered

def is_tampered() -> bool:
    with _check_lock:
        return len(_tampered_files) > 0

def is_critically_tampered() -> bool:
    with _check_lock:
        return any((Path(f).name in CRITICAL_FILES for f in _tampered_files))

def get_tampered_files() -> list[str]:
    with _check_lock:
        return list(_tampered_files)

def start_background_checker(interval: int=300):
    global _checker_started
    if _checker_started:
        return
    _checker_started = True

    def _checker():
        while True:
            time.sleep(interval)
            try:
                verify_integrity()
            except Exception as e:
                logger.error('Background integrity check error: %s', e)
    t = threading.Thread(target=_checker, daemon=True, name='integrity-checker')
    t.start()
    logger.info('Background integrity checker started (interval=%ds)', interval)