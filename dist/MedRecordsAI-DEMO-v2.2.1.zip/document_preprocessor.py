import hashlib
import io
import logging
import re
import struct
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
logger = logging.getLogger(__name__)
_MEDICAL_OCR_CORRECTIONS = {'\\bmetforrnin\\b': 'metformin', '\\blisinopnl\\b': 'lisinopril', '\\batorvastatin\\b': 'atorvastatin', '\\bomeprazo1e\\b': 'omeprazole', '\\bgabapentln\\b': 'gabapentin', '\\bhydrocodone\\b': 'hydrocodone', '\\bacetarninophen\\b': 'acetaminophen', '\\bibuprofen\\b': 'ibuprofen', '\\bamoxici1lin\\b': 'amoxicillin', '\\bprednlsone\\b': 'prednisone', '\\bcyclobenzaprlne\\b': 'cyclobenzaprine', '\\bmeloxlcam\\b': 'meloxicam', '\\btramado1\\b': 'tramadol', '\\bnaproxen\\b': 'naproxen', '\\bdiclofenac\\b': 'diclofenac', '\\bdiagnos[l1]s\\b': 'diagnosis', '\\bexarn[l1]nation\\b': 'examination', '\\bmed[l1]cation\\b': 'medication', '\\bprescr[l1]ption\\b': 'prescription', '\\btreatrnent\\b': 'treatment', '\\bassessrnent\\b': 'assessment', '\\bmanagernent\\b': 'management', '\\bpat[l1]ent\\b': 'patient', '\\bsyrnptoms\\b': 'symptoms', '\\bexarn\\b': 'exam', '\\bab[d0]omen\\b': 'abdomen', '\\bcerv[l1]cal\\b': 'cervical', '\\blurnbar\\b': 'lumbar', '\\bthorac[l1]c\\b': 'thoracic', '\\brad[l1]culopathy\\b': 'radiculopathy', '\\bstenos[l1]s\\b': 'stenosis', '\\bhern[l1]ation\\b': 'herniation', '\\bfracture\\b': 'fracture', '\\bcontus[l1]on\\b': 'contusion', '\\blacerat[l1]on\\b': 'laceration', '\\babras[l1]on\\b': 'abrasion', '\\bsurg[l1]cal\\b': 'surgical', '\\borthoped[l1]c\\b': 'orthopedic', '\\bneurologlcal\\b': 'neurological', '\\bradiolog[l1]cal\\b': 'radiological', '\\bMR[l1]\\b': 'MRI', '\\bC[B8]C\\b': 'CBC', '\\b[B8]MP\\b': 'BMP', '\\bCMP\\b': 'CMP', '\\bEKG\\b': 'EKG', '\\b[l1]CD-10\\b': 'ICD-10', '\\bCPT\\b': 'CPT', '\\bH[l1]PAA\\b': 'HIPAA', '\\bPH[l1]\\b': 'PHI', '\\brng/dL\\b': 'mg/dL', '\\bmg/d[l1]\\b': 'mg/dL', '\\brn[l1]/min\\b': 'mL/min', '\\brnrn\\b(?=\\s*Hg|\\s*$)': 'mm'}
_COMPILED_CORRECTIONS = [(re.compile(pattern, re.IGNORECASE), replacement) for pattern, replacement in _MEDICAL_OCR_CORRECTIONS.items()]

def _medical_postprocess(text):
    if not text:
        return text
    for pattern, replacement in _COMPILED_CORRECTIONS:
        text = pattern.sub(replacement, text)
    return text

def _preprocess_image(image_bytes):
    try:
        import cv2
        import numpy as np
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return image_bytes
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        denoised = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)
        coords = np.column_stack(np.where(enhanced < 128))
        if len(coords) > 100:
            angle = cv2.minAreaRect(coords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle
            if 0.5 < abs(angle) < 15:
                h, w = enhanced.shape
                center = (w // 2, h // 2)
                M = cv2.getRotationMatrix2D(center, angle, 1.0)
                enhanced = cv2.warpAffine(enhanced, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
                logger.debug('Deskewed image by %.1f degrees', angle)
        binary = cv2.adaptiveThreshold(enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 15, 8)
        _, buffer = cv2.imencode('.png', binary)
        return buffer.tobytes()
    except ImportError:
        logger.debug('OpenCV not available, skipping image pre-processing')
        return image_bytes
    except Exception as e:
        logger.warning('Image pre-processing failed: %s', e)
        return image_bytes

def _tesseract_ocr(image_bytes, preprocess=True):
    try:
        import pytesseract
        from PIL import Image
        if preprocess:
            processed_bytes = _preprocess_image(image_bytes)
        else:
            processed_bytes = image_bytes
        img = Image.open(io.BytesIO(processed_bytes))
        custom_config = '--oem 3 --psm 6'
        text = pytesseract.image_to_string(img, config=custom_config)
        try:
            data = pytesseract.image_to_data(img, config=custom_config, output_type=pytesseract.Output.DICT)
            confidences = [int(c) for c in data['conf'] if int(c) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        except Exception:
            avg_confidence = 0
        return (text.strip(), avg_confidence)
    except ImportError:
        logger.debug('pytesseract not available, skipping Tesseract OCR')
        return ('', 0)
    except Exception as e:
        logger.warning('Tesseract OCR failed: %s', e)
        return ('', 0)

def _call_ollama_vision(model, prompt, image_bytes, config, timeout=120):
    import base64
    import requests
    endpoint = config.get('ollama', {}).get('endpoint', 'http://localhost:11434')
    b64_image = base64.b64encode(image_bytes).decode('ascii')
    try:
        resp = requests.post(f'{endpoint}/api/generate', json={'model': model, 'prompt': prompt, 'images': [b64_image], 'stream': False}, timeout=timeout)
        resp.raise_for_status()
        return resp.json().get('response', '').strip()
    except Exception as e:
        logger.warning('Ollama vision call to %s failed: %s', model, e)
        return ''

def _get_available_vision_model(config):
    import requests
    endpoint = config.get('ollama', {}).get('endpoint', 'http://localhost:11434')
    try:
        resp = requests.get(f'{endpoint}/api/tags', timeout=5)
        if resp.status_code != 200:
            return None
        models = [m['name'] for m in resp.json().get('models', [])]
    except Exception:
        return None
    for candidate in ['llava:13b', 'llava:7b', 'moondream', 'glm-ocr:latest', 'glm-ocr']:
        if candidate in models:
            return candidate
    return None

@dataclass
class PageInfo:
    page_number: int
    source_file: str
    text_content: str
    quality: str
    category: str
    confidence: float
    content_hash: str
    simhash: int
    char_count: int
    has_handwriting: bool
    image_data: bytes | None
    is_duplicate: bool = False
    duplicate_of: str | None = None

@dataclass
class PreprocessingResult:
    pages: list[PageInfo] = field(default_factory=list)
    total_pages: int = 0
    unique_pages: int = 0
    duplicate_pages: int = 0
    blank_pages: int = 0
    noise_pages: int = 0
    handwritten_pages: int = 0
    clinical_pages: int = 0
    chunks: list[dict] = field(default_factory=list)
    recommended_mode: str = 'fast'
    dedup_stats: dict = field(default_factory=dict)

def _extract_pages_pdf(file_path, extract_images=True, dpi=300, use_tesseract=True):
    import fitz
    pages = []
    doc = fitz.open(str(file_path))
    filename = Path(file_path).name
    tesseract_used = 0
    tesseract_succeeded = 0
    for i, page in enumerate(doc, 1):
        text = page.get_text().strip()
        char_count = len(text)
        image_data = None
        if extract_images and char_count < 50:
            try:
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                pix = page.get_pixmap(matrix=mat)
                image_data = pix.tobytes('png')
            except Exception as e:
                logger.warning('Failed to render page %d of %s as image: %s', i, filename, e)
            if image_data and use_tesseract:
                tesseract_used += 1
                tess_text, tess_conf = _tesseract_ocr(image_data, preprocess=True)
                if tess_text and tess_conf > 40 and (len(tess_text) > 20):
                    tess_text = _medical_postprocess(tess_text)
                    text = tess_text
                    char_count = len(text)
                    tesseract_succeeded += 1
                    logger.debug('Tesseract OCR page %d of %s: %d chars (%.0f%% conf)', i, filename, char_count, tess_conf)
                    if tess_conf > 70:
                        image_data = None
        page_info = PageInfo(page_number=i, source_file=filename, text_content=text, quality='', category='', confidence=0.0, content_hash='', simhash=0, char_count=char_count, has_handwriting=False, image_data=image_data)
        pages.append(page_info)
    doc.close()
    if tesseract_used > 0:
        logger.info('Tesseract OCR: %d/%d scanned pages processed (%d succeeded)', tesseract_succeeded, tesseract_used, tesseract_succeeded)
    return pages

def _extract_pages_image(file_path):
    filename = Path(file_path).name
    try:
        img_bytes = Path(file_path).read_bytes()
    except Exception as e:
        logger.warning('Failed to read image %s: %s', filename, e)
        return []
    ext = Path(file_path).suffix.lower()
    page_info = PageInfo(page_number=1, source_file=filename, text_content='', quality='typed_scanned', category='', confidence=0.0, content_hash='', simhash=0, char_count=0, has_handwriting=False, image_data=img_bytes)
    return [page_info]

def _extract_pages_text(file_path, page_size=3000):
    filename = Path(file_path).name
    try:
        ext = Path(file_path).suffix.lower()
        if ext == '.xlsx':
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
            parts = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = []
                for row in ws.iter_rows(values_only=True):
                    rows.append('\t'.join((str(c) if c is not None else '' for c in row)))
                if rows:
                    parts.append(f'--- Sheet: {sheet_name} ---\n' + '\n'.join(rows))
            wb.close()
            text = '\n\n'.join(parts) if parts else ''
        elif ext == '.xls':
            import xlrd
            wb = xlrd.open_workbook(str(file_path))
            parts = []
            for sheet in wb.sheets():
                rows = []
                for rx in range(sheet.nrows):
                    row = [str(sheet.cell_value(rx, cx)) for cx in range(sheet.ncols)]
                    rows.append('\t'.join(row))
                if rows:
                    parts.append(f'--- Sheet: {sheet.name} ---\n' + '\n'.join(rows))
            text = '\n\n'.join(parts) if parts else ''
        else:
            text = Path(file_path).read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        logger.warning('Failed to read %s: %s', filename, e)
        return []
    if not text.strip():
        return [PageInfo(page_number=1, source_file=filename, text_content='', quality='blank', category='blank', confidence=1.0, content_hash='', simhash=0, char_count=0, has_handwriting=False, image_data=None)]
    pages = []
    paragraphs = text.split('\n\n')
    current_chunk = ''
    page_num = 1
    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 > page_size and current_chunk:
            pages.append(PageInfo(page_number=page_num, source_file=filename, text_content=current_chunk.strip(), quality='', category='', confidence=0.0, content_hash='', simhash=0, char_count=len(current_chunk.strip()), has_handwriting=False, image_data=None))
            page_num += 1
            current_chunk = para + '\n\n'
        else:
            current_chunk += para + '\n\n'
    if current_chunk.strip():
        pages.append(PageInfo(page_number=page_num, source_file=filename, text_content=current_chunk.strip(), quality='', category='', confidence=0.0, content_hash='', simhash=0, char_count=len(current_chunk.strip()), has_handwriting=False, image_data=None))
    return pages

def extract_pages(file_path, extract_images=True, dpi=300):
    ext = Path(file_path).suffix.lower()
    if ext == '.pdf':
        return _extract_pages_pdf(file_path, extract_images=extract_images, dpi=dpi)
    elif ext in ('.png', '.jpg', '.jpeg', '.tiff', '.tif'):
        return _extract_pages_image(file_path)
    else:
        return _extract_pages_text(file_path)

def _assess_page_quality(page):
    text = page.text_content
    if page.char_count < 10:
        page.quality = 'blank'
        page.confidence = 1.0
        return
    alnum_count = sum((1 for c in text if c.isalnum()))
    alnum_ratio = alnum_count / max(page.char_count, 1)
    if alnum_ratio < 0.3:
        page.quality = 'noise'
        page.confidence = 0.9
        return
    words = text.split()
    if words:
        avg_word_len = sum((len(w) for w in words)) / len(words)
        single_char_ratio = sum((1 for w in words if len(w) == 1)) / len(words)
        if single_char_ratio > 0.4 or avg_word_len < 2.0:
            page.quality = 'noise'
            page.confidence = 0.7
            return
    if page.image_data and page.char_count < 100:
        page.quality = 'typed_scanned'
        page.has_handwriting = True
        page.confidence = 0.6
        return
    if alnum_ratio > 0.5 and page.char_count > 50:
        page.quality = 'typed_clean'
        page.confidence = 0.9
    else:
        page.quality = 'typed_scanned'
        page.confidence = 0.7
_CLINICAL_KEYWORDS = {'diagnosis', 'treatment', 'medication', 'prescription', 'assessment', 'history', 'examination', 'symptoms', 'patient', 'clinical', 'chief complaint', 'hpi', 'ros', 'physical exam', 'plan', 'follow-up', 'vital signs', 'blood pressure', 'pulse', 'temperature', 'impression', 'prognosis', 'discharge', 'admit', 'surgery', 'operative', 'procedure', 'anesthesia', 'pre-op', 'post-op', 'progress note', 'soap', 'subjective', 'objective'}
_IMAGING_KEYWORDS = {'x-ray', 'xray', 'mri', 'ct scan', 'ultrasound', 'radiology', 'imaging', 'radiograph', 'fluoroscopy', 'mammogram', 'pet scan', 'impression:', 'findings:', 'comparison:', 'technique:'}
_LAB_KEYWORDS = {'lab results', 'laboratory', 'cbc', 'bmp', 'cmp', 'hemoglobin', 'hematocrit', 'wbc', 'platelet', 'glucose', 'creatinine', 'reference range', 'specimen', 'urinalysis', 'culture'}
_BILLING_KEYWORDS = {'billing', 'invoice', 'charges', 'payment', 'insurance', 'copay', 'deductible', 'claim', 'cpt', 'icd-10', 'icd-9', 'balance due', 'amount', 'total charges', 'adjustment'}
_CONSENT_KEYWORDS = {'consent', 'authorization', 'signature', 'hereby authorize', 'i understand', 'risks and benefits', 'informed consent', 'hipaa', 'privacy', 'release of information'}
_NOISE_KEYWORDS = {'fax cover', 'fax transmission', 'cover sheet', 'pages including', 'confidentiality notice', 'if you received this', 'table of contents', 'index'}

def _classify_page(page):
    if page.quality == 'blank':
        page.category = 'blank'
        page.confidence = 1.0
        return
    if page.quality == 'noise':
        page.category = 'fax_cover'
        page.confidence = 0.7
        return
    text_lower = page.text_content.lower()
    scores = {}
    for cat, keywords in [('clinical', _CLINICAL_KEYWORDS), ('imaging_report', _IMAGING_KEYWORDS), ('lab_results', _LAB_KEYWORDS), ('billing', _BILLING_KEYWORDS), ('consent', _CONSENT_KEYWORDS), ('fax_cover', _NOISE_KEYWORDS)]:
        score = sum((1 for kw in keywords if kw in text_lower))
        scores[cat] = score
    if not any(scores.values()):
        page.category = 'clinical'
        page.confidence = 0.4
        return
    best_cat = max(scores, key=scores.get)
    total_matches = sum(scores.values())
    page.category = best_cat
    page.confidence = min(0.95, scores[best_cat] / max(total_matches, 1))

def _normalize_text(text):
    import re
    text = text.lower()
    text = re.sub('[^\\w\\s]', '', text)
    text = re.sub('\\s+', ' ', text).strip()
    return text

def _compute_content_hash(text):
    normalized = _normalize_text(text)
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()

def _compute_simhash(text, hash_bits=64):
    normalized = _normalize_text(text)
    if len(normalized) < 3:
        return 0
    shingles = [normalized[i:i + 3] for i in range(len(normalized) - 2)]
    v = [0] * hash_bits
    for shingle in shingles:
        h = hashlib.md5(shingle.encode('utf-8')).digest()
        hash_int = int.from_bytes(h[:hash_bits // 8], byteorder='big')
        for i in range(hash_bits):
            if hash_int & 1 << i:
                v[i] += 1
            else:
                v[i] -= 1
    simhash = 0
    for i in range(hash_bits):
        if v[i] > 0:
            simhash |= 1 << i
    return simhash

def _hamming_distance(a, b):
    x = a ^ b
    count = 0
    while x:
        count += 1
        x &= x - 1
    return count

def _compute_hashes(pages):
    for page in pages:
        if page.quality in ('blank', 'noise') or page.char_count < 10:
            page.content_hash = ''
            page.simhash = 0
            continue
        page.content_hash = _compute_content_hash(page.text_content)
        page.simhash = _compute_simhash(page.text_content)

def _deduplicate_pages(pages, threshold=10):
    content_pages = [p for p in pages if p.quality not in ('blank', 'noise') and p.char_count >= 10]
    duplicate_count = 0
    exact_dupes = 0
    near_dupes = 0
    seen_hashes = {}
    seen_simhashes = []
    for page in content_pages:
        page_id = f'{page.source_file}:page_{page.page_number}'
        if page.content_hash in seen_hashes:
            page.is_duplicate = True
            page.duplicate_of = seen_hashes[page.content_hash]
            duplicate_count += 1
            exact_dupes += 1
            continue
        is_near_dupe = False
        for existing_hash, existing_id in seen_simhashes:
            if _hamming_distance(page.simhash, existing_hash) <= threshold:
                page.is_duplicate = True
                page.duplicate_of = existing_id
                duplicate_count += 1
                near_dupes += 1
                is_near_dupe = True
                break
        if not is_near_dupe:
            seen_hashes[page.content_hash] = page_id
            seen_simhashes.append((page.simhash, page_id))
    dedup_stats = {'total_compared': len(content_pages), 'exact_duplicates': exact_dupes, 'near_duplicates': near_dupes, 'total_duplicates': duplicate_count, 'unique_pages': len(content_pages) - duplicate_count}
    return (pages, duplicate_count, dedup_stats)

def detect_handwritten_pages(pages):
    handwritten = []
    for page in pages:
        if page.is_duplicate or page.quality == 'blank':
            continue
        if page.image_data and page.char_count < 100:
            page.has_handwriting = True
            handwritten.append(page)
    return handwritten

def _build_context_prompt(page, all_pages):
    same_file_pages = [p for p in all_pages if p.source_file == page.source_file]
    same_file_pages.sort(key=lambda p: p.page_number)
    prev_context = ''
    next_context = ''
    for p in same_file_pages:
        if p.page_number == page.page_number - 1 and p.text_content:
            prev_text = p.text_content[-300:]
            prev_context = f'\n\nCONTEXT — Previous page ended with:\n"{prev_text}"'
        elif p.page_number == page.page_number + 1 and p.text_content:
            next_text = p.text_content[:300]
            next_context = f'\n\nCONTEXT — Next page begins with:\n"{next_text}"'
    system_prompt = 'You are a medical document transcription specialist with deep expertise in:\n- Clinical progress notes, SOAP notes, and physician orders\n- Handwritten prescriptions and medication lists\n- Medical abbreviations (PRN, BID, TID, QID, QHS, PO, IM, IV, SubQ, etc.)\n- Vital signs notation (BP, HR, RR, T, SpO2, BMI)\n- Lab values and reference ranges\n- Radiology/imaging report formats\n- Surgical operative notes\n- Physical therapy/rehabilitation notes\n\nTRANSCRIPTION RULES:\n1. Transcribe ALL text visible in the image — both handwritten and typed\n2. Preserve document structure: headers, sections, bullet points, tables, dates\n3. Expand common medical abbreviations in brackets on first occurrence, e.g., "PRN [as needed]"\n4. For partially illegible text, transcribe what you can and mark unclear portions as [illegible]\n5. Preserve exact numbers, dates, dosages, and measurements — accuracy is critical\n6. Note any checkboxes, circled items, or underlined text with markers like [checked], [circled], [underlined]\n7. Do NOT add commentary, interpretation, or summary — pure transcription only'
    text_prompt = f'Transcribe this medical document page (page {page.page_number} of {page.source_file}).{prev_context}{next_context}\n\nTranscribe all visible text accurately:'
    return (system_prompt, text_prompt)

def transcribe_handwritten_pages(pages, config, all_pages=None):
    from dispatch import call_claude_vision
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    model = modes_cfg.get('handwriting_model', 'claude-haiku-4-5-20251001')
    ocr_cfg = config.get('ocr', {})
    use_ollama_vision = ocr_cfg.get('use_ollama_vision', True)
    ollama_vision_model = ocr_cfg.get('ollama_vision_model', '')
    backend = config.get('llm_backend', 'claude')
    if use_ollama_vision and (not ollama_vision_model) and (backend == 'ollama'):
        ollama_vision_model = _get_available_vision_model(config) or ''
    if all_pages is None:
        all_pages = pages
    transcribed = 0
    for page in pages:
        if not page.image_data:
            continue
        ext = Path(page.source_file).suffix.lower()
        media_type_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.tiff': 'image/tiff', '.tif': 'image/tiff'}
        media_type = media_type_map.get(ext, 'image/png')
        processed_image = _preprocess_image(page.image_data)
        text = ''
        if ollama_vision_model and use_ollama_vision:
            try:
                system_prompt, text_prompt = _build_context_prompt(page, all_pages)
                text = _call_ollama_vision(model=ollama_vision_model, prompt=f'{system_prompt}\n\n{text_prompt}', image_bytes=processed_image, config=config, timeout=120)
                if text and len(text.strip()) > 20:
                    text = _medical_postprocess(text.strip())
                    logger.info('Ollama vision (%s) transcribed page %d of %s (%d chars)', ollama_vision_model, page.page_number, page.source_file, len(text))
                else:
                    text = ''
            except Exception as e:
                logger.warning('Ollama vision failed for page %d of %s: %s', page.page_number, page.source_file, e)
                text = ''
        if not text:
            try:
                system_prompt, text_prompt = _build_context_prompt(page, all_pages)
                text = call_claude_vision(model=model, system_prompt=system_prompt, text_prompt=text_prompt, images=[(processed_image, media_type)], config=config, timeout_override=90, max_tokens_override=4096)
                if text:
                    text = _medical_postprocess(text.strip())
            except Exception as e:
                logger.warning('Claude Vision failed for page %d of %s: %s', page.page_number, page.source_file, e)
                text = ''
        if text and len(text.strip()) > 10:
            page.text_content = text.strip()
            page.char_count = len(page.text_content)
            page.quality = 'handwritten'
            page.content_hash = _compute_content_hash(page.text_content)
            page.simhash = _compute_simhash(page.text_content)
            transcribed += 1
            logger.info('Transcribed page %d of %s (%d chars)', page.page_number, page.source_file, page.char_count)
    return transcribed

def _build_chunks(pages, config):
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    chunk_size = modes_cfg.get('chunk_size_pages', 20)
    eligible = [p for p in pages if not p.is_duplicate and p.quality not in ('blank', 'noise') and (p.category not in ('fax_cover', 'blank'))]
    if not eligible:
        return []
    chunks = []
    current_chunk_pages = []
    current_chunk_id = 1
    for page in eligible:
        current_chunk_pages.append(page)
        should_split = False
        if len(current_chunk_pages) >= chunk_size:
            should_split = True
        elif len(current_chunk_pages) >= int(chunk_size * 0.75) and current_chunk_pages and (page != eligible[-1]) and (eligible[eligible.index(page) + 1].source_file != page.source_file):
            should_split = True
        if should_split:
            chunk_text = '\n\n'.join((f'[Source: {p.source_file}, Page {p.page_number}]\n{p.text_content}' for p in current_chunk_pages))
            source_files = list(set((p.source_file for p in current_chunk_pages)))
            chunks.append({'chunk_id': current_chunk_id, 'pages': current_chunk_pages, 'text': chunk_text, 'page_count': len(current_chunk_pages), 'source_files': source_files})
            current_chunk_id += 1
            current_chunk_pages = []
    if current_chunk_pages:
        chunk_text = '\n\n'.join((f'[Source: {p.source_file}, Page {p.page_number}]\n{p.text_content}' for p in current_chunk_pages))
        source_files = list(set((p.source_file for p in current_chunk_pages)))
        chunks.append({'chunk_id': current_chunk_id, 'pages': current_chunk_pages, 'text': chunk_text, 'page_count': len(current_chunk_pages), 'source_files': source_files})
    return chunks

def determine_processing_mode(result, preference='auto'):
    if preference in ('fast', 'thorough'):
        return preference
    if result.clinical_pages > 50:
        return 'thorough'
    if result.handwritten_pages > 5:
        return 'thorough'
    if result.duplicate_pages > 10:
        return 'thorough'
    if result.total_pages > 80:
        return 'thorough'
    return 'fast'

def preprocess_case(file_paths, config, mode='auto', transcribe=True):
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    extract_images = modes_cfg.get('pdf_extract_images', True)
    dpi = modes_cfg.get('pdf_dpi', 300)
    dedup_threshold = modes_cfg.get('dedup_simhash_threshold', 10)
    all_pages = []
    for fp in file_paths:
        fp = Path(fp)
        if not fp.exists():
            logger.warning('File not found: %s', fp)
            continue
        try:
            pages = extract_pages(fp, extract_images=extract_images, dpi=dpi)
            all_pages.extend(pages)
            logger.info('Extracted %d pages from %s', len(pages), fp.name)
        except Exception as e:
            logger.warning('Failed to extract pages from %s: %s', fp.name, e)
    if not all_pages:
        return PreprocessingResult()
    for page in all_pages:
        if not page.quality:
            _assess_page_quality(page)
    for page in all_pages:
        if not page.category:
            _classify_page(page)
    handwritten = detect_handwritten_pages(all_pages)
    if transcribe and handwritten and (mode != 'fast'):
        transcribed_count = transcribe_handwritten_pages(handwritten, config, all_pages=all_pages)
        logger.info('Transcribed %d/%d handwritten pages', transcribed_count, len(handwritten))
    _compute_hashes(all_pages)
    all_pages, dup_count, dedup_stats = _deduplicate_pages(all_pages, threshold=dedup_threshold)
    chunks = _build_chunks(all_pages, config)
    blank_pages = sum((1 for p in all_pages if p.quality == 'blank'))
    noise_pages = sum((1 for p in all_pages if p.quality == 'noise'))
    handwritten_count = sum((1 for p in all_pages if p.has_handwriting))
    clinical_count = sum((1 for p in all_pages if p.category in ('clinical', 'imaging_report', 'lab_results') and (not p.is_duplicate) and (p.quality not in ('blank', 'noise'))))
    result = PreprocessingResult(pages=all_pages, total_pages=len(all_pages), unique_pages=len(all_pages) - dup_count - blank_pages - noise_pages, duplicate_pages=dup_count, blank_pages=blank_pages, noise_pages=noise_pages, handwritten_pages=handwritten_count, clinical_pages=clinical_count, chunks=chunks, recommended_mode=determine_processing_mode(type('R', (), {'clinical_pages': clinical_count, 'handwritten_pages': handwritten_count, 'duplicate_pages': dup_count, 'total_pages': len(all_pages)})(), mode), dedup_stats=dedup_stats)
    logger.info('Preprocessing complete: %d total pages, %d unique, %d duplicates, %d blank, %d noise, %d handwritten, %d chunks, recommended=%s', result.total_pages, result.unique_pages, result.duplicate_pages, result.blank_pages, result.noise_pages, result.handwritten_pages, len(chunks), result.recommended_mode)
    return result