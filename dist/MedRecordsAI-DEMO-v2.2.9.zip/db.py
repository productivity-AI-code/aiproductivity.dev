"""
db.py -- Unified database schema and connection management for MedRecords AI.

Single source of truth for the tracking database schema. Replaces duplicated
schema definitions across medical_app.py, retrieval_bot.py, and setup_medical.py.

Features:
- WAL mode for concurrent read/write
- Automatic schema migration
- Transaction context manager
- Connection pooling via thread-local storage

Usage:
    from db import get_db, init_db, transaction

    # Read
    conn = get_db()
    rows = conn.execute("SELECT * FROM contacts").fetchall()
    conn.close()

    # Write with transaction
    with transaction() as conn:
        conn.execute("INSERT INTO contacts (...) VALUES (...)", (...))
"""

import sqlite3
import threading
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager
from pathlib import Path

BASE_DIR = Path(__file__).parent
TRACKING_DB = BASE_DIR / "tracking.db"

# Thread-local storage for connections
_local = threading.local()

# Schema version for migrations
SCHEMA_VERSION = 8

SCHEMA_SQL = """
-- Contacts table: tracks all record request contacts
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    contact_type TEXT DEFAULT 'custodian'
        CHECK(contact_type IN ('custodian', 'counsel', 'patient', 'provider')),
    organization TEXT,
    patient_case_ref TEXT,
    record_type_needed TEXT,
    date_added TEXT NOT NULL,
    status TEXT DEFAULT 'new'
        CHECK(status IN ('new', 'contacted', 'awaiting', 'received', 'failed', 'cancelled')),
    last_contact_date TEXT,
    thread_id TEXT,
    upload_token TEXT UNIQUE,
    notes TEXT,
    priority TEXT DEFAULT 'normal'
        CHECK(priority IN ('normal', 'high', 'urgent')),
    follow_up_count INTEGER DEFAULT 0,
    excel_row INTEGER,
    source TEXT DEFAULT 'manual'
        CHECK(source IN ('manual', 'excel', 'ui', 'api')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Email log: tracks all inbound/outbound emails per contact
CREATE TABLE IF NOT EXISTS email_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER NOT NULL,
    direction TEXT NOT NULL CHECK(direction IN ('inbound', 'outbound')),
    subject TEXT,
    message_id TEXT,
    in_reply_to TEXT,
    timestamp TEXT DEFAULT (datetime('now')),
    status TEXT DEFAULT 'sent'
        CHECK(status IN ('sent', 'delivered', 'failed', 'bounced', 'received')),
    error_message TEXT,
    has_attachments INTEGER DEFAULT 0,
    attachment_paths TEXT,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);

-- Access log: tracks who accessed what data (HIPAA requirement)
CREATE TABLE IF NOT EXISTS access_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT DEFAULT (datetime('now')),
    username TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    ip_address TEXT,
    details TEXT
);

-- Summary feedback for RLHF
CREATE TABLE IF NOT EXISTS summary_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    rating TEXT NOT NULL CHECK(rating IN ('poor', 'good', 'excellent')),
    feedback_text TEXT,
    username TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Case valuation outcome tracking for RL calibration
CREATE TABLE IF NOT EXISTS valuation_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    predicted_low INTEGER,
    predicted_mid INTEGER,
    predicted_high INTEGER,
    predicted_severity TEXT,
    actual_settlement INTEGER,
    actual_verdict INTEGER,
    outcome_type TEXT CHECK(outcome_type IN ('settled', 'verdict', 'dismissed', 'pending')),
    attorney_accuracy_rating TEXT CHECK(attorney_accuracy_rating IN ('too_low', 'accurate', 'too_high')),
    attorney_notes TEXT,
    jurisdiction TEXT,
    case_type TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Demand package feedback for RL
CREATE TABLE IF NOT EXISTS demand_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    rating TEXT CHECK(rating IN ('poor', 'good', 'excellent')),
    sections_edited TEXT,
    edit_severity TEXT CHECK(edit_severity IN ('minor_tweaks', 'significant_rewrites', 'unusable')),
    tone_feedback TEXT CHECK(tone_feedback IN ('too_aggressive', 'appropriate', 'too_conservative')),
    legal_accuracy INTEGER CHECK(legal_accuracy BETWEEN 1 AND 5),
    feedback_text TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Negligence detection feedback for RL
CREATE TABLE IF NOT EXISTS negligence_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    finding_title TEXT,
    finding_accepted INTEGER CHECK(finding_accepted IN (0, 1)),
    severity_correct INTEGER CHECK(severity_correct IN (0, 1)),
    corrected_severity TEXT,
    attorney_notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Few-shot exemplar bank for prompt enhancement
CREATE TABLE IF NOT EXISTS exemplar_bank (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    feature TEXT NOT NULL CHECK(feature IN ('valuation', 'demand', 'negligence')),
    input_hash TEXT NOT NULL,
    input_summary TEXT NOT NULL,
    output TEXT NOT NULL,
    quality_score REAL,
    severity TEXT,
    case_type TEXT,
    jurisdiction TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Adaptive system parameters (calibrated from feedback data)
CREATE TABLE IF NOT EXISTS system_parameters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    param_category TEXT NOT NULL,
    param_key TEXT NOT NULL,
    param_value TEXT NOT NULL,
    source TEXT DEFAULT 'manual',
    sample_count INTEGER DEFAULT 0,
    calibrated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(param_category, param_key)
);

-- Email configuration
CREATE TABLE IF NOT EXISTS email_config (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    smtp_host TEXT,
    smtp_port INTEGER DEFAULT 587,
    smtp_username TEXT,
    smtp_password_encrypted TEXT,
    imap_host TEXT,
    imap_port INTEGER DEFAULT 993,
    imap_username TEXT,
    imap_password_encrypted TEXT,
    sender_name TEXT,
    sender_organization TEXT,
    sender_phone TEXT,
    enabled INTEGER DEFAULT 0,
    updated_at TEXT DEFAULT (datetime('now')),
    updated_by TEXT
);

-- Documents table: tracks all files through the vault lifecycle
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    original_path TEXT NOT NULL,
    current_path TEXT,
    file_hash TEXT,
    file_size INTEGER,
    extension TEXT,
    vault_zone TEXT DEFAULT 'incoming'
        CHECK(vault_zone IN ('incoming', 'processing', 'processed', 'failed')),
    status TEXT DEFAULT 'pending'
        CHECK(status IN ('pending', 'processing', 'completed', 'failed')),
    case_ref TEXT,
    category TEXT DEFAULT 'uncategorized',
    contact_id INTEGER,
    run_id TEXT,
    summary_file TEXT,
    notes TEXT,
    uploaded_by TEXT,
    upload_source TEXT DEFAULT 'manual'
        CHECK(upload_source IN ('manual', 'secure_upload', 'email', 'api', 'demo')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    processed_at TEXT,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);

-- Tasks table: replaces tasks.json for durable metadata storage
CREATE TABLE IF NOT EXISTS tasks (
    task_id TEXT PRIMARY KEY,
    agent TEXT NOT NULL,
    model TEXT NOT NULL,
    role TEXT,
    task TEXT NOT NULL,
    context TEXT,
    status TEXT DEFAULT 'queued'
        CHECK(status IN ('queued', 'running', 'completed', 'failed', 'orphan_reset')),
    output_path TEXT,
    error TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    started_at TEXT,
    completed_at TEXT
);

-- Task queue: for reliable asynchronous processing
CREATE TABLE IF NOT EXISTS task_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL UNIQUE,
    priority INTEGER DEFAULT 0,
    locked_by TEXT,
    locked_at TEXT,
    retries INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
);

-- Vector Index for RAG (Searchable chunks)
CREATE TABLE IF NOT EXISTS vector_index (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    section_id TEXT,
    page_number INTEGER,
    content TEXT NOT NULL,
    embedding BLOB,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (run_id) REFERENCES tasks(task_id) ON DELETE CASCADE
);

-- Sales CRM: lead/prospect pipeline tracking
CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    company TEXT,
    phone TEXT,
    lead_source TEXT DEFAULT 'website'
        CHECK(lead_source IN ('website', 'referral', 'demo_download', 'cold_outreach', 'trade_show', 'stripe', 'manual', 'google_sheets', 'excel_import')),
    stage TEXT DEFAULT 'prospect'
        CHECK(stage IN ('prospect', 'demo_requested', 'demo_active', 'trial', 'negotiation', 'closed_won', 'closed_lost')),
    demo_sent_date TEXT,
    demo_expires TEXT,
    demo_cases_used INTEGER DEFAULT 0,
    license_key TEXT,
    license_tier TEXT,
    activated_at TEXT,
    amount_paid INTEGER DEFAULT 0,
    currency TEXT DEFAULT 'usd',
    stripe_session_id TEXT,
    notes TEXT,
    follow_up_date TEXT,
    assigned_to TEXT,
    lost_reason TEXT,
    prospect_tier TEXT,
    license_quantity INTEGER DEFAULT 1,
    wants_support INTEGER DEFAULT 0,
    contact_id INTEGER,
    stage_changed_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);

-- Sales CRM: stage transition history for lead timeline
CREATE TABLE IF NOT EXISTS lead_stage_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL,
    from_stage TEXT,
    to_stage TEXT NOT NULL,
    changed_by TEXT,
    notes TEXT,
    changed_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
);

-- SMTP profiles: multiple email sending configurations
CREATE TABLE IF NOT EXISTS smtp_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_name TEXT NOT NULL UNIQUE,
    smtp_host TEXT NOT NULL,
    smtp_port INTEGER DEFAULT 587,
    smtp_username TEXT NOT NULL,
    smtp_password_encrypted TEXT,
    from_name TEXT NOT NULL,
    from_email TEXT NOT NULL,
    reply_to_email TEXT,
    is_default INTEGER DEFAULT 0,
    daily_send_limit INTEGER DEFAULT 500,
    sends_today INTEGER DEFAULT 0,
    sends_today_date TEXT,
    enabled INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Campaign metadata and status tracking
CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    campaign_type TEXT NOT NULL CHECK(campaign_type IN ('sales_outreach','demo_followup','nurture','announcement')),
    status TEXT DEFAULT 'draft' CHECK(status IN ('draft','generating','review','approved','sending','sent','paused','failed')),
    smtp_profile_id INTEGER,
    subject_template TEXT,
    prompt TEXT NOT NULL,
    target_filter_json TEXT,
    sequence_step INTEGER DEFAULT 1,
    total_steps INTEGER DEFAULT 1,
    delay_days INTEGER DEFAULT 0,
    parent_campaign_id INTEGER,
    total_recipients INTEGER DEFAULT 0,
    total_sent INTEGER DEFAULT 0,
    total_failed INTEGER DEFAULT 0,
    created_by TEXT,
    approved_by TEXT,
    approved_at TEXT,
    sent_at TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (smtp_profile_id) REFERENCES smtp_profiles(id) ON DELETE SET NULL,
    FOREIGN KEY (parent_campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL
);

-- Individual draft messages per lead in a campaign
CREATE TABLE IF NOT EXISTS campaign_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL,
    lead_id INTEGER NOT NULL,
    subject TEXT NOT NULL,
    body_text TEXT NOT NULL,
    status TEXT DEFAULT 'draft' CHECK(status IN ('draft','approved','queued','sending','sent','failed','skipped')),
    personalization_context TEXT,
    message_id TEXT,
    sent_at TEXT,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    email_log_id INTEGER,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
);

-- Agent workflow run history
CREATE TABLE IF NOT EXISTS agent_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name TEXT NOT NULL,
    workflow_name TEXT NOT NULL,
    status TEXT DEFAULT 'running' CHECK(status IN ('running','completed','failed','cancelled')),
    steps_total INTEGER DEFAULT 0,
    steps_completed INTEGER DEFAULT 0,
    step_log_json TEXT,
    trigger TEXT DEFAULT 'manual' CHECK(trigger IN ('manual','cron','api')),
    error_message TEXT,
    started_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT
);

-- Service / Customer Success: active licensed customers
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    company TEXT,
    phone TEXT,
    -- License
    license_key TEXT,
    license_tier TEXT CHECK(license_tier IN ('core', 'pro')),
    license_quantity INTEGER DEFAULT 1,
    activated_at TEXT,
    expires_at TEXT,
    -- Financial
    amount_paid INTEGER DEFAULT 0,
    mrr INTEGER DEFAULT 0,
    arr INTEGER DEFAULT 0,
    currency TEXT DEFAULT 'usd',
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    stripe_session_id TEXT,
    -- Health
    health_score INTEGER DEFAULT 100 CHECK(health_score BETWEEN 0 AND 100),
    health_status TEXT DEFAULT 'healthy' CHECK(health_status IN ('healthy', 'at_risk', 'churned')),
    nps_score INTEGER,
    -- Onboarding
    onboarding_status TEXT DEFAULT 'not_started'
        CHECK(onboarding_status IN ('not_started', 'in_progress', 'completed')),
    onboarding_completed_at TEXT,
    -- Usage
    last_login_at TEXT,
    cases_processed INTEGER DEFAULT 0,
    documents_uploaded INTEGER DEFAULT 0,
    total_logins INTEGER DEFAULT 0,
    -- Support
    open_tickets INTEGER DEFAULT 0,
    total_tickets INTEGER DEFAULT 0,
    avg_response_time_hours REAL,
    -- Lifecycle
    renewal_date TEXT,
    contract_start TEXT,
    contract_end TEXT,
    churned_at TEXT,
    churn_reason TEXT,
    -- Assignment
    csm_assigned TEXT,
    -- Links
    lead_id INTEGER,
    notes TEXT,
    tags TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE SET NULL
);

-- Customer event timeline
CREATE TABLE IF NOT EXISTS customer_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    event_type TEXT NOT NULL CHECK(event_type IN (
        'onboarding_call', 'support_ticket', 'check_in', 'renewal',
        'escalation', 'nps_survey', 'feature_request', 'health_score_change',
        'license_activated', 'payment_received', 'churn', 'note'
    )),
    description TEXT,
    metadata_json TEXT,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Customer health score history for trend tracking
CREATE TABLE IF NOT EXISTS customer_health_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    score INTEGER NOT NULL CHECK(score BETWEEN 0 AND 100),
    factors_json TEXT,
    recorded_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Usage metering events
CREATE TABLE IF NOT EXISTS usage_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    feature TEXT NOT NULL,
    count INTEGER DEFAULT 1,
    recorded_date TEXT DEFAULT (date('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Schema version tracking for migrations
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT DEFAULT (datetime('now'))
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_contacts_status ON contacts(status);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(contact_email);
CREATE INDEX IF NOT EXISTS idx_contacts_upload_token ON contacts(upload_token);
CREATE INDEX IF NOT EXISTS idx_contacts_case_ref ON contacts(patient_case_ref);
CREATE INDEX IF NOT EXISTS idx_email_log_contact ON email_log(contact_id);
CREATE INDEX IF NOT EXISTS idx_access_log_timestamp ON access_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_access_log_username ON access_log(username);
CREATE INDEX IF NOT EXISTS idx_leads_stage ON leads(stage);
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(contact_email);
CREATE INDEX IF NOT EXISTS idx_leads_follow_up ON leads(follow_up_date);
CREATE INDEX IF NOT EXISTS idx_leads_stripe ON leads(stripe_session_id);
CREATE INDEX IF NOT EXISTS idx_lead_history_lead ON lead_stage_history(lead_id);
CREATE INDEX IF NOT EXISTS idx_summary_feedback_run_id ON summary_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_valuation_outcomes_run_id ON valuation_outcomes(run_id);
CREATE INDEX IF NOT EXISTS idx_valuation_outcomes_severity ON valuation_outcomes(predicted_severity);
CREATE INDEX IF NOT EXISTS idx_demand_feedback_run_id ON demand_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_negligence_feedback_run_id ON negligence_feedback(run_id);
CREATE INDEX IF NOT EXISTS idx_exemplar_bank_feature ON exemplar_bank(feature);
CREATE INDEX IF NOT EXISTS idx_exemplar_bank_lookup ON exemplar_bank(feature, severity, case_type);
CREATE INDEX IF NOT EXISTS idx_system_parameters_lookup ON system_parameters(param_category, param_key);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_case_ref ON documents(case_ref);
CREATE INDEX IF NOT EXISTS idx_documents_contact_id ON documents(contact_id);
CREATE INDEX IF NOT EXISTS idx_documents_vault_zone ON documents(vault_zone);
CREATE INDEX IF NOT EXISTS idx_documents_hash ON documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_smtp_profiles_default ON smtp_profiles(is_default);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_type ON campaigns(campaign_type);
CREATE INDEX IF NOT EXISTS idx_campaign_messages_campaign ON campaign_messages(campaign_id);
CREATE INDEX IF NOT EXISTS idx_campaign_messages_lead ON campaign_messages(lead_id);
CREATE INDEX IF NOT EXISTS idx_campaign_messages_status ON campaign_messages(status);
CREATE INDEX IF NOT EXISTS idx_agent_runs_workflow ON agent_runs(workflow_name);
CREATE INDEX IF NOT EXISTS idx_agent_runs_status ON agent_runs(status);
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(contact_email);
CREATE INDEX IF NOT EXISTS idx_customers_health_status ON customers(health_status);
CREATE INDEX IF NOT EXISTS idx_customers_tier ON customers(license_tier);
CREATE INDEX IF NOT EXISTS idx_customers_stripe ON customers(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_customers_lead ON customers(lead_id);
CREATE INDEX IF NOT EXISTS idx_customer_events_customer ON customer_events(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_events_type ON customer_events(event_type);
CREATE INDEX IF NOT EXISTS idx_customer_health_scores_customer ON customer_health_scores(customer_id);
CREATE INDEX IF NOT EXISTS idx_usage_events_customer ON usage_events(customer_id);
CREATE INDEX IF NOT EXISTS idx_usage_events_feature ON usage_events(feature);
CREATE INDEX IF NOT EXISTS idx_usage_events_date ON usage_events(recorded_date);
"""


def _create_connection(db_path: str = None) -> sqlite3.Connection:
    """Create a new database connection with production settings."""
    path = db_path or str(TRACKING_DB)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row

    # Enable WAL mode for concurrent reads during writes
    conn.execute("PRAGMA journal_mode=WAL")
    # Enable foreign key enforcement
    conn.execute("PRAGMA foreign_keys=ON")
    # Faster sync (safe with WAL mode)
    conn.execute("PRAGMA synchronous=NORMAL")
    # Larger cache for better read performance
    conn.execute("PRAGMA cache_size=-8000")  # 8MB

    return conn


def get_db(db_path: str = None) -> sqlite3.Connection:
    """Get a database connection. Creates new one per call for thread safety."""
    return _create_connection(db_path)


@contextmanager
def transaction(db_path: str = None):
    """
    Context manager for database transactions.
    Uses BEGIN IMMEDIATE to prevent 'database is locked' during concurrent writes.
    """
    import time
    max_retries = 5
    for attempt in range(max_retries):
        try:
            conn = _create_connection(db_path)
            # Force a write lock immediately to prevent mid-transaction deadlocks
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
                conn.commit()
                return
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(0.2 * (attempt + 1))
                continue
            raise


def _migrate_schema(conn):
    """Apply schema migrations for columns added after initial release."""
    # Contacts table migrations
    contacts_cols = {row[1] for row in conn.execute("PRAGMA table_info(contacts)").fetchall()}

    contacts_migrations = [
        ("source", "ALTER TABLE contacts ADD COLUMN source TEXT DEFAULT 'manual'"),
        ("excel_row", "ALTER TABLE contacts ADD COLUMN excel_row INTEGER"),
    ]

    for col_name, sql in contacts_migrations:
        if col_name not in contacts_cols:
            conn.execute(sql)

    # Email_log table migrations
    email_log_cols = {row[1] for row in conn.execute("PRAGMA table_info(email_log)").fetchall()}

    email_log_migrations = [
        ("has_attachments", "ALTER TABLE email_log ADD COLUMN has_attachments INTEGER DEFAULT 0"),
        ("attachment_paths", "ALTER TABLE email_log ADD COLUMN attachment_paths TEXT"),
    ]

    for col_name, sql in email_log_migrations:
        if col_name not in email_log_cols:
            conn.execute(sql)

    # Leads table: rebuild if CHECK constraint is outdated (missing google_sheets source)
    needs_rebuild = False
    try:
        conn.execute(
            "INSERT INTO leads (contact_name, contact_email, lead_source, stage) VALUES ('__test__', '__test__@test.com', 'google_sheets', 'prospect')"
        )
        conn.execute("DELETE FROM leads WHERE contact_email = '__test__@test.com'")
        conn.commit()
    except Exception:
        needs_rebuild = True
        conn.rollback()

    if needs_rebuild:
        conn.executescript("""
PRAGMA foreign_keys = OFF;
ALTER TABLE leads RENAME TO _leads_migrate;
CREATE TABLE leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    company TEXT,
    phone TEXT,
    lead_source TEXT DEFAULT 'website'
        CHECK(lead_source IN ('website', 'referral', 'demo_download', 'cold_outreach', 'trade_show', 'stripe', 'manual', 'google_sheets', 'excel_import')),
    stage TEXT DEFAULT 'prospect'
        CHECK(stage IN ('prospect', 'demo_requested', 'demo_active', 'trial', 'negotiation', 'closed_won', 'closed_lost')),
    demo_sent_date TEXT,
    demo_expires TEXT,
    demo_cases_used INTEGER DEFAULT 0,
    license_key TEXT,
    license_tier TEXT,
    activated_at TEXT,
    amount_paid INTEGER DEFAULT 0,
    currency TEXT DEFAULT 'usd',
    stripe_session_id TEXT,
    notes TEXT,
    follow_up_date TEXT,
    assigned_to TEXT,
    lost_reason TEXT,
    prospect_tier TEXT,
    license_quantity INTEGER DEFAULT 1,
    wants_support INTEGER DEFAULT 0,
    contact_id INTEGER,
    stage_changed_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);
INSERT INTO leads (id, contact_name, contact_email, company, phone, lead_source, stage,
    demo_sent_date, demo_expires, demo_cases_used, license_key, license_tier, activated_at,
    amount_paid, currency, stripe_session_id, notes, follow_up_date, assigned_to, lost_reason,
    contact_id, stage_changed_at, created_at, updated_at)
    SELECT id, contact_name, contact_email, company, phone, lead_source, stage,
    demo_sent_date, demo_expires, demo_cases_used, license_key, license_tier, activated_at,
    amount_paid, currency, stripe_session_id, notes, follow_up_date, assigned_to, lost_reason,
    contact_id, stage_changed_at, created_at, updated_at FROM _leads_migrate;
DROP TABLE _leads_migrate;
PRAGMA foreign_keys = ON;
        """)

    # Fix lead_stage_history FK if it still references a renamed table (e.g. leads_old)
    lsh_sql = conn.execute("SELECT sql FROM sqlite_master WHERE name='lead_stage_history'").fetchone()
    if lsh_sql and 'leads_old' in (lsh_sql[0] or ''):
        conn.execute("PRAGMA foreign_keys = OFF")
        conn.execute("ALTER TABLE lead_stage_history RENAME TO _lsh_fk_fix")
        conn.execute("""
            CREATE TABLE lead_stage_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_id INTEGER NOT NULL,
                from_stage TEXT,
                to_stage TEXT NOT NULL,
                changed_by TEXT,
                notes TEXT,
                changed_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
            )
        """)
        conn.execute("INSERT INTO lead_stage_history SELECT * FROM _lsh_fk_fix")
        conn.execute("DROP TABLE _lsh_fk_fix")
        conn.execute("PRAGMA foreign_keys = ON")

    # Leads table: add prospect fields if missing
    leads_cols = {row[1] for row in conn.execute("PRAGMA table_info(leads)").fetchall()}
    for col, sql in [
        ("prospect_tier", "ALTER TABLE leads ADD COLUMN prospect_tier TEXT"),
        ("license_quantity", "ALTER TABLE leads ADD COLUMN license_quantity INTEGER DEFAULT 1"),
        ("wants_support", "ALTER TABLE leads ADD COLUMN wants_support INTEGER DEFAULT 0"),
    ]:
        if col not in leads_cols:
            conn.execute(sql)

    # Seed customers from closed_won leads with license keys (v8 migration)
    try:
        customer_count = conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        if customer_count == 0:
            won_leads = conn.execute("""
                SELECT id, contact_name, contact_email, company, phone,
                       license_key, license_tier, license_quantity, activated_at,
                       amount_paid, currency, stripe_session_id
                FROM leads
                WHERE stage = 'closed_won' AND license_key IS NOT NULL
            """).fetchall()
            for lead in won_leads:
                conn.execute("""
                    INSERT INTO customers (contact_name, contact_email, company, phone,
                        license_key, license_tier, license_quantity, activated_at,
                        amount_paid, currency, stripe_session_id, lead_id,
                        health_status, onboarding_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'healthy', 'not_started')
                """, (
                    lead["contact_name"], lead["contact_email"], lead["company"],
                    lead["phone"], lead["license_key"], lead["license_tier"],
                    lead["license_quantity"], lead["activated_at"],
                    lead["amount_paid"], lead["currency"],
                    lead["stripe_session_id"], lead["id"],
                ))
                # Log activation event
                cust_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.execute("""
                    INSERT INTO customer_events (customer_id, event_type, description, created_by)
                    VALUES (?, 'license_activated', 'Migrated from closed_won lead', 'system')
                """, (cust_id,))
    except Exception:
        pass  # Tables may not exist yet on first run

    # Seed smtp_profiles from existing email_config if table is empty
    try:
        profile_count = conn.execute("SELECT COUNT(*) FROM smtp_profiles").fetchone()[0]
        if profile_count == 0:
            ec = conn.execute("SELECT * FROM email_config WHERE id = 1").fetchone()
            if ec and ec["smtp_host"]:
                conn.execute("""
                    INSERT INTO smtp_profiles (profile_name, smtp_host, smtp_port,
                        smtp_username, smtp_password_encrypted, from_name, from_email,
                        is_default, enabled)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
                """, (
                    "Medical Records",
                    ec["smtp_host"],
                    ec["smtp_port"] or 587,
                    ec["smtp_username"] or "",
                    ec["smtp_password_encrypted"],
                    ec["sender_name"] or "MedRecords AI",
                    ec["smtp_username"] or "",
                    ec["enabled"] or 0,
                ))
    except Exception:
        pass  # Tables may not exist yet on first run

    conn.commit()


def init_db(db_path: str = None):
    """
    Initialize the database schema. Safe to call multiple times
    (uses CREATE TABLE IF NOT EXISTS).
    """
    conn = _create_connection(db_path)
    try:
        conn.executescript(SCHEMA_SQL)

        # Apply migrations for existing databases
        _migrate_schema(conn)

        # Record schema version
        current = conn.execute(
            "SELECT MAX(version) FROM schema_version"
        ).fetchone()[0]

        if current is None or current < SCHEMA_VERSION:
            conn.execute(
                "INSERT OR REPLACE INTO schema_version (version) VALUES (?)",
                (SCHEMA_VERSION,),
            )
            conn.commit()
    finally:
        conn.close()


def log_access(username: str, action: str, resource_type: str,
               resource_id: str = None, ip_address: str = None,
               details: str = None, db_path: str = None):
    """
    Log a data access event for HIPAA compliance.
    Non-blocking: silently fails if database is unavailable.
    """
    try:
        with transaction(db_path) as conn:
            conn.execute(
                """INSERT INTO access_log
                   (username, action, resource_type, resource_id, ip_address, details)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (username, action, resource_type, resource_id, ip_address, details),
            )
    except Exception:
        pass  # Access logging should never break the main flow


def get_schema_version(db_path: str = None) -> int:
    """Get the current schema version."""
    try:
        conn = _create_connection(db_path)
        version = conn.execute(
            "SELECT MAX(version) FROM schema_version"
        ).fetchone()[0]
        conn.close()
        return version or 0
    except Exception:
        return 0


# ── Queue Management ─────────────────────────────────────────────────────────

def enqueue_task(task_id, priority=0):
    """Add a task ID to the processing queue."""
    with transaction() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO task_queue (task_id, priority) VALUES (?, ?)",
            (task_id, priority)
        )


def pop_task(worker_id):
    """
    Atomically find and lock the next available task in the queue.
    Uses 'locked_by' and 'locked_at' for basic distributed locking.
    """
    now = datetime.now(timezone.utc).isoformat()
    with transaction() as conn:
        # 1. Find a task that is not locked, or locked but timed out (e.g. 5 minutes old)
        # We prioritize by 'priority' then 'created_at'
        timeout_limit = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        
        row = conn.execute("""
            SELECT task_id FROM task_queue 
            WHERE locked_by IS NULL 
               OR (locked_at IS NOT NULL AND locked_at < ?)
            ORDER BY priority DESC, created_at ASC 
            LIMIT 1
        """, (timeout_limit,)).fetchone()
        
        if not row:
            return None
            
        task_id = row["task_id"]
        
        # 2. Lock it
        conn.execute("""
            UPDATE task_queue 
            SET locked_by = ?, locked_at = ?, retries = retries + 1 
            WHERE task_id = ?
        """, (worker_id, now, task_id))
        
        return task_id


def remove_from_queue(task_id):
    """Remove a task from the queue (on success or permanent failure)."""
    with transaction() as conn:
        conn.execute("DELETE FROM task_queue WHERE task_id = ?", (task_id,))


def release_task(task_id):
    """Unlock a task so it can be retried by another worker."""
    with transaction() as conn:
        conn.execute(
            "UPDATE task_queue SET locked_by = NULL, locked_at = NULL WHERE task_id = ?",
            (task_id,)
        )
