#!/usr/bin/env python3
"""
agent_runner.py -- Standalone daemon for scheduled workflow execution.

Reads workflow schedules from config.yaml and runs them on cron-like schedules.
Each workflow is executed via subprocess calls to medcli.py, with results
logged to the agent_runs table.

Usage:
  python agent_runner.py --once <workflow_name>   # Run one workflow and exit
  python agent_runner.py --daemon                 # Loop checking schedules
  python agent_runner.py --list                   # Show scheduled workflows
"""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

# Ensure project root is on path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from db import init_db, transaction, get_db


def load_config():
    """Load config.yaml."""
    import yaml
    config_path = os.path.join(BASE_DIR, "config.yaml")
    try:
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def log(msg):
    """Log to stderr with timestamp."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    sys.stderr.write(f"[agent-runner {ts}] {msg}\n")
    sys.stderr.flush()


def run_workflow(workflow_name, trigger="manual"):
    """Execute a workflow via medcli subprocess."""
    cmd = [sys.executable, os.path.join(BASE_DIR, "medcli.py"), "--format", "json",
           "agent", "run", workflow_name]

    log(f"Starting workflow '{workflow_name}' (trigger={trigger})")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=BASE_DIR,
            timeout=600,  # 10 minute timeout per workflow
        )

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()

        if stderr:
            for line in stderr.split("\n"):
                log(f"  {line}")

        if stdout:
            try:
                output = json.loads(stdout)
                if output.get("ok"):
                    data = output.get("data", {})
                    log(f"Workflow '{workflow_name}' completed: {data.get('steps_completed', '?')}/{data.get('steps_total', '?')} steps")
                else:
                    err = output.get("error", {})
                    log(f"Workflow '{workflow_name}' failed: {err.get('message', 'unknown error')}")
                return output
            except json.JSONDecodeError:
                log(f"Non-JSON output from workflow: {stdout[:200]}")

        return {"ok": result.returncode == 0}

    except subprocess.TimeoutExpired:
        log(f"Workflow '{workflow_name}' timed out after 600s")
        return {"ok": False, "error": {"code": "timeout", "message": "Workflow timed out"}}
    except Exception as e:
        log(f"Workflow '{workflow_name}' error: {e}")
        return {"ok": False, "error": {"code": "error", "message": str(e)}}


def parse_cron(cron_expr):
    """Parse a simple cron expression and check if it matches the current time.

    Supports: minute hour day_of_month month day_of_week
    Values: number, * (any), */N (every N)
    """
    parts = cron_expr.strip().split()
    if len(parts) != 5:
        return False

    now = datetime.now(timezone.utc)
    current = [now.minute, now.hour, now.day, now.month, now.isoweekday() % 7]  # 0=Sunday

    for i, part in enumerate(parts):
        if part == "*":
            continue
        if part.startswith("*/"):
            try:
                divisor = int(part[2:])
                if current[i] % divisor != 0:
                    return False
            except ValueError:
                return False
        else:
            try:
                values = set()
                for segment in part.split(","):
                    if "-" in segment:
                        lo, hi = segment.split("-", 1)
                        values.update(range(int(lo), int(hi) + 1))
                    else:
                        values.add(int(segment))
                if current[i] not in values:
                    return False
            except ValueError:
                return False

    return True


def run_daemon():
    """Main daemon loop — checks schedules every 60s."""
    log("Agent runner daemon starting")
    init_db()

    # Track last run times to avoid duplicate runs within the same minute
    last_runs = {}

    while True:
        try:
            config = load_config()
            workflows = config.get("agent_workflows", {})

            now_key = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")

            for wf_name, wf_info in workflows.items():
                schedule = wf_info.get("schedule")
                if not schedule:
                    continue

                # Skip if already ran this minute
                run_key = f"{wf_name}:{now_key}"
                if run_key in last_runs:
                    continue

                if parse_cron(schedule):
                    log(f"Schedule match for '{wf_name}' (cron: {schedule})")
                    last_runs[run_key] = True
                    run_workflow(wf_name, trigger="cron")

            # Prune old last_runs entries (keep last 100)
            if len(last_runs) > 100:
                keys = sorted(last_runs.keys())
                for k in keys[:-50]:
                    del last_runs[k]

        except Exception as e:
            log(f"Daemon loop error: {e}")

        time.sleep(60)


def list_scheduled():
    """Show all workflows with schedules."""
    config = load_config()
    workflows = config.get("agent_workflows", {})

    print(f"{'Workflow':<25} {'Schedule':<20} {'Steps':<6} Description")
    print("-" * 80)

    for name, info in sorted(workflows.items()):
        schedule = info.get("schedule", "(none)")
        steps = len(info.get("steps", []))
        desc = info.get("description", "")
        print(f"{name:<25} {schedule:<20} {steps:<6} {desc}")


def main():
    parser = argparse.ArgumentParser(description="MedRecords AI Agent Runner")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--once", metavar="WORKFLOW", help="Run a single workflow and exit")
    group.add_argument("--daemon", action="store_true", help="Run as daemon checking cron schedules")
    group.add_argument("--list", action="store_true", help="List scheduled workflows")

    args = parser.parse_args()

    if args.list:
        list_scheduled()
    elif args.once:
        init_db()
        result = run_workflow(args.once, trigger="manual")
        sys.exit(0 if result.get("ok") else 1)
    elif args.daemon:
        try:
            run_daemon()
        except KeyboardInterrupt:
            log("Daemon stopped by user")
            sys.exit(0)


if __name__ == "__main__":
    main()
