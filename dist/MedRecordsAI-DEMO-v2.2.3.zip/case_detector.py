import re
import os
from difflib import SequenceMatcher
_CASE_PATTERNS = [re.compile('(CASE[_\\-\\s]?\\d{2,}[_\\-]?\\d{0,})', re.IGNORECASE), re.compile('(FILE[_\\-\\s]?\\d{4,})', re.IGNORECASE), re.compile('(CLAIM[_\\-\\s]?\\d{4,})', re.IGNORECASE), re.compile('(DOCKET[_\\-\\s]?\\d+)', re.IGNORECASE)]
_MRN_PATTERNS = [re.compile('(MRN[_\\-\\s]?\\d{4,})', re.IGNORECASE), re.compile('(PID[_\\-\\s]?\\d{4,})', re.IGNORECASE), re.compile('(PT[_\\-\\s]?ID[_\\-\\s]?\\d{4,})', re.IGNORECASE), re.compile('(PATIENT[_\\-\\s]?\\d{4,})', re.IGNORECASE)]
_NAME_PATTERN = re.compile('^([A-Z][a-z]+)[_\\-,\\s]+([A-Z][a-z]+)', re.UNICODE)

def _normalize(text: str) -> str:
    text = os.path.splitext(text)[0]
    return re.sub('[_\\-.,]+', ' ', text).strip().lower()

def _tokenize(text: str) -> set:
    return {t for t in _normalize(text).split() if len(t) >= 2}

def suggest_case_ref(filename: str, existing_cases: list[str] | None=None) -> dict | None:
    if not filename:
        return None
    basename = os.path.basename(filename)
    existing_cases = existing_cases or []
    existing_lower = {c.lower(): c for c in existing_cases if c}
    for pat in _CASE_PATTERNS:
        m = pat.search(basename)
        if m:
            raw = m.group(1).strip()
            normalized = re.sub('[\\s]+', '-', raw).upper()
            for el, orig in existing_lower.items():
                if normalized.lower() == el or normalized.lower().replace('-', '') == el.replace('-', ''):
                    return {'suggestion': orig, 'source': 'case_pattern', 'confidence': 'high'}
            return {'suggestion': normalized, 'source': 'case_pattern', 'confidence': 'high'}
    for pat in _MRN_PATTERNS:
        m = pat.search(basename)
        if m:
            raw = m.group(1).strip()
            normalized = re.sub('[\\s]+', '-', raw).upper()
            for el, orig in existing_lower.items():
                if normalized.lower() in el or el in normalized.lower():
                    return {'suggestion': orig, 'source': 'mrn_pattern', 'confidence': 'medium'}
            return {'suggestion': normalized, 'source': 'mrn_pattern', 'confidence': 'medium'}
    name_match = _NAME_PATTERN.match(basename)
    if name_match and existing_cases:
        last = name_match.group(1).lower()
        first = name_match.group(2).lower()
        for el, orig in existing_lower.items():
            el_norm = _normalize(el)
            if last in el_norm and first in el_norm:
                return {'suggestion': orig, 'source': 'name_match', 'confidence': 'medium'}
            if last in el_norm:
                return {'suggestion': orig, 'source': 'name_match', 'confidence': 'low'}
    if existing_cases:
        file_tokens = _tokenize(basename)
        noise = {'medical', 'records', 'record', 'report', 'pdf', 'doc', 'scan', 'copy', 'page', 'pages', 'file', 'files', 'the', 'and', 'for', 'from', 'with'}
        file_tokens -= noise
        if len(file_tokens) >= 2:
            best_match = None
            best_score = 0
            for case in existing_cases:
                case_tokens = _tokenize(case) - noise
                if not case_tokens:
                    continue
                overlap = file_tokens & case_tokens
                if len(overlap) >= 2:
                    score = len(overlap) / max(len(file_tokens), len(case_tokens))
                    if score > best_score:
                        best_score = score
                        best_match = case
            if best_match and best_score >= 0.3:
                return {'suggestion': best_match, 'source': 'token_overlap', 'confidence': 'low'}
        file_norm = _normalize(basename)
        for case in existing_cases:
            case_norm = _normalize(case)
            ratio = SequenceMatcher(None, file_norm, case_norm).ratio()
            if ratio >= 0.6:
                return {'suggestion': case, 'source': 'fuzzy_match', 'confidence': 'low'}
    return None