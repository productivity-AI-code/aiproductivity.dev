"""
demand_generator.py -- Generates litigation demand packages from summarized case data.

Produces a complete demand letter package including:
- Liability narrative
- Injury & diagnosis summary
- Treatment chronology (narrative form)
- Medical bills summary table
- Pain & suffering / damages narrative
- Settlement demand with multiplier calculation
- Exhibit list with source references

Outputs: DOCX (editable), PDF-ready text, billing XLSX, exhibit list.

Usage:
    from demand_generator import generate_demand_package
    result = generate_demand_package(summary_data, config, options)
"""

import io
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

logger = logging.getLogger("demand_generator")

BASE_DIR = Path(__file__).parent


def _normalize_summary_data(summary_data):
    """Normalize the nested summary structure for uniform data access."""
    if not isinstance(summary_data, dict):
        return summary_data
    summarizer_output = summary_data.get("summary", {})
    if not isinstance(summarizer_output, dict):
        return summary_data
    inner_summary = summarizer_output.get("summary", {})
    if isinstance(inner_summary, dict) and inner_summary.get("active_diagnoses") is not None:
        merged = dict(summarizer_output)
        for key, val in inner_summary.items():
            if key not in merged or key in ("active_diagnoses", "medications", "key_findings",
                "timeline_gaps", "chronological_events", "master_chronology", "overall_confidence"):
                merged[key] = val
        result = dict(summary_data)
        result["summary"] = merged
        if "billing_data" not in result and "billing_data" in merged:
            result["billing_data"] = merged["billing_data"]
        if "alerts" not in result and "alerts" in merged:
            result["alerts"] = merged["alerts"]
        return result
    return summary_data


# ── Case Type Templates ─────────────────────────────────────────────────────

CASE_TEMPLATES = {
    "mva": {
        "name": "Motor Vehicle Accident",
        "liability_intro": "On {incident_date}, {plaintiff} was involved in a motor vehicle collision caused by the negligence of the at-fault party.",
        "liability_standard": "The at-fault driver breached their duty of care by failing to operate their vehicle in a safe and prudent manner, directly and proximately causing the collision and resulting injuries to {plaintiff}.",
        "causation_language": "As a direct and proximate result of the {incident_date} motor vehicle collision,",
    },
    "slip_fall": {
        "name": "Slip and Fall / Premises Liability",
        "liability_intro": "On {incident_date}, {plaintiff} sustained injuries due to a dangerous condition on premises owned, operated, and/or maintained by the responsible party.",
        "liability_standard": "The property owner/operator had a duty to maintain the premises in a reasonably safe condition and to warn of known hazards. This duty was breached, directly and proximately causing the injuries sustained by {plaintiff}.",
        "causation_language": "As a direct and proximate result of the hazardous condition and the property owner's negligence,",
    },
    "med_mal": {
        "name": "Medical Malpractice",
        "liability_intro": "On or about {incident_date}, {plaintiff} was a patient under the care of the defendant healthcare provider(s). During the course of treatment, the standard of care was breached.",
        "liability_standard": "The healthcare provider(s) deviated from the accepted standard of medical care, which a reasonably competent provider in the same specialty would have followed under similar circumstances. This deviation directly and proximately caused harm to {plaintiff}.",
        "causation_language": "As a direct and proximate result of the healthcare provider's deviation from the standard of care,",
    },
    "workers_comp": {
        "name": "Workers' Compensation",
        "liability_intro": "On {incident_date}, {plaintiff} sustained injuries in the course and scope of their employment.",
        "liability_standard": "The injury arose out of and in the course of employment. The employee is entitled to medical benefits, temporary disability, and permanent disability as applicable under the workers' compensation statutes.",
        "causation_language": "As a direct result of the workplace injury occurring on {incident_date},",
    },
    "dog_bite": {
        "name": "Dog Bite / Animal Attack",
        "liability_intro": "On {incident_date}, {plaintiff} was attacked and bitten by an animal owned and/or harbored by the responsible party.",
        "liability_standard": "Under applicable strict liability and/or negligence principles, the animal owner is liable for injuries caused by their animal. The owner knew or should have known of the animal's dangerous propensities.",
        "causation_language": "As a direct and proximate result of the animal attack on {incident_date},",
    },
    "product_liability": {
        "name": "Product Liability",
        "liability_intro": "On or about {incident_date}, {plaintiff} was injured by a defective product designed, manufactured, and/or distributed by the responsible party.",
        "liability_standard": "The product was defective in design, manufacture, or labeling/warning, and was unreasonably dangerous to users. The defect existed when the product left the defendant's control and was a producing cause of the injuries.",
        "causation_language": "As a direct and proximate result of the defective product,",
    },
}

# State-specific demand letter requirements — all 50 states + DC
STATE_CONFIGS = {
    "default": {
        "response_deadline_days": 30,
        "interest_statute": "",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "AL": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Alabama Code Section 8-8-1",
        "demand_requirements": "",
        "comparative_fault_standard": "contributory",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "AK": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Alaska Statute Section 09.30.070",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Non-economic damages capped at the greater of $400,000 or the injured person's life expectancy in years multiplied by $8,000",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "AZ": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Arizona Revised Statutes Section 44-1201",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "AR": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Arkansas Code Section 16-65-114",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "CA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to California Civil Code Section 3291",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Medical malpractice non-economic damages capped per MICRA (Cal. Civ. Code Section 3333.2, as amended by AB 35, effective 2023 with $40,000/year increases for non-death cases; verify current cap amount at time of filing)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "CO": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Colorado Revised Statutes Section 5-12-102",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages capped at $1,500,000 (per HB24-1472 effective Jan 1, 2025, C.R.S. Section 13-21-102.5); medical malpractice total damages cap per C.R.S. Section 13-64-302 (verify current inflation-adjusted amount at time of filing)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "CT": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Connecticut General Statutes Section 37-3a",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "DE": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to 6 Delaware Code Section 2301(a)",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "FL": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Florida common law and Florida Statute Section 768.736",
        "demand_requirements": "This letter constitutes a pre-suit demand. Pursuant to Florida Statute Section 768.79 (Offer of Judgment), failure to accept a reasonable settlement offer may result in attorney fee liability. For medical malpractice claims, pre-suit notice under Fla. Stat. Section 766.106 is required.",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 2,
    },
    "GA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Georgia Code Section 51-12-14",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "HI": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Hawaii Revised Statutes Section 636-16",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages in tort actions capped at $375,000 per plaintiff (HRS Section 663-8.7)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "ID": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Idaho Code Section 28-22-104",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages capped at $503,957 (adjusted annually per Idaho Code Section 6-1603)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "IL": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to 815 ILCS 205/2",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "IN": {
        "response_deadline_days": 90,
        "interest_statute": "pursuant to Indiana Code Section 34-51-4-8",
        "demand_requirements": "For medical malpractice claims, a proposed complaint must be filed with the Indiana Department of Insurance before filing suit, per Indiana Code Section 34-18-8-4.",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Medical malpractice total damages capped at $1,800,000 per occurrence (Ind. Code Section 34-18-14-3, as amended). Non-economic damages in general tort capped where comparative fault applies.",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 2,
    },
    "IA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Iowa Code Section 535.3",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "KS": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Kansas Statutes Section 16-201",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages capped at $325,000 for personal injury (K.S.A. Section 60-19a02); medical malpractice non-economic damages capped at $325,000",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "KY": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Kentucky Revised Statutes Section 360.010",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 1,
    },
    "LA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Louisiana Civil Code Article 2000 and Louisiana Revised Statutes Section 13:4203",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Medical malpractice total damages (exclusive of future medical) capped at $500,000 per La. R.S. Section 40:1231.2",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 1,
    },
    "ME": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to 14 Maine Revised Statutes Section 1602-C",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 6,
    },
    "MD": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Maryland Code, Courts & Judicial Proceedings Section 11-107",
        "demand_requirements": "",
        "comparative_fault_standard": "contributory",
        "damages_cap": "Non-economic damages capped at $920,000 (adjusted annually per Md. Code, Cts. & Jud. Proc. Section 11-108)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "MA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Massachusetts General Laws Chapter 231, Section 6B (12% from date of commencement of action)",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Medical malpractice non-economic damages capped at $500,000 unless substantial impairment (M.G.L. c. 231, Section 60H)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "MI": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Michigan Compiled Laws Section 600.6013",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $521,710 for general tort; $948,050 if permanently impaired (adjusted biennially per MCL Section 600.1483)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "MN": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Minnesota Statutes Section 549.09",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "MS": {
        "response_deadline_days": 60,
        "interest_statute": "pursuant to Mississippi Code Section 75-17-7",
        "demand_requirements": "For medical malpractice claims, a 60-day pre-suit notice is required per Mississippi Code Section 15-1-36(15).",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Non-economic damages in civil actions capped at $1,000,000 (Miss. Code Section 11-1-60)",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 3,
    },
    "MO": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Missouri Revised Statutes Section 408.040",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Medical malpractice non-economic damages capped at $400,000 per occurrence ($700,000 for catastrophic injury) under Mo. Rev. Stat. Section 538.210 (adjusted for inflation); no statutory cap for general PI tort claims",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 5,
    },
    "MT": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Montana Code Section 27-1-211",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $250,000 (Mont. Code Section 25-9-411)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "NE": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Nebraska Revised Statutes Section 45-103",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Medical malpractice total damages capped at $2,250,000 (Neb. Rev. Stat. Section 44-2825)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 4,
    },
    "NV": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Nevada Revised Statutes Section 17.130",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Medical malpractice non-economic damages capped at $350,000 (NRS Section 41A.035)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "NH": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to New Hampshire Revised Statutes Section 524:1-b",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $875,000 (RSA Section 508:4-d)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "NJ": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to New Jersey Court Rule 4:42-11(b)",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "NM": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to New Mexico Statutes Section 56-8-4",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "Medical malpractice damages capped at $600,000 (NMSA Section 41-5-6)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "NY": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to CPLR Section 5001",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "NC": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to North Carolina General Statutes Section 24-5",
        "demand_requirements": "",
        "comparative_fault_standard": "contributory",
        "damages_cap": "Medical malpractice non-economic damages capped at $500,000 (N.C.G.S. Section 90-21.19); no cap for general PI",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "ND": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to North Dakota Century Code Section 32-03.2-11",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages capped at $500,000 (N.D.C.C. Section 32-42-02)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 6,
    },
    "OH": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Ohio Revised Code Section 1343.03",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at the greater of $250,000 or three times the economic damages, up to $350,000 per plaintiff (ORC Section 2315.18); does not apply to permanent and substantial physical deformity or disability",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "OK": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to 12 Oklahoma Statutes Section 727.1",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $350,000 (12 Okla. Stat. Section 19.1); does not apply to wrongful death",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "OR": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Oregon Revised Statutes Section 82.010",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages cap under ORS Section 31.710 held unconstitutional for PI claims (Busch v. McInnis Waste Systems, 2020); cap applies only to wrongful death claims",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "PA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Pennsylvania Rule of Civil Procedure 238 (delay damages)",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "RI": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Rhode Island General Laws Section 9-21-10",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "SC": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to South Carolina Code Section 34-31-20",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $350,000 per defendant in medical malpractice; $1,050,000 aggregate (S.C. Code Section 15-32-220)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "SD": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to South Dakota Codified Laws Section 21-1-13.1",
        "demand_requirements": "",
        "comparative_fault_standard": "slight_vs_gross",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "TN": {
        "response_deadline_days": 60,
        "interest_statute": "pursuant to Tennessee Code Section 47-14-123",
        "demand_requirements": "For medical malpractice claims, a 60-day pre-suit notice is required per Tennessee Code Section 29-26-121.",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages capped at $750,000; $1,000,000 for catastrophic injury (Tenn. Code Section 29-39-102)",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 1,
    },
    "TX": {
        "response_deadline_days": 60,
        "interest_statute": "pursuant to Texas Finance Code Section 304.003",
        "demand_requirements": "For medical malpractice claims, a 60-day pre-suit notice is required per Texas Civil Practice & Remedies Code Section 74.051.",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Medical malpractice non-economic damages capped at $250,000 per defendant, $500,000 aggregate (Tex. Civ. Prac. & Rem. Code Section 74.301)",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 2,
    },
    "UT": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Utah Code Section 15-1-1",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_50",
        "damages_cap": "Non-economic damages in medical malpractice capped at $450,000 (Utah Code Section 78B-3-410)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 4,
    },
    "VT": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to 9 Vermont Statutes Section 41a",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "VA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Virginia Code Section 8.01-382",
        "demand_requirements": "",
        "comparative_fault_standard": "contributory",
        "damages_cap": "Medical malpractice total damages capped at $2,550,000 (Va. Code Section 8.01-581.15, adjusted annually through 2031)",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 2,
    },
    "WA": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Revised Code of Washington Section 4.56.110",
        "demand_requirements": "",
        "comparative_fault_standard": "pure_comparative",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "WV": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to West Virginia Code Section 56-6-31",
        "demand_requirements": "Pre-suit screening required for medical malpractice claims per West Virginia Code Section 55-7B-6.",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages in medical malpractice capped at $250,000 (W. Va. Code Section 55-7B-8); general non-economic damages capped at $500,000 (W. Va. Code Section 55-7-13d)",
        "pre_suit_notice_required": True,
        "statute_of_limitations_years": 2,
    },
    "WI": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Wisconsin Statutes Section 807.01(4)",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "Non-economic damages capped at $750,000 for medical malpractice (Wis. Stat. Section 893.55(4)(d))",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
    "WY": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to Wyoming Statutes Section 40-14-106",
        "demand_requirements": "",
        "comparative_fault_standard": "modified_51",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 4,
    },
    "DC": {
        "response_deadline_days": 30,
        "interest_statute": "pursuant to District of Columbia Code Section 15-108",
        "demand_requirements": "",
        "comparative_fault_standard": "contributory",
        "damages_cap": "",
        "pre_suit_notice_required": False,
        "statute_of_limitations_years": 3,
    },
}


def _get_state_config(state_code):
    """Get state-specific config, falling back to defaults."""
    return STATE_CONFIGS.get(state_code, STATE_CONFIGS["default"])


# ── LLM Narrative Generation ────────────────────────────────────────────────

def _generate_narrative(summary_data, options, config):
    """Use Claude to generate the demand letter narrative from summary data."""
    from dispatch import call_claude

    case_type = options.get("case_type", "mva")
    template = CASE_TEMPLATES.get(case_type, CASE_TEMPLATES["mva"])
    state_code = options.get("state", "default")
    state_cfg = _get_state_config(state_code)

    plaintiff = options.get("plaintiff_name", "[PLAINTIFF]")
    incident_date = options.get("incident_date", "[DATE OF INCIDENT]")
    demand_amount = options.get("demand_amount")
    multiplier = options.get("multiplier", 3.0)
    response_days = options.get("response_deadline_days", state_cfg["response_deadline_days"])

    summary = summary_data.get("summary", {})
    billing = summary_data.get("billing_data", {})
    alerts = summary_data.get("alerts", [])

    # Build context for the LLM
    chronology_text = ""
    for event in summary.get("chronological_events", []):
        if isinstance(event, dict):
            date = event.get("date", "Unknown date")
            desc = event.get("description", event.get("event", ""))
            provider = event.get("provider", "")
            chronology_text += f"- {date}: {desc}"
            if provider:
                chronology_text += f" (Provider: {provider})"
            chronology_text += "\n"

    diagnoses_text = ""
    for dx in summary.get("active_diagnoses", []):
        if isinstance(dx, dict):
            diagnoses_text += f"- {dx.get('diagnosis', dx.get('text', str(dx)))}\n"
        elif isinstance(dx, str):
            diagnoses_text += f"- {dx}\n"

    medications_text = ""
    for med in summary.get("medications", []):
        if isinstance(med, dict):
            medications_text += f"- {med.get('name', med.get('medication', str(med)))}\n"
        elif isinstance(med, str):
            medications_text += f"- {med}\n"

    findings_text = ""
    for f in summary.get("key_findings", []):
        if isinstance(f, dict):
            findings_text += f"- {f.get('finding', f.get('text', str(f)))}\n"
        elif isinstance(f, str):
            findings_text += f"- {f}\n"

    gaps_text = ""
    for g in summary.get("timeline_gaps", []):
        if isinstance(g, dict):
            gaps_text += f"- {g.get('gap_description', g.get('note', str(g)))}\n"
        elif isinstance(g, str):
            gaps_text += f"- {g}\n"

    alerts_text = ""
    for a in alerts:
        if isinstance(a, dict):
            alerts_text += f"- [{a.get('severity', 'medium').upper()}] {a.get('title', '')}: {a.get('description', '')}\n"

    billing_text = ""
    total_bills = billing.get("total_past_medical", 0)
    future_medical = billing.get("total_future_medical_estimate", 0)
    for provider in billing.get("providers", []):
        if isinstance(provider, dict):
            billing_text += f"- {provider.get('provider_name', 'Unknown')}: ${provider.get('subtotal', 0):,.2f}\n"

    # Calculate demand if auto
    if not demand_amount and total_bills > 0:
        demand_amount = total_bills * multiplier
        if future_medical:
            demand_amount += future_medical

    bluf = ""
    if isinstance(summary.get("bluf"), dict):
        bluf = summary["bluf"].get("text", "")
    elif isinstance(summary.get("bluf"), str):
        bluf = summary["bluf"]

    # Build comparative fault context for the prompt
    fault_standard = state_cfg.get("comparative_fault_standard", "pure_comparative")
    fault_labels = {
        "pure_comparative": "Pure Comparative Fault (plaintiff can recover even at 99% fault, reduced by percentage of fault)",
        "modified_50": "Modified Comparative Fault — 50% Bar (plaintiff barred if 50% or more at fault)",
        "modified_51": "Modified Comparative Fault — 51% Bar (plaintiff barred if 51% or more at fault)",
        "contributory": "Contributory Negligence (plaintiff barred from recovery if any fault — must establish defendant was sole proximate cause)",
        "slight_vs_gross": "Slight/Gross Negligence Comparison (plaintiff recovers only if fault is 'slight' compared to defendant's 'gross' negligence)",
    }
    fault_description = fault_labels.get(fault_standard, fault_standard)

    damages_cap = state_cfg.get("damages_cap", "")
    interest_statute = state_cfg.get("interest_statute", "")
    sol_years = state_cfg.get("statute_of_limitations_years", 2)
    pre_suit_required = state_cfg.get("pre_suit_notice_required", False)

    state_context = f"COMPARATIVE FAULT STANDARD: {fault_description}\n"
    if damages_cap:
        state_context += f"STATUTORY DAMAGES CAP: {damages_cap}\n"
    else:
        state_context += "STATUTORY DAMAGES CAP: None applicable to this claim type in this state.\n"
    if interest_statute:
        state_context += f"PREJUDGMENT INTEREST: Claimant reserves the right to seek prejudgment interest {interest_statute}.\n"
    state_context += f"STATUTE OF LIMITATIONS: {sol_years} year(s) for personal injury in this state.\n"
    if pre_suit_required:
        state_context += "PRE-SUIT NOTICE: This state requires a formal pre-suit notice. Ensure the demand letter satisfies statutory pre-suit requirements.\n"

    prompt = f"""You are a senior personal injury attorney drafting a demand letter for settlement.
Generate a professional, persuasive demand letter using the case data below.

CASE TYPE: {template['name']}
PLAINTIFF: {plaintiff}
INCIDENT DATE: {incident_date}
STATE: {state_code}

{state_context}
LIABILITY FRAMEWORK:
{template['liability_intro'].format(plaintiff=plaintiff, incident_date=incident_date)}
{template['liability_standard'].format(plaintiff=plaintiff)}

CASE SUMMARY (BLUF):
{bluf or 'See chronology and findings below.'}

CHRONOLOGY OF TREATMENT:
{chronology_text or 'No chronology data available.'}

DIAGNOSES:
{diagnoses_text or 'Diagnoses to be extracted from records.'}

MEDICATIONS:
{medications_text or 'See medical records.'}

KEY FINDINGS:
{findings_text or 'See summary.'}

TREATMENT GAPS / RISK FACTORS:
{gaps_text or 'None identified.'}
{alerts_text}

MEDICAL BILLS:
Total Past Medical Expenses: ${total_bills:,.2f}
Estimated Future Medical Expenses: ${future_medical:,.2f}
{billing_text}

DEMAND AMOUNT: ${demand_amount:,.2f} if demand_amount else '[TO BE DETERMINED]'
MULTIPLIER USED: {multiplier}x
RESPONSE DEADLINE: {response_days} days

Generate the demand letter with these sections as a JSON object:
{{
    "liability_narrative": "2-3 paragraphs describing what happened and establishing liability. Address the comparative/contributory fault standard for this state — if contributory negligence applies, emphasize the defendant's sole fault; if comparative fault applies, note the plaintiff bears no fault.",
    "injury_summary": "2-3 paragraphs describing all injuries, diagnoses, and their medical significance",
    "treatment_chronology_narrative": "Detailed narrative chronology of all treatment visits in paragraph form, not bullet points. Include dates, providers, and what was done at each visit.",
    "pain_and_suffering": "2-3 paragraphs describing the impact on daily life, work, relationships, and emotional well-being. Be specific and compelling. If there is a statutory damages cap in this state, frame the non-economic damages argument within that context.",
    "settlement_demand": "1-2 paragraphs stating the demand amount, basis for calculation, and response deadline. Be firm but professional. Reference the applicable prejudgment interest statute if available. If a statutory damages cap applies, address how it factors into the demand.",
    "closing": "Professional closing paragraph referencing the response deadline and reserving all rights including the right to seek prejudgment interest"
}}

IMPORTANT RULES:
- Write in formal legal prose, not casual language
- {template['causation_language']} use this causation language
- Every medical claim should be factual and based on the data provided
- Do not fabricate medical facts not present in the data
- Be persuasive but truthful
- Reference specific dates, providers, and diagnoses from the data
- Address the state's comparative/contributory fault standard in the liability section
- If a statutory damages cap applies, acknowledge it appropriately in the damages discussion
- Output ONLY the JSON object, no other text
"""

    # Inject RL feedback and exemplars
    feedback_context = _load_demand_feedback()
    exemplar_context = _load_demand_exemplars(case_type, state_code)
    if feedback_context:
        prompt += "\n\n" + feedback_context
    if exemplar_context:
        prompt += "\n\n" + exemplar_context

    model = config.get("claude", {}).get("model", "claude-sonnet-4-6")
    messages = [{"role": "user", "content": prompt}]

    response = call_claude(
        model=model,
        messages=messages,
        config=config,
        timeout_override=300,
        max_tokens_override=16384,
    )

    from pipeline_schemas import extract_json_from_response
    return extract_json_from_response(response)


# ── RL Feedback Loaders ──────────────────────────────────────────────────────

def _load_demand_feedback():
    """Load recent demand feedback to inject style guidance into prompts."""
    try:
        from db import get_db
        conn = get_db()
        try:
            # Get tone feedback aggregate
            tone_stats = conn.execute(
                """SELECT tone_feedback, COUNT(*) as cnt
                   FROM demand_feedback WHERE tone_feedback IS NOT NULL
                   GROUP BY tone_feedback"""
            ).fetchall()

            # Get edit severity aggregate
            edit_stats = conn.execute(
                """SELECT edit_severity, COUNT(*) as cnt
                   FROM demand_feedback WHERE edit_severity IS NOT NULL
                   GROUP BY edit_severity"""
            ).fetchall()

            # Get recent text feedback from non-excellent ratings
            corrections = conn.execute(
                """SELECT feedback_text, sections_edited, rating
                   FROM demand_feedback
                   WHERE feedback_text IS NOT NULL AND feedback_text != ''
                   ORDER BY created_at DESC LIMIT 10"""
            ).fetchall()

            if not tone_stats and not edit_stats and not corrections:
                return ""

            parts = ["## QUALITY FEEDBACK FROM ATTORNEY REVIEWS"]

            if tone_stats:
                tone_map = {r["tone_feedback"]: r["cnt"] for r in tone_stats}
                total_tone = sum(tone_map.values())
                parts.append(f"Tone feedback ({total_tone} reviews):")
                for tone, cnt in tone_map.items():
                    label = tone.replace("_", " ").title()
                    parts.append(f"  - {label}: {cnt} ({cnt*100//total_tone}%)")

                # Dominant tone feedback
                dominant = max(tone_map, key=tone_map.get)
                if dominant == "too_aggressive" and tone_map[dominant] > total_tone * 0.4:
                    parts.append("\nADJUSTMENT: Attorneys consistently find the tone too aggressive. "
                                 "Use a firm but measured professional tone. Avoid inflammatory language.")
                elif dominant == "too_conservative" and tone_map[dominant] > total_tone * 0.4:
                    parts.append("\nADJUSTMENT: Attorneys find the tone too conservative. "
                                 "Be more assertive in establishing liability and damages.")

            if corrections:
                parts.append("\nRecent attorney corrections (apply these improvements):")
                for c in corrections:
                    if c["rating"] in ("poor", "good") and c["feedback_text"]:
                        parts.append(f"  - {c['feedback_text'][:200]}")

            parts.append("")
            return "\n".join(parts)

        finally:
            conn.close()

    except Exception as e:
        logger.warning("Could not load demand feedback: %s", e)
        return ""


def _load_demand_exemplars(case_type, jurisdiction):
    """Load few-shot exemplars for demand prompt injection."""
    try:
        from exemplar_manager import get_exemplars, build_exemplar_prompt
        exemplars = get_exemplars("demand", case_type=case_type,
                                   jurisdiction=jurisdiction, limit=2)
        return build_exemplar_prompt("demand", exemplars)
    except Exception as e:
        logger.warning("Could not load demand exemplars: %s", e)
        return ""


# ── Document Generation ─────────────────────────────────────────────────────

def _create_demand_docx(narrative, summary_data, options):
    """Create a professional Word document for the demand package."""
    doc = Document()

    # Page margins
    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.18)
        section.right_margin = Cm(3.18)

    plaintiff = options.get("plaintiff_name", "[PLAINTIFF]")
    case_type = options.get("case_type", "mva")
    template = CASE_TEMPLATES.get(case_type, CASE_TEMPLATES["mva"])
    state_code = options.get("state", "default")
    state_cfg = _get_state_config(state_code)
    demand_amount = options.get("demand_amount")
    response_days = options.get("response_deadline_days", state_cfg["response_deadline_days"])
    billing = summary_data.get("billing_data", {})

    # ── Header ──
    header_para = doc.add_paragraph()
    header_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    header_run = header_para.add_run("DEMAND FOR SETTLEMENT")
    header_run.bold = True
    header_run.font.size = Pt(16)
    header_run.font.color.rgb = RGBColor(0x1a, 0x1a, 0x2e)

    sub_header = doc.add_paragraph()
    sub_header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub_run = sub_header.add_run(f"{template['name']} — {plaintiff}")
    sub_run.font.size = Pt(12)
    sub_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    doc.add_paragraph()  # Spacer

    # ── Date & Addressee ──
    date_para = doc.add_paragraph()
    date_para.add_run(datetime.now().strftime("%B %d, %Y"))
    doc.add_paragraph()
    doc.add_paragraph("VIA CERTIFIED MAIL AND EMAIL")
    doc.add_paragraph()
    doc.add_paragraph("[Insurance Adjuster Name]")
    doc.add_paragraph("[Insurance Company]")
    doc.add_paragraph("[Address]")
    doc.add_paragraph()

    re_para = doc.add_paragraph()
    re_run = re_para.add_run(f"RE: {plaintiff} — {template['name']}")
    re_run.bold = True

    claim_para = doc.add_paragraph()
    claim_para.add_run(f"Claim No.: [CLAIM NUMBER]")
    claim_para.add_run(f"\nDate of Loss: {options.get('incident_date', '[DATE]')}")
    doc.add_paragraph()

    doc.add_paragraph("Dear Claims Professional:")
    doc.add_paragraph()

    # State-specific pre-suit notice and demand requirements
    if state_cfg.get("pre_suit_notice_required"):
        notice_para = doc.add_paragraph()
        notice_run = notice_para.add_run(
            "NOTICE: This letter serves as formal pre-suit notice as required by applicable state law."
        )
        notice_run.bold = True
        notice_run.italic = True

    if state_cfg.get("demand_requirements"):
        req_para = doc.add_paragraph()
        req_run = req_para.add_run(state_cfg["demand_requirements"])
        req_run.italic = True
        doc.add_paragraph()

    # ── I. LIABILITY ──
    _add_section_heading(doc, "I. LIABILITY")
    doc.add_paragraph(narrative.get("liability_narrative", "[Liability narrative to be drafted]"))

    # ── II. INJURIES AND DIAGNOSES ──
    _add_section_heading(doc, "II. INJURIES AND DIAGNOSES")
    doc.add_paragraph(narrative.get("injury_summary", "[Injury summary to be drafted]"))

    # ── III. TREATMENT CHRONOLOGY ──
    _add_section_heading(doc, "III. TREATMENT CHRONOLOGY")
    doc.add_paragraph(narrative.get("treatment_chronology_narrative", "[Treatment chronology to be drafted]"))

    # ── IV. MEDICAL EXPENSES ──
    _add_section_heading(doc, "IV. MEDICAL EXPENSES")

    providers = billing.get("providers", [])
    if providers:
        # Create billing table
        table = doc.add_table(rows=1, cols=4)
        table.style = "Light Grid Accent 1"
        table.alignment = WD_TABLE_ALIGNMENT.CENTER

        headers = table.rows[0].cells
        for i, text in enumerate(["Provider", "Date(s) of Service", "Description", "Amount"]):
            headers[i].text = text
            for paragraph in headers[i].paragraphs:
                for run in paragraph.runs:
                    run.bold = True
                    run.font.size = Pt(9)

        for provider in providers:
            for service in provider.get("services", []):
                row = table.add_row().cells
                row[0].text = provider.get("provider_name", "")
                row[1].text = str(service.get("date", ""))
                row[2].text = service.get("description", "")
                amt = service.get("amount", 0)
                row[3].text = f"${amt:,.2f}" if isinstance(amt, (int, float)) else str(amt)
                for cell in row:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(9)

        doc.add_paragraph()

    total_past = billing.get("total_past_medical", 0)
    total_future = billing.get("total_future_medical_estimate", 0)

    totals_para = doc.add_paragraph()
    totals_para.add_run(f"Total Past Medical Expenses: ").bold = False
    amt_run = totals_para.add_run(f"${total_past:,.2f}")
    amt_run.bold = True

    if total_future > 0:
        future_para = doc.add_paragraph()
        future_para.add_run(f"Estimated Future Medical Expenses: ").bold = False
        fut_run = future_para.add_run(f"${total_future:,.2f}")
        fut_run.bold = True

        basis = billing.get("future_care_basis", "")
        if basis:
            basis_para = doc.add_paragraph()
            basis_run = basis_para.add_run(f"Basis: {basis}")
            basis_run.italic = True
            basis_run.font.size = Pt(10)

    # ── V. PAIN AND SUFFERING ──
    _add_section_heading(doc, "V. PAIN AND SUFFERING / DAMAGES")
    doc.add_paragraph(narrative.get("pain_and_suffering", "[Pain and suffering narrative to be drafted]"))

    # ── VI. DEMAND ──
    _add_section_heading(doc, "VI. SETTLEMENT DEMAND")
    doc.add_paragraph(narrative.get("settlement_demand", "[Settlement demand to be drafted]"))

    if demand_amount:
        demand_para = doc.add_paragraph()
        demand_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        d_run = demand_para.add_run(f"DEMAND AMOUNT: ${demand_amount:,.2f}")
        d_run.bold = True
        d_run.font.size = Pt(14)
        d_run.font.color.rgb = RGBColor(0xB9, 0x1C, 0x1C)

    deadline_para = doc.add_paragraph()
    deadline_para.add_run(
        f"\nPlease respond to this demand within {response_days} days of receipt. "
        f"Failure to respond will be deemed a rejection and we will proceed accordingly."
    )

    # ── STATE-SPECIFIC LEGAL NOTICES ──
    interest_statute = state_cfg.get("interest_statute", "")
    damages_cap = state_cfg.get("damages_cap", "")
    fault_standard = state_cfg.get("comparative_fault_standard", "")
    sol_years = state_cfg.get("statute_of_limitations_years")

    has_state_notices = interest_statute or damages_cap or fault_standard or sol_years
    if has_state_notices:
        _add_section_heading(doc, "VII. APPLICABLE STATE LAW")

        if interest_statute:
            interest_para = doc.add_paragraph()
            interest_para.add_run(
                f"Prejudgment Interest: In the event this matter proceeds to litigation, "
                f"our client reserves the right to seek prejudgment interest {interest_statute}."
            )

        if fault_standard:
            fault_labels = {
                "pure_comparative": "This state follows the pure comparative fault doctrine. "
                    "Any damages awarded will be reduced by the plaintiff's percentage of fault, if any.",
                "modified_50": "This state follows a modified comparative fault standard (50% bar). "
                    "A plaintiff who is 50% or more at fault is barred from recovery.",
                "modified_51": "This state follows a modified comparative fault standard (51% bar). "
                    "A plaintiff who is 51% or more at fault is barred from recovery.",
                "contributory": "This state follows the contributory negligence doctrine. "
                    "The defendant bears sole responsibility for the injuries sustained, "
                    "and our client was free from any contributory negligence.",
                "slight_vs_gross": "This state applies the slight/gross negligence comparison standard. "
                    "The plaintiff's conduct was at most slight in comparison to the gross negligence of the defendant.",
            }
            fault_text = fault_labels.get(fault_standard, "")
            if fault_text:
                fault_para = doc.add_paragraph()
                fault_para.add_run(f"Comparative Fault: {fault_text}")

        if damages_cap:
            cap_para = doc.add_paragraph()
            cap_run = cap_para.add_run(f"Statutory Damages Cap: {damages_cap}.")
            cap_run.italic = True

        if sol_years:
            sol_para = doc.add_paragraph()
            sol_para.add_run(
                f"Statute of Limitations: The applicable statute of limitations for personal "
                f"injury claims in this jurisdiction is {sol_years} year(s) from the date of injury."
            )

    # ── CLOSING ──
    doc.add_paragraph()
    doc.add_paragraph(narrative.get("closing", "We look forward to your prompt response to resolve this matter."))
    doc.add_paragraph()
    doc.add_paragraph("Respectfully submitted,")
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph("[ATTORNEY NAME]")
    doc.add_paragraph("[FIRM NAME]")
    doc.add_paragraph("[ADDRESS]")
    doc.add_paragraph("[PHONE]")
    doc.add_paragraph("[EMAIL]")

    return doc


def _add_section_heading(doc, text):
    """Add a styled section heading."""
    heading = doc.add_paragraph()
    heading_run = heading.add_run(text)
    heading_run.bold = True
    heading_run.font.size = Pt(13)
    heading_run.font.color.rgb = RGBColor(0x1a, 0x1a, 0x2e)
    # Add bottom border effect via spacing
    heading.paragraph_format.space_after = Pt(6)


def _create_billing_xlsx(summary_data):
    """Create a billing summary Excel spreadsheet."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Medical Bills Summary"

    # Styles
    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="1a1a2e", end_color="1a1a2e", fill_type="solid")
    currency_fmt = '"$"#,##0.00'
    total_font = Font(bold=True, size=12)
    thin_border = Border(
        bottom=Side(style="thin", color="CCCCCC"),
    )

    # Headers
    headers = ["Provider", "Date of Service", "Description", "CPT Code", "Amount"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    # Column widths
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 15

    billing = summary_data.get("billing_data", {})
    row = 2

    for provider in billing.get("providers", []):
        provider_name = provider.get("provider_name", "Unknown Provider")
        for service in provider.get("services", []):
            ws.cell(row=row, column=1, value=provider_name)
            ws.cell(row=row, column=2, value=str(service.get("date", "")))
            ws.cell(row=row, column=3, value=service.get("description", ""))
            ws.cell(row=row, column=4, value=service.get("cpt_code", ""))
            amt_cell = ws.cell(row=row, column=5, value=service.get("amount", 0))
            amt_cell.number_format = currency_fmt
            for col in range(1, 6):
                ws.cell(row=row, column=col).border = thin_border
            row += 1

        # Provider subtotal
        subtotal = provider.get("subtotal", 0)
        if subtotal:
            ws.cell(row=row, column=3, value=f"Subtotal — {provider_name}").font = Font(bold=True, italic=True)
            sub_cell = ws.cell(row=row, column=5, value=subtotal)
            sub_cell.number_format = currency_fmt
            sub_cell.font = Font(bold=True, italic=True)
            row += 1

    # Totals section
    row += 1
    total_past = billing.get("total_past_medical", 0)
    total_future = billing.get("total_future_medical_estimate", 0)
    total_combined = billing.get("total_combined", total_past + total_future)

    ws.cell(row=row, column=3, value="TOTAL PAST MEDICAL EXPENSES").font = total_font
    total_cell = ws.cell(row=row, column=5, value=total_past)
    total_cell.number_format = currency_fmt
    total_cell.font = total_font
    row += 1

    if total_future > 0:
        ws.cell(row=row, column=3, value="ESTIMATED FUTURE MEDICAL EXPENSES").font = Font(bold=True)
        fut_cell = ws.cell(row=row, column=5, value=total_future)
        fut_cell.number_format = currency_fmt
        fut_cell.font = Font(bold=True)
        row += 1

        basis = billing.get("future_care_basis", "")
        if basis:
            ws.cell(row=row, column=3, value=f"  Basis: {basis}").font = Font(italic=True, size=9)
            row += 1

    row += 1
    ws.cell(row=row, column=3, value="TOTAL COMBINED").font = Font(bold=True, size=14)
    combined_cell = ws.cell(row=row, column=5, value=total_combined)
    combined_cell.number_format = currency_fmt
    combined_cell.font = Font(bold=True, size=14, color="B91C1C")

    return wb


def _create_exhibit_list_docx(summary_data, options):
    """Create an exhibit list document referencing source files."""
    doc = Document()

    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.18)
        section.right_margin = Cm(3.18)

    plaintiff = options.get("plaintiff_name", "[PLAINTIFF]")

    # Header
    header = doc.add_paragraph()
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    h_run = header.add_run("EXHIBIT LIST")
    h_run.bold = True
    h_run.font.size = Pt(16)

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.add_run(f"Case: {plaintiff}")
    doc.add_paragraph()

    # Build exhibit list from source files
    source_files = summary_data.get("source_files", [])
    if not source_files:
        # Try to extract from the summary data
        source_file = summary_data.get("source_file", "")
        if source_file:
            source_files = [source_file]

    # Create table
    table = doc.add_table(rows=1, cols=3)
    table.style = "Light Grid Accent 1"

    headers = table.rows[0].cells
    headers[0].text = "Exhibit"
    headers[1].text = "Description"
    headers[2].text = "Pages"
    for cell in headers:
        for para in cell.paragraphs:
            for run in para.runs:
                run.bold = True

    exhibit_labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for i, sf in enumerate(source_files):
        row = table.add_row().cells
        label = exhibit_labels[i] if i < 26 else f"A{i - 25}"
        row[0].text = f"Exhibit {label}"

        if isinstance(sf, dict):
            row[1].text = sf.get("filename", sf.get("name", str(sf)))
            row[2].text = str(sf.get("page_count", "—"))
        else:
            row[1].text = str(Path(sf).name) if sf else "—"
            row[2].text = "—"

    doc.add_paragraph()
    doc.add_paragraph(f"Total Exhibits: {len(source_files)}")

    return doc


# ── Main Entry Point ─────────────────────────────────────────────────────────

def generate_demand_package(summary_data, config, options):
    """Generate a complete demand package from summary data.

    Args:
        summary_data: The full summary JSON (from summarization pipeline)
        config: Application config (config.yaml contents)
        options: Dict with:
            - case_type: "mva", "slip_fall", "med_mal", "workers_comp", "dog_bite", "product_liability"
            - state: Two-letter state code (e.g., "FL", "CA")
            - plaintiff_name: Plaintiff's name
            - incident_date: Date of incident
            - demand_amount: Explicit demand amount (float) or None for auto-calculate
            - multiplier: Multiplier for auto-calculation (default 3.0)
            - response_deadline_days: Days for response (default: state-specific)

    Returns:
        Dict with:
            - demand_docx: bytes (Word document)
            - billing_xlsx: bytes (Excel spreadsheet)
            - exhibit_docx: bytes (Exhibit list document)
            - narrative: dict (raw narrative sections)
            - demand_amount: float (final demand amount)
            - billing_total: float
    """
    summary_data = _normalize_summary_data(summary_data)
    logger.info("Generating demand package: case_type=%s, state=%s",
                options.get("case_type"), options.get("state"))

    # Step 1: Generate narrative via LLM
    try:
        narrative = _generate_narrative(summary_data, options, config)
    except Exception as e:
        logger.error("Failed to generate narrative: %s", e)
        narrative = {
            "liability_narrative": "[Narrative generation failed — please draft manually]",
            "injury_summary": "[See medical summary for diagnoses and findings]",
            "treatment_chronology_narrative": "[See chronology in medical summary]",
            "pain_and_suffering": "[Please draft pain and suffering narrative]",
            "settlement_demand": "[Please draft settlement demand]",
            "closing": "We look forward to your prompt response.",
        }

    # Calculate final demand amount
    billing = summary_data.get("billing_data", {})
    total_past = billing.get("total_past_medical", 0)
    total_future = billing.get("total_future_medical_estimate", 0)
    multiplier = options.get("multiplier", 3.0)

    demand_amount = options.get("demand_amount")
    if not demand_amount and total_past > 0:
        demand_amount = (total_past * multiplier) + total_future
    options["demand_amount"] = demand_amount

    # Step 2: Generate documents
    demand_doc = _create_demand_docx(narrative, summary_data, options)
    billing_wb = _create_billing_xlsx(summary_data)
    exhibit_doc = _create_exhibit_list_docx(summary_data, options)

    # Serialize to bytes
    demand_buf = io.BytesIO()
    demand_doc.save(demand_buf)
    demand_bytes = demand_buf.getvalue()

    billing_buf = io.BytesIO()
    billing_wb.save(billing_buf)
    billing_bytes = billing_buf.getvalue()

    exhibit_buf = io.BytesIO()
    exhibit_doc.save(exhibit_buf)
    exhibit_bytes = exhibit_buf.getvalue()

    logger.info("Demand package generated: demand=$%s, billing_total=$%s",
                f"{demand_amount:,.2f}" if demand_amount else "TBD",
                f"{total_past:,.2f}")

    return {
        "demand_docx": demand_bytes,
        "billing_xlsx": billing_bytes,
        "exhibit_docx": exhibit_bytes,
        "narrative": narrative,
        "demand_amount": demand_amount,
        "billing_total": total_past + total_future,
    }


def get_case_types():
    """Return available case types for the UI."""
    return [
        {"id": k, "name": v["name"]}
        for k, v in CASE_TEMPLATES.items()
    ]


def get_states():
    """Return available states with specific configs."""
    states = [
        {"code": "default", "name": "General (No State-Specific)"},
        {"code": "AL", "name": "Alabama"}, {"code": "AK", "name": "Alaska"},
        {"code": "AZ", "name": "Arizona"}, {"code": "AR", "name": "Arkansas"},
        {"code": "CA", "name": "California"}, {"code": "CO", "name": "Colorado"},
        {"code": "CT", "name": "Connecticut"}, {"code": "DE", "name": "Delaware"},
        {"code": "FL", "name": "Florida"}, {"code": "GA", "name": "Georgia"},
        {"code": "HI", "name": "Hawaii"}, {"code": "ID", "name": "Idaho"},
        {"code": "IL", "name": "Illinois"}, {"code": "IN", "name": "Indiana"},
        {"code": "IA", "name": "Iowa"}, {"code": "KS", "name": "Kansas"},
        {"code": "KY", "name": "Kentucky"}, {"code": "LA", "name": "Louisiana"},
        {"code": "ME", "name": "Maine"}, {"code": "MD", "name": "Maryland"},
        {"code": "MA", "name": "Massachusetts"}, {"code": "MI", "name": "Michigan"},
        {"code": "MN", "name": "Minnesota"}, {"code": "MS", "name": "Mississippi"},
        {"code": "MO", "name": "Missouri"}, {"code": "MT", "name": "Montana"},
        {"code": "NE", "name": "Nebraska"}, {"code": "NV", "name": "Nevada"},
        {"code": "NH", "name": "New Hampshire"}, {"code": "NJ", "name": "New Jersey"},
        {"code": "NM", "name": "New Mexico"}, {"code": "NY", "name": "New York"},
        {"code": "NC", "name": "North Carolina"}, {"code": "ND", "name": "North Dakota"},
        {"code": "OH", "name": "Ohio"}, {"code": "OK", "name": "Oklahoma"},
        {"code": "OR", "name": "Oregon"}, {"code": "PA", "name": "Pennsylvania"},
        {"code": "RI", "name": "Rhode Island"}, {"code": "SC", "name": "South Carolina"},
        {"code": "SD", "name": "South Dakota"}, {"code": "TN", "name": "Tennessee"},
        {"code": "TX", "name": "Texas"}, {"code": "UT", "name": "Utah"},
        {"code": "VT", "name": "Vermont"}, {"code": "VA", "name": "Virginia"},
        {"code": "WA", "name": "Washington"}, {"code": "WV", "name": "West Virginia"},
        {"code": "WI", "name": "Wisconsin"}, {"code": "WY", "name": "Wyoming"},
        {"code": "DC", "name": "District of Columbia"},
    ]
    return states
