"""
case_valuation.py -- Predictive case valuation engine for personal injury cases.

Uses structured analysis of case data + Claude LLM to estimate settlement ranges.
Factors: diagnosis severity, treatment duration/costs, jurisdiction, injury mechanism,
patient demographics, treatment compliance, pre-existing conditions.

Output: low/mid/high settlement estimates with confidence band, comparable reasoning,
and factors that strengthen/weaken the case value.

Usage:
    from case_valuation import estimate_case_value
    result = estimate_case_value(summary_data, config, options)
"""

import json
import logging
import re
from datetime import datetime

logger = logging.getLogger("case_valuation")


def _normalize_summary_data(summary_data):
    """Normalize the nested summary structure for uniform data access."""
    if not isinstance(summary_data, dict):
        return summary_data
    summarizer_output = summary_data.get("summary", {})
    if not isinstance(summarizer_output, dict):
        return summary_data
    inner_summary = summarizer_output.get("summary", {})
    if isinstance(inner_summary, dict) and inner_summary.get("active_diagnoses") is not None:
        merged = dict(summarizer_output)
        for key, val in inner_summary.items():
            if key not in merged or key in ("active_diagnoses", "medications", "key_findings",
                "timeline_gaps", "chronological_events", "master_chronology", "overall_confidence"):
                merged[key] = val
        result = dict(summary_data)
        result["summary"] = merged
        if "billing_data" not in result and "billing_data" in merged:
            result["billing_data"] = merged["billing_data"]
        if "alerts" not in result and "alerts" in merged:
            result["alerts"] = merged["alerts"]
        return result
    return summary_data


# ── Severity Multiplier Ranges ───────────────────────────────────────────────
# Based on typical PI settlement data: multiplier applied to medical specials

SEVERITY_TIERS = {
    "minor": {
        "description": "Soft tissue, sprains, strains, minor lacerations",
        "multiplier_range": (1.5, 3.0),
        "typical_range": (5000, 25000),
    },
    "moderate": {
        "description": "Herniated discs, fractures (non-surgical), concussions, significant soft tissue",
        "multiplier_range": (2.5, 4.0),
        "typical_range": (25000, 100000),
    },
    "serious": {
        "description": "Surgical intervention required, multiple fractures, TBI, significant scarring",
        "multiplier_range": (3.5, 5.0),
        "typical_range": (75000, 350000),
    },
    "severe": {
        "description": "Permanent disability, spinal cord injury, amputation, organ damage",
        "multiplier_range": (5.0, 10.0),
        "typical_range": (200000, 1500000),
    },
    "catastrophic": {
        "description": "Paralysis, severe TBI, wrongful death, loss of major bodily function",
        "multiplier_range": (8.0, 25.0),
        "typical_range": (500000, 10000000),
    },
}

# ── Jurisdiction Modifiers ──────────────────────────────────────────────────
# Relative adjustment factors by state (1.0 = national average)

JURISDICTION_MODIFIERS = {
    "FL": 1.1,   # Plaintiff-friendly, no-fault state
    "CA": 1.25,  # High verdicts, plaintiff-friendly
    "TX": 0.85,  # Tort reform, caps on non-economic damages
    "NY": 1.3,   # High verdicts, especially NYC
    "IL": 1.15,  # Cook County plaintiff-friendly
    "PA": 1.0,   # Average
    "NJ": 1.1,   # Moderate plaintiff-friendly
    "GA": 0.9,   # Moderate
    "OH": 0.85,  # Tort reform state
    "MI": 0.8,   # No-fault, modified comparative
    "NC": 0.75,  # Contributory negligence state
    "VA": 0.75,  # Contributory negligence state
    "MA": 1.1,   # Moderate plaintiff-friendly
    "WA": 1.05,  # Moderate
    "AZ": 0.95,  # Moderate
    "CO": 0.9,   # Moderate, some caps
    "NV": 1.15,  # Plaintiff-friendly for PI
    "default": 1.0,
}

# ── Diagnosis Severity Classification ────────────────────────────────────────

SEVERE_DIAGNOSES = [
    "spinal cord", "paralysis", "paraplegia", "quadriplegia", "amputation",
    "traumatic brain injury", "tbi", "skull fracture", "subdural hematoma",
    "epidural hematoma", "intracranial hemorrhage", "wrongful death",
    "organ damage", "organ failure", "loss of limb",
]

SERIOUS_DIAGNOSES = [
    "surgery", "surgical", "fusion", "discectomy", "laminectomy",
    "arthroplasty", "fixation", "open reduction", "multiple fracture",
    "compound fracture", "displaced fracture", "torn acl", "torn meniscus",
    "rotator cuff tear", "labral tear", "nerve damage", "neuropathy",
    "complex regional pain", "crps", "rsd", "concussion",
    "mild traumatic brain", "mtbi", "post-concussion",
]

MODERATE_DIAGNOSES = [
    "herniat", "bulging disc", "protru", "fracture", "broken",
    "dislocation", "ligament tear", "tendon tear", "meniscus",
    "labrum", "impingement", "radiculopathy", "stenosis",
    "carpal tunnel", "thoracic outlet",
]


def _classify_severity(summary_data):
    """Classify case severity based on diagnoses and treatment data."""
    summary = summary_data.get("summary", {})
    diagnoses = summary.get("active_diagnoses", [])
    findings = summary.get("key_findings", [])
    procedures = summary.get("procedures", summary.get("surgical_history", []))

    # Combine all text for matching
    all_text = ""
    for item in diagnoses + findings + (procedures or []):
        if isinstance(item, dict):
            all_text += " " + json.dumps(item).lower()
        elif isinstance(item, str):
            all_text += " " + item.lower()

    # Check catastrophic first
    for keyword in SEVERE_DIAGNOSES:
        if keyword in all_text:
            return "catastrophic" if "paralysis" in all_text or "quadriplegia" in all_text else "severe"

    # Check serious
    for keyword in SERIOUS_DIAGNOSES:
        if keyword in all_text:
            return "serious"

    # Check moderate
    for keyword in MODERATE_DIAGNOSES:
        if keyword in all_text:
            return "moderate"

    return "minor"


def _extract_billing_total(summary_data):
    """Extract total medical billing from summary data."""
    summary = summary_data.get("summary", {})
    billing = summary.get("billing_data", summary_data.get("billing_data", {}))

    if isinstance(billing, dict):
        total = billing.get("total_combined", billing.get("total_past_medical", 0))
        try:
            return float(str(total).replace("$", "").replace(",", "")) if total else 0
        except (ValueError, TypeError):
            return 0
    return 0


def _calculate_treatment_duration(summary_data):
    """Estimate treatment duration in months from chronological events."""
    summary = summary_data.get("summary", {})
    events = summary.get("chronological_events", summary.get("master_chronology", []))

    dates = []
    for event in events:
        if isinstance(event, dict):
            date_str = event.get("date", "")
            if date_str and date_str != "Unknown date":
                try:
                    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%B %d, %Y", "%m-%d-%Y"):
                        try:
                            dates.append(datetime.strptime(date_str, fmt))
                            break
                        except ValueError:
                            continue
                except Exception:
                    pass

    if len(dates) >= 2:
        dates.sort()
        delta = dates[-1] - dates[0]
        return max(1, delta.days / 30)
    return 6  # Default assumption


def _count_providers(summary_data):
    """Count number of unique medical providers."""
    summary = summary_data.get("summary", {})
    billing = summary.get("billing_data", summary_data.get("billing_data", {}))
    providers = set()

    if isinstance(billing, dict):
        for prov in billing.get("providers", []):
            if isinstance(prov, dict):
                name = prov.get("provider_name", prov.get("name", ""))
                if name:
                    providers.add(name.lower().strip())

    events = summary.get("chronological_events", summary.get("master_chronology", []))
    for event in events:
        if isinstance(event, dict):
            prov = event.get("provider", "")
            if prov:
                providers.add(prov.lower().strip())

    return max(1, len(providers))


def _rule_based_estimate(summary_data, options):
    """Generate a rule-based settlement estimate as a baseline."""
    severity = _classify_severity(summary_data)
    tier = SEVERITY_TIERS[severity]
    billing_total = _extract_billing_total(summary_data)
    treatment_months = _calculate_treatment_duration(summary_data)
    provider_count = _count_providers(summary_data)
    state = options.get("state", "default")
    jurisdiction_mod = JURISDICTION_MODIFIERS.get(state, JURISDICTION_MODIFIERS["default"])

    # Base calculation: billing * multiplier range
    low_mult, high_mult = tier["multiplier_range"]
    mid_mult = (low_mult + high_mult) / 2

    if billing_total > 0:
        base_low = billing_total * low_mult
        base_mid = billing_total * mid_mult
        base_high = billing_total * high_mult
    else:
        # No billing data — use typical ranges
        base_low, base_high = tier["typical_range"]
        base_mid = (base_low + base_high) / 2

    # Adjustments
    # Treatment duration bonus: longer treatment = higher value
    duration_factor = min(1.5, max(1.0, 1.0 + (treatment_months - 3) * 0.03))

    # Provider count bonus: more providers = more credibility
    provider_factor = min(1.3, max(1.0, 1.0 + (provider_count - 1) * 0.05))

    # Jurisdiction modifier
    low = base_low * duration_factor * provider_factor * jurisdiction_mod
    mid = base_mid * duration_factor * provider_factor * jurisdiction_mod
    high = base_high * duration_factor * provider_factor * jurisdiction_mod

    # Confidence based on data quality
    confidence = 0.5
    if billing_total > 0:
        confidence += 0.15
    if treatment_months > 1:
        confidence += 0.1
    if provider_count > 1:
        confidence += 0.1
    if len(summary_data.get("summary", {}).get("active_diagnoses", [])) > 0:
        confidence += 0.1
    confidence = min(0.85, confidence)

    return {
        "severity": severity,
        "billing_total": billing_total,
        "treatment_months": round(treatment_months, 1),
        "provider_count": provider_count,
        "jurisdiction_modifier": jurisdiction_mod,
        "low": round(low),
        "mid": round(mid),
        "high": round(high),
        "confidence": round(confidence, 2),
    }


def estimate_case_value(summary_data, config=None, options=None):
    """
    Main entry point: estimate settlement value range for a PI case.

    Returns dict with:
        - low, mid, high: settlement range estimates
        - confidence: 0.0-1.0 confidence score
        - severity: classified injury severity tier
        - factors: list of strengthening/weakening factors
        - reasoning: LLM-generated explanation
        - comparable_basis: reasoning basis
    """
    options = options or {}
    config = config or {}
    summary_data = _normalize_summary_data(summary_data)

    # Step 1: Rule-based baseline
    baseline = _rule_based_estimate(summary_data, options)

    # Step 2: LLM-enhanced analysis
    try:
        llm_result = _llm_valuation(summary_data, baseline, options, config)
    except Exception as e:
        logger.warning("LLM valuation failed, using rule-based only: %s", e)
        llm_result = None

    # Merge results
    if llm_result:
        # Use LLM estimates if they're within reasonable bounds of rule-based
        result = {
            "low": llm_result.get("low", baseline["low"]),
            "mid": llm_result.get("mid", baseline["mid"]),
            "high": llm_result.get("high", baseline["high"]),
            "confidence": llm_result.get("confidence", baseline["confidence"]),
            "severity": llm_result.get("severity", baseline["severity"]),
            "factors_strengthening": llm_result.get("factors_strengthening", []),
            "factors_weakening": llm_result.get("factors_weakening", []),
            "reasoning": llm_result.get("reasoning", ""),
            "comparable_basis": llm_result.get("comparable_basis", ""),
        }
    else:
        result = {
            "low": baseline["low"],
            "mid": baseline["mid"],
            "high": baseline["high"],
            "confidence": baseline["confidence"],
            "severity": baseline["severity"],
            "factors_strengthening": [],
            "factors_weakening": [],
            "reasoning": f"Rule-based estimate using {baseline['severity']} severity tier with ${baseline['billing_total']:,.0f} in medical specials.",
            "comparable_basis": f"Based on {baseline['severity']}-severity PI cases with similar medical specials in this jurisdiction.",
        }

    # Add metadata
    result["billing_total"] = baseline["billing_total"]
    result["treatment_months"] = baseline["treatment_months"]
    result["provider_count"] = baseline["provider_count"]
    result["jurisdiction"] = options.get("state", "default")
    result["method"] = "llm_enhanced" if llm_result else "rule_based"

    return result


def _llm_valuation(summary_data, baseline, options, config):
    """Use Claude to provide a refined case valuation with reasoning."""
    from dispatch import call_claude

    summary = summary_data.get("summary", {})
    billing = summary.get("billing_data", summary_data.get("billing_data", {}))
    alerts = summary.get("alerts", summary_data.get("alerts", []))

    # Build case profile for LLM
    diagnoses_text = ""
    for dx in summary.get("active_diagnoses", []):
        if isinstance(dx, dict):
            diagnoses_text += f"- {dx.get('diagnosis', dx.get('text', str(dx)))}\n"
        elif isinstance(dx, str):
            diagnoses_text += f"- {dx}\n"

    findings_text = ""
    for f in summary.get("key_findings", []):
        if isinstance(f, dict):
            findings_text += f"- {f.get('finding', f.get('text', str(f)))}\n"
        elif isinstance(f, str):
            findings_text += f"- {f}\n"

    procedures_text = ""
    for p in summary.get("procedures", summary.get("surgical_history", [])) or []:
        if isinstance(p, dict):
            procedures_text += f"- {p.get('procedure', p.get('name', str(p)))}\n"
        elif isinstance(p, str):
            procedures_text += f"- {p}\n"

    gaps_text = ""
    for g in summary.get("timeline_gaps", []):
        if isinstance(g, dict):
            gaps_text += f"- {g.get('gap_description', g.get('note', str(g)))}\n"
        elif isinstance(g, str):
            gaps_text += f"- {g}\n"

    alerts_text = ""
    for a in (alerts if isinstance(alerts, list) else []):
        if isinstance(a, dict):
            alerts_text += f"- [{a.get('severity', 'info').upper()}] {a.get('title', '')}: {a.get('description', '')}\n"

    state = options.get("state", "unknown")
    case_type = options.get("case_type", "personal injury")

    # Load RL feedback and exemplars
    feedback_context = _load_valuation_feedback()
    exemplar_context = _load_valuation_exemplars(baseline["severity"], case_type, state)

    prompt = f"""You are an experienced personal injury case valuation analyst. Based on the following case data, provide a settlement value estimate.

CASE PROFILE:
- Case Type: {case_type}
- Jurisdiction: {state.upper() if state != 'default' else 'General US'}
- Treatment Duration: {baseline['treatment_months']} months
- Number of Providers: {baseline['provider_count']}
- Total Medical Specials: ${baseline['billing_total']:,.2f}

DIAGNOSES:
{diagnoses_text or 'Not specified'}

KEY FINDINGS:
{findings_text or 'Not specified'}

PROCEDURES / SURGERIES:
{procedures_text or 'None documented'}

TREATMENT GAPS:
{gaps_text or 'No significant gaps noted'}

ALERTS / RISK FACTORS:
{alerts_text or 'None'}

OUR RULE-BASED BASELINE ESTIMATE:
- Severity: {baseline['severity']}
- Low: ${baseline['low']:,.0f}
- Mid: ${baseline['mid']:,.0f}
- High: ${baseline['high']:,.0f}

INSTRUCTIONS:
Analyze this case and provide a refined settlement value estimate. Consider:
1. The specific diagnoses and their typical settlement values
2. Treatment duration and intensity
3. Jurisdiction-specific trends
4. Factors that strengthen or weaken the case value
5. Pre-existing conditions noted in alerts
6. Treatment compliance / gaps

Respond in STRICT JSON format:
{{
    "low": <integer>,
    "mid": <integer>,
    "high": <integer>,
    "confidence": <float 0.0-1.0>,
    "severity": "<minor|moderate|serious|severe|catastrophic>",
    "factors_strengthening": ["factor 1", "factor 2", ...],
    "factors_weakening": ["factor 1", "factor 2", ...],
    "reasoning": "<2-3 sentence explanation of the valuation>",
    "comparable_basis": "<1-2 sentences describing what comparable cases this is based on>"
}}

Only return valid JSON, nothing else."""

    # Inject RL feedback and exemplars
    if feedback_context:
        prompt += "\n\n" + feedback_context
    if exemplar_context:
        prompt += "\n\n" + exemplar_context

    model = config.get("claude", {}).get("model", "claude-sonnet-4-6")
    messages = [
        {"role": "system", "content": "You are a personal injury case valuation expert. Respond only with valid JSON."},
        {"role": "user", "content": prompt},
    ]

    response = call_claude(
        model=model,
        messages=messages,
        config=config,
        timeout_override=120,
    )

    if not response:
        return None

    # Parse JSON from response
    text = response.strip()
    # Try to extract JSON from code blocks if present
    json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if json_match:
        text = json_match.group(1)
    # Try bare JSON
    json_match2 = re.search(r'\{.*\}', text, re.DOTALL)
    if json_match2:
        text = json_match2.group(0)

    try:
        result = json.loads(text)
        # Validate required fields
        for key in ("low", "mid", "high"):
            if key not in result or not isinstance(result[key], (int, float)):
                return None
            result[key] = int(result[key])
        return result
    except (json.JSONDecodeError, KeyError, TypeError) as e:
        logger.warning("Failed to parse LLM valuation response: %s", e)
        return None


def get_severity_tiers():
    """Return severity tier descriptions for UI display."""
    return {k: v["description"] for k, v in SEVERITY_TIERS.items()}


# ── RL Feedback Loader ───────────────────────────────────────────────────────

def _load_valuation_feedback():
    """Load recent valuation outcomes to inject calibration context into prompts."""
    try:
        from db import get_db
        conn = get_db()
        try:
            # Get outcomes with accuracy ratings
            outcomes = conn.execute(
                """SELECT predicted_mid, actual_settlement, attorney_accuracy_rating,
                          predicted_severity, case_type, jurisdiction
                   FROM valuation_outcomes
                   WHERE attorney_accuracy_rating IS NOT NULL
                   ORDER BY created_at DESC LIMIT 30"""
            ).fetchall()

            if not outcomes:
                return ""

            # Calculate directional bias
            too_low = sum(1 for o in outcomes if o["attorney_accuracy_rating"] == "too_low")
            accurate = sum(1 for o in outcomes if o["attorney_accuracy_rating"] == "accurate")
            too_high = sum(1 for o in outcomes if o["attorney_accuracy_rating"] == "too_high")
            total = len(outcomes)

            parts = ["## CALIBRATION FEEDBACK FROM ATTORNEY REVIEWS"]
            parts.append(f"Based on {total} recent case outcomes: "
                         f"{too_low} too low ({too_low*100//total}%), "
                         f"{accurate} accurate ({accurate*100//total}%), "
                         f"{too_high} too high ({too_high*100//total}%).")

            # Calculate average error for cases with actual settlements
            errors_by_severity = {}
            for o in outcomes:
                if o["actual_settlement"] and o["predicted_mid"]:
                    sev = o["predicted_severity"] or "unknown"
                    if sev not in errors_by_severity:
                        errors_by_severity[sev] = []
                    error_pct = ((o["actual_settlement"] - o["predicted_mid"]) / max(1, o["predicted_mid"])) * 100
                    errors_by_severity[sev].append(error_pct)

            if errors_by_severity:
                parts.append("\nCalibration by severity tier:")
                for sev, errors in errors_by_severity.items():
                    avg_error = sum(errors) / len(errors)
                    direction = "ABOVE" if avg_error > 0 else "BELOW"
                    parts.append(f"  - {sev}: Actual settlements averaged {abs(avg_error):.0f}% "
                                 f"{direction} your predictions (n={len(errors)})")

            if too_low > too_high and too_low > accurate:
                parts.append("\nIMPORTANT: Your estimates have been consistently TOO LOW. "
                             "Adjust upward, especially for cases with documented surgical intervention "
                             "or prolonged treatment.")
            elif too_high > too_low and too_high > accurate:
                parts.append("\nIMPORTANT: Your estimates have been consistently TOO HIGH. "
                             "Be more conservative, especially for cases with treatment gaps "
                             "or pre-existing conditions.")

            parts.append("")
            return "\n".join(parts)

        finally:
            conn.close()

    except Exception as e:
        logger.warning("Could not load valuation feedback: %s", e)
        return ""


def _load_valuation_exemplars(severity, case_type, jurisdiction):
    """Load few-shot exemplars for valuation prompt injection."""
    try:
        from exemplar_manager import get_exemplars, build_exemplar_prompt
        exemplars = get_exemplars("valuation", severity=severity,
                                   case_type=case_type, jurisdiction=jurisdiction, limit=2)
        return build_exemplar_prompt("valuation", exemplars)
    except Exception as e:
        logger.warning("Could not load valuation exemplars: %s", e)
        return ""
