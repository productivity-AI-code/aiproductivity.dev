"""
negligence_detector.py -- Detects potential standard-of-care deviations and negligence indicators.

Analyzes medical record summaries to identify:
- Delayed diagnosis or referrals
- Medication errors or contraindications
- Documentation inconsistencies
- Missed follow-ups or treatment gaps
- Failure to order appropriate tests
- Deviation from clinical guidelines
"""

import json
import logging
import re
from datetime import datetime

logger = logging.getLogger("negligence_detector")


def _normalize_summary_data(summary_data):
    """Normalize the nested summary structure so modules can access data uniformly.

    The saved summary JSON has structure: {run_id, summary: {summary: {active_diagnoses, ...}, billing_data, alerts}}
    This flattens it so summary_data["summary"] contains the inner summary fields directly,
    and billing_data/alerts are accessible at the top level.
    """
    if not isinstance(summary_data, dict):
        return summary_data

    summarizer_output = summary_data.get("summary", {})
    if not isinstance(summarizer_output, dict):
        return summary_data

    # Check if we have the nested structure (summary.summary.active_diagnoses)
    inner_summary = summarizer_output.get("summary", {})
    if isinstance(inner_summary, dict) and inner_summary.get("active_diagnoses") is not None:
        # Flatten: merge inner summary fields into the summarizer output level
        merged = dict(summarizer_output)
        for key, val in inner_summary.items():
            if key not in merged:
                merged[key] = val
            elif key in ("active_diagnoses", "medications", "key_findings", "timeline_gaps",
                         "chronological_events", "master_chronology", "overall_confidence",
                         "chief_complaint", "smoking_gun_quotes", "contradictions_flagged",
                         "discovery_deficiencies"):
                merged[key] = val
        result = dict(summary_data)
        result["summary"] = merged
        # Also promote billing_data and alerts to top level if not already there
        if "billing_data" not in result and "billing_data" in merged:
            result["billing_data"] = merged["billing_data"]
        if "alerts" not in result and "alerts" in merged:
            result["alerts"] = merged["alerts"]
        return result

    return summary_data


# Standard of care rules (rule-based checks before LLM)
TIMING_RULES = {
    "er_imaging": {
        "description": "ER visit with trauma should have imaging within visit",
        "trigger_keywords": ["emergency", "er ", "trauma", "accident", "mva", "fall"],
        "expected_keywords": ["x-ray", "ct scan", "mri", "imaging", "radiograph"],
        "severity": "high",
    },
    "followup_after_er": {
        "description": "Follow-up visit should occur within 7-14 days of ER discharge",
        "severity": "medium",
    },
    "referral_delay": {
        "description": "Specialist referral should occur within 2-4 weeks of persistent symptoms",
        "severity": "medium",
    },
    "surgical_consult": {
        "description": "Surgical consult indicated when conservative treatment fails after 6-12 weeks",
        "severity": "high",
    },
}

MEDICATION_RULES = {
    "nsaid_gi_risk": {
        "description": "NSAID use without GI protection in patients with risk factors",
        "nsaids": ["ibuprofen", "naproxen", "diclofenac", "meloxicam", "celecoxib"],
        "risk_factors": ["gi bleed", "ulcer", "gastritis", "anticoagulant", "warfarin", "aspirin"],
        "severity": "medium",
    },
    "opioid_monitoring": {
        "description": "Opioid prescribed without documented pain agreement or monitoring plan",
        "opioids": ["oxycodone", "hydrocodone", "morphine", "fentanyl", "tramadol", "codeine", "percocet", "vicodin"],
        "severity": "high",
    },
}

def detect_negligence(summary_data, config=None):
    """
    Main entry point. Analyzes summary data for standard-of-care issues.

    Returns dict with:
        - findings: list of negligence findings
        - severity_summary: counts by severity
        - overall_risk: low/medium/high/critical
        - recommendations: actionable items
    """
    config = config or {}
    summary_data = _normalize_summary_data(summary_data)
    findings = []

    # Step 1: Rule-based checks
    findings.extend(_check_timeline_gaps(summary_data))
    findings.extend(_check_medication_issues(summary_data))
    findings.extend(_check_documentation_gaps(summary_data))

    # Step 2: LLM-enhanced analysis
    try:
        llm_findings = _llm_negligence_analysis(summary_data, config)
        if llm_findings:
            findings.extend(llm_findings)
    except Exception as e:
        logger.warning("LLM negligence analysis failed: %s", e)

    # Deduplicate by title
    seen_titles = set()
    unique_findings = []
    for f in findings:
        key = f.get("title", "").lower().strip()
        if key and key not in seen_titles:
            seen_titles.add(key)
            unique_findings.append(f)

    # Calculate severity summary
    severity_counts = {"high": 0, "medium": 0, "low": 0}
    for f in unique_findings:
        sev = f.get("severity", "low")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    # Overall risk
    if severity_counts.get("high", 0) >= 2:
        overall_risk = "critical"
    elif severity_counts.get("high", 0) >= 1:
        overall_risk = "high"
    elif severity_counts.get("medium", 0) >= 2:
        overall_risk = "medium"
    else:
        overall_risk = "low"

    return {
        "findings": unique_findings,
        "severity_summary": severity_counts,
        "overall_risk": overall_risk,
        "finding_count": len(unique_findings),
    }


def _check_timeline_gaps(summary_data):
    """Check for significant gaps in treatment timeline."""
    findings = []
    summary = summary_data.get("summary", {})
    gaps = summary.get("timeline_gaps", [])

    for gap in gaps:
        if isinstance(gap, dict):
            desc = gap.get("gap_description", gap.get("note", str(gap)))
            findings.append({
                "title": f"Treatment Gap: {desc[:80]}",
                "description": f"A significant gap in treatment was identified: {desc}. Treatment gaps can indicate failure to follow up or patient non-compliance, both of which affect case value.",
                "severity": "medium",
                "type": "timeline_gap",
                "citation": gap.get("citation", ""),
                "recommendation": "Review whether the gap was patient-initiated or provider-initiated. Request records from the gap period.",
            })

    return findings


def _check_medication_issues(summary_data):
    """Check for medication-related standard of care issues."""
    findings = []
    summary = summary_data.get("summary", {})
    medications = summary.get("medications", [])
    diagnoses = summary.get("active_diagnoses", [])

    med_names = []
    for med in medications:
        if isinstance(med, dict):
            med_names.append(med.get("name", med.get("medication", str(med))).lower())
        elif isinstance(med, str):
            med_names.append(med.lower())

    all_text = " ".join(med_names + [str(d).lower() for d in diagnoses])

    # Check NSAID + GI risk
    rule = MEDICATION_RULES["nsaid_gi_risk"]
    has_nsaid = any(n in all_text for n in rule["nsaids"])
    has_risk = any(r in all_text for r in rule["risk_factors"])
    if has_nsaid and has_risk:
        findings.append({
            "title": "NSAID prescribed with GI risk factors present",
            "description": "NSAIDs were prescribed to a patient with documented GI risk factors without apparent gastroprotective co-prescription.",
            "severity": rule["severity"],
            "type": "medication_issue",
            "recommendation": "Verify if PPI or H2 blocker was co-prescribed. If not, this may indicate a prescribing oversight.",
        })

    # Check opioid without monitoring
    rule = MEDICATION_RULES["opioid_monitoring"]
    has_opioid = any(o in all_text for o in rule["opioids"])
    if has_opioid:
        findings.append({
            "title": "Opioid prescribed — verify monitoring documentation",
            "description": "Opioid medications were prescribed. Standard of care requires documented pain management agreements, risk assessments (e.g., PDMP check), and monitoring plans.",
            "severity": rule["severity"],
            "type": "medication_issue",
            "recommendation": "Request pain management agreement and PDMP check documentation. Absence may indicate inadequate monitoring.",
        })

    return findings


def _check_documentation_gaps(summary_data):
    """Check for documentation completeness issues."""
    findings = []
    summary = summary_data.get("summary", {})
    verification = summary_data.get("verification", summary_data.get("summary", {}).get("verification", {}))

    conf = summary.get("overall_confidence", 1.0)
    if conf < 0.6:
        findings.append({
            "title": "Low overall documentation confidence",
            "description": f"The overall confidence score is {conf:.0%}, indicating significant gaps or inconsistencies in the medical documentation.",
            "severity": "high",
            "type": "documentation_gap",
            "recommendation": "Request complete medical records. Current documentation may be incomplete or contain inconsistencies.",
        })

    # Check for low-confidence findings
    low_conf = verification.get("low_confidence_items", [])
    if isinstance(low_conf, list) and len(low_conf) > 2:
        findings.append({
            "title": f"{len(low_conf)} findings with low confidence scores",
            "description": "Multiple findings in the medical records have low confidence scores, suggesting inconsistent or ambiguous documentation.",
            "severity": "medium",
            "type": "documentation_gap",
            "recommendation": "Cross-reference low-confidence items with original source documents. May need clarification from treating providers.",
        })

    return findings


def _llm_negligence_analysis(summary_data, config):
    """Use Claude to perform deep negligence analysis."""
    from dispatch import call_claude

    summary = summary_data.get("summary", {})

    # Build context
    diagnoses = summary.get("active_diagnoses", [])
    medications = summary.get("medications", [])
    events = summary.get("chronological_events", [])
    findings = summary.get("key_findings", [])
    gaps = summary.get("timeline_gaps", [])
    alerts = summary.get("alerts", summary_data.get("alerts", []))

    def to_text(items):
        lines = []
        for item in (items or []):
            if isinstance(item, dict):
                lines.append(json.dumps(item))
            elif isinstance(item, str):
                lines.append(item)
        return "\n".join(lines) if lines else "None documented"

    prompt = f"""You are a medical-legal expert analyzing medical records for potential standard-of-care deviations and negligence indicators. This analysis is for a personal injury case.

DIAGNOSES:
{to_text(diagnoses)}

TREATMENT TIMELINE:
{to_text(events)}

KEY FINDINGS:
{to_text(findings)}

MEDICATIONS:
{to_text(medications)}

TREATMENT GAPS:
{to_text(gaps)}

EXISTING ALERTS:
{to_text(alerts if isinstance(alerts, list) else [])}

Analyze these records for:
1. DELAYED DIAGNOSIS: Was there an unreasonable delay in diagnosing the primary condition?
2. DELAYED REFERRAL: Were specialist referrals made in a timely manner?
3. TREATMENT ADEQUACY: Was the treatment plan appropriate for the diagnoses?
4. MEDICATION APPROPRIATENESS: Were medications appropriate, with proper monitoring?
5. DOCUMENTATION INCONSISTENCIES: Are there contradictions between different records/providers?
6. MISSED FOLLOW-UPS: Were recommended follow-ups actually completed?
7. STANDARD OF CARE: Does the treatment align with current clinical guidelines?

Return STRICT JSON array of findings. Each finding:
{{
    "title": "Brief title",
    "description": "Detailed explanation of the potential deviation",
    "severity": "high|medium|low",
    "type": "delayed_diagnosis|delayed_referral|treatment_inadequacy|medication_issue|documentation_inconsistency|missed_followup|standard_of_care",
    "recommendation": "Specific actionable recommendation for the attorney",
    "citation": "Reference to specific record if applicable"
}}

Return an empty array [] if no significant issues found. Only flag genuine concerns, not minor variations. Return ONLY the JSON array, nothing else."""

    # Inject RL feedback and exemplars
    feedback_context = _load_negligence_feedback()
    exemplar_context = _load_negligence_exemplars()
    if feedback_context:
        prompt += "\n\n" + feedback_context
    if exemplar_context:
        prompt += "\n\n" + exemplar_context

    model = config.get("claude", {}).get("model", "claude-sonnet-4-6")
    messages = [
        {"role": "system", "content": "You are a medical-legal negligence analyst. Respond only with a valid JSON array."},
        {"role": "user", "content": prompt},
    ]

    response = call_claude(
        model=model,
        messages=messages,
        config=config,
        timeout_override=120,
    )

    if not response:
        return []

    text = response.strip()
    # Extract JSON array
    match = re.search(r'\[.*\]', text, re.DOTALL)
    if match:
        text = match.group(0)

    try:
        results = json.loads(text)
        if isinstance(results, list):
            return results
    except (json.JSONDecodeError, TypeError):
        logger.warning("Failed to parse LLM negligence response")

    return []


# ── RL Feedback Loaders ──────────────────────────────────────────────────────

def _load_negligence_feedback():
    """Load attorney feedback on negligence findings to improve precision."""
    try:
        from db import get_db
        conn = get_db()
        try:
            # Get accept/reject ratios by finding type
            type_stats = conn.execute(
                """SELECT finding_title,
                          SUM(CASE WHEN finding_accepted = 1 THEN 1 ELSE 0 END) as accepted,
                          SUM(CASE WHEN finding_accepted = 0 THEN 1 ELSE 0 END) as rejected,
                          COUNT(*) as total
                   FROM negligence_feedback
                   WHERE finding_accepted IS NOT NULL
                   GROUP BY finding_title
                   HAVING COUNT(*) >= 2"""
            ).fetchall()

            # Get overall precision
            overall = conn.execute(
                """SELECT
                     SUM(CASE WHEN finding_accepted = 1 THEN 1 ELSE 0 END) as accepted,
                     SUM(CASE WHEN finding_accepted = 0 THEN 1 ELSE 0 END) as rejected,
                     COUNT(*) as total
                   FROM negligence_feedback WHERE finding_accepted IS NOT NULL"""
            ).fetchone()

            # Get recent corrections
            corrections = conn.execute(
                """SELECT finding_title, attorney_notes, corrected_severity
                   FROM negligence_feedback
                   WHERE attorney_notes IS NOT NULL AND attorney_notes != ''
                   ORDER BY created_at DESC LIMIT 8"""
            ).fetchall()

            if not overall or not overall["total"]:
                return ""

            parts = ["## PRECISION FEEDBACK FROM ATTORNEY REVIEWS"]
            total = overall["total"]
            accepted = overall["accepted"] or 0
            rejected = overall["rejected"] or 0
            precision = accepted / max(1, total)
            parts.append(f"Overall precision: {precision:.0%} ({accepted}/{total} findings accepted by attorneys)")

            # Flag high false-positive finding types
            if type_stats:
                high_fp = [t for t in type_stats if t["total"] >= 3 and (t["rejected"] or 0) / t["total"] > 0.5]
                high_precision = [t for t in type_stats if t["total"] >= 3 and (t["accepted"] or 0) / t["total"] > 0.8]

                if high_fp:
                    parts.append("\nFinding types with HIGH FALSE POSITIVE rate (reduce or eliminate these):")
                    for t in high_fp:
                        fp_rate = (t["rejected"] or 0) / t["total"]
                        parts.append(f"  - \"{t['finding_title']}\": {fp_rate:.0%} rejected ({t['rejected']}/{t['total']})")

                if high_precision:
                    parts.append("\nFinding types attorneys consistently ACCEPT (continue finding these):")
                    for t in high_precision:
                        acc_rate = (t["accepted"] or 0) / t["total"]
                        parts.append(f"  - \"{t['finding_title']}\": {acc_rate:.0%} accepted ({t['accepted']}/{t['total']})")

            if rejected > accepted and total >= 5:
                parts.append("\nIMPORTANT: Your findings are being rejected more often than accepted. "
                             "Be MORE conservative. Only flag findings with strong evidence of deviation. "
                             "Do NOT flag minor documentation variations or standard treatment choices.")

            if corrections:
                parts.append("\nRecent attorney corrections:")
                for c in corrections:
                    note = c["attorney_notes"][:150]
                    parts.append(f"  - {c['finding_title']}: {note}")

            parts.append("")
            return "\n".join(parts)

        finally:
            conn.close()

    except Exception as e:
        logger.warning("Could not load negligence feedback: %s", e)
        return ""


def _load_negligence_exemplars():
    """Load few-shot exemplars for negligence prompt injection."""
    try:
        from exemplar_manager import get_exemplars, build_exemplar_prompt
        exemplars = get_exemplars("negligence", limit=2)
        return build_exemplar_prompt("negligence", exemplars)
    except Exception as e:
        logger.warning("Could not load negligence exemplars: %s", e)
        return ""
