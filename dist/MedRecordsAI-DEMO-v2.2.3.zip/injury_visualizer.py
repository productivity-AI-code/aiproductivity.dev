"""
injury_visualizer.py -- Generates SVG body diagrams highlighting injury locations.

Maps medical diagnoses to anatomical body regions and renders a human body
outline with colored injury overlays for use in demand packages.
"""

import re
import logging

logger = logging.getLogger("injury_visualizer")


def _normalize_summary_data(summary_data):
    """Normalize the nested summary structure for uniform data access."""
    if not isinstance(summary_data, dict):
        return summary_data
    summarizer_output = summary_data.get("summary", {})
    if not isinstance(summarizer_output, dict):
        return summary_data
    inner_summary = summarizer_output.get("summary", {})
    if isinstance(inner_summary, dict) and inner_summary.get("active_diagnoses") is not None:
        merged = dict(summarizer_output)
        for key, val in inner_summary.items():
            if key not in merged or key in ("active_diagnoses", "medications", "key_findings",
                "timeline_gaps", "chronological_events", "master_chronology", "overall_confidence"):
                merged[key] = val
        result = dict(summary_data)
        result["summary"] = merged
        if "billing_data" not in result and "billing_data" in merged:
            result["billing_data"] = merged["billing_data"]
        return result
    return summary_data


# Body region mapping - diagnosis keywords to SVG region IDs
BODY_REGIONS = {
    "head": {
        "keywords": ["head", "skull", "cranial", "tbi", "traumatic brain", "concussion",
                      "subdural", "epidural", "intracranial", "scalp", "facial"],
        "color": "#EF4444",
        "cx": 200, "cy": 45, "rx": 25, "ry": 30,
        "label": "Head/Brain",
    },
    "cervical_spine": {
        "keywords": ["cervical", "neck", "c-spine", "c1", "c2", "c3", "c4", "c5", "c6", "c7",
                      "whiplash", "cervicalgia"],
        "color": "#F97316",
        "cx": 200, "cy": 95, "rx": 18, "ry": 15,
        "label": "Cervical Spine",
    },
    "left_shoulder": {
        "keywords": ["left shoulder", "left rotator", "left labr"],
        "color": "#EAB308",
        "cx": 145, "cy": 120, "rx": 22, "ry": 18,
        "label": "L. Shoulder",
    },
    "right_shoulder": {
        "keywords": ["right shoulder", "right rotator", "right labr"],
        "color": "#EAB308",
        "cx": 255, "cy": 120, "rx": 22, "ry": 18,
        "label": "R. Shoulder",
    },
    "thoracic_spine": {
        "keywords": ["thoracic", "t-spine", "upper back", "t1", "t2", "t3", "t4", "t5",
                      "t6", "t7", "t8", "t9", "t10", "t11", "t12", "rib", "chest wall"],
        "color": "#F97316",
        "cx": 200, "cy": 160, "rx": 35, "ry": 40,
        "label": "Thoracic Spine",
    },
    "left_arm": {
        "keywords": ["left arm", "left elbow", "left wrist", "left hand", "left forearm",
                      "left carpal", "left ulnar"],
        "color": "#8B5CF6",
        "cx": 115, "cy": 200, "rx": 14, "ry": 50,
        "label": "L. Arm",
    },
    "right_arm": {
        "keywords": ["right arm", "right elbow", "right wrist", "right hand", "right forearm",
                      "right carpal", "right ulnar"],
        "color": "#8B5CF6",
        "cx": 285, "cy": 200, "rx": 14, "ry": 50,
        "label": "R. Arm",
    },
    "lumbar_spine": {
        "keywords": ["lumbar", "l-spine", "lower back", "lumbosacral", "l1", "l2", "l3",
                      "l4", "l5", "s1", "sacral", "sacroiliac", "si joint",
                      "herniat", "bulging disc", "disc protru", "radiculopathy",
                      "sciatica", "stenosis", "spondylo", "degenerative disc"],
        "color": "#EF4444",
        "cx": 200, "cy": 225, "rx": 30, "ry": 25,
        "label": "Lumbar Spine",
    },
    "pelvis": {
        "keywords": ["pelvis", "pelvic", "hip", "acetabul", "femoral head", "iliac",
                      "pubic", "coccyx", "tailbone"],
        "color": "#EC4899",
        "cx": 200, "cy": 265, "rx": 40, "ry": 18,
        "label": "Pelvis/Hip",
    },
    "left_leg": {
        "keywords": ["left knee", "left leg", "left thigh", "left femur", "left tibia",
                      "left fibula", "left patella", "left acl", "left mcl", "left meniscus",
                      "left quadricep", "left hamstring", "left calf", "left shin"],
        "color": "#3B82F6",
        "cx": 175, "cy": 345, "rx": 18, "ry": 60,
        "label": "L. Leg",
    },
    "right_leg": {
        "keywords": ["right knee", "right leg", "right thigh", "right femur", "right tibia",
                      "right fibula", "right patella", "right acl", "right mcl", "right meniscus",
                      "right quadricep", "right hamstring", "right calf", "right shin"],
        "color": "#3B82F6",
        "cx": 225, "cy": 345, "rx": 18, "ry": 60,
        "label": "R. Leg",
    },
    "left_ankle_foot": {
        "keywords": ["left ankle", "left foot", "left achilles", "left plantar", "left toe"],
        "color": "#6366F1",
        "cx": 175, "cy": 425, "rx": 16, "ry": 15,
        "label": "L. Ankle/Foot",
    },
    "right_ankle_foot": {
        "keywords": ["right ankle", "right foot", "right achilles", "right plantar", "right toe"],
        "color": "#6366F1",
        "cx": 225, "cy": 425, "rx": 16, "ry": 15,
        "label": "R. Ankle/Foot",
    },
    # General (non-lateralized) -- map to both sides or center
    "knee_general": {
        "keywords": ["knee", "patella", "acl", "mcl", "meniscus", "patellar"],
        "color": "#3B82F6",
        "cx": 200, "cy": 330, "rx": 45, "ry": 20,
        "label": "Knee(s)",
    },
    "shoulder_general": {
        "keywords": ["shoulder", "rotator cuff", "labr", "impingement", "supraspinatus"],
        "color": "#EAB308",
        "cx": 200, "cy": 120, "rx": 60, "ry": 18,
        "label": "Shoulder(s)",
    },
    "abdomen": {
        "keywords": ["abdomen", "abdominal", "organ", "spleen", "liver", "kidney",
                      "intestin", "bowel", "stomach", "internal bleeding"],
        "color": "#DC2626",
        "cx": 200, "cy": 200, "rx": 35, "ry": 30,
        "label": "Abdomen",
    },
}


def _match_diagnoses_to_regions(summary_data):
    """Map diagnoses from summary data to body regions."""
    summary = summary_data.get("summary", {})
    diagnoses = summary.get("active_diagnoses", [])
    findings = summary.get("key_findings", [])

    all_text = ""
    for item in diagnoses + findings:
        if isinstance(item, dict):
            text = item.get("diagnosis", item.get("finding", item.get("text", "")))
            all_text += " " + str(text).lower()
        elif isinstance(item, str):
            all_text += " " + item.lower()

    matched_regions = {}
    # Check lateralized regions first, then general
    lateralized = [k for k in BODY_REGIONS if "left" in k or "right" in k]
    general = [k for k in BODY_REGIONS if k not in lateralized]

    for region_id in lateralized + general:
        region = BODY_REGIONS[region_id]
        for keyword in region["keywords"]:
            if keyword in all_text:
                # For general regions, don't add if lateralized version already matched
                if region_id in general:
                    base = region_id.replace("_general", "")
                    if f"left_{base}" in matched_regions or f"right_{base}" in matched_regions:
                        continue
                matched_regions[region_id] = {
                    "label": region["label"],
                    "color": region["color"],
                    "keyword_matched": keyword,
                }
                break

    return matched_regions


def generate_injury_svg(summary_data):
    """
    Generate an SVG body diagram with injury overlays.

    Returns dict with:
        - svg: SVG string
        - regions_affected: list of affected region labels
        - injury_count: number of injury regions
    """
    summary_data = _normalize_summary_data(summary_data)
    matched = _match_diagnoses_to_regions(summary_data)

    # Build SVG
    svg_parts = []
    svg_parts.append('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 480" width="400" height="480">
  <defs>
    <style>
      .body-outline { fill: #F1F5F9; stroke: #94A3B8; stroke-width: 1.5; }
      .injury-zone { opacity: 0.4; }
      .injury-label { font-family: system-ui, sans-serif; font-size: 10px; fill: #1E293B; font-weight: 600; }
      .title-text { font-family: system-ui, sans-serif; font-size: 14px; fill: #1E293B; font-weight: 700; }
      .subtitle-text { font-family: system-ui, sans-serif; font-size: 10px; fill: #64748B; }
    </style>
  </defs>

  <!-- Title -->
  <text x="200" y="18" text-anchor="middle" class="title-text">Injury Diagram</text>

  <!-- Body Outline (simplified human figure) -->
  <!-- Head -->
  <ellipse cx="200" cy="52" rx="22" ry="26" class="body-outline"/>
  <!-- Neck -->
  <rect x="192" y="78" width="16" height="15" rx="3" class="body-outline"/>
  <!-- Torso -->
  <path d="M155 93 Q155 88 165 88 L235 88 Q245 88 245 93 L250 250 Q250 260 240 260 L160 260 Q150 260 150 250 Z" class="body-outline"/>
  <!-- Left Arm -->
  <path d="M155 93 Q135 95 125 120 L110 200 Q105 220 108 250 L115 250 Q120 220 118 200 L130 120 Q135 105 155 100" class="body-outline"/>
  <!-- Right Arm -->
  <path d="M245 93 Q265 95 275 120 L290 200 Q295 220 292 250 L285 250 Q280 220 282 200 L270 120 Q265 105 245 100" class="body-outline"/>
  <!-- Left Leg -->
  <path d="M165 258 L160 340 Q158 370 162 410 L158 440 L175 440 L172 410 Q168 370 170 340 L180 258" class="body-outline"/>
  <!-- Right Leg -->
  <path d="M220 258 L225 340 Q228 370 232 410 L228 440 L245 440 L242 410 Q238 370 235 340 L230 258" class="body-outline"/>
''')

    # Add injury overlays
    legend_y = 460
    for i, (region_id, info) in enumerate(matched.items()):
        region = BODY_REGIONS[region_id]
        color = region["color"]
        cx, cy = region["cx"], region["cy"]
        rx, ry = region["rx"], region["ry"]

        # Pulsing injury zone
        svg_parts.append(f'''  <!-- {info["label"]} -->
  <ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{color}" class="injury-zone">
    <animate attributeName="opacity" values="0.3;0.6;0.3" dur="2s" repeatCount="indefinite"/>
  </ellipse>
  <ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="none" stroke="{color}" stroke-width="2" opacity="0.8"/>
''')

    # Legend
    if matched:
        legend_start_x = 20
        legend_y = 460
        svg_parts.append(f'  <line x1="20" y1="{legend_y - 8}" x2="380" y2="{legend_y - 8}" stroke="#E2E8F0" stroke-width="1"/>')

        items_per_row = 3
        for i, (region_id, info) in enumerate(matched.items()):
            region = BODY_REGIONS[region_id]
            col = i % items_per_row
            row = i // items_per_row
            x = legend_start_x + col * 130
            y = legend_y + row * 16
            svg_parts.append(f'  <rect x="{x}" y="{y}" width="8" height="8" rx="2" fill="{region["color"]}"/>')
            svg_parts.append(f'  <text x="{x + 12}" y="{y + 8}" class="injury-label">{info["label"]}</text>')

    # Adjust viewBox height based on legend
    extra_height = 10 + (len(matched) // 3 + 1) * 16 if matched else 0
    total_height = 460 + extra_height

    svg_parts.append('</svg>')
    svg_content = '\n'.join(svg_parts)

    # Fix viewBox height
    svg_content = svg_content.replace('viewBox="0 0 400 480"', f'viewBox="0 0 400 {total_height}"')
    svg_content = svg_content.replace('height="480"', f'height="{total_height}"')

    return {
        "svg": svg_content,
        "regions_affected": [info["label"] for info in matched.values()],
        "injury_count": len(matched),
    }
