"""
task_generator.py -- Generates actionable task lists from medical record analysis.

When records reveal findings, gaps, alerts, or negligence issues, this module
auto-generates prioritized task lists for the legal team.

Examples:
- "Depose Dr. Smith about LOC discrepancy"
- "Request imaging records from Memorial Hospital (gap: 3/15 - 6/20)"
- "Follow up on pre-existing condition documentation"
- "Subpoena pharmacy records for opioid prescriptions"
"""

import json
import logging
import re
from datetime import datetime

logger = logging.getLogger("task_generator")


def _normalize_summary_data(summary_data):
    """Normalize the nested summary structure for uniform data access."""
    if not isinstance(summary_data, dict):
        return summary_data
    summarizer_output = summary_data.get("summary", {})
    if not isinstance(summarizer_output, dict):
        return summary_data
    inner_summary = summarizer_output.get("summary", {})
    if isinstance(inner_summary, dict) and inner_summary.get("active_diagnoses") is not None:
        merged = dict(summarizer_output)
        for key, val in inner_summary.items():
            if key not in merged or key in ("active_diagnoses", "medications", "key_findings",
                "timeline_gaps", "chronological_events", "master_chronology", "overall_confidence"):
                merged[key] = val
        result = dict(summary_data)
        result["summary"] = merged
        if "billing_data" not in result and "billing_data" in merged:
            result["billing_data"] = merged["billing_data"]
        if "alerts" not in result and "alerts" in merged:
            result["alerts"] = merged["alerts"]
        return result
    return summary_data


TASK_CATEGORIES = {
    "deposition": {"icon": "\U0001f4cb", "priority_base": 2},
    "records_request": {"icon": "\U0001f4c1", "priority_base": 3},
    "follow_up": {"icon": "\U0001f4de", "priority_base": 4},
    "investigation": {"icon": "\U0001f50d", "priority_base": 3},
    "documentation": {"icon": "\U0001f4dd", "priority_base": 5},
    "expert_review": {"icon": "\U0001f468\u200d\u2695\ufe0f", "priority_base": 1},
    "discovery": {"icon": "\u2696\ufe0f", "priority_base": 2},
}


def generate_tasks(summary_data, config=None):
    """
    Main entry point. Generate task list from summary data.

    Returns dict with:
        - tasks: list of task objects
        - task_count: total count
        - priority_breakdown: counts by priority
    """
    config = config or {}
    summary_data = _normalize_summary_data(summary_data)
    tasks = []

    # Rule-based task generation
    tasks.extend(_tasks_from_gaps(summary_data))
    tasks.extend(_tasks_from_alerts(summary_data))
    tasks.extend(_tasks_from_billing(summary_data))
    tasks.extend(_tasks_from_providers(summary_data))

    # LLM-enhanced task generation
    try:
        llm_tasks = _llm_task_generation(summary_data, config)
        if llm_tasks:
            tasks.extend(llm_tasks)
    except Exception as e:
        logger.warning("LLM task generation failed: %s", e)

    # Deduplicate
    seen = set()
    unique_tasks = []
    for t in tasks:
        key = t.get("title", "").lower().strip()[:50]
        if key and key not in seen:
            seen.add(key)
            unique_tasks.append(t)

    # Sort by priority (1=highest)
    unique_tasks.sort(key=lambda t: t.get("priority", 5))

    # Number them
    for i, t in enumerate(unique_tasks, 1):
        t["task_number"] = i

    priority_breakdown = {}
    for t in unique_tasks:
        p = t.get("priority", 5)
        label = {1: "critical", 2: "high", 3: "medium", 4: "low", 5: "routine"}.get(p, "routine")
        priority_breakdown[label] = priority_breakdown.get(label, 0) + 1

    return {
        "tasks": unique_tasks,
        "task_count": len(unique_tasks),
        "priority_breakdown": priority_breakdown,
    }


def _tasks_from_gaps(summary_data):
    """Generate tasks from timeline gaps."""
    tasks = []
    summary = summary_data.get("summary", {})
    gaps = summary.get("timeline_gaps", [])

    for gap in gaps:
        if isinstance(gap, dict):
            desc = gap.get("gap_description", gap.get("note", str(gap)))
            tasks.append({
                "title": f"Request records for treatment gap: {desc[:60]}",
                "description": f"A treatment gap was identified: {desc}. Request all medical records covering this period to determine if treatment was received elsewhere.",
                "category": "records_request",
                "priority": 3,
                "assignee_type": "paralegal",
            })
    return tasks


def _tasks_from_alerts(summary_data):
    """Generate tasks from case alerts."""
    tasks = []
    summary = summary_data.get("summary", {})
    alerts = summary.get("alerts", summary_data.get("alerts", []))

    for alert in (alerts if isinstance(alerts, list) else []):
        if isinstance(alert, dict):
            severity = alert.get("severity", "medium")
            title = alert.get("title", "")
            desc = alert.get("description", "")
            alert_type = alert.get("type", "")

            if severity == "high":
                if "pre-existing" in (title + desc).lower():
                    tasks.append({
                        "title": f"Investigate pre-existing condition: {title[:50]}",
                        "description": f"High-severity alert: {desc}. Obtain complete prior medical history to document baseline vs. injury-related changes.",
                        "category": "investigation",
                        "priority": 2,
                        "assignee_type": "attorney",
                    })
                elif "gap" in (title + desc).lower() or "compliance" in (title + desc).lower():
                    tasks.append({
                        "title": f"Address treatment compliance issue: {title[:50]}",
                        "description": f"Alert flagged: {desc}. Prepare client explanation for deposition readiness.",
                        "category": "follow_up",
                        "priority": 2,
                        "assignee_type": "attorney",
                    })
                else:
                    tasks.append({
                        "title": f"Review high-severity alert: {title[:50]}",
                        "description": f"{desc}. This requires immediate attorney review and may impact case strategy.",
                        "category": "investigation",
                        "priority": 1,
                        "assignee_type": "attorney",
                    })
    return tasks


def _tasks_from_billing(summary_data):
    """Generate tasks from billing data."""
    tasks = []
    summary = summary_data.get("summary", {})
    billing = summary.get("billing_data", summary_data.get("billing_data", {}))

    if isinstance(billing, dict):
        providers = billing.get("providers", [])
        for prov in providers:
            if isinstance(prov, dict):
                name = prov.get("provider_name", prov.get("name", ""))
                total = prov.get("total_billed", prov.get("total", 0))
                try:
                    total_val = float(str(total).replace("$", "").replace(",", ""))
                except (ValueError, TypeError):
                    total_val = 0

                if total_val > 10000:
                    tasks.append({
                        "title": f"Verify billing records from {name[:40]}",
                        "description": f"Provider {name} has ${total_val:,.0f} in billed charges. Verify all bills are itemized and match treatment records.",
                        "category": "documentation",
                        "priority": 4,
                        "assignee_type": "paralegal",
                    })

        future = billing.get("total_future_medical_estimate", 0)
        try:
            future_val = float(str(future).replace("$", "").replace(",", ""))
        except (ValueError, TypeError):
            future_val = 0

        if future_val > 0:
            tasks.append({
                "title": "Obtain future care opinion from treating physician",
                "description": f"Future medical estimate of ${future_val:,.0f} documented. Obtain written opinion letter from treating physician to support this projection.",
                "category": "expert_review",
                "priority": 1,
                "assignee_type": "attorney",
            })

    return tasks


def _tasks_from_providers(summary_data):
    """Generate tasks for provider-related follow-ups."""
    tasks = []
    summary = summary_data.get("summary", {})
    events = summary.get("chronological_events", summary.get("master_chronology", []))

    providers = set()
    for event in events:
        if isinstance(event, dict):
            prov = event.get("provider", "")
            if prov:
                providers.add(prov.strip())

    if len(providers) >= 3:
        tasks.append({
            "title": f"Compile complete provider list ({len(providers)} providers)",
            "description": f"Case involves {len(providers)} medical providers. Create master provider list with contact info for records requests and potential depositions.",
            "category": "documentation",
            "priority": 4,
            "assignee_type": "paralegal",
        })

    return tasks


def _llm_task_generation(summary_data, config):
    """Use Claude to generate additional strategic tasks."""
    from dispatch import call_claude

    summary = summary_data.get("summary", {})

    def to_text(items):
        lines = []
        for item in (items or []):
            if isinstance(item, dict):
                lines.append(json.dumps(item))
            elif isinstance(item, str):
                lines.append(item)
        return "\n".join(lines[:20]) if lines else "None"

    diagnoses = to_text(summary.get("active_diagnoses", []))
    events = to_text(summary.get("chronological_events", summary.get("master_chronology", []))[:15])
    findings = to_text(summary.get("key_findings", []))
    alerts = to_text(summary.get("alerts", summary_data.get("alerts", [])) if isinstance(summary.get("alerts", summary_data.get("alerts", [])), list) else [])

    prompt = f"""You are a senior personal injury paralegal generating an actionable task list from medical record analysis.

DIAGNOSES:
{diagnoses}

TREATMENT TIMELINE (recent):
{events}

KEY FINDINGS:
{findings}

ALERTS:
{alerts}

Generate 3-8 specific, actionable tasks for the legal team. Each task should be something a paralegal or attorney needs to DO. Focus on:
- Depositions to schedule
- Records to request
- Experts to consult
- Documentation to verify
- Witnesses to contact
- Discovery items

Return STRICT JSON array:
[
  {{
    "title": "Short actionable title (imperative verb)",
    "description": "Detailed description of what to do and why",
    "category": "deposition|records_request|follow_up|investigation|documentation|expert_review|discovery",
    "priority": 1-5 (1=critical, 5=routine),
    "assignee_type": "attorney|paralegal"
  }}
]

Return ONLY the JSON array, nothing else."""

    model = config.get("claude", {}).get("model", "claude-sonnet-4-6")
    messages = [
        {"role": "system", "content": "You are a personal injury paralegal task manager. Respond only with a valid JSON array."},
        {"role": "user", "content": prompt},
    ]

    response = call_claude(
        model=model,
        messages=messages,
        config=config,
        timeout_override=120,
    )

    if not response:
        return []

    text = response.strip()
    match = re.search(r'\[.*\]', text, re.DOTALL)
    if match:
        text = match.group(0)

    try:
        results = json.loads(text)
        if isinstance(results, list):
            return results
    except (json.JSONDecodeError, TypeError):
        logger.warning("Failed to parse LLM task generation response")

    return []
