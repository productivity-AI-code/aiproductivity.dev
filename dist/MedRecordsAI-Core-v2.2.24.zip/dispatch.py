import argparse
import copy
import json
import os
import random
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
import requests
import yaml
from dotenv import load_dotenv
try:
    from error_tracker import record_error, inject_into_prompt
except ImportError:

    def record_error(*args, **kwargs):
        pass

    def inject_into_prompt(_agent, prompt):
        return prompt
from db import transaction, get_db, init_db
load_dotenv()
BASE_DIR = Path(__file__).parent

def load_config():
    config_path = BASE_DIR / 'config.yaml'
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}

def make_task_id(agent_name):
    ts = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    return f'{ts}-{agent_name}'

def get_task(task_id):
    with get_db() as conn:
        row = conn.execute('SELECT * FROM tasks WHERE task_id = ?', (task_id,)).fetchone()
        return dict(row) if row else None

def update_task(task_id, **kwargs):
    if not kwargs:
        return
    cols = ', '.join([f'{k} = ?' for k in kwargs.keys()])
    vals = list(kwargs.values()) + [task_id]
    with transaction() as conn:
        conn.execute(f'UPDATE tasks SET {cols} WHERE task_id = ?', vals)

def create_task(task_id, agent, model, role, task, context=None, status='queued'):
    with transaction() as conn:
        conn.execute("\n            INSERT OR REPLACE INTO tasks (task_id, agent, model, role, task, context, status, created_at)\n            VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))\n        ", (task_id, agent, model, role, task, context, status))

def list_tasks(limit=50):
    with get_db() as conn:
        rows = conn.execute('SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()
        return [dict(r) for r in rows]

def load_agent_prompt(config, agent_name):
    agents_dir = config.get('paths', {}).get('agents_dir', 'agents')
    prompt_file = BASE_DIR / agents_dir / agent_name / 'prompt.md'
    if prompt_file.exists():
        return prompt_file.read_text(encoding='utf-8')
    return f'You are {agent_name}, an AI assistant.'

def _wait_for_ollama(endpoint, max_wait=120):
    url = f'{endpoint}/api/tags'
    elapsed = 0
    interval = 5
    while elapsed < max_wait:
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                if elapsed > 0:
                    print(f'  Ollama is ready (waited {elapsed}s).')
                return True
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            pass
        print(f'  Ollama not ready, retrying in {interval}s... ({elapsed}/{max_wait}s elapsed)')
        time.sleep(interval)
        elapsed += interval
    return False

def _warmup_model(model, endpoint, timeout=60):
    try:
        ps = requests.get(f'{endpoint}/api/ps', timeout=5).json()
        loaded = [m['name'] for m in ps.get('models', [])]
        if model in loaded:
            print(f'  {model} already loaded — skipping warmup.')
            return
    except Exception:
        pass
    print(f'  Loading {model} into memory...', end=' ', flush=True)
    try:
        r = requests.post(f'{endpoint}/api/show', json={'name': model}, timeout=timeout)
        r.raise_for_status()
        print('ready.')
    except Exception as e:
        print(f'warmup skipped ({e}).')

def _trim_context(messages, ratio=0.6):
    trimmed = copy.deepcopy(messages)
    for msg in trimmed:
        if msg['role'] == 'user':
            content = msg['content']
            marker = '\n\n## Context\n'
            if marker in content:
                task_part, context_part = content.split(marker, 1)
                max_len = int(len(context_part) * ratio)
                trimmed_context = context_part[:max_len]
                if max_len < len(context_part):
                    trimmed_context += '\n\n[Context trimmed due to timeout — see staging files for full details]'
                msg['content'] = task_part + marker + trimmed_context
            else:
                max_len = int(len(content) * ratio)
                msg['content'] = content[:max_len] + '\n\n[Content trimmed due to timeout]'
            break
    return trimmed

def call_ollama(model, messages, endpoint, timeout, retries, force_json=False):
    url = f'{endpoint}/api/chat'
    current_messages = messages
    payload_base = {'model': model, 'stream': False}
    if force_json:
        payload_base['format'] = 'json'
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json={**payload_base, 'messages': current_messages}, timeout=timeout)
            resp.raise_for_status()
            content = resp.json()['message']['content']
            content = re.sub('<think>.*?</think>\\s*', '', content, flags=re.DOTALL)
            if not content or not content.strip():
                raise RuntimeError('__ERROR__:empty_response:Empty response from Ollama')
            return content
        except requests.exceptions.Timeout:
            if attempt == retries:
                raise RuntimeError(f'__ERROR__:api_timeout:Ollama timed out after {timeout}s ({retries} attempts)')
            trim_ratios = [0.6, 0.4, 0.25]
            ratio = trim_ratios[min(attempt - 1, len(trim_ratios) - 1)]
            original_len = sum((len(m['content']) for m in current_messages))
            current_messages = _trim_context(current_messages, ratio=ratio)
            trimmed_len = sum((len(m['content']) for m in current_messages))
            delay = _backoff_delay(attempt)
            print(f'  Timeout on attempt {attempt}/{retries}. Context trimmed to {ratio:.0%}: {original_len} -> {trimmed_len} chars. Retrying in {delay:.1f}s...')
            time.sleep(delay)
        except requests.exceptions.ConnectionError as e:
            if attempt == retries:
                raise RuntimeError(f'__ERROR__:api_connection_error:Cannot connect to Ollama at {endpoint}: {e}')
            delay = _backoff_delay(attempt)
            print(f'  ConnectionError on attempt {attempt}/{retries}: {e}. Retrying in {delay:.1f}s...')
            time.sleep(delay)
        except RuntimeError:
            raise
        except requests.exceptions.RequestException as e:
            if attempt == retries:
                raise RuntimeError(f'__ERROR__:api_error:Ollama request failed after {retries} attempts: {e}')
            delay = _backoff_delay(attempt)
            print(f'  Error on attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)

def _backoff_delay(attempt, base=2.0, max_delay=60.0):
    delay = base * 3 ** (attempt - 1)
    delay = min(delay, max_delay)
    jitter = delay * 0.3 * (2 * random.random() - 1)
    return max(0.5, delay + jitter)

def _classify_api_error(error):
    import anthropic
    if isinstance(error, anthropic.AuthenticationError):
        return ('api_key_invalid', False, 0)
    if isinstance(error, anthropic.PermissionDeniedError):
        return ('api_key_invalid', False, 0)
    if isinstance(error, anthropic.RateLimitError):
        wait = 30
        if hasattr(error, 'response') and error.response is not None:
            retry_after = error.response.headers.get('retry-after')
            if retry_after:
                try:
                    wait = min(int(float(retry_after)), 120)
                except (ValueError, TypeError):
                    pass
        return ('api_rate_limited', True, wait)
    if isinstance(error, anthropic.InternalServerError):
        return ('api_server_error', True, 15)
    if isinstance(error, anthropic.APIStatusError):
        status = getattr(error, 'status_code', 0)
        error_body = str(error).lower()
        if status == 400 and ('context' in error_body or 'too large' in error_body or 'token' in error_body):
            return ('context_length_exceeded', True, 2)
        if status == 529:
            return ('api_overloaded', True, 30)
        return ('api_error', True, 5)
    err_str = str(error).lower()
    if 'credit balance' in err_str or 'insufficient' in err_str:
        return ('api_credits_exhausted', False, 0)
    if 'timeout' in err_str or 'timed out' in err_str:
        return ('api_timeout', True, 5)
    if isinstance(error, (ConnectionError, OSError)):
        return ('api_connection_error', True, 10)
    return ('api_error', True, 5)

def call_claude(model, messages, config, timeout_override=None, max_tokens_override=None):
    import anthropic
    api_key = os.getenv('ANTHROPIC_API_KEY', '')
    if not api_key:
        raise RuntimeError('ANTHROPIC_API_KEY not set in environment')
    claude_cfg = config.get('claude', {})
    max_tokens = max_tokens_override or claude_cfg.get('max_tokens', 16384)
    max_tokens = min(max_tokens, 64000)
    timeout = timeout_override or claude_cfg.get('timeout', 180)
    retries = claude_cfg.get('retries', 2)
    system_text = ''
    conversation = []
    for msg in messages:
        if msg['role'] == 'system':
            system_text += msg['content'] + '\n'
        else:
            conversation.append({'role': msg['role'], 'content': msg['content']})
    if not conversation or conversation[0]['role'] != 'user':
        conversation.insert(0, {'role': 'user', 'content': 'Please proceed with the task.'})
    import httpx
    hard_timeout = httpx.Timeout(connect=15.0, read=min(timeout, 300), write=30.0, pool=10.0)
    client = anthropic.Anthropic(api_key=api_key, timeout=hard_timeout)
    last_error = None
    last_error_type = 'api_error'
    for attempt in range(1, retries + 1):
        try:
            response = client.messages.create(model=model, max_tokens=max_tokens, system=system_text.strip() if system_text.strip() else anthropic.NOT_GIVEN, messages=conversation)
            text_parts = []
            for block in response.content:
                if block.type == 'text':
                    text_parts.append(block.text)
            result = '\n'.join(text_parts)
            if not result.strip():
                raise RuntimeError('__ERROR__:empty_response:Empty response from Claude API')
            return result
        except Exception as e:
            last_error = e
            error_type, retryable, wait_override = _classify_api_error(e)
            last_error_type = error_type
            if not retryable:
                raise RuntimeError(f'__ERROR__:{error_type}:{e}')
            if attempt == retries:
                break
            delay = wait_override if wait_override > 0 else _backoff_delay(attempt)
            if error_type == 'context_length_exceeded':
                trim_ratios = [0.5, 0.3, 0.2]
                ratio = trim_ratios[min(attempt - 1, len(trim_ratios) - 1)]
                original_len = sum((len(m['content']) for m in conversation))
                conversation = _trim_context(conversation, ratio=ratio)
                trimmed_len = sum((len(m['content']) for m in conversation))
                print(f'  Claude API context_length_exceeded on attempt {attempt}/{retries}: context trimmed to {ratio:.0%}: {original_len} -> {trimmed_len} chars. Retrying in {delay:.1f}s...')
            elif error_type == 'api_timeout':
                trim_ratios = [0.6, 0.4, 0.25]
                ratio = trim_ratios[min(attempt - 1, len(trim_ratios) - 1)]
                original_len = sum((len(m['content']) for m in conversation))
                conversation = _trim_context(conversation, ratio=ratio)
                trimmed_len = sum((len(m['content']) for m in conversation))
                print(f'  Claude API {error_type} on attempt {attempt}/{retries}: context trimmed to {ratio:.0%}: {original_len} -> {trimmed_len} chars. Retrying in {delay:.1f}s...')
            else:
                print(f'  Claude API {error_type} on attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)
    raise RuntimeError(f'__ERROR__:{last_error_type}:Claude API failed after {retries} attempts: {last_error}')

def call_claude_vision(model, system_prompt, text_prompt, images, config, timeout_override=None, max_tokens_override=None):
    import anthropic
    import base64
    api_key = os.getenv('ANTHROPIC_API_KEY', '')
    if not api_key:
        raise RuntimeError('ANTHROPIC_API_KEY not set in environment')
    claude_cfg = config.get('claude', {})
    max_tokens = max_tokens_override or claude_cfg.get('max_tokens', 16384)
    timeout = timeout_override or claude_cfg.get('timeout', 180)
    retries = claude_cfg.get('retries', 2)
    content_blocks = []
    for img_bytes, media_type in images:
        content_blocks.append({'type': 'image', 'source': {'type': 'base64', 'media_type': media_type, 'data': base64.b64encode(img_bytes).decode('ascii')}})
    content_blocks.append({'type': 'text', 'text': text_prompt})
    conversation = [{'role': 'user', 'content': content_blocks}]
    client = anthropic.Anthropic(api_key=api_key)
    last_error = None
    last_error_type = 'api_error'
    for attempt in range(1, retries + 1):
        try:
            response = client.messages.create(model=model, max_tokens=max_tokens, system=system_prompt if system_prompt else anthropic.NOT_GIVEN, messages=conversation, timeout=timeout)
            text_parts = []
            for block in response.content:
                if block.type == 'text':
                    text_parts.append(block.text)
            return '\n'.join(text_parts)
        except Exception as e:
            last_error = e
            error_type, retryable, wait_override = _classify_api_error(e)
            last_error_type = error_type
            if not retryable:
                raise RuntimeError(f'__ERROR__:{error_type}:{e}')
            if attempt == retries:
                break
            delay = wait_override if wait_override > 0 else _backoff_delay(attempt)
            print(f'  Claude Vision {error_type} attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)
    raise RuntimeError(f'__ERROR__:{last_error_type}:Claude Vision API failed after {retries} attempts: {last_error}')

def _classify_bedrock_error(error):
    try:
        import botocore.exceptions
        if isinstance(error, botocore.exceptions.ClientError):
            code = error.response['Error']['Code']
            if code in ('ThrottlingException',):
                return ('api_rate_limited', True, 30)
            if code == 'ModelTimeoutException':
                return ('api_timeout', True, 5)
            if code in ('AccessDeniedException',):
                return ('api_key_invalid', False, 0)
            if code == 'ValidationException':
                err_msg = str(error).lower()
                if 'too many' in err_msg or 'token' in err_msg or 'input is too long' in err_msg:
                    return ('context_length_exceeded', True, 2)
                return ('api_key_invalid', False, 0)
            if code in ('ModelNotReadyException', 'ServiceUnavailableException'):
                return ('api_server_error', True, 15)
            if code == 'ModelErrorException':
                return ('api_server_error', True, 10)
        if isinstance(error, botocore.exceptions.ReadTimeoutError):
            return ('api_timeout', True, 5)
        if isinstance(error, botocore.exceptions.ConnectTimeoutError):
            return ('api_connection_error', True, 10)
    except ImportError:
        pass
    return ('api_error', True, 5)

def _estimate_tokens(text):
    if not text:
        return 0
    return max(1, len(text) // 4)

def _measure_messages(messages):
    total = 0
    for msg in messages:
        content = msg.get('content', '')
        if isinstance(content, str):
            total += len(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    if block.get('type') == 'text':
                        total += len(block.get('text', ''))
                    elif block.get('type') == 'image':
                        total += len(block.get('source', {}).get('data', ''))
    return total
_MODEL_INPUT_LIMITS = {'haiku': 180000, 'sonnet': 180000, 'opus': 180000}

def _get_model_input_limit(model_id):
    model_lower = model_id.lower()
    for key, limit in _MODEL_INPUT_LIMITS.items():
        if key in model_lower:
            return limit
    return 180000

def call_bedrock(model_id, messages, config, timeout_override=None, max_tokens_override=None):
    import boto3
    import botocore.config
    import botocore.exceptions
    bedrock_cfg = config.get('bedrock', {})
    region = bedrock_cfg.get('region', os.getenv('AWS_DEFAULT_REGION', 'us-east-1'))
    max_tokens = max_tokens_override or bedrock_cfg.get('max_tokens', 16384)
    max_tokens = min(max_tokens, 64000)
    timeout_val = timeout_override or bedrock_cfg.get('timeout', 300)
    retries = bedrock_cfg.get('retries', 3)
    system_text = ''
    conversation = []
    for msg in messages:
        if msg['role'] == 'system':
            system_text += msg['content'] + '\n'
        else:
            conversation.append({'role': msg['role'], 'content': msg['content']})
    if not conversation or conversation[0]['role'] != 'user':
        conversation.insert(0, {'role': 'user', 'content': 'Please proceed with the task.'})
    total_chars = len(system_text) + sum((len(m.get('content', '')) if isinstance(m.get('content'), str) else 0 for m in conversation))
    estimated_tokens = _estimate_tokens(system_text) + sum((_estimate_tokens(m.get('content', '')) if isinstance(m.get('content'), str) else 0 for m in conversation))
    input_limit = _get_model_input_limit(model_id)
    print(f"  Bedrock pre-flight: {total_chars:,} chars, ~{estimated_tokens:,} tokens (limit ~{input_limit:,}), model={model_id.split('.')[-1]}")
    if estimated_tokens > input_limit:
        target_chars = int(input_limit * 4 * 0.85)
        sys_chars = len(system_text)
        available_for_conv = max(target_chars - sys_chars, 10000)
        conversation = _trim_context(conversation, ratio=available_for_conv / max(total_chars - sys_chars, 1))
        trimmed_chars = sum((len(m.get('content', '')) if isinstance(m.get('content'), str) else 0 for m in conversation))
        print(f"  Bedrock auto-trim: {total_chars:,} -> {sys_chars + trimmed_chars:,} chars (~{_estimate_tokens(system_text) + sum((_estimate_tokens(m.get('content', '')) if isinstance(m.get('content'), str) else 0 for m in conversation)):,} tokens)")
    body = {'anthropic_version': 'bedrock-2023-05-31', 'max_tokens': max_tokens, 'messages': conversation}
    if system_text.strip():
        body['system'] = system_text.strip()
    body_json = json.dumps(body)
    body_size_mb = len(body_json.encode('utf-8')) / (1024 * 1024)
    if body_size_mb > 20:
        conversation = _trim_context(conversation, ratio=0.3)
        body['messages'] = conversation
        body_json = json.dumps(body)
        print(f'  Bedrock body too large ({body_size_mb:.1f}MB), trimmed to {len(body_json) / (1024 * 1024):.1f}MB')
    client = boto3.client('bedrock-runtime', region_name=region, config=botocore.config.Config(read_timeout=timeout_val, connect_timeout=15, retries={'max_attempts': 0}))
    last_error = None
    last_error_type = 'api_error'
    for attempt in range(1, retries + 1):
        try:
            response = client.invoke_model(modelId=model_id, body=json.dumps(body), contentType='application/json', accept='application/json')
            result = json.loads(response['body'].read())
            stop_reason = result.get('stop_reason', '')
            usage = result.get('usage', {})
            input_tokens = usage.get('input_tokens', 0)
            output_tokens = usage.get('output_tokens', 0)
            text_parts = []
            for block in result.get('content', []):
                if block.get('type') == 'text':
                    text_parts.append(block['text'])
            text = '\n'.join(text_parts)
            print(f'  Bedrock response: {input_tokens:,} in / {output_tokens:,} out tokens, stop={stop_reason}, {len(text):,} chars')
            if stop_reason == 'max_tokens':
                print(f'  WARNING: Response truncated at max_tokens={max_tokens}. Output may be incomplete JSON. Pipeline will attempt recovery.')
            if not text.strip():
                raise RuntimeError('__ERROR__:empty_response:Empty response from Bedrock')
            return text
        except (botocore.exceptions.ClientError, botocore.exceptions.ReadTimeoutError, botocore.exceptions.ConnectTimeoutError) as e:
            last_error = e
            error_type, retryable, wait_override = _classify_bedrock_error(e)
            last_error_type = error_type
            if not retryable:
                raise RuntimeError(f'__ERROR__:{error_type}:{e}')
            if attempt == retries:
                break
            delay = wait_override if wait_override > 0 else _backoff_delay(attempt)
            if error_type == 'context_length_exceeded':
                trim_ratios = [0.5, 0.3, 0.2]
                ratio = trim_ratios[min(attempt - 1, len(trim_ratios) - 1)]
                original_len = sum((len(m.get('content', '') if isinstance(m.get('content'), str) else '') for m in conversation))
                conversation = _trim_context(conversation, ratio=ratio)
                trimmed_len = sum((len(m.get('content', '') if isinstance(m.get('content'), str) else '') for m in conversation))
                body['messages'] = conversation
                print(f'  Bedrock context_length_exceeded attempt {attempt}/{retries}: trimmed {ratio:.0%}: {original_len} -> {trimmed_len} chars. Retrying in {delay:.1f}s...')
            elif error_type == 'api_timeout':
                trim_ratios = [0.6, 0.4, 0.25]
                ratio = trim_ratios[min(attempt - 1, len(trim_ratios) - 1)]
                original_len = sum((len(m.get('content', '') if isinstance(m.get('content'), str) else '') for m in conversation))
                conversation = _trim_context(conversation, ratio=ratio)
                trimmed_len = sum((len(m.get('content', '') if isinstance(m.get('content'), str) else '') for m in conversation))
                body['messages'] = conversation
                print(f'  Bedrock timeout attempt {attempt}/{retries}: trimmed {ratio:.0%}: {original_len} -> {trimmed_len} chars. Retrying in {delay:.1f}s...')
            else:
                print(f'  Bedrock {error_type} attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)
        except RuntimeError:
            raise
        except Exception as e:
            last_error = e
            last_error_type = 'api_error'
            if attempt == retries:
                break
            delay = _backoff_delay(attempt)
            print(f'  Bedrock error attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)
    raise RuntimeError(f'__ERROR__:{last_error_type}:Bedrock failed after {retries} attempts: {last_error}')

def call_bedrock_vision(model_id, system_prompt, text_prompt, images, config, timeout_override=None, max_tokens_override=None):
    import base64
    import boto3
    import botocore.config
    import botocore.exceptions
    bedrock_cfg = config.get('bedrock', {})
    region = bedrock_cfg.get('region', os.getenv('AWS_DEFAULT_REGION', 'us-east-1'))
    max_tokens = max_tokens_override or bedrock_cfg.get('max_tokens', 4096)
    timeout_val = timeout_override or bedrock_cfg.get('vision_timeout', 120)
    retries = bedrock_cfg.get('retries', 3)
    MAX_IMAGES = 20
    MAX_IMAGE_BYTES = 5 * 1024 * 1024
    total_image_bytes = 0
    content_blocks = []
    skipped = 0
    for img_bytes, media_type in images[:MAX_IMAGES]:
        if len(img_bytes) > MAX_IMAGE_BYTES:
            skipped += 1
            continue
        total_image_bytes += len(img_bytes)
        if total_image_bytes > 18 * 1024 * 1024:
            skipped += 1
            continue
        content_blocks.append({'type': 'image', 'source': {'type': 'base64', 'media_type': media_type, 'data': base64.b64encode(img_bytes).decode('ascii')}})
    if skipped > 0 or len(images) > MAX_IMAGES:
        total_skipped = skipped + max(0, len(images) - MAX_IMAGES)
        print(f'  Bedrock Vision: skipped {total_skipped} images (size/count limits), sending {len(content_blocks)} images ({total_image_bytes / (1024 * 1024):.1f}MB)')
    content_blocks.append({'type': 'text', 'text': text_prompt})
    print(f'  Bedrock Vision pre-flight: {len(content_blocks) - 1} images, {total_image_bytes / (1024 * 1024):.1f}MB images, {len(text_prompt):,} chars text')
    body = {'anthropic_version': 'bedrock-2023-05-31', 'max_tokens': max_tokens, 'messages': [{'role': 'user', 'content': content_blocks}]}
    if system_prompt:
        body['system'] = system_prompt
    client = boto3.client('bedrock-runtime', region_name=region, config=botocore.config.Config(read_timeout=timeout_val, connect_timeout=15, retries={'max_attempts': 0}))
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            response = client.invoke_model(modelId=model_id, body=json.dumps(body), contentType='application/json', accept='application/json')
            result = json.loads(response['body'].read())
            return '\n'.join((b['text'] for b in result.get('content', []) if b.get('type') == 'text'))
        except Exception as e:
            last_error = e
            if attempt == retries:
                break
            delay = _backoff_delay(attempt)
            print(f'  Bedrock Vision attempt {attempt}/{retries}: {e}, retrying in {delay:.1f}s...')
            time.sleep(delay)
    raise RuntimeError(f'__ERROR__:api_error:Bedrock Vision failed after {retries} attempts: {last_error}')

def run_task(task_id, config=None):
    if not config:
        config = load_config()
    task_data = get_task(task_id)
    if not task_data:
        return False
    agent_name = task_data['agent']
    task = task_data['task']
    context = task_data['context'] or ''
    agents = config.get('agents', {})
    medical_agents = config.get('medical_agents', {})
    all_agents = {**agents, **medical_agents}
    if agent_name not in all_agents:
        update_task(task_id, status='failed', error=f"Agent '{agent_name}' not configured")
        return False
    agent_cfg = all_agents[agent_name]
    backend = os.getenv('AGENT_BACKEND_OVERRIDE', '').strip() or agent_cfg.get('backend') or config.get('llm_backend', 'bedrock')
    bedrock_cfg = config.get('bedrock', {})
    env_model_override = os.getenv('AGENT_MODEL_OVERRIDE', '').strip()
    model = env_model_override or agent_cfg.get('bedrock_model') or agent_cfg.get('claude_model') or bedrock_cfg.get('model', 'us.anthropic.claude-sonnet-4-5-v2:0')
    backend = 'bedrock'
    system_prompt = load_agent_prompt(config, agent_name)
    system_prompt = inject_into_prompt(agent_name, system_prompt)
    user_content = f'## Task\n{task}'
    if context:
        user_content += f'\n\n## Context\n{context}'
    messages = [{'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': user_content}]
    output_path = task_data.get('output_path')
    if not output_path:
        staging_dir = Path(config.get('paths', {}).get('staging', 'staging'))
        output_dir = staging_dir / task_id
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / 'output.txt'
        update_task(task_id, output_path=str(output_file))
    else:
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
    total_chars = len(system_prompt) + len(user_content)
    timeout_override = os.getenv('DISPATCH_TIMEOUT_OVERRIDE', '').strip()
    if timeout_override:
        try:
            adaptive_timeout = int(timeout_override)
        except ValueError:
            adaptive_timeout = 600
    else:
        time_per_char = 60 / 10000
        base_timeout = bedrock_cfg.get('timeout', 300)
        adaptive_timeout = int(max(base_timeout, 300 + total_chars * time_per_char))
        adaptive_timeout = min(adaptive_timeout, 3600)
    update_task(task_id, status='running', started_at=datetime.now(timezone.utc).isoformat())
    try:
        is_combined = os.getenv('COMBINED_PIPELINE') == '1'
        env_max_tokens = os.getenv('DISPATCH_MAX_TOKENS_OVERRIDE', '').strip()
        override_timeout = bedrock_cfg.get('combined_timeout') if is_combined else adaptive_timeout
        override_tokens = bedrock_cfg.get('combined_max_tokens') if is_combined else int(env_max_tokens) if env_max_tokens else None
        output = call_bedrock(model_id=model, messages=messages, config=config, timeout_override=override_timeout, max_tokens_override=override_tokens)
        output_file.write_text(output, encoding='utf-8')
        update_task(task_id, status='completed', completed_at=datetime.now(timezone.utc).isoformat())
        return True
    except Exception as e:
        update_task(task_id, status='failed', error=str(e), completed_at=datetime.now(timezone.utc).isoformat())
        try:
            output_file.write_text(f'ERROR: {e}', encoding='utf-8')
        except:
            pass
        record_error(task_id, agent_name, str(e), task, model)
        return False

def dispatch(agent_name, task, context, config):
    agents = config.get('agents', {})
    medical_agents = config.get('medical_agents', {})
    all_agents = {**agents, **medical_agents}
    if agent_name not in all_agents:
        print(f"ERROR: Unknown agent '{agent_name}'.")
        sys.exit(1)
    agent_cfg = all_agents[agent_name]
    task_id = make_task_id(agent_name)
    backend = agent_cfg.get('backend') or config.get('llm_backend', 'ollama')
    if backend == 'claude':
        model = agent_cfg.get('claude_model') or config.get('claude', {}).get('model', 'claude-sonnet-4-6')
    else:
        model = agent_cfg['model']
    create_task(task_id=task_id, agent=agent_name, model=model, role=agent_cfg['role'], task=task, context=context, status='queued')
    print(f'\n[DISPATCHED]')
    print(f'  Task ID : {task_id}')
    print(f"  Agent   : {agent_name} ({agent_cfg['role']})")
    print(f'  Task    : {task[:80]}')
    print(f'\nRunning... (Adaptive timeout based on input size)\n')
    success = run_task(task_id, config)
    if success:
        task_data = get_task(task_id)
        output_path = task_data.get('output_path')
        if output_path:
            with open(output_path, 'r', encoding='utf-8') as f:
                output = f.read()
                print(f'[COMPLETED] Output saved to: {output_path}')
                print(f'\n--- Output Preview ---\n{output[:400]}\n')
    else:
        task_data = get_task(task_id)
        print(f"[FAILED] {task_data.get('error')}")
        sys.exit(1)
    return task_id

def show_status(config):
    tasks = list_tasks(limit=50)
    if not tasks:
        print('No tasks found.')
        return
    print(f"\n{'Task ID':<30} {'Agent':<8} {'Status':<12} {'Created':<22} {'Task'}")
    print('-' * 100)
    for t in sorted(tasks, key=lambda x: x['created_at']):
        print(f"{t['task_id']:<30} {t['agent']:<8} {t['status']:<12} {t['created_at'][:19]:<22} {t['task'][:40]}")
    print()

def list_agents(config):
    print(f"\n{'Agent':<12} {'Role':<30} {'Model'}")
    print('-' * 70)
    for name, cfg in config.get('agents', {}).items():
        print(f"{name:<12} {cfg['role']:<30} {cfg['model']}")
    for name, cfg in config.get('medical_agents', {}).items():
        print(f"{name:<12} {cfg['role']:<30} {cfg['model']}")
    print()

def main():
    parser = argparse.ArgumentParser(description='Dispatch tasks to local Ollama agents.')
    parser.add_argument('--agent', help='Agent name (aria, forge, nova, scout, sage)')
    parser.add_argument('--task', help='Task description')
    parser.add_argument('--task-file', help='Path to a file containing the task description')
    parser.add_argument('--context', default='', help='Additional context or spec text')
    parser.add_argument('--context-file', help='Path to a file containing context')
    parser.add_argument('--status', action='store_true', help='Show all task statuses')
    parser.add_argument('--list', action='store_true', help='List available agents')
    args = parser.parse_args()
    config = load_config()
    if args.list:
        list_agents(config)
        return
    if args.status:
        show_status(config)
        return
    task = args.task
    if args.task_file:
        tf = Path(args.task_file).resolve()
        try:
            tf.relative_to(BASE_DIR.resolve())
        except ValueError:
            print(f'ERROR: --task-file must be within the project directory ({BASE_DIR})')
            sys.exit(1)
        with open(tf, encoding='utf-8') as f:
            task = f.read()
    if not args.agent or not task:
        parser.print_help()
        sys.exit(1)
    context = args.context
    if args.context_file:
        cf = Path(args.context_file).resolve()
        try:
            cf.relative_to(BASE_DIR.resolve())
        except ValueError:
            print(f'ERROR: --context-file must be within the project directory ({BASE_DIR})')
            sys.exit(1)
        with open(cf, encoding='utf-8') as f:
            context = f.read()
    dispatch(args.agent, task, context, config)
if __name__ == '__main__':
    main()