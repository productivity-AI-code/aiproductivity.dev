import json
import re
from datetime import datetime

def _repair_json_string(text):
    candidates = []
    repaired = re.sub('(\\"[a-zA-Z_]+\\")>', '\\1:', text)
    if repaired != text:
        candidates.append(('arrow_to_colon', repaired))
    no_trailing = re.sub(',\\s*([}\\]])', '\\1', text)
    if no_trailing != text:
        candidates.append(('trailing_commas', no_trailing))
    if "'" in text and '"' not in text[:50]:
        single_to_double = text.replace("'", '"')
        candidates.append(('single_quotes', single_to_double))
    unquoted_fixed = re.sub('(?<=[{,])\\s*([a-zA-Z_]\\w*)\\s*:', ' "\\1":', text)
    if unquoted_fixed != text:
        candidates.append(('unquoted_keys', unquoted_fixed))
    combined = re.sub(',\\s*([}\\]])', '\\1', repaired)
    if combined != text and combined not in [c[1] for c in candidates]:
        candidates.append(('combined_fix', combined))
    return candidates

def _unwrap_list(obj):
    if isinstance(obj, list) and len(obj) >= 1 and isinstance(obj[0], dict):
        if len(obj) == 1:
            return obj[0]
        merged = {}
        for item in obj:
            if isinstance(item, dict):
                merged.update(item)
        return merged
    return obj

def extract_json_from_response(raw_text):
    if not raw_text or not raw_text.strip():
        raise ValueError('Empty response from LLM')
    text = raw_text.strip()
    try:
        return _unwrap_list(json.loads(text))
    except json.JSONDecodeError as e:
        if 'Extra data' in str(e):
            try:
                decoder = json.JSONDecoder()
                for i, c in enumerate(text):
                    if c in ('{', '['):
                        obj, _ = decoder.raw_decode(text, i)
                        return _unwrap_list(obj)
            except (json.JSONDecodeError, ValueError):
                pass
    fenced = re.search('```(?:json)?\\s*\\n?(.*?)\\n?\\s*```', text, re.DOTALL)
    if fenced:
        fenced_text = fenced.group(1).strip()
        try:
            return _unwrap_list(json.loads(fenced_text))
        except json.JSONDecodeError:
            for label, repaired in _repair_json_string(fenced_text):
                try:
                    return _unwrap_list(json.loads(repaired))
                except json.JSONDecodeError:
                    continue
    for label, repaired in _repair_json_string(text):
        try:
            return _unwrap_list(json.loads(repaired))
        except json.JSONDecodeError:
            continue
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        start = text.find(start_char)
        if start == -1:
            continue
        depth = 0
        in_string = False
        escape = False
        for i in range(start, len(text)):
            c = text[i]
            if escape:
                escape = False
                continue
            if c == '\\':
                escape = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == start_char:
                depth += 1
            elif c == end_char:
                depth -= 1
                if depth == 0:
                    block = text[start:i + 1]
                    try:
                        return _unwrap_list(json.loads(block))
                    except json.JSONDecodeError:
                        for label, repaired in _repair_json_string(block):
                            try:
                                return _unwrap_list(json.loads(repaired))
                            except json.JSONDecodeError:
                                continue
                        break
    try:
        decoder = json.JSONDecoder()
        for i, c in enumerate(text):
            if c in ('{', '['):
                obj, _ = decoder.raw_decode(text, i)
                return _unwrap_list(obj)
    except (json.JSONDecodeError, ValueError):
        pass
    start = text.find('{')
    if start == -1:
        start = text.find('[')
    if start >= 0:
        fragment = text[start:]
        close_positions = []
        depth_brace = 0
        depth_bracket = 0
        in_str = False
        esc = False
        for i, c in enumerate(fragment):
            if esc:
                esc = False
                continue
            if c == '\\' and in_str:
                esc = True
                continue
            if c == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if c == '{':
                depth_brace += 1
            elif c == '}':
                depth_brace -= 1
                close_positions.append(i + 1)
            elif c == '[':
                depth_bracket += 1
            elif c == ']':
                depth_bracket -= 1
                close_positions.append(i + 1)
        for pos in reversed(close_positions):
            candidate = fragment[:pos]
            stack = []
            ins = esc2 = False
            for c in candidate:
                if esc2:
                    esc2 = False
                    continue
                if c == '\\' and ins:
                    esc2 = True
                    continue
                if c == '"':
                    ins = not ins
                    continue
                if ins:
                    continue
                if c in ('{', '['):
                    stack.append('}' if c == '{' else ']')
                elif c in ('}', ']') and stack:
                    stack.pop()
            closed = candidate + ''.join(reversed(stack))
            try:
                return _unwrap_list(json.loads(closed))
            except json.JSONDecodeError:
                continue
        recovered = fragment
        if in_str:
            recovered += '"'
        recovered = re.sub(',\\s*"[^"]*"\\s*:\\s*"[^"]*"\\s*$', '', recovered)
        recovered = re.sub(',\\s*"[^"]*"\\s*:\\s*$', '', recovered)
        recovered = re.sub(',\\s*\\{[^}]*$', '', recovered)
        recovered = recovered.rstrip().rstrip(',')
        stack = []
        ins = esc2 = False
        for c in recovered:
            if esc2:
                esc2 = False
                continue
            if c == '\\' and ins:
                esc2 = True
                continue
            if c == '"':
                ins = not ins
                continue
            if ins:
                continue
            if c in ('{', '['):
                stack.append('}' if c == '{' else ']')
            elif c in ('}', ']') and stack:
                stack.pop()
        recovered += ''.join(reversed(stack))
        try:
            return _unwrap_list(json.loads(recovered))
        except json.JSONDecodeError:
            pass
    raise ValueError('No valid JSON found in LLM response')

def _check_required(data, fields):
    errors = []
    for field in fields:
        if field not in data or data[field] is None:
            errors.append(f"Missing required field: '{field}'")
    return errors

def _check_type(data, field, expected_type, label=None):
    label = label or field
    if field in data and data[field] is not None:
        if not isinstance(data[field], expected_type):
            return [f"'{label}' must be {expected_type.__name__}, got {type(data[field]).__name__}"]
    return []

def _check_enum(data, field, allowed_values, label=None):
    label = label or field
    if field in data and data[field] is not None:
        if data[field] not in allowed_values:
            return [f"'{label}' must be one of {allowed_values}, got '{data[field]}'"]
    return []
_PHI_PATTERNS = [('\\b\\d{3}-\\d{2}-\\d{4}\\b', 'SSN pattern'), ('\\b\\d{3}[-.]\\d{3}[-.]\\d{4}\\b', 'Phone number pattern'), ('\\b\\(\\d{3}\\)\\s*\\d{3}[-.]\\d{4}\\b', 'Phone number with area code'), ('\\b[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}\\b', 'Email pattern'), ('\\b\\d{1,5}\\s+\\w+\\s+(Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Blvd|Boulevard|Way|Court|Ct|Circle|Cir|Place|Pl|Terrace|Ter)\\b', 'Street address pattern'), ('\\b\\d{5}-\\d{4}\\b', 'ZIP+4 code pattern'), ('\\b(MRN|Medical Record|Med Rec|Record #|Acct|Account)\\s*[:#]?\\s*\\d{4,12}\\b', 'MRN/Account number pattern'), ('\\b(NPI|Provider ID)\\s*[:#]?\\s*\\d{10}\\b', 'NPI pattern'), ('\\b(Policy|Member|Subscriber|Insurance|Plan)\\s*(#|ID|No|Number)\\s*[:#]?\\s*[A-Z0-9]{6,20}\\b', 'Health plan number pattern'), ('\\b(License|DEA|Cert)\\s*(#|No|Number)\\s*[:#]?\\s*[A-Z0-9]{5,15}\\b', 'License/certificate number pattern'), ('\\b(VIN|Vehicle)\\s*[:#]?\\s*[A-HJ-NPR-Z0-9]{17}\\b', 'VIN pattern'), ('https?://[^\\s]{10,}', 'URL pattern'), ('\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b', 'IP address pattern'), ('\\b(DOB|Date of Birth|Birth Date|Birthdate)\\s*[:#]?\\s*\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{2,4}\\b', 'Date of birth pattern'), ('\\b(age[ds]?\\s*[:#]?\\s*)(9[0-9]|1[0-9]{2})\\b', 'Age over 89 pattern'), ('\\b(Patient|Pt|Mr|Mrs|Ms|Miss|Dr|Prof)\\.\\s+[A-Z][a-z]{1,20}\\s+[A-Z][a-z]{1,20}\\b', 'Potential name with title')]

def check_for_phi_leak(text):
    warnings = []
    if not isinstance(text, str):
        return warnings
    for pattern, label in _PHI_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            warnings.append(f'Potential PHI leak ({label}): {len(matches)} match(es)')
    return warnings
_PRESCRUB_PATTERNS = [(re.compile('\\b\\d{3}-\\d{2}-\\d{4}\\b'), '[REDACTED_SSN]'), (re.compile('\\b\\d{3}[-.]\\d{3}[-.]\\d{4}\\b'), '[REDACTED_PHONE]'), (re.compile('\\b\\(\\d{3}\\)\\s*\\d{3}[-.]\\d{4}\\b'), '[REDACTED_PHONE]'), (re.compile('\\b[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}\\b'), '[REDACTED_EMAIL]'), (re.compile('\\b(MRN|Medical Record|Med Rec|Record #|Acct|Account)\\s*[:#]?\\s*\\d{4,12}\\b', re.IGNORECASE), '[REDACTED_MRN]'), (re.compile('\\b(DOB|Date of Birth|Birth Date|Birthdate)\\s*[:#]?\\s*\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{2,4}\\b', re.IGNORECASE), '[REDACTED_DOB]'), (re.compile('\\b(Policy|Member|Subscriber|Insurance|Plan)\\s*(#|ID|No|Number)\\s*[:#]?\\s*[A-Z0-9]{6,20}\\b', re.IGNORECASE), '[REDACTED_PLAN_ID]')]

def pre_scrub_phi(text):
    if not isinstance(text, str):
        return (text, 0)
    count = 0
    for pattern, replacement in _PRESCRUB_PATTERNS:
        text, n = pattern.subn(replacement, text)
        count += n
    return (text, count)
VALID_DOC_TYPES = ['clinical_note', 'lab_report', 'imaging', 'discharge', 'referral', 'prescription', 'progress_note', 'operative_report', 'consultation', 'pathology', 'radiology', 'other']
VALID_SECTION_TYPES = ['demographics', 'encounter', 'diagnosis', 'medications', 'labs', 'notes', 'procedures', 'vitals', 'imaging', 'history', 'assessment', 'plan', 'allergies', 'other']
VALID_OCR_QUALITY = ['high', 'medium', 'low', 'uncertain']

def validate_ingestion_output(data):
    if not isinstance(data, dict):
        return [f'CRITICAL: Expected JSON object, got {type(data).__name__}']
    errors = []
    errors += _check_required(data, ['document_id', 'source_file', 'ingestion_timestamp', 'document_type', 'sections'])
    errors += _check_type(data, 'sections', list)
    errors += _check_enum(data, 'document_type', VALID_DOC_TYPES)
    if 'page_count' in data:
        errors += _check_type(data, 'page_count', int)
    sections = data.get('sections', [])
    if not sections:
        errors.append("'sections' array must not be empty")
    section_ids = set()
    for i, sec in enumerate(sections):
        prefix = f'sections[{i}]'
        if not isinstance(sec, dict):
            errors.append(f'{prefix} must be a dict')
            continue
        errors += _check_required(sec, ['section_id', 'section_type', 'content'])
        errors += _check_enum(sec, 'section_type', VALID_SECTION_TYPES, f'{prefix}.section_type')
        errors += _check_type(sec, 'content', str, f'{prefix}.content')
        if 'confidence' in sec:
            if not isinstance(sec['confidence'], (int, float)):
                errors.append(f'{prefix}.confidence must be a number')
            elif not 0.0 <= sec['confidence'] <= 1.0:
                errors.append(f'{prefix}.confidence must be between 0.0 and 1.0')
        if 'ocr_quality' in sec:
            errors += _check_enum(sec, 'ocr_quality', VALID_OCR_QUALITY, f'{prefix}.ocr_quality')
        sid = sec.get('section_id')
        if sid:
            if sid in section_ids:
                errors.append(f"{prefix}.section_id '{sid}' is duplicated")
            section_ids.add(sid)
    meta = data.get('metadata')
    if meta and isinstance(meta, dict):
        if 'encounter_dates' in meta:
            errors += _check_type(meta, 'encounter_dates', list, 'metadata.encounter_dates')
    return errors
VALID_PHI_TYPES = ['NAME', 'GEO', 'DATE', 'PHONE', 'FAX', 'EMAIL', 'SSN', 'MRN', 'PLAN', 'ACCOUNT', 'LICENSE', 'VEHICLE', 'DEVICE', 'URL', 'IP', 'BIOMETRIC', 'PHOTO', 'ID']

def validate_privacy_output(data):
    if not isinstance(data, dict):
        return [f'CRITICAL: Expected JSON object, got {type(data).__name__}']
    errors = []
    errors += _check_required(data, ['document_id', 'privacy_timestamp', 'sections', 'phi_summary'])
    errors += _check_type(data, 'sections', list)
    for i, sec in enumerate(data.get('sections', [])):
        prefix = f'sections[{i}]'
        if not isinstance(sec, dict):
            errors.append(f'{prefix} must be a dict')
            continue
        errors += _check_required(sec, ['section_id', 'section_type', 'content'])
        redactions = sec.get('redactions_applied', [])
        if not isinstance(redactions, list):
            errors.append(f'{prefix}.redactions_applied must be a list')
        else:
            for j, r in enumerate(redactions):
                if not isinstance(r, dict):
                    errors.append(f'{prefix}.redactions_applied[{j}] must be a dict')
                    continue
                errors += _check_required(r, ['type', 'count'])
                errors += _check_enum(r, 'type', VALID_PHI_TYPES, f'{prefix}.redactions_applied[{j}].type')
    phi = data.get('phi_summary', {})
    if not isinstance(phi, dict):
        errors.append("'phi_summary' must be a dict")
    else:
        errors += _check_required(phi, ['total_identifiers_found', 'total_redacted', 'redaction_complete'])
        found = phi.get('total_identifiers_found', 0)
        redacted = phi.get('total_redacted', 0)
        if isinstance(found, int) and isinstance(redacted, int):
            if redacted < found:
                errors.append(f'CRITICAL: Incomplete redaction — found {found} PHI identifiers but only redacted {redacted}')
        if phi.get('redaction_complete') is False:
            errors.append('CRITICAL: phi_summary.redaction_complete is False')
        by_type = phi.get('by_type', {})
        if isinstance(by_type, dict):
            for phi_type in by_type:
                if phi_type not in VALID_PHI_TYPES:
                    errors.append(f"Unknown PHI type in by_type: '{phi_type}'")
    return errors

def _validate_claim(claim, prefix, valid_section_ids=None):
    errors = []
    if not isinstance(claim, dict):
        errors.append(f'{prefix} must be a dict')
        return errors
    if 'text' not in claim and 'event' not in claim and ('diagnosis' not in claim) and ('name' not in claim) and ('finding' not in claim):
        errors.append(f'{prefix} must have a text/event/diagnosis/name/finding field')
    if 'citation' not in claim:
        errors.append(f"{prefix} missing required 'citation' field")
    elif valid_section_ids and isinstance(claim['citation'], str):
        cited_section = claim['citation'].split(':')[0]
        if cited_section not in valid_section_ids:
            errors.append(f"{prefix}.citation '{claim['citation']}' references unknown section '{cited_section}'")
    if 'confidence' in claim:
        if not isinstance(claim['confidence'], (int, float)):
            errors.append(f'{prefix}.confidence must be a number')
        elif not 0.0 <= claim['confidence'] <= 1.0:
            errors.append(f'{prefix}.confidence must be between 0.0 and 1.0')
    return errors

def validate_summary_output(data, privacy_output=None):
    if not isinstance(data, dict):
        return [f'CRITICAL: Expected JSON object, got {type(data).__name__}']
    errors = []
    errors += _check_required(data, ['document_id', 'summary_timestamp', 'summary', 'verification'])
    valid_section_ids = None
    if privacy_output and isinstance(privacy_output.get('sections'), list):
        valid_section_ids = {s['section_id'] for s in privacy_output['sections'] if isinstance(s, dict) and 'section_id' in s}
    bluf = data.get('bluf')
    if bluf is not None:
        if not isinstance(bluf, dict):
            errors.append("'bluf' must be a dict")
        else:
            for field in ['primary_diagnosis', 'objective_proof', 'future_outlook']:
                if field in bluf and (not isinstance(bluf[field], str)):
                    errors.append(f'bluf.{field} must be a string')
    cheat_sheet = data.get('litigation_cheat_sheet')
    if cheat_sheet is not None:
        if not isinstance(cheat_sheet, dict):
            errors.append("'litigation_cheat_sheet' must be a dict")
        else:
            for array_name in ['wins', 'risks']:
                items = cheat_sheet.get(array_name)
                if items is not None:
                    if not isinstance(items, list):
                        errors.append(f'litigation_cheat_sheet.{array_name} must be a list')
                    else:
                        key_field = 'leverage' if array_name == 'wins' else 'target'
                        for i, item in enumerate(items):
                            prefix = f'litigation_cheat_sheet.{array_name}[{i}]'
                            if not isinstance(item, dict):
                                errors.append(f'{prefix} must be a dict')
                            elif key_field not in item:
                                errors.append(f"{prefix} missing '{key_field}' field")
    summary = data.get('summary', {})
    if not isinstance(summary, dict):
        errors.append("'summary' must be a dict")
    else:
        if 'chief_complaint' in summary:
            errors += _validate_claim(summary['chief_complaint'], 'summary.chief_complaint', valid_section_ids)
        for array_name in ['chronological_events', 'active_diagnoses', 'medications', 'key_findings']:
            items = summary.get(array_name, [])
            if not isinstance(items, list):
                errors.append(f'summary.{array_name} must be a list')
            else:
                for i, item in enumerate(items):
                    errors += _validate_claim(item, f'summary.{array_name}[{i}]', valid_section_ids)
        for array_name in ['contradictions_flagged', 'timeline_gaps']:
            val = summary.get(array_name)
            if val is not None and (not isinstance(val, list)):
                errors.append(f'summary.{array_name} must be a list')
        oc = summary.get('overall_confidence')
        if oc is not None:
            if not isinstance(oc, (int, float)):
                errors.append('summary.overall_confidence must be a number')
            elif not 0.0 <= oc <= 1.0:
                errors.append('summary.overall_confidence must be between 0.0 and 1.0')
    billing = data.get('billing_data')
    if billing is not None:
        if not isinstance(billing, dict):
            errors.append("'billing_data' must be a dict")
        else:
            providers = billing.get('providers')
            if providers is not None:
                if not isinstance(providers, list):
                    errors.append("'billing_data.providers' must be a list")
                else:
                    for i, prov in enumerate(providers):
                        prefix = f'billing_data.providers[{i}]'
                        if not isinstance(prov, dict):
                            errors.append(f'{prefix} must be a dict')
                            continue
                        if 'provider_name' not in prov:
                            errors.append(f"{prefix} missing 'provider_name'")
                        services = prov.get('services')
                        if services is not None:
                            if not isinstance(services, list):
                                errors.append(f'{prefix}.services must be a list')
                            else:
                                for j, svc in enumerate(services):
                                    svc_prefix = f'{prefix}.services[{j}]'
                                    if not isinstance(svc, dict):
                                        errors.append(f'{svc_prefix} must be a dict')
                                    elif 'amount' in svc and (not isinstance(svc['amount'], (int, float))):
                                        errors.append(f'{svc_prefix}.amount must be a number')
                        if 'subtotal' in prov and (not isinstance(prov['subtotal'], (int, float))):
                            errors.append(f'{prefix}.subtotal must be a number')
            for total_field in ['total_past_medical', 'total_future_medical_estimate', 'total_combined']:
                if total_field in billing and billing[total_field] is not None:
                    if not isinstance(billing[total_field], (int, float)):
                        errors.append(f"'billing_data.{total_field}' must be a number")
    VALID_ALERT_TYPES = ['treatment_gap', 'missing_provider', 'pre_existing', 'inconsistency', 'compliance_issue', 'prior_injury', 'medication_change']
    VALID_ALERT_SEVERITIES = ['high', 'medium', 'low']
    alerts = data.get('alerts')
    if alerts is not None:
        if not isinstance(alerts, list):
            errors.append("'alerts' must be a list")
        else:
            for i, alert in enumerate(alerts):
                prefix = f'alerts[{i}]'
                if not isinstance(alert, dict):
                    errors.append(f'{prefix} must be a dict')
                    continue
                alert_type = alert.get('type')
                if alert_type and alert_type not in VALID_ALERT_TYPES:
                    errors.append(f"{prefix}.type '{alert_type}' not in {VALID_ALERT_TYPES}")
                severity = alert.get('severity')
                if severity and severity not in VALID_ALERT_SEVERITIES:
                    errors.append(f"{prefix}.severity '{severity}' not in {VALID_ALERT_SEVERITIES}")
                for field in ['title', 'description']:
                    if field not in alert or not alert[field]:
                        errors.append(f"{prefix} missing required field '{field}'")
    verif = data.get('verification', {})
    if not isinstance(verif, dict):
        errors.append("'verification' must be a dict")
    else:
        errors += _check_required(verif, ['total_claims', 'claims_with_citations', 'citation_coverage'])
        total = verif.get('total_claims', 0)
        cited = verif.get('claims_with_citations', 0)
        coverage = verif.get('citation_coverage', 0)
        if isinstance(total, int) and isinstance(cited, int) and (total > 0):
            if cited < total:
                errors.append(f'Incomplete citations: {cited}/{total} claims have citations')
        if isinstance(coverage, (int, float)) and coverage < 1.0:
            errors.append(f'Citation coverage is {coverage:.0%} — must be 100% or flagged REVIEW_NEEDED')
    return errors

def validate_audit_output(data):
    if not isinstance(data, dict):
        return [f'CRITICAL: Expected JSON object, got {type(data).__name__}']
    errors = []
    errors += _check_required(data, ['audit_id', 'timestamp', 'pipeline_run_id', 'source_file_hash', 'stages_completed', 'compliance_status'])
    errors += _check_type(data, 'stages_completed', list)
    errors += _check_enum(data, 'compliance_status', ['PASS', 'REVIEW_NEEDED'])
    for field in ['phi_identifiers_found', 'phi_identifiers_redacted', 'summary_claims_count']:
        if field in data and data[field] is not None:
            if not isinstance(data[field], int):
                errors.append(f"'{field}' must be an integer")
    for field in ['citation_coverage', 'overall_confidence']:
        if field in data and data[field] is not None:
            if not isinstance(data[field], (int, float)):
                errors.append(f"'{field}' must be a number")
    phi_warnings = []
    _scan_dict_for_phi(data, '', phi_warnings)
    for w in phi_warnings:
        if 'SSN pattern' in w or 'Potential name with title' in w or 'Date of birth' in w:
            errors.append(f'CRITICAL: PHI leak detected in audit — {w}')
    if 'anomalies' in data:
        errors += _check_type(data, 'anomalies', list)
    return errors

def validate_review_output(data):
    if not isinstance(data, dict):
        return [f'CRITICAL: Expected JSON object, got {type(data).__name__}']
    errors = []
    errors += _check_required(data, ['review_timestamp', 'total_claims_reviewed', 'accuracy_score'])
    errors += _check_type(data, 'inaccuracies_found', list)
    errors += _check_type(data, 'unsupported_claims', list)
    score = data.get('accuracy_score')
    if score is not None:
        if not isinstance(score, (int, float)):
            errors.append("'accuracy_score' must be a number")
        elif not 0.0 <= score <= 1.0:
            errors.append("'accuracy_score' must be between 0.0 and 1.0")
    for i, item in enumerate(data.get('inaccuracies_found', [])):
        if not isinstance(item, dict):
            errors.append(f'inaccuracies_found[{i}] must be a dict')
            continue
        for field in ['claim', 'issue', 'correction']:
            if field not in item:
                errors.append(f"inaccuracies_found[{i}] missing '{field}'")
    return errors

def _scan_dict_for_phi(obj, path, warnings):
    if isinstance(obj, dict):
        for key, value in obj.items():
            _scan_dict_for_phi(value, f'{path}.{key}' if path else key, warnings)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            _scan_dict_for_phi(item, f'{path}[{i}]', warnings)
    elif isinstance(obj, str):
        for w in check_for_phi_leak(obj):
            warnings.append(f"at '{path}': {w}")

def build_stage_prompt(stage, input_json, schema_example=None):
    json_input = json.dumps(input_json, indent=2) if isinstance(input_json, dict) else input_json
    prompt = f'## Input Data (JSON)\n```json\n{json_input}\n```\n\n'
    prompt += '## Output Requirements\n'
    prompt += 'You MUST respond with ONLY a valid JSON object. No markdown, no explanation, '
    prompt += 'no text before or after the JSON. Your entire response must be parseable by '
    prompt += 'json.loads().\n\n'
    if schema_example:
        prompt += f'## Expected Output Schema\n```json\n{json.dumps(schema_example, indent=2)}\n```\n'
    return prompt
INGESTION_SCHEMA_EXAMPLE = {'document_id': '<sha256_hash>', 'source_file': '<filename>', 'ingestion_timestamp': '<ISO-8601>', 'document_type': '<clinical_note|lab_report|imaging|discharge|referral|other>', 'page_count': 0, 'sections': [{'section_id': 'sec_001', 'section_type': '<demographics|encounter|diagnosis|medications|labs|notes|procedures|other>', 'heading': '<section heading>', 'content': '<structured text content>', 'page_number': 1, 'confidence': 0.95, 'ocr_quality': '<high|medium|low|uncertain>'}], 'metadata': {'encounter_dates': [], 'document_date': '<YYYY-MM-DD>', 'facility_mentioned': False, 'provider_mentioned': False}}
PRIVACY_SCHEMA_EXAMPLE = {'document_id': '<sha256_hash>', 'privacy_timestamp': '<ISO-8601>', 'sections': [{'section_id': 'sec_001', 'section_type': '<type>', 'heading': '<heading>', 'content': '<de-identified content with [REDACTED_*] tokens>', 'redactions_applied': [{'type': 'NAME', 'count': 1, 'positions': [0]}]}], 'phi_summary': {'total_identifiers_found': 0, 'total_redacted': 0, 'by_type': {}, 'redaction_complete': True}}
SUMMARY_SCHEMA_EXAMPLE = {'document_id': '<sha256_hash>', 'summary_timestamp': '<ISO-8601>', 'case_type': 'pi_general', 'specialty_modules_triggered': [], 'executive_strategy': 'This case presents strong objective evidence of radiculopathy [see: Key Findings] supported by consistent treatment trajectory [see: Master Chronology]. The smoking gun documentation [see: Smoking Gun Quotes] and confirmed nerve root compression make this high-value. Recommend subpoenaing missing MRI [see: Discovery Deficiencies] and deposing treating neurologist.', 'bluf': {'primary_diagnosis': 'Single most impactful diagnosed condition with objective confirmation', 'objective_proof': "Specific test/imaging that objectively confirms the diagnosis (e.g., MRI, EMG/NCV, positive Spurling's)", 'future_outlook': 'Surgical candidacy, permanent impairment rating, or long-term prognosis driving case value'}, 'litigation_cheat_sheet': {'wins': [{'leverage': 'Favorable evidence or finding the attorney can use offensively', 'source_ref': 'sec_003:p2'}], 'risks': [{'target': 'Defense attack vector or vulnerability the attorney must prepare for', 'source_ref': 'sec_005:p3'}]}, 'summary': {'chief_complaint': {'text': '...', 'citation': 'sec_001:p1', 'confidence': 0.9}, 'master_chronology': [{'date': 'YYYY-MM-DD', 'provider': '...', 'clinical_finding': '...', 'legal_leverage': '...', 'citation': 'sec_002:p2', 'confidence': 0.9}], 'active_diagnoses': [{'diagnosis': '...', 'citation': 'sec_003:p3', 'confidence': 0.9}], 'medications': [{'name': '...', 'dosage': '...', 'citation': 'sec_004:p4', 'confidence': 0.9}], 'key_findings': [{'finding': '...', 'citation': 'sec_005:p5', 'confidence': 0.9}], 'smoking_gun_quotes': [{'quote': '...', 'significance': '...', 'citation': 'sec_003:p2'}], 'contradictions_flagged': [{'contradiction': '...', 'subjective': '...', 'objective': '...', 'legal_note': '...', 'citations': []}], 'timeline_gaps': [], 'discovery_deficiencies': [{'missing_item': '...', 'evidence': '...', 'citation': 'sec_004:p3', 'urgency': 'HIGH|MEDIUM|LOW'}], 'overall_confidence': 0.9}, 'pi_core_analysis': {'mechanism_of_injury': {'description': '...', 'clinical_correlation': '...', 'physics_match': True, 'citation': 'sec_001:p1'}, 'treatment_gaps': [{'gap_start': 'YYYY-MM-DD', 'gap_end': 'YYYY-MM-DD', 'days': 0, 'defense_risk': '...', 'neutralization': '...', 'citation': '...'}], 'pre_existing_conditions': [{'condition': '...', 'new_vs_aggravation': 'new|aggravation', 'eggshell_plaintiff_note': '...', 'citation': 'sec_002:p1'}]}, 'specialty_insights': {'tbi': None, 'spinal_orthopedic': None, 'soft_tissue': None, 'pain_management': None}, 'billing_data': {'providers': [{'provider_name': 'City Hospital ER', 'dates_of_service': ['03/12/2024'], 'services': [{'date': '03/12/2024', 'description': 'Emergency Room Visit', 'cpt_code': '99285', 'amount': 8450.0, 'citation': 'sec_002:p1'}], 'subtotal': 8450.0}], 'total_past_medical': 0.0, 'total_future_medical_estimate': 0.0, 'future_care_basis': '', 'total_combined': 0.0, 'notes': ''}, 'alerts': [{'type': 'treatment_gap|missing_provider|pre_existing|inconsistency|compliance_issue|prior_injury|medication_change', 'severity': 'high|medium|low', 'title': '45-Day Physical Therapy Gap', 'description': 'No physical therapy visits between 04/15/2024 and 05/30/2024. This 45-day gap in treatment may indicate non-compliance or symptom resolution, which defense counsel will likely argue reduces case value.', 'impact_estimate': 'May reduce settlement value by 15-20%', 'recommended_action': 'Request client explanation for gap. Consider obtaining PT records from this period if treatment occurred elsewhere.', 'citation': 'sec_003:p7', 'date_range': '04/15/2024 - 05/30/2024'}], 'trial_strategy_note': 'Strongest evidence: EMG/NCV confirms objective radiculopathy [see: Key Findings] correlating with clinical complaints [see: Master Chronology]. Failed conservative care strengthens surgical candidacy. Defense gap argument neutralized [see: PI Core]. Recommend deposing treating neurologist and subpoenaing missing lumbar MRI [see: Discovery Deficiencies].', 'verification': {'total_claims': 0, 'claims_with_citations': 0, 'citation_coverage': 1.0, 'low_confidence_claims': 0, 'needs_verification': 0, 'contradictions_found': 0, 'discovery_gaps': 0}}
AUDIT_SCHEMA_EXAMPLE = {'audit_id': '<uuid>', 'timestamp': '<ISO-8601>', 'pipeline_run_id': '<task_id>', 'source_file_hash': '<sha256>', 'stages_completed': ['ingestion', 'privacy', 'summarizer', 'auditor'], 'phi_identifiers_found': 0, 'phi_identifiers_redacted': 0, 'summary_claims_count': 0, 'citation_coverage': 1.0, 'overall_confidence': 0.0, 'compliance_status': 'PASS', 'anomalies': []}
REVIEW_SCHEMA_EXAMPLE = {'review_timestamp': '<ISO-8601>', 'total_claims_reviewed': 0, 'inaccuracies_found': [{'claim': 'text of the inaccurate claim from the summary', 'citation': 'sec_XXX:pN', 'issue': 'what is wrong with this claim', 'correction': 'what the claim should say based on the source', 'severity': 'high|medium|low'}], 'unsupported_claims': [{'claim': 'text of claim without source support', 'citation': 'sec_XXX:pN', 'reason': 'why this claim is unsupported'}], 'omitted_findings': [{'finding': 'critical finding from source not in summary', 'source_section': 'sec_XXX', 'significance': 'why this matters for litigation'}], 'accuracy_score': 0.95, 'review_notes': 'Overall assessment of summary quality'}