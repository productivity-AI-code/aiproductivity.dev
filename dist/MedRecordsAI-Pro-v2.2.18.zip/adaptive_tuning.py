import argparse
import json
import logging
import sys
from pathlib import Path
logger = logging.getLogger('adaptive_tuning')
BASE_DIR = Path(__file__).parent
MIN_SAMPLES_SEVERITY = 10
MIN_SAMPLES_JURISDICTION = 5
MIN_SAMPLES_NEGLIGENCE = 5

def _get_db():
    from db import get_db
    return get_db()

def calibrate_severity_multipliers():
    conn = _get_db()
    try:
        rows = conn.execute('SELECT vo.predicted_severity, vo.actual_settlement,\n                      vo.predicted_low, vo.predicted_mid, vo.predicted_high\n               FROM valuation_outcomes vo\n               WHERE vo.actual_settlement IS NOT NULL\n                 AND vo.actual_settlement > 0\n                 AND vo.predicted_severity IS NOT NULL\n               ORDER BY vo.created_at DESC').fetchall()
        if not rows:
            logger.info('No valuation outcomes with actual settlements — skipping calibration')
            return {}
        by_severity = {}
        for r in rows:
            sev = r['predicted_severity']
            if sev not in by_severity:
                by_severity[sev] = []
            by_severity[sev].append({'actual': r['actual_settlement'], 'predicted_mid': r['predicted_mid'], 'predicted_low': r['predicted_low'], 'predicted_high': r['predicted_high']})
        calibrations = {}
        for sev, outcomes in by_severity.items():
            if len(outcomes) < MIN_SAMPLES_SEVERITY:
                logger.info("Severity '%s': only %d samples (need %d) — skipping", sev, len(outcomes), MIN_SAMPLES_SEVERITY)
                continue
            ratios = []
            for o in outcomes:
                if o['predicted_mid'] and o['predicted_mid'] > 0:
                    ratios.append(o['actual'] / o['predicted_mid'])
            if not ratios:
                continue
            ratios.sort()
            median_idx = len(ratios) // 2
            median_ratio = ratios[median_idx]
            calibrations[sev] = {'adjustment_factor': round(median_ratio, 3), 'sample_count': len(outcomes), 'median_actual': int(sorted((o['actual'] for o in outcomes))[len(outcomes) // 2]), 'median_predicted': int(sorted((o['predicted_mid'] for o in outcomes if o['predicted_mid']))[len(outcomes) // 2])}
            _save_parameter('severity_multiplier', sev, json.dumps(calibrations[sev]), len(outcomes))
            logger.info("Severity '%s': calibration factor=%.3f (n=%d, median actual=$%d vs predicted=$%d)", sev, median_ratio, len(outcomes), calibrations[sev]['median_actual'], calibrations[sev]['median_predicted'])
        return calibrations
    finally:
        conn.close()

def calibrate_jurisdiction_modifiers():
    conn = _get_db()
    try:
        rows = conn.execute('SELECT vo.jurisdiction, vo.actual_settlement, vo.predicted_mid\n               FROM valuation_outcomes vo\n               WHERE vo.actual_settlement IS NOT NULL\n                 AND vo.actual_settlement > 0\n                 AND vo.predicted_mid IS NOT NULL\n                 AND vo.predicted_mid > 0\n                 AND vo.jurisdiction IS NOT NULL\n               ORDER BY vo.created_at DESC').fetchall()
        if not rows:
            return {}
        by_state = {}
        for r in rows:
            state = r['jurisdiction']
            if state not in by_state:
                by_state[state] = []
            by_state[state].append(r['actual_settlement'] / r['predicted_mid'])
        calibrations = {}
        for state, ratios in by_state.items():
            if len(ratios) < MIN_SAMPLES_JURISDICTION:
                continue
            ratios.sort()
            median_ratio = ratios[len(ratios) // 2]
            calibrations[state] = {'adjustment_factor': round(median_ratio, 3), 'sample_count': len(ratios)}
            _save_parameter('jurisdiction_modifier', state, json.dumps(calibrations[state]), len(ratios))
            logger.info("Jurisdiction '%s': calibration factor=%.3f (n=%d)", state, median_ratio, len(ratios))
        return calibrations
    finally:
        conn.close()

def calibrate_negligence_rules():
    conn = _get_db()
    try:
        rows = conn.execute('SELECT finding_title,\n                      SUM(CASE WHEN finding_accepted = 1 THEN 1 ELSE 0 END) as accepted,\n                      SUM(CASE WHEN finding_accepted = 0 THEN 1 ELSE 0 END) as rejected,\n                      COUNT(*) as total\n               FROM negligence_feedback\n               WHERE finding_accepted IS NOT NULL\n               GROUP BY finding_title\n               HAVING COUNT(*) >= ?', (MIN_SAMPLES_NEGLIGENCE,)).fetchall()
        if not rows:
            return {}
        calibrations = {}
        for r in rows:
            title = r['finding_title'] or 'unknown'
            accepted = r['accepted'] or 0
            rejected = r['rejected'] or 0
            total = r['total']
            precision = accepted / max(1, total)
            status = 'normal'
            if precision < 0.4:
                status = 'suppress'
            elif precision < 0.6:
                status = 'demote'
            elif precision > 0.8:
                status = 'emphasize'
            calibrations[title] = {'precision': round(precision, 3), 'accepted': accepted, 'rejected': rejected, 'total': total, 'status': status}
            _save_parameter('negligence_rule', title, json.dumps(calibrations[title]), total)
            logger.info("Negligence '%s': precision=%.0f%% (%d/%d) — %s", title[:50], precision * 100, accepted, total, status)
        return calibrations
    finally:
        conn.close()

def _save_parameter(category, key, value, sample_count):
    conn = _get_db()
    try:
        conn.execute("INSERT INTO system_parameters (param_category, param_key, param_value, source, sample_count)\n               VALUES (?, ?, ?, 'auto_calibration', ?)\n               ON CONFLICT(param_category, param_key) DO UPDATE SET\n                 param_value = excluded.param_value,\n                 source = 'auto_calibration',\n                 sample_count = excluded.sample_count,\n                 calibrated_at = datetime('now')", (category, key, value, sample_count))
        conn.commit()
    except Exception as e:
        logger.error('Failed to save parameter %s/%s: %s', category, key, e)
    finally:
        conn.close()

def get_calibrated_parameter(category, key):
    conn = _get_db()
    try:
        row = conn.execute('SELECT param_value, sample_count, calibrated_at FROM system_parameters WHERE param_category = ? AND param_key = ?', (category, key)).fetchone()
        if row:
            try:
                return json.loads(row['param_value'])
            except json.JSONDecodeError:
                return row['param_value']
        return None
    except Exception:
        return None
    finally:
        conn.close()

def get_calibrated_multipliers():
    conn = _get_db()
    try:
        rows = conn.execute("SELECT param_key, param_value FROM system_parameters WHERE param_category = 'severity_multiplier'").fetchall()
        result = {}
        for r in rows:
            try:
                data = json.loads(r['param_value'])
                result[r['param_key']] = data.get('adjustment_factor', 1.0)
            except json.JSONDecodeError:
                pass
        return result
    except Exception:
        return {}
    finally:
        conn.close()

def get_calibrated_jurisdiction_modifiers():
    conn = _get_db()
    try:
        rows = conn.execute("SELECT param_key, param_value FROM system_parameters WHERE param_category = 'jurisdiction_modifier'").fetchall()
        result = {}
        for r in rows:
            try:
                data = json.loads(r['param_value'])
                result[r['param_key']] = data.get('adjustment_factor', 1.0)
            except json.JSONDecodeError:
                pass
        return result
    except Exception:
        return {}
    finally:
        conn.close()

def get_negligence_rule_status(finding_title):
    data = get_calibrated_parameter('negligence_rule', finding_title)
    if isinstance(data, dict):
        return data.get('status', 'normal')
    return 'normal'

def calibrate_all():
    logger.info('Running full parameter calibration...')
    sev = calibrate_severity_multipliers()
    jur = calibrate_jurisdiction_modifiers()
    neg = calibrate_negligence_rules()
    total = len(sev) + len(jur) + len(neg)
    logger.info('Calibration complete: %d severity, %d jurisdiction, %d negligence parameters updated', len(sev), len(jur), len(neg))
    return {'severity_multipliers': sev, 'jurisdiction_modifiers': jur, 'negligence_rules': neg, 'total_parameters': total}

def generate_report():
    from case_valuation import SEVERITY_TIERS, JURISDICTION_MODIFIERS
    lines = ['=' * 60, '  ADAPTIVE TUNING REPORT', '=' * 60, '']
    lines.append('── SEVERITY MULTIPLIER CALIBRATION ─────────────────────')
    cal_mult = get_calibrated_multipliers()
    for tier, data in SEVERITY_TIERS.items():
        default_range = data['multiplier_range']
        cal = cal_mult.get(tier)
        if cal:
            lines.append(f'  {tier:15s} Default: {default_range[0]:.1f}-{default_range[1]:.1f}x  →  Calibrated: {cal:.3f}x adjustment')
        else:
            lines.append(f'  {tier:15s} Default: {default_range[0]:.1f}-{default_range[1]:.1f}x  →  No data yet')
    lines.append('\n── JURISDICTION MODIFIER CALIBRATION ───────────────────')
    cal_jur = get_calibrated_jurisdiction_modifiers()
    for state in sorted(set(list(JURISDICTION_MODIFIERS.keys()) + list(cal_jur.keys()))):
        if state == 'default':
            continue
        default = JURISDICTION_MODIFIERS.get(state, 1.0)
        cal = cal_jur.get(state)
        if cal:
            lines.append(f'  {state:4s} Default: {default:.2f}  →  Calibrated: {cal:.3f}x')
        elif state in JURISDICTION_MODIFIERS:
            lines.append(f'  {state:4s} Default: {default:.2f}  →  No data yet')
    lines.append('\n── NEGLIGENCE RULE PRECISION ────────────────────────────')
    conn = _get_db()
    try:
        rows = conn.execute("SELECT param_key, param_value FROM system_parameters WHERE param_category = 'negligence_rule'").fetchall()
        for r in rows:
            try:
                data = json.loads(r['param_value'])
                title = r['param_key'][:40]
                lines.append(f"  {title:42s} Precision: {data['precision']:.0%} ({data['accepted']}/{data['total']}) — {data['status']}")
            except (json.JSONDecodeError, KeyError):
                pass
        if not rows:
            lines.append('  No negligence feedback data yet')
    finally:
        conn.close()
    lines.append('\n' + '=' * 60)
    return '\n'.join(lines)

def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(name)s] %(message)s')
    parser = argparse.ArgumentParser(description='Adaptive parameter tuning for MedRecords AI')
    parser.add_argument('--calibrate', action='store_true', help='Run all calibrations')
    parser.add_argument('--calibrate-valuation', action='store_true', help='Calibrate valuation parameters only')
    parser.add_argument('--calibrate-negligence', action='store_true', help='Calibrate negligence rules only')
    parser.add_argument('--report', action='store_true', help='Show current parameters report')
    args = parser.parse_args()
    if args.report:
        print(generate_report())
    elif args.calibrate:
        result = calibrate_all()
        print(f"\nCalibration complete: {result['total_parameters']} parameters updated")
        print(generate_report())
    elif args.calibrate_valuation:
        sev = calibrate_severity_multipliers()
        jur = calibrate_jurisdiction_modifiers()
        print(f'Calibrated {len(sev)} severity tiers, {len(jur)} jurisdictions')
    elif args.calibrate_negligence:
        neg = calibrate_negligence_rules()
        print(f'Calibrated {len(neg)} negligence rules')
    else:
        parser.print_help()
if __name__ == '__main__':
    main()