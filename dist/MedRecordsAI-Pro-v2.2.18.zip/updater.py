
import os
import json
import requests
import shutil
import sys
import zipfile
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger("updater")

MANIFEST_URL = "https://aiproductivity.dev/dist/manifest.json"
BASE_DIR = Path(__file__).parent

class Updater:
    def __init__(self, current_version):
        self.current_version = current_version

    def check_for_updates(self):
        """Check if a newer version is available."""
        try:
            resp = requests.get(MANIFEST_URL, timeout=10)
            resp.raise_for_status()
            manifest = resp.json()
            latest_version = manifest.get("version")
            
            if self._is_newer(latest_version, self.current_version):
                return {
                    "update_available": True,
                    "latest_version": latest_version,
                    "download_url": manifest.get("download_url"),
                    "changelog": manifest.get("changelog", "No changelog provided.")
                }
        except Exception as e:
            logger.error(f"Update check failed: {e}")
            
        return {"update_available": False}

    def _is_newer(self, latest, current):
        """Simple version comparison (e.g. 2.2.6 > 2.2.5)"""
        try:
            l_parts = [int(p) for p in latest.split(".")]
            c_parts = [int(p) for p in current.split(".")]
            return l_parts > c_parts
        except:
            return latest != current

    def apply_update(self, download_url):
        """Download and apply update ZIP."""
        update_tmp = BASE_DIR / "vault" / "tmp" / "update.zip"
        update_tmp.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            logger.info(f"Downloading update from {download_url}...")
            resp = requests.get(download_url, stream=True, timeout=60)
            resp.raise_for_status()
            
            with open(update_tmp, "wb") as f:
                shutil.copyfileobj(resp.raw, f)
            
            logger.info("Extracting update...")
            with zipfile.ZipFile(update_tmp, 'r') as zip_ref:
                # We extract to a temporary folder then move to avoid overwriting running code
                extract_path = BASE_DIR / "vault" / "tmp" / "extracted_update"
                if extract_path.exists():
                    shutil.rmtree(extract_path)
                zip_ref.extractall(extract_path)
                
                # In a real on-premise app, we'd trigger a .bat script to 
                # kill the process, move files, and restart.
                # For this implementation, we'll mark it as 'pending_restart'
                return True
        except Exception as e:
            logger.error(f"Update failed: {e}")
            return False
