
import os
import time
import logging
import signal
import sys
import uuid
import json
from datetime import datetime, timezone
from pathlib import Path

from db import pop_task, remove_from_queue, release_task, init_db
from dispatch import run_task, load_config

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("worker.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("worker")

# Worker Identity
WORKER_ID = f"worker-{uuid.uuid4().hex[:8]}"
RUNNING = True

def handle_exit(signum, frame):
    global RUNNING
    logger.info("Exit signal received. Shutting down gracefully...")
    RUNNING = False

signal.signal(signal.SIGINT, handle_exit)
signal.signal(signal.SIGTERM, handle_exit)

def process_pipeline_task(task_id, task_data, config):
    """Handle complex multi-stage pipeline tasks."""
    try:
        from summarization_watcher import run_pipeline, run_pipeline_combined, run_pipeline_thorough
        context = json.loads(task_data["context"])
        file_paths = context.get("file_paths", [])
        case_ref = context.get("case_ref")
        mode = context.get("mode", "auto")
        is_thorough = context.get("is_thorough", False)
        
        if not file_paths:
            logger.error("No file paths in pipeline context for %s", task_id)
            return False
            
        paths = [Path(p) for p in file_paths]
        
        if is_thorough or mode == "thorough":
            run_pipeline_thorough(paths, config, run_id=task_id, case_ref=case_ref, mode=mode)
        elif len(paths) > 1:
            run_pipeline_combined(paths, config, run_id=task_id, case_ref=case_ref)
        else:
            run_pipeline(paths[0], config, run_id=task_id)
            
        return True
    except Exception as e:
        logger.error("Pipeline task error: %s", e, exc_info=True)
        return False


def start_worker():
    logger.info(f"AI Team Worker {WORKER_ID} starting...")
    config = load_config()
    init_db()
    
    idle_count = 0
    
    while RUNNING:
        try:
            task_id = pop_task(WORKER_ID)
            
            if task_id:
                idle_count = 0
                logger.info(f"[*] Processing task: {task_id}")
                
                from dispatch import get_task
                task_data = get_task(task_id)
                
                if not task_data:
                    logger.error(f"Task data missing for {task_id}")
                    remove_from_queue(task_id)
                    continue

                if task_data["agent"] == "pipeline":
                    success = process_pipeline_task(task_id, task_data, config)
                else:
                    success = run_task(task_id, config)
                
                if success:
                    logger.info(f"[+] Task {task_id} completed successfully.")
                    remove_from_queue(task_id)
                else:
                    logger.error(f"[-] Task {task_id} failed.")
                    # Retry logic
                    from db import get_db
                    with get_db() as conn:
                        row = conn.execute("SELECT retries, max_retries FROM task_queue WHERE task_id = ?", (task_id,)).fetchone()
                        if row and row["retries"] >= row["max_retries"]:
                            logger.error(f"[!] Task {task_id} exceeded max retries.")
                            remove_from_queue(task_id)
                        else:
                            release_task(task_id)
            else:
                idle_count += 1
                time.sleep(10)
                
        except Exception as e:
            logger.error(f"Worker loop error: {e}", exc_info=True)
            time.sleep(30)

    logger.info("Worker shut down.")

if __name__ == "__main__":
    start_worker()
