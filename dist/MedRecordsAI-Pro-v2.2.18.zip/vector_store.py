
import json
import sqlite3
import numpy as np
import requests
import logging
from pathlib import Path
from db import transaction, get_db

logger = logging.getLogger("vector_store")

EMBEDDING_MODEL = "nomic-embed-text"

class VectorStore:
    def __init__(self, config):
        self.config = config
        self.ollama_endpoint = config.get("ollama", {}).get("endpoint", "http://localhost:11434")

    def _get_embedding(self, text):
        """Get embedding vector from Ollama."""
        try:
            resp = requests.post(
                f"{self.ollama_endpoint}/api/embeddings",
                json={"model": EMBEDDING_MODEL, "prompt": text},
                timeout=30
            )
            resp.raise_for_status()
            return resp.json()["embedding"]
        except Exception as e:
            logger.error(f"Embedding error: {e}")
            return None

    def index_document(self, run_id, sections):
        """Index sections of a document into the vector store."""
        indexed_count = 0
        with transaction() as conn:
            # Clear existing index for this run if any
            conn.execute("DELETE FROM vector_index WHERE run_id = ?", (run_id,))
            
            for section in sections:
                content = section.get("content", "")
                if not content or len(content) < 50:
                    continue
                
                # For very large sections, split into smaller chunks (e.g. 1000 chars)
                chunks = [content[i:i+1000] for i in range(0, len(content), 800)]
                
                for chunk in chunks:
                    embedding = self._get_embedding(chunk)
                    if embedding:
                        # Store as blob
                        emb_blob = np.array(embedding, dtype=np.float32).tobytes()
                        conn.execute("""
                            INSERT INTO vector_index (run_id, section_id, page_number, content, embedding)
                            VALUES (?, ?, ?, ?, ?)
                        """, (
                            run_id, 
                            section.get("section_id"), 
                            section.get("page_number"), 
                            chunk, 
                            emb_blob
                        ))
                        indexed_count += 1
        
        logger.info(f"Indexed {indexed_count} chunks for run {run_id}")
        return indexed_count

    def search(self, query, run_ids=None, top_k=5):
        """Search for relevant chunks using cosine similarity."""
        query_emb = self._get_embedding(query)
        if not query_emb:
            return []
        
        query_vec = np.array(query_emb, dtype=np.float32)
        
        results = []
        with get_db() as conn:
            sql = "SELECT id, run_id, section_id, page_number, content, embedding FROM vector_index"
            params = []
            if run_ids:
                placeholders = ",".join(["?" for _ in run_ids])
                sql += f" WHERE run_id IN ({placeholders})"
                params.extend(run_ids)
            
            rows = conn.execute(sql, params).fetchall()
            
            for row in rows:
                if not row["embedding"]:
                    continue
                
                # Convert blob back to vector
                db_vec = np.frombuffer(row["embedding"], dtype=np.float32)
                
                # Cosine similarity
                if db_vec.shape == query_vec.shape:
                    sim = np.dot(query_vec, db_vec) / (np.linalg.norm(query_vec) * np.linalg.norm(db_vec))
                    results.append({
                        "id": row["id"],
                        "run_id": row["run_id"],
                        "section_id": row["section_id"],
                        "page_number": row["page_number"],
                        "content": row["content"],
                        "score": float(sim)
                    })
        
        # Sort by score
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]
