
import os
import subprocess
import requests
import time
import logging
import platform
import shutil
from pathlib import Path

logger = logging.getLogger("dependency_manager")

REQUIRED_MODELS = [
    "qwen2.5:7b",
    "glm4:9b",
    "nomic-embed-text"
]

class DependencyManager:
    def __init__(self, config):
        self.config = config
        self.ollama_endpoint = config.get("ollama", {}).get("endpoint", "http://localhost:11434")
        self.base_dir = Path(__file__).parent

    def check_all(self):
        """Run all dependency checks."""
        logger.info("Starting dependency verification...")
        
        # 1. Check Ollama Service
        if not self._ensure_ollama_running():
            return False
            
        # 2. Check/Pull Models
        self._ensure_models_synced()
        
        logger.info("Dependency verification complete.")
        return True

    def _ensure_ollama_running(self):
        """Check if Ollama is running, try to start it if not."""
        try:
            requests.get(f"{self.ollama_endpoint}/api/tags", timeout=2)
            return True
        except requests.exceptions.ConnectionError:
            logger.info("Ollama not responding. Attempting to start service...")
            
            # Check if ollama command exists
            if not shutil.which("ollama"):
                logger.error("Ollama executable not found in PATH. Please install Ollama from https://ollama.com")
                return False

            # Try to start it in background
            if platform.system() == "Windows":
                subprocess.Popen(["ollama", "serve"], 
                                creationflags=subprocess.CREATE_NEW_CONSOLE if hasattr(subprocess, 'CREATE_NEW_CONSOLE') else 0,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["ollama", "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Wait for it to wake up
            for _ in range(10):
                time.sleep(2)
                try:
                    requests.get(f"{self.ollama_endpoint}/api/tags", timeout=2)
                    logger.info("Ollama service started successfully.")
                    return True
                except:
                    continue
            
            logger.error("Failed to start Ollama service automatically.")
            return False

    def _ensure_models_synced(self):
        """Check for required models and pull them if missing."""
        try:
            response = requests.get(f"{self.ollama_endpoint}/api/tags", timeout=5)
            existing_models = [m['name'] for m in response.json().get('models', [])]
            
            for model in REQUIRED_MODELS:
                if model not in existing_models and f"{model}:latest" not in existing_models:
                    logger.info(f"Model '{model}' is missing. Initiating background pull...")
                    # We run the pull in a separate thread/process so we don't block app startup
                    # But we notify the app state
                    self._pull_model_async(model)
                else:
                    logger.info(f"Model '{model}' is verified.")
        except Exception as e:
            logger.error(f"Error syncing models: {e}")

    def _pull_model_async(self, model_name):
        """Pull a model via the Ollama API without blocking."""
        def pull_worker():
            try:
                logger.info(f"Downloading {model_name}... (this may take several minutes)")
                payload = {"name": model_name, "stream": False}
                requests.post(f"{self.ollama_endpoint}/api/pull", json=payload, timeout=900)
                logger.info(f"Successfully downloaded {model_name}")
            except Exception as e:
                logger.error(f"Failed to pull {model_name}: {e}")

        import threading
        threading.Thread(target=pull_worker, daemon=True).start()

    def check_disk_space(self, required_gb=15):
        """Verify there is enough space for models."""
        total, used, free = shutil.disk_usage(self.base_dir)
        free_gb = free // (2**30)
        if free_gb < required_gb:
            logger.warning(f"Low disk space: {free_gb}GB available. {required_gb}GB recommended for local AI.")
            return False
        return True

    def run_health_checks(self):
        """Run self-healing diagnostics for Law Firm IT environments."""
        results = {
            "disk_space": self.check_disk_space(),
            "ollama_path": shutil.which("ollama") is not None,
            "temp_writable": os.access(os.environ.get("TEMP", "."), os.W_OK),
            "vault_writable": os.access(self.base_dir / "vault", os.W_OK) if (self.base_dir / "vault").exists() else True
        }
        
        if not all(results.values()):
            logger.error(f"Health check failures detected: {results}")
            
        return results
