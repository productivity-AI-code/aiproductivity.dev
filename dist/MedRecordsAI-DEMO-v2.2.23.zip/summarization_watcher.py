import argparse
import hashlib
import json
import logging
import os
import random
import re
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
import yaml
from security_vault import Vault
from pipeline_schemas import extract_json_from_response, validate_ingestion_output, validate_privacy_output, validate_summary_output, validate_audit_output, build_stage_prompt, INGESTION_SCHEMA_EXAMPLE, PRIVACY_SCHEMA_EXAMPLE, SUMMARY_SCHEMA_EXAMPLE, AUDIT_SCHEMA_EXAMPLE
BASE_DIR = Path(__file__).parent
INCOMING_DIR = BASE_DIR / 'vault' / 'incoming'
PROCESSING_DIR = BASE_DIR / 'vault' / 'processing'
PROCESSED_DIR = BASE_DIR / 'vault' / 'processed'
SUMMARIES_DIR = BASE_DIR / 'vault' / 'summaries'
AUDIT_DIR = BASE_DIR / 'vault' / 'audit'
LEDGER_FILE = BASE_DIR / 'vault' / 'processed_files.json'
PIPELINE_STATUS_DIR = BASE_DIR / 'vault' / 'pipeline_status'
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s', handlers=[logging.StreamHandler()])
logger = logging.getLogger('summarization_watcher')

class ShutdownException(Exception):
    pass
import ctypes
import contextlib
_ES_CONTINUOUS = 2147483648
_ES_SYSTEM_REQUIRED = 1

@contextlib.contextmanager
def prevent_sleep():
    if sys.platform == 'win32':
        ctypes.windll.kernel32.SetThreadExecutionState(_ES_CONTINUOUS | _ES_SYSTEM_REQUIRED)
        logger.info('Sleep prevention: ENABLED (system will stay awake)')
    try:
        yield
    finally:
        if sys.platform == 'win32':
            ctypes.windll.kernel32.SetThreadExecutionState(_ES_CONTINUOUS)
            logger.info('Sleep prevention: RELEASED')
SHUTDOWN_FLAG_FILE = BASE_DIR / 'vault' / '.shutting_down'

def _check_shutting_down():
    if SHUTDOWN_FLAG_FILE.exists():
        raise ShutdownException('Server shutdown in progress')
PIPELINE_STAGES = [{'name': 'ingestion', 'agent': 'ingestion', 'task': 'Parse this medical document into structured JSON for litigation support analysis. Extract all sections, classify each section by type (e.g., encounter notes, labs, imaging, vitals, discharge). Preserve clinical detail — attorneys need exact findings, dates, and provider names. Output ONLY valid JSON matching the schema.', 'validator': validate_ingestion_output, 'schema_example': INGESTION_SCHEMA_EXAMPLE}, {'name': 'privacy', 'agent': 'privacy', 'task': 'De-identify this medical record for HIPAA-compliant litigation review. Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens. Count every redaction. Output ONLY valid JSON matching the schema.', 'validator': validate_privacy_output, 'schema_example': PRIVACY_SCHEMA_EXAMPLE}, {'name': 'summarizer', 'agent': 'summarizer', 'task': "Produce a litigation-ready clinical summary of this de-identified medical record. This system is used by personal injury attorneys to analyze patient medical records. Every claim must cite its source section. Build a master chronology of all clinical events. Identify smoking-gun quotes, contradictions, discovery deficiencies, and timeline gaps. Include confidence scores. Additionally, extract ALL billing and cost information found in the records into a 'billing_data' object. For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. Calculate subtotals per provider, total past medical costs, and any future medical cost estimates with the basis for those estimates. If no billing data is found, output billing_data with an empty providers array and totals of 0.\n\nALERTS & GAP DETECTION (REQUIRED):\nYou MUST also generate an 'alerts' array at the top level of your JSON output. These alerts serve as proactive intelligence for the attorney — flagging risks, gaps, and strategic vulnerabilities that could impact case value BEFORE opposing counsel finds them.\n\nGenerate between 3 and 10 alerts per case. Each alert must be one of these types:\n  - treatment_gap: Periods where expected treatment was absent (e.g., no PT visits for 30+ days)\n  - missing_provider: Referenced providers whose records are not in the file\n  - pre_existing: Pre-existing conditions that defense will use to argue causation\n  - inconsistency: Contradictions between records, statements, or clinical findings\n  - compliance_issue: Missed appointments, non-compliance with treatment plans, AMA discharges\n  - prior_injury: Prior injuries to the same body region that weaken causation arguments\n  - medication_change: Significant medication changes (escalation, new narcotics, discontinuation)\n\nEach alert object MUST have these fields:\n  - type: one of the types listed above\n  - severity: 'high' | 'medium' | 'low'\n  - title: concise title (e.g., '45-Day Physical Therapy Gap')\n  - description: detailed explanation of the alert and its litigation significance\n  - impact_estimate: how this may affect settlement value or case strategy\n  - recommended_action: specific next step for the attorney or paralegal\n  - citation: section reference (e.g., 'sec_003:p7')\n  - date_range: relevant date range if applicable (e.g., '04/15/2024 - 05/30/2024'), or null\n\nPrioritize HIGH severity alerts for issues that directly threaten case value. Think like opposing counsel: what weaknesses would THEY exploit?\n\nOutput ONLY valid JSON matching the schema.", 'validator': validate_summary_output, 'schema_example': SUMMARY_SCHEMA_EXAMPLE}, {'name': 'auditor', 'agent': 'auditor', 'task': 'Create a HIPAA compliance audit entry for this pipeline run. Reference files ONLY by SHA-256 hash. Include NO PHI. Determine compliance status. Output ONLY valid JSON matching the schema.', 'validator': validate_audit_output, 'schema_example': AUDIT_SCHEMA_EXAMPLE}]

def load_config():
    config_path = BASE_DIR / 'config.yaml'
    if not config_path.exists():
        logger.warning('config.yaml not found, using defaults')
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}

def load_ledger():
    return _safe_load_json(LEDGER_FILE) or {}

def save_ledger(ledger):
    tmp = LEDGER_FILE.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(ledger, f, indent=2)
    tmp.replace(LEDGER_FILE)

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def update_pipeline_status(run_id, stage, status, details=None, source_file=None, case_ref=None):
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f'{run_id}.json'
    data = _safe_load_json(status_file)
    if not data:
        data = {'run_id': run_id, 'started_at': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'stages': {}}
    if source_file and 'source_file' not in data:
        data['source_file'] = source_file
    if case_ref and 'case_ref' not in data:
        data['case_ref'] = case_ref
    now = datetime.now(timezone.utc).isoformat()
    stage_data = data.get('stages', {}).get(stage, {})
    if status == 'running':
        original_start = stage_data.get('started_at', now) if stage_data.get('status') == 'running' else now
        stage_data = {'status': status, 'started_at': original_start, 'details': details}
    else:
        stage_data['status'] = status
        stage_data['timestamp'] = now
        stage_data['details'] = details
        if 'started_at' in stage_data:
            try:
                start = datetime.fromisoformat(stage_data['started_at'])
                end = datetime.fromisoformat(now)
                stage_data['duration_seconds'] = round((end - start).total_seconds(), 1)
            except (ValueError, TypeError):
                pass
    data.setdefault('stages', {})[stage] = stage_data
    if status == 'failed':
        data['status'] = 'failed'
        if isinstance(details, dict):
            data['error_type'] = details.get('error_type', 'unknown')
            data['error_message'] = details.get('error_msg', str(details))
            data['retryable'] = details.get('retryable', True)
            data['user_action'] = _get_user_action(details.get('error_type', 'unknown'))
        elif isinstance(details, str):
            data['error_message'] = details
            data['retryable'] = True
        data['failed_at'] = now
    elif stage == 'auditor' and status == 'completed':
        data['status'] = 'completed'
        data['completed_at'] = now
    _atomic_json_write(status_file, data)
    try:
        from db import transaction
        with transaction() as conn:
            exists = conn.execute('SELECT 1 FROM tasks WHERE task_id = ?', (run_id,)).fetchone()
            if not exists:
                conn.execute('\n                    INSERT INTO tasks (task_id, agent, model, task, status, created_at)\n                    VALUES (?, ?, ?, ?, ?, ?)\n                ', (run_id, 'pipeline', 'claude-sonnet-4-6', f'Pipeline: {stage}', 'running', data['started_at']))
            update_sql = 'UPDATE tasks SET status = ?, role = ?'
            params = [data['status'], f'Stage: {stage}']
            if data['status'] == 'failed':
                update_sql += ', error = ?'
                params.append(data.get('error_message', str(details)))
            if data['status'] == 'completed':
                update_sql += ', completed_at = ?'
                params.append(data['completed_at'])
            update_sql += ' WHERE task_id = ?'
            params.append(run_id)
            conn.execute(update_sql, params)
    except Exception as e:
        logger.error(f'Failed to sync pipeline status to SQLite: {e}')
PIPELINE_STATS_FILE = BASE_DIR / 'vault' / 'pipeline_stats.json'

def _update_pipeline_metadata(run_id, metadata):
    status_file = PIPELINE_STATUS_DIR / f'{run_id}.json'
    data = _safe_load_json(status_file)
    if not data:
        return
    stats = _safe_load_json(PIPELINE_STATS_FILE) or []
    if stats and metadata.get('input_chars'):
        matching_runs = [r for r in stats if r.get('mode') == metadata.get('mode', 'fast')]
        if matching_runs:
            total_chars = sum((r.get('input_chars', 0) for r in matching_runs))
            total_seconds = sum((sum(r.get('stage_durations', {}).values()) for r in matching_runs))
            if total_chars > 0 and total_seconds > 0:
                chars_per_sec = total_chars / total_seconds
                estimated_seconds = metadata['input_chars'] / chars_per_sec * 1.2
                data['estimated_duration'] = round(estimated_seconds, 1)
                logger.info('Estimated duration for %s: %.1fs (based on %d past runs)', run_id, estimated_seconds, len(matching_runs))
    data.update(metadata)
    _atomic_json_write(status_file, data)
    try:
        from db import transaction
        with transaction() as conn:
            conn.execute('UPDATE tasks SET context = ? WHERE task_id = ?', (json.dumps(metadata), run_id))
    except Exception as e:
        logger.error(f'Failed to sync metadata to SQLite: {e}')

def _record_pipeline_stats(run_id):
    status_file = PIPELINE_STATUS_DIR / f'{run_id}.json'
    data = _safe_load_json(status_file)
    if not data:
        return
    if data.get('status') != 'completed':
        return
    stage_durations = {}
    stages = data.get('stages', {})
    for stage_name, stage_data in stages.items():
        if isinstance(stage_data, dict) and 'duration_seconds' in stage_data:
            stage_durations[stage_name] = stage_data['duration_seconds']
    if not stage_durations:
        stage_order = ['ingestion', 'privacy', 'summarizer', 'auditor']
        prev_ts = data.get('started_at')
        for sn in stage_order:
            sd = stages.get(sn)
            if not isinstance(sd, dict) or not sd.get('timestamp'):
                continue
            if prev_ts:
                try:
                    t_start = datetime.fromisoformat(prev_ts)
                    t_end = datetime.fromisoformat(sd['timestamp'])
                    dur = round((t_end - t_start).total_seconds(), 1)
                    if dur > 0:
                        stage_durations[sn] = dur
                except (ValueError, TypeError):
                    pass
            prev_ts = sd.get('timestamp', prev_ts)
    if not stage_durations:
        return
    record = {'run_id': run_id, 'mode': data.get('mode', 'fast'), 'completed_at': data.get('completed_at'), 'input_chars': data.get('input_chars', 0), 'file_size_bytes': data.get('file_size_bytes', 0), 'file_count': data.get('file_count', 1), 'stage_durations': stage_durations}
    if data.get('mode') == 'thorough':
        record['chunk_count'] = data.get('chunk_count', 0)
        chunks_phase = data.get('chunks', {})
        preprocessing = data.get('preprocessing', {})
        if isinstance(chunks_phase, dict) and isinstance(preprocessing, dict):
            try:
                c_ts = chunks_phase.get('timestamp')
                p_ts = preprocessing.get('timestamp')
                if c_ts and p_ts:
                    chunks_start = datetime.fromisoformat(p_ts)
                    chunks_end = datetime.fromisoformat(c_ts)
                    record['chunks_total_seconds'] = round((chunks_end - chunks_start).total_seconds(), 1)
            except (ValueError, TypeError):
                pass
    stats = _safe_load_json(PIPELINE_STATS_FILE) or []
    if not isinstance(stats, list):
        stats = []
    stats.append(record)
    stats = stats[-50:]
    _atomic_json_write(PIPELINE_STATS_FILE, stats)

def _get_user_action(error_type):
    actions = {'api_credits_exhausted': 'Add credits at console.anthropic.com, then click Retry.', 'API_CREDITS_EXHAUSTED': 'Add credits at console.anthropic.com, then click Retry.', 'api_key_invalid': 'Check your API key in Settings, then click Retry.', 'INVALID_API_KEY': 'Check your API key in Settings, then click Retry.', 'api_rate_limited': 'Too many requests. Wait a minute, then click Retry.', 'api_overloaded': 'The AI service is temporarily overloaded. Click Retry in a few minutes.', 'api_server_error': 'The AI service had a temporary error. Click Retry.', 'api_timeout': 'Processing took too long. Try a smaller document, or click Retry.', 'api_connection_error': 'Could not connect to the AI service. Check your internet connection.', 'json_parse_failed': 'The AI returned malformed output. Click Retry — this usually works on the second attempt.', 'validation_failed': "The AI output didn't match the expected format. Click Retry.", 'no_output': "The AI didn't return a response. Click Retry.", 'pipeline_timeout': 'Processing exceeded the time limit. Try splitting large documents.', 'CONFIG_ERROR': 'Configuration error. Check config.yaml and restart.'}
    return actions.get(error_type, 'An unexpected error occurred. Click Retry to try again.')

def _kill_process_tree(pid):
    try:
        if sys.platform == 'win32':
            for attempt in range(3):
                result = subprocess.run(['taskkill', '/T', '/F', '/PID', str(pid)], capture_output=True, timeout=15)
                if result.returncode == 0:
                    break
                if b'not found' in result.stderr.lower() or result.returncode == 128:
                    break
                time.sleep(2)
            else:
                logger.warning('taskkill failed for PID %d after 3 attempts', pid)
        else:
            import signal
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                try:
                    os.kill(pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
    except Exception as e:
        logger.debug('Process tree kill for PID %d: %s', pid, e)

def _resolve_stage_model(stage_name, config):
    backend = config.get('llm_backend', 'ollama')
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    if backend == 'claude':
        key = f'{stage_name}_model'
    else:
        key = f'ollama_{stage_name}_model'
    return modes_cfg.get(key)

def _resolve_combined_model(stage_name, config):
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    return modes_cfg.get(f'{stage_name}_model') or config.get('claude', {}).get('model', 'claude-sonnet-4-6')

def dispatch_agent(agent_name, task, context_json, config, combined=False, model_override=None, backend_override=None, max_tokens_override=None):
    tmp_dir = BASE_DIR / 'vault' / 'tmp'
    tmp_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    task_file = tmp_dir / f'task_{agent_name}_{ts}.txt'
    try:
        task_file.write_text(task, encoding='utf-8')
    except Exception as e:
        logger.error('Failed to write temp files for %s: %s', agent_name, e)
        return None
    cmd = [sys.executable, str(BASE_DIR / 'dispatch.py'), '--agent', agent_name, '--task-file', str(task_file)]
    logger.info('Dispatching to %s...', agent_name)
    task_size = task_file.stat().st_size if task_file.exists() else 0
    base_timeout = 300
    effective_backend = backend_override or config.get('llm_backend', 'ollama')
    if effective_backend == 'claude':
        time_per_char = 60 / 10000
    else:
        time_per_char = 60 / 2000
    adaptive_add = task_size * time_per_char
    if effective_backend == 'claude':
        cfg_timeout = config.get('claude', {}).get('combined_timeout' if combined else 'timeout', 600)
    else:
        cfg_timeout = config.get('ollama', {}).get('timeout', 300)
    timeout = max(cfg_timeout, base_timeout + adaptive_add)
    timeout = min(timeout, 3600)
    logger.info('Agent %s timeout: %ds (task size: %d chars, backend: %s)', agent_name, int(timeout), task_size, effective_backend)
    proc = None
    try:
        kwargs = {}
        if sys.platform == 'win32':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = 0
            kwargs['startupinfo'] = startupinfo
            kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        env = os.environ.copy()
        if combined:
            env['COMBINED_PIPELINE'] = '1'
        if model_override:
            env['AGENT_MODEL_OVERRIDE'] = model_override
        if backend_override:
            env['AGENT_BACKEND_OVERRIDE'] = backend_override
        if max_tokens_override:
            env['DISPATCH_MAX_TOKENS_OVERRIDE'] = str(max_tokens_override)
        env['DISPATCH_TIMEOUT_OVERRIDE'] = str(int(timeout * 0.85))
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=str(BASE_DIR), env=env, **kwargs)
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            _kill_process_tree(proc.pid)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
            logger.error('Agent %s timed out after %ds — process tree killed (PID %d)', agent_name, timeout, proc.pid)
            return None
        if proc.returncode != 0:
            stderr_msg = stderr[-500:] if stderr else 'no stderr'
            stdout_tail = stdout[-500:] if stdout else 'no stdout'
            logger.error('Agent %s failed (rc=%d): %s', agent_name, proc.returncode, stderr_msg)
            if stdout_tail and stdout_tail != 'no stdout':
                logger.error('Agent %s stdout: %s', agent_name, stdout_tail)
            combined_output = (stderr_msg + ' ' + stdout_tail).lower()
            if 'credit balance' in combined_output or 'insufficient' in combined_output or 'api_credits_exhausted' in combined_output:
                return '__ERROR__:API_CREDITS_EXHAUSTED:Your Anthropic API credit balance is too low. Add credits at console.anthropic.com.'
            elif 'invalid x-api-key' in combined_output or 'invalid api key' in combined_output or 'api_key_invalid' in combined_output:
                return '__ERROR__:INVALID_API_KEY:Your Anthropic API key is invalid. Check ANTHROPIC_API_KEY in your .env file.'
            elif 'keyerror' in combined_output:
                return '__ERROR__:CONFIG_ERROR:Configuration error in dispatch.py. Check config.yaml for missing keys.'
            for line in (stdout_tail or '').split('\n'):
                if '__error__:' in line.lower():
                    for orig_line in (stdout or '').split('\n'):
                        if '__ERROR__:' in orig_line:
                            return orig_line.strip().split(']')[-1].strip() if ']' in orig_line else orig_line.strip()
                    break
            return None
        output_path = None
        for line in stdout.split('\n'):
            if 'Output saved to:' in line:
                output_path = line.split('Output saved to:')[-1].strip()
                break
        if output_path and Path(output_path).exists():
            raw_output = Path(output_path).read_text(encoding='utf-8')
            return raw_output
        else:
            logger.error('Agent %s completed but output file not found', agent_name)
            return None
    except Exception as e:
        logger.error('Agent %s dispatch error: %s', agent_name, e)
        if proc and proc.poll() is None:
            _kill_process_tree(proc.pid)
        return None
    finally:
        try:
            task_file.unlink(missing_ok=True)
        except Exception:
            pass

def _update_document_status(file_path, **kwargs):
    try:
        from db import transaction as db_transaction
        file_str = str(file_path)
        sets = []
        params = []
        for key, val in kwargs.items():
            sets.append(f'{key} = ?')
            params.append(val)
        if not sets:
            return
        sets.append('updated_at = ?')
        params.append(datetime.now(timezone.utc).isoformat())
        params.extend([file_str, file_str])
        with db_transaction() as conn:
            conn.execute(f"UPDATE documents SET {', '.join(sets)} WHERE original_path = ? OR current_path = ?", params)
    except Exception as e:
        logger.debug('Document status sync skipped: %s', e)

def _register_summary_document(summary_file, run_id, source_file_path):
    try:
        from db import transaction as db_transaction
        source_str = str(source_file_path)
        with db_transaction() as conn:
            row = conn.execute('SELECT case_ref FROM documents WHERE original_path = ? OR current_path = ?', (source_str, source_str)).fetchone()
            case_ref = row['case_ref'] if row else None
            existing = conn.execute("SELECT id FROM documents WHERE run_id = ? AND category = 'summary'", (run_id,)).fetchone()
            if existing:
                logger.debug('Summary document already registered for run %s', run_id)
                return
            now = datetime.now(timezone.utc).isoformat()
            summary_path = str(summary_file)
            conn.execute('INSERT INTO documents\n                   (filename, original_path, current_path, file_size, extension,\n                    vault_zone, status, case_ref, category, run_id,\n                    upload_source, created_at, updated_at, processed_at)\n                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (f'{run_id}_summary.json', summary_path, summary_path, summary_file.stat().st_size if summary_file.exists() else 0, '.json', 'processed', 'completed', case_ref, 'summary', run_id, 'api', now, now, now))
    except Exception as e:
        logger.debug('Summary document registration skipped: %s', e)

def _read_file_content(file_path):
    ext = file_path.suffix.lower()
    if ext == '.pdf':
        try:
            import fitz
            with fitz.open(str(file_path)) as doc:
                pages = []
                page_map = []
                running_char = 0
                for i, page in enumerate(doc, 1):
                    text = page.get_text().strip()
                    if text:
                        header = f'--- Page {i} ---\n'
                        page_text = header + text
                        start_char = running_char
                        end_char = running_char + len(page_text)
                        page_map.append({'page': i, 'start_char': start_char, 'end_char': end_char, 'text_preview': text[:100]})
                        pages.append(page_text)
                        running_char = end_char + 2
            return ('\n\n'.join(pages) if pages else '(PDF contained no extractable text)', page_map if page_map else None)
        except ImportError:
            logger.warning('PyMuPDF not installed; cannot extract PDF text')
            return ('(PDF file — install PyMuPDF to extract content)', None)
        except Exception as e:
            logger.warning('PDF extraction failed for %s: %s', file_path.name, e)
            return (f'(PDF extraction error: {e})', None)
    elif ext in ('.png', '.jpg', '.jpeg', '.tiff', '.tif'):
        return (f'(Image file: {file_path.name} — requires Vision API for text extraction)', None)
    elif ext in ('.dcm', '.dicom'):
        return (f'(DICOM file: {file_path.name} — medical imaging file)', None)
    elif ext == '.xlsx':
        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
            try:
                parts = []
                for sheet_name in wb.sheetnames:
                    ws = wb[sheet_name]
                    rows = []
                    for row in ws.iter_rows(values_only=True):
                        rows.append('\t'.join((str(c) if c is not None else '' for c in row)))
                    if rows:
                        parts.append(f'--- Sheet: {sheet_name} ---\n' + '\n'.join(rows))
                return ('\n\n'.join(parts) if parts else '(empty workbook)', None)
            finally:
                wb.close()
        except ImportError:
            logger.warning('openpyxl not installed; cannot read .xlsx files')
            return ('(Excel .xlsx file — install openpyxl to extract content)', None)
    elif ext == '.xls':
        try:
            import xlrd
            wb = xlrd.open_workbook(str(file_path))
            parts = []
            for sheet in wb.sheets():
                rows = []
                for rx in range(sheet.nrows):
                    rows.append('\t'.join((str(sheet.cell_value(rx, cx)) for cx in range(sheet.ncols))))
                if rows:
                    parts.append(f'--- Sheet: {sheet.name} ---\n' + '\n'.join(rows))
            return ('\n\n'.join(parts) if parts else '(empty workbook)', None)
        except ImportError:
            logger.warning('xlrd not installed; cannot read .xls files')
            return ('(Excel .xls file — install xlrd to extract content)', None)
    else:
        try:
            return (file_path.read_text(encoding='utf-8', errors='replace'), None)
        except Exception:
            with open(file_path, 'rb') as f:
                return (f.read().decode('utf-8', errors='replace'), None)
CHECKPOINT_DIR = PROCESSING_DIR / 'checkpoints'

def _save_checkpoint(run_id, stage_name, stage_output):
    try:
        CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
        checkpoint_file = CHECKPOINT_DIR / f'{run_id}.json'
        data = _safe_load_json(checkpoint_file) or {}
        data[stage_name] = stage_output
        tmp = checkpoint_file.with_suffix('.tmp')
        tmp.write_text(json.dumps(data), encoding='utf-8')
        tmp.replace(checkpoint_file)
    except Exception as e:
        logger.warning('Failed to save checkpoint for %s/%s: %s (pipeline will continue)', run_id, stage_name, e)

def _load_checkpoint(run_id):
    checkpoint_file = CHECKPOINT_DIR / f'{run_id}.json'
    return _safe_load_json(checkpoint_file) or {}

def _clear_checkpoint(run_id):
    checkpoint_file = CHECKPOINT_DIR / f'{run_id}.json'
    try:
        if checkpoint_file.exists():
            checkpoint_file.unlink()
    except OSError:
        pass

def _dispatch_with_retry(stage, task_with_schema, current_input, config, combined=False, max_retries=None, model_override=None, run_id=None, backend_override=None, max_tokens_override=None):
    stage_name = stage['name']
    if max_retries is None:
        max_retries = 3
    db_lock_retries = 0
    original_task = task_with_schema
    for attempt in range(1, max_retries + 1):
        if run_id and _check_cancelled(run_id):
            return (None, {'error_type': 'cancelled', 'error_msg': 'Pipeline cancelled by user', 'retryable': True})
        if attempt > 1:
            base_backoff = min(10 * 2 ** (attempt - 2), 60)
            backoff = base_backoff * (0.7 + random.random() * 0.6)
            logger.info('  Stage %s: backoff %.1fs before retry %d/%d...', stage_name, backoff, attempt, max_retries)
            time.sleep(backoff)
        if attempt >= 2 and stage_name in ('summarizer', 'merge'):
            reduction_pct = 75 if attempt == 2 else 50
            logger.warning('  Stage %s: attempt %d — reducing content to %d%% for resilience', stage_name, attempt, reduction_pct)
            if isinstance(current_input, dict) and 'raw_content' in current_input:
                truncated_input = dict(current_input)
                orig_len = len(truncated_input['raw_content'])
                truncated_input['raw_content'] = truncated_input['raw_content'][:int(orig_len * reduction_pct / 100)]
                task_with_schema = original_task.replace(current_input['raw_content'][:500], truncated_input['raw_content'][:500]) if len(original_task) > 10000 else original_task
                task_with_schema = f"NOTE: Content has been truncated to {reduction_pct}% ({len(truncated_input['raw_content'])} chars) for processing reliability. Summarize what is available.\n\n" + task_with_schema
            elif isinstance(current_input, dict) and current_input.get('merge'):
                marker = '## CHUNK SUMMARIES TO MERGE'
                marker_pos = task_with_schema.find(marker)
                if marker_pos >= 0:
                    preamble = task_with_schema[:marker_pos + len(marker)]
                    chunk_data = task_with_schema[marker_pos + len(marker):]
                    truncated_data = chunk_data[:int(len(chunk_data) * reduction_pct / 100)]
                    last_chunk = truncated_data.rfind('### CHUNK')
                    if last_chunk > 0:
                        truncated_data = truncated_data[:last_chunk]
                    orig_len = len(task_with_schema)
                    task_with_schema = f'NOTE: Merge input truncated to ~{reduction_pct}% for processing reliability. Merge what is available — some later chunks may be missing.\n\n' + preamble + truncated_data
                    logger.info('  Merge content reduced: %d -> %d chars', orig_len, len(task_with_schema))
                else:
                    logger.warning('  Merge stage: no chunk summaries marker found for truncation')
        raw_output = dispatch_agent(stage['agent'], task_with_schema, current_input, config, combined=combined, model_override=model_override, backend_override=backend_override, max_tokens_override=max_tokens_override)
        if not raw_output or (isinstance(raw_output, str) and raw_output.startswith('__ERROR__:')):
            if raw_output and raw_output.startswith('__ERROR__:'):
                parts = raw_output.split(':', 2)
                error_type = parts[1] if len(parts) > 1 else 'UNKNOWN'
                error_msg = parts[2] if len(parts) > 2 else 'Agent error'
                if 'database is locked' in error_msg.lower():
                    db_lock_retries += 1
                    if db_lock_retries > 5:
                        return (None, {'error_type': 'database_locked', 'error_msg': 'Database locked after 5 retries', 'retryable': True})
                    backoff = min(2 ** db_lock_retries, 16)
                    logger.warning('  Database locked during stage %s — backoff %ds (attempt %d/5)...', stage_name, backoff, db_lock_retries)
                    time.sleep(backoff)
                    continue
                retryable = error_type not in ('API_CREDITS_EXHAUSTED', 'INVALID_API_KEY', 'api_key_invalid', 'api_credits_exhausted')
                if not retryable:
                    return (None, {'error_type': error_type, 'error_msg': error_msg, 'retryable': False})
                if attempt == max_retries:
                    return (None, {'error_type': error_type, 'error_msg': error_msg, 'retryable': retryable})
                logger.warning('  Stage %s attempt %d/%d: %s — will retry...', stage_name, attempt, max_retries, error_msg)
                continue
            else:
                if attempt == max_retries:
                    return (None, {'error_type': 'no_output', 'error_msg': f'No output from agent after {max_retries} attempts', 'retryable': True})
                logger.warning('  Stage %s attempt %d/%d: no output (timeout/crash) — will retry...', stage_name, attempt, max_retries)
                continue
        try:
            parsed_output = extract_json_from_response(raw_output)
        except ValueError as e:
            if attempt < max_retries:
                logger.info('  Stage %s: Invalid JSON (attempt %d/%d), retrying with correction...', stage_name, attempt, max_retries)
                bad_preview = raw_output[:500] if raw_output else '(empty)'
                correction_header = f'IMPORTANT: Your previous output was not valid JSON. Error: {e}\nFirst 500 chars of your output:\n{bad_preview}\n\nYou MUST output ONLY a valid JSON object. No markdown code fences, no explanation text, no preamble.\n\n'
                task_with_schema = correction_header + original_task
                continue
            return (None, {'error_type': 'json_parse_failed', 'error_msg': f'Invalid JSON after {max_retries} attempts: {e}', 'retryable': True})
        validation_errors = stage['validator'](parsed_output)
        if validation_errors:
            critical = [e for e in validation_errors if 'CRITICAL' in e]
            warnings = [e for e in validation_errors if 'CRITICAL' not in e]
            if warnings:
                logger.warning('  Stage %s validation warnings: %s', stage_name, warnings)
            if critical:
                if attempt < max_retries:
                    logger.info('  Stage %s: critical validation errors (attempt %d/%d), retrying...', stage_name, attempt, max_retries)
                    validation_feedback = f'IMPORTANT: Your previous output had validation errors:\n' + '\n'.join((f'- {err}' for err in critical)) + f'\n\nFix these issues. Output ONLY a valid JSON object (not an array/list). No markdown code fences, no explanation text.\n\n'
                    task_with_schema = validation_feedback + original_task
                    continue
                return (None, {'error_type': 'validation_failed', 'error_msg': f'Validation: {critical}', 'retryable': True})
        return (parsed_output, None)
    return (None, {'error_type': 'max_retries', 'error_msg': f'All {max_retries} retry attempts exhausted', 'retryable': True})

def _atomic_json_write(file_path, data, encrypt=False):
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = file_path.with_suffix('.tmp')
    json_str = json.dumps(data, indent=2)
    if encrypt:
        try:
            from security_vault import Vault
            write_data = Vault.encrypt(json_str)
            mode = 'wb'
        except ImportError:
            logger.error('security_vault not found — writing sensitive data UNENCRYPTED!')
            write_data = json_str
            mode = 'w'
    else:
        write_data = json_str
        mode = 'w'
    with open(tmp, mode, encoding='utf-8' if mode == 'w' else None) as f:
        f.write(write_data)
    for _retry in range(5):
        try:
            tmp.replace(file_path)
            break
        except PermissionError:
            if _retry == 4:
                raise
            time.sleep(0.2 * 2 ** _retry)

def _safe_load_json(file_path):
    file_path = Path(file_path)
    if not file_path.exists():
        return None
    try:
        from security_vault import Vault
        if Vault.is_encrypted(file_path):
            decrypted_bytes = Vault.decrypt_file(file_path)
            return json.loads(decrypted_bytes.decode('utf-8'))
        else:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        logger.debug('Failed to load JSON from %s: %s', file_path.name, e)
        return None

def _check_cancelled(run_id):
    cancel_flag = PIPELINE_STATUS_DIR / f'{run_id}.cancel'
    if cancel_flag.exists():
        return True
    status_file = PIPELINE_STATUS_DIR / f'{run_id}.json'
    if status_file.exists():
        try:
            data = json.loads(status_file.read_text(encoding='utf-8'))
            return data.get('cancelled', False)
        except Exception:
            pass
    return False

def _clear_cancel_flag(run_id):
    cancel_flag = PIPELINE_STATUS_DIR / f'{run_id}.cancel'
    try:
        if cancel_flag.exists():
            cancel_flag.unlink()
    except Exception:
        pass

def _cancel_pipeline(run_id, processing_path=None):
    logger.warning('Pipeline %s CANCELLED by user.', run_id)
    update_pipeline_status(run_id, 'pipeline', 'failed', {'error_type': 'cancelled', 'error_msg': 'Pipeline was cancelled by user', 'retryable': True, 'cancelled': True})
    if processing_path and Path(processing_path).exists():
        _move_to_failed(processing_path, run_id)

def _cleanup_incoming_source(file_path):
    file_path = Path(file_path)
    try:
        if file_path.exists() and str(file_path.resolve()).startswith(str(INCOMING_DIR.resolve())):
            file_path.unlink()
            logger.info('  Removed source from incoming: %s', file_path.name)
            parent = file_path.parent
            if parent != INCOMING_DIR and parent.exists() and (not any(parent.iterdir())):
                parent.rmdir()
                logger.info('  Removed empty incoming folder: %s', parent.name)
    except Exception as e:
        logger.warning('  Could not remove source from incoming: %s', e)

def run_pipeline(file_path, config, run_id=None, dry_run=False):
    with prevent_sleep():
        return _run_pipeline_inner(file_path, config, run_id, dry_run)

def _run_pipeline_inner(file_path, config, run_id=None, dry_run=False):
    file_path = Path(file_path)
    file_hash = file_sha256(file_path)
    if not run_id:
        run_id = f"pipeline_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{file_hash[:8]}"
    logger.info('Pipeline %s starting for: %s', run_id, file_path.name)
    checkpoints = _load_checkpoint(run_id)
    if checkpoints:
        logger.info('  Resuming from checkpoint with %d completed stages', len(checkpoints))
    _update_document_status(file_path, status='processing', vault_zone='processing', run_id=run_id)
    processing_path = PROCESSING_DIR / f'{run_id}_{file_path.name}'
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)
    if not dry_run and (not processing_path.exists()):
        shutil.copy2(file_path, processing_path)
    _save_checkpoint(run_id, '_source_paths', [str(file_path)])
    raw_content, source_page_map = _read_file_content(file_path)
    pipeline_input = {'source_file': file_path.name, 'file_hash_sha256': file_hash, 'raw_content': raw_content[:200000], 'file_size_bytes': file_path.stat().st_size}
    stage_outputs = {}
    current_input = pipeline_input
    _update_pipeline_metadata(run_id, {'mode': 'fast', 'input_chars': len(raw_content), 'file_size_bytes': file_path.stat().st_size})
    pipeline_start = time.time()
    max_duration = config.get('pipeline', {}).get('max_duration_fast', 3600)
    _clear_cancel_flag(run_id)
    feedback_context = _load_rlhf_feedback()
    for stage in PIPELINE_STAGES:
        stage_name = stage['name']
        try:
            _check_shutting_down()
        except ShutdownException:
            logger.warning('Pipeline %s: server shutting down before stage %s — saving checkpoint', run_id, stage_name)
            _save_checkpoint(run_id, '_shutdown', {'interrupted_at': stage_name})
            update_pipeline_status(run_id, stage_name, 'interrupted', 'Server shutdown — will auto-resume on restart')
            return None
        if _check_cancelled(run_id):
            _cancel_pipeline(run_id, processing_path)
            return None
        elapsed = time.time() - pipeline_start
        if elapsed > max_duration:
            logger.error('Pipeline %s exceeded max duration (%ds). Failing.', run_id, max_duration)
            update_pipeline_status(run_id, stage_name, 'failed', {'error_type': 'pipeline_timeout', 'error_msg': f'Pipeline exceeded {max_duration}s time limit after {int(elapsed)}s', 'retryable': True})
            _move_to_failed(processing_path, run_id)
            return None
        if stage_name in checkpoints:
            logger.info('  Stage %s: RESTORED from checkpoint', stage_name)
            stage_outputs[stage_name] = checkpoints[stage_name]
            current_input = checkpoints[stage_name]
            update_pipeline_status(run_id, stage_name, 'completed', 'restored from checkpoint')
            continue
        logger.info('  Stage: %s', stage_name)
        if dry_run:
            logger.info('  [DRY RUN] Would dispatch to %s', stage['agent'])
            update_pipeline_status(run_id, stage_name, 'skipped', 'dry run')
            continue
        update_pipeline_status(run_id, stage_name, 'running', details={'sub_stage': 'preparing'}, source_file=file_path.name)
        task_with_schema = stage['task'] + '\n\n' + build_stage_prompt(stage_name, current_input, stage['schema_example'])
        if stage_name == 'summarizer' and feedback_context:
            task_with_schema += '\n\n' + feedback_context
        update_pipeline_status(run_id, stage_name, 'running', details={'sub_stage': 'calling_api'})
        parsed_output, error_info = _dispatch_with_retry(stage, task_with_schema, current_input, config, model_override=_resolve_stage_model(stage_name, config), run_id=run_id)
        if parsed_output is None:
            error_msg = error_info.get('error_msg', 'Unknown error') if error_info else 'Unknown error'
            error_type = error_info.get('error_type', 'unknown') if error_info else 'unknown'
            retryable = error_info.get('retryable', True) if error_info else True
            if error_type == 'cancelled':
                _cancel_pipeline(run_id, processing_path)
                return None
            logger.error('  Stage %s FAILED: [%s] %s', stage_name, error_type, error_msg)
            update_pipeline_status(run_id, stage_name, 'failed', {'error_type': error_type, 'error_msg': error_msg, 'retryable': retryable})
            _move_to_failed(processing_path, run_id)
            return None
        update_pipeline_status(run_id, stage_name, 'running', details={'sub_stage': 'saving'})
        stage_outputs[stage_name] = parsed_output
        current_input = parsed_output
        if stage_name == 'privacy' and parsed_output:
            try:
                from vector_store import VectorStore
                vs = VectorStore(config)
                vs.index_document(run_id, parsed_output.get('sections', []))
            except Exception as e:
                logger.warning('  Vector indexing failed for %s: %s', run_id, e)
        _save_checkpoint(run_id, stage_name, parsed_output)
        update_pipeline_status(run_id, stage_name, 'completed')
        logger.info('  Stage %s: PASSED', stage_name)
    if dry_run:
        return None
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f'{run_id}_summary.json'
    summary_data = {'run_id': run_id, 'source_file': file_path.name, 'source_file_hash': file_hash, 'processed_at': datetime.now(timezone.utc).isoformat(), 'ingestion': stage_outputs.get('ingestion'), 'privacy': stage_outputs.get('privacy'), 'summary': stage_outputs.get('summarizer'), 'audit': stage_outputs.get('auditor')}
    if source_page_map:
        summary_data['source_pages'] = source_page_map
    _atomic_json_write(summary_file, summary_data, encrypt=True)
    logger.info('Summary saved (ENCRYPTED): %s', summary_file)
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f'{run_id}_audit.json'
    _atomic_json_write(audit_file, stage_outputs.get('auditor', {}), encrypt=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    processed_path = PROCESSED_DIR / f'{run_id}_{file_path.name}'
    if processing_path.exists():
        shutil.move(str(processing_path), str(processed_path))
    _cleanup_incoming_source(file_path)
    _update_document_status(file_path, status='completed', vault_zone='processed', current_path=str(processed_path), summary_file=f'{run_id}_summary.json', processed_at=datetime.now(timezone.utc).isoformat())
    _register_summary_document(summary_file, run_id, file_path)
    _clear_checkpoint(run_id)
    _record_pipeline_stats(run_id)
    return summary_data

def run_pipeline_thorough(file_paths, config, run_id=None, case_ref=None, mode='thorough'):
    with prevent_sleep():
        return _run_pipeline_thorough_inner(file_paths, config, run_id, case_ref, mode)

def _run_pipeline_thorough_inner(file_paths, config, run_id=None, case_ref=None, mode='thorough'):
    from document_preprocessor import preprocess_case, PreprocessingResult
    file_paths = [Path(p) for p in file_paths]
    if not run_id:
        run_id = f"thorough_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}"
    logger.info('Thorough pipeline %s starting for %d files (case_ref=%s, mode=%s)', run_id, len(file_paths), case_ref, mode)
    modes_cfg = config.get('processing_modes', {}).get('thorough', {})
    pipeline_start = time.time()
    max_duration = config.get('pipeline', {}).get('max_duration_thorough', 10800)
    _clear_cancel_flag(run_id)
    for fp in file_paths:
        _update_document_status(fp, status='processing', vault_zone='processing', run_id=run_id)
    ledger = load_ledger()
    for fp in file_paths:
        if str(fp) not in ledger:
            ledger[str(fp)] = {'run_id': run_id, 'status': 'processing', 'started_at': datetime.now(timezone.utc).isoformat(), 'case_ref': case_ref}
    save_ledger(ledger)
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)
    processing_paths = []
    for fp in file_paths:
        dest = PROCESSING_DIR / f'{run_id}_{fp.name}'
        shutil.copy2(fp, dest)
        processing_paths.append(dest)
    _save_checkpoint(run_id, '_source_paths', [str(p) for p in file_paths])
    logger.info('Phase 1: Preprocessing...')
    _update_thorough_status(run_id, 'preprocessing', 'running')
    try:
        preprocess_result = preprocess_case(file_paths, config, mode=mode, transcribe=True)
    except Exception as e:
        logger.error('Preprocessing failed: %s', e)
        _update_thorough_status(run_id, 'preprocessing', 'failed', str(e))
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    _update_thorough_status(run_id, 'preprocessing', 'completed', {'total_pages': preprocess_result.total_pages, 'unique_pages': preprocess_result.unique_pages, 'duplicate_pages': preprocess_result.duplicate_pages, 'blank_pages': preprocess_result.blank_pages, 'noise_pages': preprocess_result.noise_pages, 'handwritten_pages': preprocess_result.handwritten_pages, 'clinical_pages': preprocess_result.clinical_pages, 'chunks': len(preprocess_result.chunks), 'dedup_stats': preprocess_result.dedup_stats})
    _update_pipeline_metadata(run_id, {'mode': 'thorough', 'chunk_count': len(preprocess_result.chunks), 'total_pages': preprocess_result.total_pages})
    chunks = preprocess_result.chunks
    if not chunks:
        logger.warning('No processable content found after preprocessing')
        _update_thorough_status(run_id, 'preprocessing', 'failed', 'No processable content')
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    logger.info('Preprocessing complete: %d chunks from %d unique pages (of %d total)', len(chunks), preprocess_result.unique_pages, preprocess_result.total_pages)
    logger.info('Phase 2: Per-chunk processing (%d chunks)...', len(chunks))
    chunk_summaries = []
    chunk_contexts = []
    resume_from_chunk = 0
    feedback_context = _load_rlhf_feedback()
    existing_checkpoint = _load_checkpoint(run_id)
    thorough_progress = existing_checkpoint.get('_thorough_progress', {}) if existing_checkpoint else {}
    saved_completed = thorough_progress.get('completed_chunks', 0)
    saved_total = thorough_progress.get('total_chunks', 0)
    if saved_completed > 0:
        if saved_total == len(chunks):
            chunk_summaries = thorough_progress.get('chunk_summaries', [])
            chunk_contexts = thorough_progress.get('chunk_contexts', [])
            completed_chunk_nums = {cs.get('chunk_num', 0) for cs in chunk_summaries}
            resume_from_chunk = max(completed_chunk_nums) if completed_chunk_nums else 0
            logger.info('  Resuming from checkpoint: %d/%d chunks already completed, continuing from chunk %d', saved_completed, len(chunks), resume_from_chunk + 1)
        else:
            logger.warning('  Checkpoint chunk count mismatch (saved=%d, current=%d) — restarting from scratch', saved_total, len(chunks))
    _save_checkpoint(run_id, '_thorough_progress', {'completed_chunks': len(chunk_summaries), 'chunk_summaries': chunk_summaries, 'chunk_contexts': chunk_contexts, 'total_chunks': len(chunks)})
    for i, chunk in enumerate(chunks):
        chunk_id = chunk['chunk_id']
        chunk_num = i + 1
        total_chunks = len(chunks)
        if i < resume_from_chunk:
            logger.info('  Chunk %d/%d: SKIPPED (restored from checkpoint)', chunk_num, total_chunks)
            continue
        try:
            _check_shutting_down()
        except ShutdownException:
            logger.warning('Thorough pipeline %s: server shutting down before chunk %d — saving checkpoint', run_id, chunk_num)
            _save_checkpoint(run_id, '_thorough_progress', {'interrupted_at_chunk': chunk_num, 'completed_chunks': len(chunk_summaries), 'chunk_summaries': chunk_summaries, 'chunk_contexts': chunk_contexts, 'total_chunks': total_chunks})
            _update_thorough_status(run_id, 'chunks', 'interrupted', 'Server shutdown — will auto-resume on restart')
            return None
        if _check_cancelled(run_id):
            _cancel_pipeline(run_id)
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None
        elapsed = time.time() - pipeline_start
        if elapsed > max_duration:
            logger.error('Thorough pipeline %s exceeded max duration (%ds). Failing.', run_id, max_duration)
            _update_thorough_status(run_id, 'chunks', 'failed', {'error_type': 'pipeline_timeout', 'error_msg': f'Pipeline exceeded {max_duration}s time limit after {int(elapsed)}s', 'retryable': True})
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None
        logger.info('  Processing chunk %d/%d (%d pages)...', chunk_num, total_chunks, chunk['page_count'])
        chunks_attempted = chunk_num - 1
        _update_thorough_status(run_id, 'chunks', 'running', {'total': total_chunks, 'completed': len(chunk_summaries), 'current': chunk_num, 'failed': chunks_attempted - len(chunk_summaries)})
        context_header = _build_chunk_context(chunk_num, total_chunks, chunk_contexts)
        chunk_result = _run_chunk_pipeline(chunk, chunk_num, total_chunks, context_header, config, run_id, feedback_context, modes_cfg)
        if chunk_result:
            chunk_summaries.append(chunk_result)
            chunk_contexts.append(_extract_chunk_context(chunk_result, chunk_num))
            logger.info('  Chunk %d/%d: PASSED', chunk_num, total_chunks)
            _save_checkpoint(run_id, '_thorough_progress', {'completed_chunks': len(chunk_summaries), 'chunk_summaries': chunk_summaries, 'chunk_contexts': chunk_contexts, 'total_chunks': total_chunks})
        else:
            logger.warning('  Chunk %d/%d: FAILED (continuing with remaining chunks)', chunk_num, total_chunks)
    _update_thorough_status(run_id, 'chunks', 'completed', {'total': len(chunks), 'completed': len(chunk_summaries), 'failed': len(chunks) - len(chunk_summaries)})
    if not chunk_summaries:
        logger.error('All chunks failed — aborting pipeline')
        _update_thorough_status(run_id, 'merge', 'failed', 'No chunk summaries to merge')
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    try:
        _check_shutting_down()
    except ShutdownException:
        logger.warning('Thorough pipeline %s: server shutting down before merge — saving checkpoint', run_id)
        _save_checkpoint(run_id, '_thorough_progress', {'completed_chunks': len(chunk_summaries), 'chunk_summaries': chunk_summaries, 'chunk_contexts': chunk_contexts, 'total_chunks': len(chunks), 'ready_for_merge': True})
        _update_thorough_status(run_id, 'merge', 'interrupted', 'Server shutdown — will auto-resume on restart')
        return None
    if _check_cancelled(run_id):
        _cancel_pipeline(run_id)
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    logger.info('Phase 3: Merging %d chunk summaries...', len(chunk_summaries))
    _update_thorough_status(run_id, 'merge', 'running')
    merged_summary = _merge_chunk_summaries(chunk_summaries, config, run_id, case_ref, modes_cfg)
    if not merged_summary:
        logger.error('Merge failed')
        _update_thorough_status(run_id, 'merge', 'failed', 'Merge stage failed')
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    _update_thorough_status(run_id, 'merge', 'completed')
    logger.info('Phase 3: Merge PASSED')
    if _check_cancelled(run_id):
        _cancel_pipeline(run_id)
        for pp in processing_paths:
            _move_to_failed(pp, run_id)
        return None
    logger.info('Phase 4: Audit...')
    update_pipeline_status(run_id, 'auditor', 'running')
    combined_hashes = [file_sha256(fp) for fp in file_paths]
    combined_hash = hashlib.sha256('|'.join(combined_hashes).encode()).hexdigest()
    audit_input = {'pipeline_run_id': run_id, 'source_file_hash': combined_hash, 'stages_completed': ['preprocessing', 'ingestion', 'privacy', 'summarizer', 'merge'], 'mode': 'thorough', 'total_pages': preprocess_result.total_pages, 'unique_pages': preprocess_result.unique_pages, 'chunks_processed': len(chunk_summaries), 'phi_summary': merged_summary.get('privacy', {}).get('phi_summary', {}), 'verification': merged_summary.get('summary', {}).get('verification', merged_summary.get('verification', {}))}
    audit_task = f'Create a HIPAA compliance audit entry for this THOROUGH pipeline run. This was a large case ({preprocess_result.total_pages} pages, {len(chunks)} chunks). Reference files ONLY by SHA-256 hash. Include NO PHI. Output ONLY valid JSON matching the schema.'
    audit_prompt = audit_task + '\n\n' + build_stage_prompt('auditor', audit_input, AUDIT_SCHEMA_EXAMPLE)
    raw_audit = dispatch_agent('auditor', audit_prompt, audit_input, config)
    audit_output = None
    if raw_audit:
        try:
            audit_output = extract_json_from_response(raw_audit)
            validation_errors = validate_audit_output(audit_output)
            critical = [e for e in validation_errors or [] if 'CRITICAL' in e]
            if critical:
                logger.warning('Audit validation critical errors: %s', critical)
        except ValueError as e:
            logger.warning('Audit JSON parse failed: %s', e)
    update_pipeline_status(run_id, 'auditor', 'completed')
    thorough_page_maps = {}
    for fp in file_paths:
        _, file_page_map = _read_file_content(fp)
        if file_page_map:
            thorough_page_maps[fp.name] = file_page_map
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f'{run_id}_summary.json'
    summary_data = {'run_id': run_id, 'mode': 'thorough', 'source_file': f'CASE: {case_ref or run_id} ({len(file_paths)} files, {preprocess_result.total_pages} pages)', 'source_files': [fp.name for fp in file_paths], 'case_ref': case_ref, 'source_file_hash': combined_hash, 'processed_at': datetime.now(timezone.utc).isoformat(), 'preprocessing': {'total_pages': preprocess_result.total_pages, 'unique_pages': preprocess_result.unique_pages, 'duplicate_pages': preprocess_result.duplicate_pages, 'blank_pages': preprocess_result.blank_pages, 'handwritten_pages': preprocess_result.handwritten_pages, 'chunks_processed': len(chunk_summaries), 'chunks_total': len(chunks), 'dedup_stats': preprocess_result.dedup_stats}, 'ingestion': merged_summary.get('ingestion'), 'privacy': merged_summary.get('privacy'), 'summary': merged_summary, 'audit': audit_output}
    if thorough_page_maps:
        summary_data['source_pages'] = thorough_page_maps
    _atomic_json_write(summary_file, summary_data, encrypt=True)
    logger.info('Thorough summary saved (ENCRYPTED): %s', summary_file)
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f'{run_id}_audit.json'
    _atomic_json_write(audit_file, audit_output or {}, encrypt=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for i, fp in enumerate(file_paths):
        processed_path = PROCESSED_DIR / f'{run_id}_{fp.name}'
        pp = processing_paths[i]
        if pp.exists():
            shutil.move(str(pp), str(processed_path))
        _cleanup_incoming_source(fp)
        _update_document_status(fp, status='completed', vault_zone='processed', current_path=str(processed_path), summary_file=f'{run_id}_summary.json', processed_at=datetime.now(timezone.utc).isoformat())
    _register_summary_document(summary_file, run_id, file_paths[0])
    _update_thorough_status(run_id, 'pipeline', 'completed')
    _record_pipeline_stats(run_id)
    logger.info('Thorough pipeline %s complete: %d pages → %d chunks → merged summary', run_id, preprocess_result.total_pages, len(chunk_summaries))
    return summary_data

def _update_thorough_status(run_id, phase, status, details=None):
    PIPELINE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
    status_file = PIPELINE_STATUS_DIR / f'{run_id}.json'
    data = _safe_load_json(status_file)
    if not data:
        data = {'run_id': run_id, 'mode': 'thorough', 'started_at': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'stages': {}}
    if phase == 'chunks' and isinstance(details, dict) and (phase in data) and isinstance(data[phase].get('details'), dict):
        merged = dict(data[phase]['details'])
        merged.update(details)
        data[phase] = {'status': status, 'timestamp': datetime.now(timezone.utc).isoformat(), 'details': merged}
    else:
        data[phase] = {'status': status, 'timestamp': datetime.now(timezone.utc).isoformat(), 'details': details}
    if status == 'failed' and phase != 'chunks':
        data['status'] = 'failed'
    elif phase == 'pipeline' and status == 'completed':
        data['status'] = 'completed'
        data['completed_at'] = datetime.now(timezone.utc).isoformat()
    _atomic_json_write(status_file, data)

def _build_chunk_context(chunk_num, total_chunks, previous_contexts):
    if chunk_num == 1:
        return f'You are processing CHUNK 1 of {total_chunks}. This is the first chunk.'
    all_dates = []
    all_diagnoses = []
    summaries = []
    for ctx in previous_contexts:
        all_dates.extend(ctx.get('dates', []))
        all_diagnoses.extend(ctx.get('diagnoses', []))
        if ctx.get('summary'):
            summaries.append(ctx['summary'])
    header = f'You are processing CHUNK {chunk_num} of {total_chunks}.\n\n'
    header += 'PRIOR CHUNKS CONTEXT (do NOT repeat this information, focus on NEW data in this chunk):\n'
    if all_dates:
        header += f"- Encounter dates seen so far: {', '.join(sorted(set(all_dates))[:20])}\n"
    if all_diagnoses:
        header += f"- Diagnoses seen so far: {', '.join(sorted(set(all_diagnoses))[:15])}\n"
    if summaries:
        combined = ' | '.join(summaries[-3:])
        if len(combined) > 500:
            combined = combined[:500] + '...'
        header += f'- Recent chunk summaries: {combined}\n'
    return header

def _extract_chunk_context(chunk_result, chunk_num):
    context = {'chunk': chunk_num, 'dates': [], 'diagnoses': [], 'summary': ''}
    summary = chunk_result.get('summary', {})
    if isinstance(summary, dict):
        s = summary.get('summary', {})
        if isinstance(s, dict):
            for event in s.get('master_chronology', s.get('chronological_events', [])):
                if isinstance(event, dict) and 'date' in event:
                    context['dates'].append(str(event['date']))
            for diag in s.get('active_diagnoses', []):
                if isinstance(diag, dict):
                    d = diag.get('diagnosis', diag.get('text', ''))
                    if d:
                        context['diagnoses'].append(str(d))
            cc = s.get('chief_complaint', {})
            if isinstance(cc, dict):
                context['summary'] = str(cc.get('text', ''))[:200]
    return context

def _run_chunk_pipeline(chunk, chunk_num, total_chunks, context_header, config, run_id, feedback_context, modes_cfg):
    chunk_start = time.time()
    chunk_timeout = modes_cfg.get('timeout_per_chunk', 600)
    chunk_text = chunk['text']
    source_files = chunk['source_files']
    content_only = re.sub('\\[Source:.*?\\]\\n?', '', chunk_text).strip()
    if len(content_only) < 100:
        logger.warning('  Chunk %d has insufficient content (%d chars after removing headers) — skipping', chunk_num, len(content_only))
        return None
    logger.info('  Chunk %d/%d: dispatching (%d content chars, %d total chars)', chunk_num, total_chunks, len(content_only), len(chunk_text))
    _update_thorough_status(run_id, 'chunks', 'running', {'current': chunk_num, 'total': total_chunks, 'stage': 'ingestion'})
    ingestion_input = {'source_file': f"Chunk {chunk_num}/{total_chunks} ({', '.join(source_files)})", 'file_hash_sha256': hashlib.sha256(chunk_text.encode()).hexdigest(), 'raw_content': chunk_text[:200000], 'file_size_bytes': len(chunk_text), 'chunk_info': {'chunk_number': chunk_num, 'total_chunks': total_chunks, 'page_count': chunk['page_count']}}
    ingestion_task = f'{context_header}\n\nParse this CHUNK of medical documents into structured JSON. This is chunk {chunk_num} of {total_chunks} from a large case. Extract all sections, classify by type. Output ONLY valid JSON matching the schema.'
    ingestion_prompt = ingestion_task + '\n\n' + build_stage_prompt('ingestion', ingestion_input, INGESTION_SCHEMA_EXAMPLE)
    ingestion_stage = {'name': 'ingestion', 'agent': 'ingestion', 'validator': validate_ingestion_output, 'schema_example': INGESTION_SCHEMA_EXAMPLE}
    chunk_max_tokens = modes_cfg.get('chunk_max_tokens')
    ingestion_output, error_info = _dispatch_with_retry(ingestion_stage, ingestion_prompt, ingestion_input, config, model_override=_resolve_stage_model('ingestion', config), run_id=run_id, max_tokens_override=chunk_max_tokens)
    if ingestion_output is None:
        error_msg = error_info.get('error_msg', 'Unknown') if error_info else 'Unknown'
        logger.error('  Chunk %d ingestion FAILED: %s', chunk_num, error_msg)
        return None
    if isinstance(ingestion_output, dict):
        sections = ingestion_output.get('sections', [])
        total_content = sum((len(s.get('content', '')) for s in sections if isinstance(s, dict)))
        doc_id = ingestion_output.get('document_id', '')
        if total_content < 100 or 'no_content' in str(doc_id).lower():
            logger.warning('  Chunk %d ingestion returned empty/error content (%d chars, doc_id=%s) — skipping', chunk_num, total_content, doc_id)
            return None
    if time.time() - chunk_start > chunk_timeout:
        logger.error('  Chunk %d/%d exceeded per-chunk timeout (%ds) after ingestion', chunk_num, total_chunks, chunk_timeout)
        return None
    _update_thorough_status(run_id, 'chunks', 'running', {'current': chunk_num, 'total': total_chunks, 'stage': 'privacy'})
    privacy_task = f'De-identify this medical record chunk ({chunk_num}/{total_chunks}). Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens. Output ONLY valid JSON matching the schema.'
    privacy_prompt = privacy_task + '\n\n' + build_stage_prompt('privacy', ingestion_output, PRIVACY_SCHEMA_EXAMPLE)
    privacy_stage = {'name': 'privacy', 'agent': 'privacy', 'validator': validate_privacy_output, 'schema_example': PRIVACY_SCHEMA_EXAMPLE}
    privacy_output, error_info = _dispatch_with_retry(privacy_stage, privacy_prompt, ingestion_output, config, model_override=_resolve_stage_model('privacy', config), run_id=run_id, max_tokens_override=chunk_max_tokens)
    if privacy_output is None:
        error_msg = error_info.get('error_msg', 'Unknown') if error_info else 'Unknown'
        logger.error('  Chunk %d privacy FAILED: %s', chunk_num, error_msg)
        return None
    if time.time() - chunk_start > chunk_timeout:
        logger.error('  Chunk %d/%d exceeded per-chunk timeout (%ds) after privacy', chunk_num, total_chunks, chunk_timeout)
        return None
    _update_thorough_status(run_id, 'chunks', 'running', {'current': chunk_num, 'total': total_chunks, 'stage': 'summarizer'})
    summarizer_task = f"{context_header}\n\nProduce a litigation-ready clinical summary of this de-identified chunk ({chunk_num}/{total_chunks}). Summarize THIS CHUNK ONLY. Do NOT repeat information from prior chunks listed in the context header. Focus on NEW encounters, findings, medications, and diagnoses in this chunk. Every claim must cite its source section. Include confidence scores. Additionally, extract ANY billing and cost information found in this chunk into a 'billing_data' object. For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. If no billing data is found in this chunk, output billing_data with an empty providers array and totals of 0. Also generate an 'alerts' array flagging any treatment gaps, missing providers, pre-existing conditions, inconsistencies, compliance issues, prior injuries, or medication changes found in THIS chunk. Each alert needs: type, severity (high|medium|low), title, description, impact_estimate, recommended_action, citation, and date_range (or null). Output ONLY valid JSON matching the schema."
    summarizer_prompt = summarizer_task + '\n\n' + build_stage_prompt('summarizer', privacy_output, SUMMARY_SCHEMA_EXAMPLE)
    if feedback_context:
        summarizer_prompt += '\n\n' + feedback_context
    summarizer_stage = {'name': 'summarizer', 'agent': 'summarizer', 'validator': validate_summary_output, 'schema_example': SUMMARY_SCHEMA_EXAMPLE}
    summary_output, error_info = _dispatch_with_retry(summarizer_stage, summarizer_prompt, privacy_output, config, model_override=_resolve_stage_model('summarizer', config), max_tokens_override=chunk_max_tokens, run_id=run_id)
    if summary_output is None:
        error_msg = error_info.get('error_msg', 'Unknown') if error_info else 'Unknown'
        logger.error('  Chunk %d summarizer FAILED: %s', chunk_num, error_msg)
        return None
    return {'chunk_id': chunk['chunk_id'], 'chunk_num': chunk_num, 'ingestion': ingestion_output, 'privacy': privacy_output, 'summary': summary_output}
_MERGE_ESSENTIAL_FIELDS = {'master_chronology', 'active_diagnoses', 'medications', 'key_findings', 'smoking_gun_quotes', 'contradictions_flagged', 'timeline_gaps', 'discovery_deficiencies', 'overall_confidence', 'chief_complaint', 'alerts', 'billing_data'}
_MERGE_NARRATIVE_FIELDS = {'executive_strategy', 'bluf', 'litigation_cheat_sheet', 'trial_strategy_note', 'case_type', 'pi_core_analysis', 'verification'}

def _compact_summary_for_merge(summary_json, level=0):
    if level == 0:
        return summary_json
    if not isinstance(summary_json, dict):
        return summary_json
    compacted = {}
    for key in _MERGE_NARRATIVE_FIELDS:
        if key in summary_json:
            compacted[key] = summary_json[key]
    for key in _MERGE_ESSENTIAL_FIELDS:
        if key in summary_json:
            compacted[key] = summary_json[key]
    if 'summary' in summary_json and isinstance(summary_json['summary'], dict):
        inner = summary_json['summary']
        compacted['summary'] = {k: inner[k] for k in _MERGE_ESSENTIAL_FIELDS | _MERGE_NARRATIVE_FIELDS if k in inner}
    return compacted

def _build_merge_prompt(batch, batch_label, case_ref, run_id, merge_level=0):
    chunk_summary_texts = []
    for item in batch:
        summ = item.get('summary', {})
        compacted = _compact_summary_for_merge(summ, level=merge_level)
        chunk_summary_texts.append(json.dumps(compacted, indent=2))
    merge_input = '\n\n---\n\n'.join((f"### CHUNK {item['chunk_num']} SUMMARY\n{text}" for item, text in zip(batch, chunk_summary_texts)))
    merge_task = f'You are merging {len(batch)} summaries ({batch_label}) from a large medical case ({case_ref or run_id}) into ONE unified summary.\n\nINSTRUCTIONS:\n1. Combine all master_chronology entries into one unified timeline, sorted by date, deduplicated\n2. Consolidate active_diagnoses — remove duplicates, keep highest confidence\n3. Consolidate medications — remove duplicates, note dosage changes over time\n4. Merge key_findings — deduplicate, keep all unique findings\n5. Merge smoking_gun_quotes — keep all unique quotes\n6. Merge contradictions_flagged — include cross-chunk contradictions\n7. Merge timeline_gaps — include gaps between chunks\n8. Merge discovery_deficiencies — deduplicate\n9. Merge alerts — combine all chunk alerts, deduplicate, and add any NEW cross-chunk alerts (e.g., treatment gaps spanning chunks, cross-chunk inconsistencies). Keep 3-10 total alerts.\n10. Write a unified executive_strategy, bluf, litigation_cheat_sheet, and trial_strategy_note\n11. Update verification stats for the merged summary\n\nCONSTRAINTS:\n- Use ONLY data from the chunk summaries below. Do NOT invent or hallucinate.\n- Preserve all citations in their original format\n- When deduplicating, keep the entry with highest confidence\n\nOutput ONLY valid JSON matching the schema.\n\n## CHUNK SUMMARIES TO MERGE\n\n{merge_input}'
    return merge_task + '\n\n' + build_stage_prompt('summarizer', {'merge_mode': True, 'chunks_count': len(batch)}, SUMMARY_SCHEMA_EXAMPLE)

def _merge_batch(batch, batch_label, config, run_id, case_ref, modes_cfg, merge_level=0):
    merge_prompt = _build_merge_prompt(batch, batch_label, case_ref, run_id, merge_level)
    merge_stage = {'name': 'merge', 'agent': 'summarizer', 'validator': validate_summary_output, 'schema_example': SUMMARY_SCHEMA_EXAMPLE}
    merged_output, error_info = _dispatch_with_retry(merge_stage, merge_prompt, {'merge': True}, config, combined=True, model_override=_resolve_combined_model('merge', config), run_id=run_id, backend_override='claude')
    if merged_output is None:
        error_msg = error_info.get('error_msg', 'Unknown') if error_info else 'Unknown'
        logger.error('Merge %s FAILED: %s', batch_label, error_msg)
        return None
    return merged_output

def _merge_chunk_summaries(chunk_summaries, config, run_id, case_ref, modes_cfg):
    MERGE_BATCH_SIZE = modes_cfg.get('merge_batch_size', 5)
    MAX_MERGE_LEVELS = modes_cfg.get('merge_max_levels', 4)
    all_ingestion_sections = []
    all_privacy_sections = []
    total_phi = {'total_identifiers_found': 0, 'total_redacted': 0, 'by_type': {}, 'redaction_complete': True}
    for cs in chunk_summaries:
        chunk_num = cs['chunk_num']
        ing = cs.get('ingestion', {})
        if isinstance(ing.get('sections'), list):
            for sec in ing['sections']:
                sec['_chunk'] = chunk_num
                all_ingestion_sections.append(sec)
        priv = cs.get('privacy', {})
        if isinstance(priv.get('sections'), list):
            for sec in priv['sections']:
                sec['_chunk'] = chunk_num
                all_privacy_sections.append(sec)
        phi = priv.get('phi_summary', {})
        total_phi['total_identifiers_found'] += phi.get('total_identifiers_found', 0)
        total_phi['total_redacted'] += phi.get('total_redacted', 0)
        for ptype, count in phi.get('by_type', {}).items():
            total_phi['by_type'][ptype] = total_phi['by_type'].get(ptype, 0) + count
    items_to_merge = [{'chunk_num': cs['chunk_num'], 'summary': cs.get('summary', {})} for cs in chunk_summaries]
    merge_level = 0
    while len(items_to_merge) > 1:
        if merge_level >= MAX_MERGE_LEVELS:
            logger.error('Hierarchical merge exceeded %d levels — aborting', MAX_MERGE_LEVELS)
            return None
        n_items = len(items_to_merge)
        n_batches = (n_items + MERGE_BATCH_SIZE - 1) // MERGE_BATCH_SIZE
        logger.info('Merge level %d: %d items -> %d batches of up to %d', merge_level, n_items, n_batches, MERGE_BATCH_SIZE)
        _update_thorough_status(run_id, 'merge', 'running', {'level': merge_level, 'items': n_items, 'batches': n_batches})
        next_level_items = []
        for batch_idx in range(n_batches):
            if _check_cancelled(run_id):
                return None
            start = batch_idx * MERGE_BATCH_SIZE
            end = min(start + MERGE_BATCH_SIZE, n_items)
            batch = items_to_merge[start:end]
            if len(batch) == 1:
                next_level_items.append(batch[0])
                continue
            batch_label = f'level {merge_level}, batch {batch_idx + 1}/{n_batches}'
            logger.info('  Merging %s (%d items)...', batch_label, len(batch))
            merged = _merge_batch(batch, batch_label, config, run_id, case_ref, modes_cfg, merge_level)
            if merged is None and len(batch) > 2:
                logger.warning('  Batch %s failed — splitting into sub-batches...', batch_label)
                half = len(batch) // 2
                sub_a = batch[:half]
                sub_b = batch[half:]
                merged_a = _merge_batch(sub_a, f'{batch_label} sub-A', config, run_id, case_ref, modes_cfg, merge_level)
                merged_b = _merge_batch(sub_b, f'{batch_label} sub-B', config, run_id, case_ref, modes_cfg, merge_level)
                if merged_a is not None:
                    next_level_items.append({'chunk_num': sub_a[0]['chunk_num'], 'summary': merged_a})
                else:
                    logger.error('  Sub-batch A of %s also failed — data from chunks %s lost', batch_label, [i['chunk_num'] for i in sub_a])
                if merged_b is not None:
                    next_level_items.append({'chunk_num': sub_b[0]['chunk_num'], 'summary': merged_b})
                else:
                    logger.error('  Sub-batch B of %s also failed — data from chunks %s lost', batch_label, [i['chunk_num'] for i in sub_b])
            elif merged is not None:
                next_level_items.append({'chunk_num': batch[0]['chunk_num'], 'summary': merged})
            else:
                logger.error('  Batch %s failed with only %d items — skipping', batch_label, len(batch))
        if not next_level_items:
            logger.error('All merge batches at level %d failed', merge_level)
            return None
        items_to_merge = next_level_items
        merge_level += 1
    final_summary = items_to_merge[0]['summary']
    logger.info('Hierarchical merge complete: %d levels, final summary ready', merge_level)
    return {'ingestion': {'sections': all_ingestion_sections, 'document_type': 'multi_chunk_case', 'total_chunks': len(chunk_summaries)}, 'privacy': {'sections': all_privacy_sections, 'phi_summary': total_phi}, 'summary': final_summary}

def _move_to_failed(processing_path, run_id):
    failed_dir = PROCESSING_DIR / 'failed'
    failed_dir.mkdir(parents=True, exist_ok=True)
    dest = failed_dir / processing_path.name
    if processing_path.exists():
        shutil.move(str(processing_path), str(dest))
    _update_document_status(processing_path, status='failed', vault_zone='failed', current_path=str(dest))
    if run_id:
        try:
            from db import transaction as db_transaction
            now = datetime.now(timezone.utc).isoformat()
            with db_transaction() as conn:
                conn.execute("UPDATE documents SET status = 'failed', vault_zone = 'failed', updated_at = ? WHERE run_id = ? AND status = 'processing'", (now, run_id))
        except Exception as e:
            logger.debug('Failed to update documents by run_id %s: %s', run_id, e)

def run_pipeline_combined(file_paths, config, run_id=None, case_ref=None, dry_run=False):
    with prevent_sleep():
        return _run_pipeline_combined_inner(file_paths, config, run_id, case_ref, dry_run)

def _run_pipeline_combined_inner(file_paths, config, run_id=None, case_ref=None, dry_run=False):
    if not file_paths:
        return None
    file_paths = [Path(p) for p in file_paths]
    if not run_id:
        run_id = f"case_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}_{uuid.uuid4().hex[:8]}" if hasattr(uuid, 'uuid4') else f"case_{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"
    logger.info('Combined pipeline %s starting for %d files (case_ref=%s)', run_id, len(file_paths), case_ref)
    for fp in file_paths:
        _update_document_status(fp, status='processing', vault_zone='processing', run_id=run_id)
    ledger = load_ledger()
    for fp in file_paths:
        if str(fp) not in ledger:
            ledger[str(fp)] = {'run_id': run_id, 'status': 'processing', 'started_at': datetime.now(timezone.utc).isoformat(), 'case_ref': case_ref}
    save_ledger(ledger)
    PROCESSING_DIR.mkdir(parents=True, exist_ok=True)
    processing_paths = []
    for fp in file_paths:
        dest = PROCESSING_DIR / f'{run_id}_{fp.name}'
        if not dry_run:
            shutil.copy2(fp, dest)
        processing_paths.append(dest)
    _save_checkpoint(run_id, '_source_paths', [str(p) for p in file_paths])
    combined_parts = []
    combined_hashes = []
    combined_page_maps = {}
    total_size = 0
    for fp in file_paths:
        file_hash = file_sha256(fp)
        combined_hashes.append(file_hash)
        total_size += fp.stat().st_size
        content, file_page_map = _read_file_content(fp)
        if file_page_map:
            combined_page_maps[fp.name] = file_page_map
        combined_parts.append(f'===== FILE: {fp.name} =====\n{content}')
    combined_content = '\n\n'.join(combined_parts)
    combined_hash = hashlib.sha256('|'.join(combined_hashes).encode()).hexdigest()
    if len(file_paths) > 3:
        logger.info('Combined pipeline has %d files (>3) — routing to thorough pipeline for reliability', len(file_paths))
        return run_pipeline_thorough(file_paths, config, run_id=run_id, case_ref=case_ref, mode='thorough')
    fast_cfg = config.get('processing_modes', {}).get('fast', {})
    combined_limit = fast_cfg.get('combined_content_limit', 80000)
    if len(combined_content) > combined_limit:
        logger.info('Combined content (%d chars) exceeds limit (%d) — escalating to thorough pipeline', len(combined_content), combined_limit)
        return run_pipeline_thorough(file_paths, config, run_id=run_id, case_ref=case_ref, mode='thorough')
    pipeline_input = {'source_file': f'CASE: {case_ref or run_id} ({len(file_paths)} files)', 'file_hash_sha256': combined_hash, 'raw_content': combined_content[:combined_limit], 'file_size_bytes': total_size, 'file_count': len(file_paths), 'case_ref': case_ref, 'source_files': [fp.name for fp in file_paths]}
    _update_pipeline_metadata(run_id, {'mode': 'combined', 'input_chars': len(combined_content), 'file_size_bytes': total_size, 'file_count': len(file_paths)})
    pipeline_start = time.time()
    max_duration = config.get('pipeline', {}).get('max_duration_fast', 1800)
    _clear_cancel_flag(run_id)
    checkpoints = _load_checkpoint(run_id)
    if checkpoints:
        logger.info('  Resuming from checkpoint with %d completed stages', len(checkpoints))
    stage_outputs = {}
    current_input = pipeline_input
    feedback_context = _load_rlhf_feedback()
    combined_tasks = {'ingestion': 'Parse these medical documents into structured JSON. This is a MULTI-FILE CASE containing {n} files from the same patient case. Extract all sections from ALL files, classify each section by type, and tag each section with the source filename. Output ONLY valid JSON matching the schema.'.format(n=len(file_paths)), 'privacy': 'De-identify these medical records. This is a MULTI-FILE CASE with {n} source files. Find and redact ALL 18 HIPAA identifiers using [REDACTED_*] tokens across ALL sections. Count every redaction. Output ONLY valid JSON matching the schema.'.format(n=len(file_paths)), 'summarizer': "Produce a unified clinical summary for this patient case combining {n} medical records. This is the PRIMARY USE CASE: a litigation support team has uploaded multiple records (e.g., ER reports, imaging, PT notes, discharge summaries, lab results) for ONE patient. You MUST cross-reference findings across all files to build a complete picture. Every claim must cite its source section. Include confidence scores. Detect contradictions BETWEEN files and timeline gaps. The master_chronology must weave events from ALL files into one unified timeline. Additionally, extract ALL billing and cost information found across all records into a 'billing_data' object. For each provider, list dates of service, service descriptions, CPT codes if available, and dollar amounts. Calculate subtotals per provider, total past medical costs, and any future medical cost estimates with the basis for those estimates. If no billing data is found, output billing_data with an empty providers array and totals of 0. \n\nALERTS & GAP DETECTION (REQUIRED):\nYou MUST also generate an 'alerts' array at the top level of your JSON output. These alerts serve as proactive intelligence for the attorney — flagging risks, gaps, and strategic vulnerabilities that could impact case value BEFORE opposing counsel finds them. Generate between 3 and 10 alerts per case. Each alert must be one of these types: treatment_gap, missing_provider, pre_existing, inconsistency, compliance_issue, prior_injury, medication_change. Each alert object MUST have: type, severity (high|medium|low), title, description, impact_estimate, recommended_action, citation, and date_range (or null). Prioritize HIGH severity alerts for issues that directly threaten case value. Think like opposing counsel: what weaknesses would THEY exploit? Output ONLY valid JSON matching the schema.".format(n=len(file_paths)), 'auditor': 'Create a HIPAA compliance audit entry for this multi-file pipeline run covering {n} source files. Reference files ONLY by SHA-256 hash. Include NO PHI. Determine compliance status. Output ONLY valid JSON matching the schema.'.format(n=len(file_paths))}
    for stage in PIPELINE_STAGES:
        stage_name = stage['name']
        try:
            _check_shutting_down()
        except ShutdownException:
            logger.warning('Combined pipeline %s: server shutting down before stage %s — saving checkpoint', run_id, stage_name)
            _save_checkpoint(run_id, '_shutdown', {'interrupted_at': stage_name})
            update_pipeline_status(run_id, stage_name, 'interrupted', 'Server shutdown — will auto-resume on restart')
            return None
        if _check_cancelled(run_id):
            _cancel_pipeline(run_id)
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None
        elapsed = time.time() - pipeline_start
        if elapsed > max_duration:
            logger.error('Combined pipeline %s exceeded max duration (%ds). Failing.', run_id, max_duration)
            update_pipeline_status(run_id, stage_name, 'failed', {'error_type': 'pipeline_timeout', 'error_msg': f'Pipeline exceeded {max_duration}s time limit after {int(elapsed)}s', 'retryable': True})
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None
        if stage_name in checkpoints:
            logger.info('  Stage %s: RESTORED from checkpoint', stage_name)
            stage_outputs[stage_name] = checkpoints[stage_name]
            current_input = checkpoints[stage_name]
            update_pipeline_status(run_id, stage_name, 'completed', 'restored from checkpoint')
            continue
        logger.info('  Stage: %s', stage_name)
        if dry_run:
            logger.info('  [DRY RUN] Would dispatch to %s', stage['agent'])
            update_pipeline_status(run_id, stage_name, 'skipped', 'dry run')
            continue
        update_pipeline_status(run_id, stage_name, 'running', case_ref=case_ref, source_file=f'{len(file_paths)} files')
        stage_task = combined_tasks.get(stage_name, stage['task'])
        task_with_schema = stage_task + '\n\n' + build_stage_prompt(stage_name, current_input, stage['schema_example'])
        if stage_name == 'summarizer' and feedback_context:
            task_with_schema += '\n\n' + feedback_context
        parsed_output, error_info = _dispatch_with_retry(stage, task_with_schema, current_input, config, combined=True, model_override=_resolve_combined_model(stage_name, config), run_id=run_id, backend_override='claude')
        if parsed_output is None:
            error_msg = error_info.get('error_msg', 'Unknown error') if error_info else 'Unknown error'
            error_type = error_info.get('error_type', 'unknown') if error_info else 'unknown'
            retryable = error_info.get('retryable', True) if error_info else True
            logger.error('  Stage %s FAILED: [%s] %s', stage_name, error_type, error_msg)
            is_timeout_like = error_type in ('no_output', 'api_timeout', 'pipeline_timeout')
            if is_timeout_like and len(file_paths) >= 1:
                logger.warning('Combined pipeline timed out on stage %s — escalating to thorough (chunked) mode', stage_name)
                update_pipeline_status(run_id, stage_name, 'failed', {'error_type': error_type, 'error_msg': f'{error_msg} — escalating to chunked mode', 'retryable': True})
                for pp in processing_paths:
                    try:
                        if pp.exists():
                            pp.unlink()
                    except OSError:
                        pass
                _clear_checkpoint(run_id)
                thorough_run_id = run_id + '_chunked'
                return run_pipeline_thorough(file_paths, config, run_id=thorough_run_id, case_ref=case_ref, mode='thorough')
            update_pipeline_status(run_id, stage_name, 'failed', {'error_type': error_type, 'error_msg': error_msg, 'retryable': retryable})
            for pp in processing_paths:
                _move_to_failed(pp, run_id)
            return None
        update_pipeline_status(run_id, stage_name, 'running', details={'sub_stage': 'saving'})
        stage_outputs[stage_name] = parsed_output
        current_input = parsed_output
        if stage_name == 'privacy' and parsed_output:
            try:
                from vector_store import VectorStore
                vs = VectorStore(config)
                vs.index_document(run_id, parsed_output.get('sections', []))
            except Exception as e:
                logger.warning('  Vector indexing failed for %s: %s', run_id, e)
        _save_checkpoint(run_id, stage_name, parsed_output)
        update_pipeline_status(run_id, stage_name, 'completed')
        logger.info('  Stage %s: PASSED', stage_name)
    if dry_run:
        return None
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_file = SUMMARIES_DIR / f'{run_id}_summary.json'
    summary_data = {'run_id': run_id, 'source_file': f'CASE: {case_ref or run_id} ({len(file_paths)} files)', 'source_files': [fp.name for fp in file_paths], 'case_ref': case_ref, 'source_file_hash': combined_hash, 'processed_at': datetime.now(timezone.utc).isoformat(), 'ingestion': stage_outputs.get('ingestion'), 'privacy': stage_outputs.get('privacy'), 'summary': stage_outputs.get('summarizer'), 'audit': stage_outputs.get('auditor')}
    if combined_page_maps:
        summary_data['source_pages'] = combined_page_maps
    _atomic_json_write(summary_file, summary_data, encrypt=True)
    logger.info('Combined summary saved: %s', summary_file)
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    audit_file = AUDIT_DIR / f'{run_id}_audit.json'
    _atomic_json_write(audit_file, stage_outputs.get('auditor', {}))
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for i, fp in enumerate(file_paths):
        processed_path = PROCESSED_DIR / f'{run_id}_{fp.name}'
        pp = processing_paths[i]
        if pp.exists():
            shutil.move(str(pp), str(processed_path))
        _cleanup_incoming_source(fp)
        _update_document_status(fp, status='completed', vault_zone='processed', current_path=str(processed_path), summary_file=f'{run_id}_summary.json', processed_at=datetime.now(timezone.utc).isoformat())
    _register_summary_document(summary_file, run_id, file_paths[0])
    _clear_checkpoint(run_id)
    _record_pipeline_stats(run_id)
    return summary_data

def _load_rlhf_feedback():
    try:
        from db import get_db
        conn = get_db()
        try:
            rows = conn.execute("SELECT sf.run_id, sf.rating, sf.feedback_text\n                   FROM summary_feedback sf\n                   WHERE sf.feedback_text IS NOT NULL AND sf.feedback_text != ''\n                   ORDER BY sf.created_at DESC LIMIT 10").fetchall()
            stats = conn.execute('SELECT rating, COUNT(*) as cnt FROM summary_feedback GROUP BY rating').fetchall()
        finally:
            conn.close()
        if not rows and (not stats):
            return ''
        stat_map = {r['rating']: r['cnt'] for r in stats}
        total = sum(stat_map.values())
        parts = ['## QUALITY FEEDBACK FROM HUMAN REVIEWERS']
        parts.append(f"Total reviews: {total} (Poor: {stat_map.get('poor', 0)}, Good: {stat_map.get('good', 0)}, Excellent: {stat_map.get('excellent', 0)})")
        if stat_map.get('poor', 0) > 0:
            parts.append('\nCommon issues from POOR ratings (AVOID these):')
            for r in rows:
                if r['rating'] == 'poor' and r['feedback_text']:
                    parts.append(f"  - {r['feedback_text'][:200]}")
        if stat_map.get('excellent', 0) > 0:
            parts.append('\nQualities from EXCELLENT ratings (DO more of this):')
            for r in rows:
                if r['rating'] == 'excellent' and r['feedback_text']:
                    parts.append(f"  - {r['feedback_text'][:200]}")
        parts.append('\nUse this feedback to improve your summary quality.')
        return '\n'.join(parts)
    except Exception as e:
        logger.warning('Could not load RLHF feedback: %s', e)
        return ''

def scan_incoming(config):
    supported = set(config.get('summarization', {}).get('supported_extensions', ['.pdf']))
    ledger = load_ledger()
    files = []
    if not INCOMING_DIR.exists():
        return files
    for path in INCOMING_DIR.rglob('*'):
        if not path.is_file():
            continue
        if path.suffix.lower() not in supported:
            continue
        if str(path) in ledger:
            continue
        files.append(path)
    return sorted(files, key=lambda p: p.stat().st_mtime)

def _get_case_ref_for_file(file_path):
    try:
        from db import get_db
        conn = get_db()
        try:
            row = conn.execute('SELECT case_ref FROM documents WHERE (original_path = ? OR current_path = ?) AND case_ref IS NOT NULL', (str(file_path), str(file_path))).fetchone()
            return row['case_ref'] if row else None
        finally:
            conn.close()
    except Exception:
        return None

def _reap_stale_pipelines(config):
    if not PIPELINE_STATUS_DIR.exists():
        return
    max_fast = config.get('pipeline', {}).get('max_duration_fast', 3600)
    max_thorough = config.get('pipeline', {}).get('max_duration_thorough', 10800)
    now = datetime.now(timezone.utc)
    for status_file in PIPELINE_STATUS_DIR.glob('*.json'):
        data = _safe_load_json(status_file)
        if not data or data.get('status') != 'running':
            continue
        started = data.get('started_at')
        if not started:
            continue
        try:
            start_dt = datetime.fromisoformat(started)
            if start_dt.tzinfo is None:
                start_dt = start_dt.replace(tzinfo=timezone.utc)
            elapsed = (now - start_dt).total_seconds()
        except (ValueError, TypeError):
            continue
        mode = data.get('mode', 'fast')
        max_dur = max_thorough if mode == 'thorough' else max_fast
        if elapsed > max_dur * 1.5:
            logger.warning('Reaping stale pipeline %s (mode=%s, elapsed=%.0fs, max=%ds)', data.get('run_id', status_file.stem), mode, elapsed, max_dur)
            data['status'] = 'failed'
            data['error_type'] = 'stale_timeout'
            data['error_message'] = f'Pipeline exceeded max duration ({elapsed:.0f}s > {max_dur}s)'
            data['failed_at'] = now.isoformat()
            data['retryable'] = True
            _atomic_json_write(status_file, data)

def _has_active_pipeline(case_ref):
    if not case_ref or not PIPELINE_STATUS_DIR.exists():
        return False
    for status_file in PIPELINE_STATUS_DIR.glob('*.json'):
        try:
            data = _safe_load_json(status_file)
            if data and data.get('status') == 'running' and (data.get('case_ref') == case_ref):
                logger.info("Skipping case '%s' — active pipeline %s already running", case_ref, data.get('run_id', status_file.stem))
                return True
        except Exception:
            continue
    return False

def run_scan(config, dry_run=False):
    _reap_stale_pipelines(config)
    files = scan_incoming(config)
    if not files:
        logger.info('No new files to process.')
        return
    logger.info('Found %d new file(s) to process.', len(files))
    ledger = load_ledger()
    case_groups = {}
    solo_files = []
    for file_path in files:
        case_ref = _get_case_ref_for_file(file_path)
        if case_ref:
            case_groups.setdefault(case_ref, []).append(file_path)
        else:
            solo_files.append(file_path)
    for case_ref, group_files in case_groups.items():
        if _has_active_pipeline(case_ref):
            continue
        logger.info("Processing case '%s' with %d file(s)...", case_ref, len(group_files))
        try:
            if len(group_files) == 1:
                result = run_pipeline(group_files[0], config, dry_run=dry_run)
            else:
                result = run_pipeline_combined(group_files, config, case_ref=case_ref, dry_run=dry_run)
            if result:
                for fp in group_files:
                    ledger[str(fp)] = {'run_id': result['run_id'], 'processed_at': result['processed_at'], 'summary_file': f"{result['run_id']}_summary.json", 'case_ref': case_ref}
                save_ledger(ledger)
                logger.info("Case '%s' processed: %s", case_ref, result['run_id'])
            elif dry_run:
                logger.info("[DRY RUN] Would process case '%s'", case_ref)
            else:
                logger.error("Pipeline failed for case '%s'", case_ref)
                for fp in group_files:
                    ledger[str(fp)] = {'status': 'failed', 'failed_at': datetime.now(timezone.utc).isoformat(), 'case_ref': case_ref}
                save_ledger(ledger)
        except Exception as e:
            logger.error("Error processing case '%s': %s", case_ref, e)
    for file_path in solo_files:
        try:
            result = run_pipeline(file_path, config, dry_run=dry_run)
            if result:
                ledger[str(file_path)] = {'run_id': result['run_id'], 'processed_at': result['processed_at'], 'summary_file': f"{result['run_id']}_summary.json"}
                save_ledger(ledger)
                logger.info('Processed: %s → %s', file_path.name, result['run_id'])
            elif dry_run:
                logger.info('[DRY RUN] Would process: %s', file_path.name)
            else:
                logger.error('Pipeline failed for: %s', file_path.name)
                ledger[str(file_path)] = {'status': 'failed', 'failed_at': datetime.now(timezone.utc).isoformat()}
                save_ledger(ledger)
        except Exception as e:
            logger.error('Error processing %s: %s', file_path.name, e)

def run_loop(config, dry_run=False):
    interval = config.get('summarization', {}).get('scan_interval_seconds', 1800)
    logger.info('Summarization watcher started. Scan interval: %ds', interval)
    while True:
        try:
            run_scan(config, dry_run=dry_run)
        except Exception as e:
            logger.error('Scan error: %s', e)
        time.sleep(interval)

def main():
    parser = argparse.ArgumentParser(description='Summarization Watcher Daemon')
    parser.add_argument('--once', action='store_true', help='Single scan and exit')
    parser.add_argument('--dry-run', action='store_true', help='Report without processing')
    args = parser.parse_args()
    config = load_config()
    for d in [INCOMING_DIR, PROCESSING_DIR, PROCESSED_DIR, SUMMARIES_DIR, AUDIT_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    if args.once:
        run_scan(config, dry_run=args.dry_run)
    else:
        run_loop(config, dry_run=args.dry_run)
if __name__ == '__main__':
    main()